---
name: crear-instrumentos-aula-infantil-cv
description: Crea instrumentos de observación (listas de control, escalas de observación, registros anecdóticos) para situaciones de aprendizaje de Educación Infantil ya diseñadas, sin generar calificaciones acreditativas.
---

# Crear instrumentos de observación de aula (Infantil)

## Procedimiento
1. Recupera los criterios de evaluación orientadores del alcance (por área) y lo que se espera observar en cada uno, según la programación vigente (ver la skill disenar-evaluacion-infantil-cv).
2. Elige el tipo de instrumento de observación (lista de control, escala de observación con niveles descriptivos, registro anecdótico, diario de aula) según lo que el criterio permite observar. Redacta indicadores observables y descriptivos, en lenguaje no técnico ni etiquetador, evitando comparaciones entre niños.
3. Especifica cuándo y cómo se usa el instrumento (durante la actividad, al cierre, en varios momentos del proyecto) y quién lo cumplimenta.
4. Comprueba con ejemplos de observación contrastados (ficticios y señalados como tales) que el instrumento permite describir el progreso individual sin necesidad de una nota o calificación.

## Límites
No generes una calificación, nota o "resultado" acreditativo de ningún niño o niña. No redactes indicadores que suenen a diagnóstico clínico o etiqueta: describe conducta observable, no interpretaciones. Si el encargo implica cambiar el enfoque general de evaluación del nivel, redirige a la skill disenar-evaluacion-infantil-cv en vez de resolverlo aquí.
