---
name: auditar-aula-fp-cv
description: Audita secuencias, materiales e instrumentos de aula de FP ya creados frente al CE que deben cubrir y a los criterios DUA de accesibilidad.
---

# Auditar aula de FP

Auditoría interna de aula: distinta de auditar la programación didáctica del módulo completo (para eso usa la skill auditar-programacion-fp-cv).

## Procedimiento
1. Fija el alcance y las versiones de los productos a revisar (secuencia, materiales, instrumentos); identifica la programación didáctica de referencia.
2. Revisa cada CE del alcance: literal, desempeño exigido, evidencia esperada, instrumento asociado y reglas de calificación. Señala CE sin evidencia individual, instrumentos que no miden lo que dicen medir, o exigencias de autonomía incoherentes con los apoyos ofrecidos.
3. Comprueba que los materiales están completos (con soluciones, no solo enunciados), que los tiempos son realistas para las sesiones disponibles, que los recursos citados existen o están identificados como pendientes, y que el diseño aplica el DUA de forma coherente (opciones reales de acceso/expresión, no solo declaradas).
4. Entrega los hallazgos con estado (cumple / parcial / no cumple / no verificable), evidencia (archivo y sección), impacto, acción propuesta y responsable. No certifiques la eficacia real en el aula: eso solo se comprueba usándolo con alumnado.

## Límites
No inventes una puntuación oficial de calidad del material. No modifiques los originales salvo que el docente pida corrección explícita.
