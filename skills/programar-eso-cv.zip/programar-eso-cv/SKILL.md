---
name: programar-eso-cv
description: Coordina la elaboración de una programación didáctica de materia/ámbito de ESO en la Comunitat Valenciana, desde el currículo hasta la evaluación, la secuenciación de situaciones de aprendizaje y el cierre, conforme al Decreto 107/2022 y la Orden 19/2023.
---

# Programar una materia de ESO en la Comunitat Valenciana

## Marco normativo de referencia
- Real Decreto 217/2022 (currículo básico estatal LOMLOE de ESO) y Real Decreto 984/2021 (evaluación, promoción y titulación, marco estatal).
- Decreto 107/2022, de 5 de agosto, del Consell, por el que se establece la ordenación y el currículo de la ESO en la Comunitat Valenciana (modificado por el Decreto 66/2024).
- Orden 19/2023, de 29 de junio, de la Conselleria de Educación, Cultura y Deporte, que regula los procedimientos derivados de los Decretos 107/2022 (ESO) y 108/2022 (Bachillerato) — evaluación, programaciones y procedimientos de centro. También afectada por el Decreto 66/2024.
- Instrucciones de inicio de curso vigentes cada año (para 2026-2027, Resolución de 15 de julio de 2026, DOGV 17.07.2026).

No uses la Resolución de 20 de abril de 2022 como base de evaluación: fue la concreción transitoria del Real Decreto 984/2021 mientras se implantaba la LOMLOE y ha quedado desplazada por el Decreto 107/2022 y la Orden 19/2023, que son lo que citan las instrucciones de inicio de curso actuales.
- Proyecto Educativo de Centro (PEC) y concreción curricular del centro: la programación de materia debe ajustarse a lo fijado por el centro (Comisión de Coordinación Pedagógica), sin duplicarlo.

Este marco está verificado a septiembre de 2026 (curso 2026-2027). Las reglas de promoción y titulación han estado sujetas a cambios en distintos cursos; verifica siempre la instrucción de inicio de curso vigente antes de aplicar un límite concreto de materias suspendidas.

## Entradas
Pide al docente: etapa/curso, materia o ámbito, currículo oficial (competencias específicas, criterios de evaluación, saberes básicos del curso), concreción curricular o programación anterior del centro si existe, perfil de grupo, y acuerdos de departamento sobre evaluación. Empieza con lo disponible; marca como pendiente lo que falte y no inventes acuerdos de departamento que no se hayan confirmado.

## Procedimiento
1. **Currículo.** Localiza competencias específicas, criterios de evaluación (con su código, p. ej. CE.X.Y) y saberes básicos literales del Decreto 107/2022 para el curso y materia.
2. **Evaluación.** Aplica la skill disenar-evaluacion-eso-cv para fijar instrumentos, calificación y criterios de calificación por criterio de evaluación.
3. **Situaciones de aprendizaje.** Organiza el curso en situaciones de aprendizaje secuenciadas, relacionando cada una con las competencias específicas y criterios de evaluación que trabaja; distribuye la carga horaria del curso entre ellas.
4. **Redacción.** Integra los apartados habituales de una programación de materia: contextualización y marco normativo; competencias específicas y su contribución al perfil de salida; criterios de evaluación y saberes básicos por curso; secuenciación de situaciones de aprendizaje; metodología; recursos y materiales; medidas de atención a la diversidad; procedimientos e instrumentos de evaluación, criterios de calificación y recuperación; actividades complementarias; procedimiento de evaluación de la propia programación y de la práctica docente.
5. **Revisión.** Aplica la skill auditar-programacion-eso-cv sobre el borrador. Corrige lo detectado y deja explícitos los pendientes que dependan de acuerdos de departamento o del centro.
6. Entrega la programación diferenciando lo confirmado, lo propuesto y lo pendiente; no presentes una propuesta propia como acuerdo institucional ya tomado.

## Límites
No inventes acuerdos de departamento, calendario de evaluaciones ni normativa. Cuando falte un dato de centro, declara pendiente en vez de rellenarlo con un valor plausible.
