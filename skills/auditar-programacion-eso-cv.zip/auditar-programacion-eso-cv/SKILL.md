---
name: auditar-programacion-eso-cv
description: Audita una programación didáctica de materia de ESO ya redactada frente al Decreto 107/2022, la Orden 19/2023 y los acuerdos de centro, señalando huecos y contradicciones sin inventar una nota oficial.
---

# Auditar una programación de ESO

Esta skill es de solo lectura salvo que el docente pida explícitamente que corrijas el documento.

## Lista de comprobación
Verifica que la programación contiene, con contenido real y no solo el título del epígrafe:
1. Contextualización y marco normativo (Decreto 107/2022, Orden 19/2023 y modificaciones vigentes).
2. Competencias específicas de la materia y su contribución a las competencias clave/perfil de salida.
3. Criterios de evaluación y saberes básicos literales del curso, con su código si el currículo lo asigna.
4. Secuenciación de situaciones de aprendizaje con su distribución horaria y su relación con competencias específicas/criterios de evaluación.
5. Metodología didáctica.
6. Recursos y materiales.
7. Medidas de atención a la diversidad.
8. Procedimientos e instrumentos de evaluación, criterios de calificación y recuperación, coherentes con la normativa de evaluación vigente (ver la skill disenar-evaluacion-eso-cv).
9. Actividades complementarias y extraescolares, si las hay.
10. Procedimiento de evaluación de la programación y de la práctica docente.

## Procedimiento
1. Fija alcance y versión del documento auditado; identifica qué fuentes faltan (currículo, acuerdos de departamento, concreción curricular del centro) para verificar cada punto.
2. Para cada apartado, evalúa como cumple / parcial / no cumple / no verificable, citando ubicación exacta y evidencia.
3. Revisa especialmente: que los criterios de evaluación citados sean literales del decreto de currículo, que cada criterio tenga al menos un instrumento asociado, que las reglas de recuperación y promoción no contradigan la normativa vigente, y que la programación no choque con la concreción curricular o el PEC del centro.
4. Entrega los hallazgos en una tabla: apartado, estado, evidencia, diagnóstico, acción propuesta, responsable. No emitas una calificación global oficial de la programación.
5. Si el docente pide corrección, aplícala solo sobre lo detectado.

## Límites
No certifiques conformidad institucional ni sustituyas la aprobación del departamento o la dirección del centro. No inventes una versión del decreto o la orden si no la tienes disponible: pide el documento o marca el punto como no verificable.
