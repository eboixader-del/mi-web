---
name: crear-instrumentos-aula-eso-cv
description: Crea instrumentos de evaluación (rúbricas, listas de cotejo, escalas, pruebas) para actividades de ESO ya diseñadas, por criterio de evaluación, sin alterar la calificación de origen de la materia.
---

# Crear instrumentos de evaluación de aula (ESO)

## Procedimiento
1. Recupera los criterios de evaluación literales del alcance, la evidencia que deben acreditar y las reglas de calificación vigentes de la materia (ver la skill disenar-evaluacion-eso-cv). Si faltan reglas de departamento, propón el instrumento sin inventar una calificación final oficial.
2. Elige el tipo de instrumento (rúbrica, lista de cotejo, escala, prueba, registro de observación) según lo que el criterio de evaluación exige demostrar. Redacta indicadores observables derivados del criterio, distinguiéndolos del literal oficial; especifica descriptores por nivel de logro, instrucciones de uso y pauta de corrección.
3. Comprueba con respuestas de ejemplo contrastadas (un desempeño alto y uno bajo, ficticios y señalados como tales) que el instrumento distingue niveles de desempeño reales.
4. Evita puntuar rasgos personales, actitudes generales o conductas ajenas al criterio de evaluación.

## Límites
No generes una nota real de ningún alumno. Si el encargo implica cambiar la arquitectura general de evaluación de la materia (ponderaciones, número de instrumentos por competencia específica), redirige a la skill disenar-evaluacion-eso-cv en vez de resolverlo aquí.
