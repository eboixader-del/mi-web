---
name: crear-instrumentos-aula-primaria-cv
description: Crea instrumentos de evaluación (rúbricas, listas de cotejo, escalas, registros de observación) para actividades de Educación Primaria ya diseñadas, por criterio de evaluación, sin alterar la calificación de origen del área.
---

# Crear instrumentos de evaluación de aula (Primaria)

## Procedimiento
1. Recupera los criterios de evaluación literales del alcance, la evidencia que deben acreditar y las reglas de calificación vigentes del área (ver la skill disenar-evaluacion-primaria-cv). Si faltan reglas de ciclo, propón el instrumento sin inventar una calificación final oficial.
2. Elige el tipo de instrumento (rúbrica, lista de cotejo, escala, registro de observación, prueba breve) según lo que el criterio de evaluación exige demostrar y la edad del curso. Redacta indicadores observables derivados del criterio, distinguiéndolos del literal oficial; especifica descriptores por nivel de logro, instrucciones de uso y pauta de corrección.
3. Comprueba con respuestas de ejemplo contrastadas (un desempeño alto y uno bajo, ficticios y señalados como tales) que el instrumento distingue niveles de desempeño reales.
4. Evita puntuar rasgos personales, actitudes generales o conductas ajenas al criterio de evaluación.

## Límites
No generes una nota real de ningún alumno. Si el encargo implica cambiar la arquitectura general de evaluación del área (ponderaciones, número de instrumentos por competencia específica), redirige a la skill disenar-evaluacion-primaria-cv en vez de resolverlo aquí.
