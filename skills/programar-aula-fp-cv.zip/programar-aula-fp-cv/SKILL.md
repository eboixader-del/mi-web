---
name: programar-aula-fp-cv
description: Coordina la programación de aula de un módulo de FP (un resultado de aprendizaje, una unidad o una secuencia completa) a partir de una programación didáctica existente, con diseño accesible según el DUA.
---

# Programar aula de un módulo de FP

Usa esta skill cuando el encargo sea "prográmame el aula de este RA/módulo" de principio a fin; para una pieza aislada (solo materiales, solo instrumentos, solo revisión), ve directamente a la skill correspondiente.

## Procedimiento
1. Recupera la programación didáctica vigente del módulo (RA, CE, ponderaciones, unidades) — si no está disponible, pide al docente el mínimo imprescindible (RA/CE del alcance y evidencia esperada) y continúa con lo demás como propuesta pendiente de confirmar.
2. Para diseñar una secuencia nueva, aplica la skill disenar-secuencias-aula-fp-cv.
3. Según el encargo, aplica crear-materiales-aula-fp-cv y/o crear-instrumentos-aula-fp-cv.
4. Integra los productos y aplica auditar-aula-fp-cv; corrige lo detectado dentro del alcance del encargo.
5. Entrega la secuencia, los materiales, los instrumentos y las comprobaciones realizadas, dejando explícitos los pendientes.

## Nota sobre accesibilidad
Todo el diseño de aula sigue el DUA (Diseño Universal para el Aprendizaje): un único itinerario con múltiples formas de acceso, implicación, procesamiento y expresión, en vez de recorridos paralelos distintos por nivel de alumnado. No propongas rutas de aprendizaje separadas por nivel; propón apoyos y opciones dentro de la misma actividad.
