---
name: auditar-programacion-infantil-cv
description: Audita una programación didáctica de Educación Infantil ya redactada frente al Decreto 100/2022 y los acuerdos de centro, señalando huecos y contradicciones sin convertir la evaluación en una calificación acreditativa.
---

# Auditar una programación de Educación Infantil

Esta skill es de solo lectura salvo que el docente pida explícitamente que corrijas el documento.

## Lista de comprobación
Verifica que la programación contiene, con contenido real y no solo el título del epígrafe:
1. Contextualización y marco normativo (Decreto 100/2022 y normativa vigente).
2. Contribución de las tres áreas (Crecimiento en Armonía; Descubrimiento y Exploración del Entorno; Comunicación y Representación de la Realidad) al desarrollo integral del alumnado.
3. Criterios de evaluación orientadores por área y nivel.
4. Secuenciación de situaciones de aprendizaje globalizadas, con relación clara a las tres áreas.
5. Metodología: organización de espacios, tiempos, rutinas y agrupamientos.
6. Recursos y materiales.
7. Medidas de atención a la diversidad y protocolo de detección temprana.
8. Procedimientos de observación, instrumentos y comunicación a las familias, coherentes con la naturaleza no acreditativa de la evaluación en esta etapa (ver la skill disenar-evaluacion-infantil-cv).
9. Actividades complementarias, si las hay.
10. Procedimiento de evaluación de la programación y de la práctica docente.

## Procedimiento
1. Fija alcance y versión del documento auditado; identifica qué fuentes faltan (currículo, acuerdos de ciclo, concreción curricular del centro) para verificar cada punto.
2. Para cada apartado, evalúa como cumple / parcial / no cumple / no verificable, citando ubicación exacta y evidencia.
3. Revisa especialmente: que no aparezca ninguna calificación numérica o de tipo aprobado/suspenso, que los criterios de evaluación citados sean literales del decreto de currículo, que cada área tenga instrumentos de observación asociados, y que la programación no choque con la concreción curricular o el PEC del centro.
4. Entrega los hallazgos en una tabla: apartado, estado, evidencia, diagnóstico, acción propuesta, responsable.
5. Si el docente pide corrección, aplícala solo sobre lo detectado.

## Límites
No certifiques conformidad institucional ni sustituyas la aprobación del ciclo o la dirección del centro. No inventes una versión del decreto si no la tienes disponible: pide el documento o marca el punto como no verificable.
