# -*- coding: utf-8 -*-
"""
Genera las dos plantillas oficiales de la UDI en formato .docx a partir de un
único fichero JSON con los datos acordados con el docente:

    PLANTILLA 2 · CONCRECIÓN CURRICULAR
    PLANTILLA 3 · TRANSPOSICIÓN DIDÁCTICA Y PLANIFICACIÓN DEL DESARROLLO

Uso:
    python generar_udi.py datos_udi.json [carpeta_salida]

El esquema completo del JSON está documentado en
`references/esquema-datos-udi.md` y hay un ejemplo real en `ejemplos/`.

Requisitos: pip install python-docx
"""
import json
import re
import sys
import unicodedata
from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

RAIZ = Path(__file__).resolve().parent.parent
LOGO = RAIZ / "assets" / "logo-udi.png"

AZUL = RGBColor(0x1F, 0x38, 0x64)
AMARILLO = "FFE599"
AZUL_CLARO = "C5D3ED"
VERDE = "C5E0B3"
GRIS = "F2F2F2"
# Colores de los bloques de competencia específica en la Plantilla 2
PALETA = ["CDE4BE", "FFB7FF", "CCCCCC", "FFFF93", "D9B3FF", "BDFFDE", "FFD7AF", "D8FF8B"]


# --------------------------------------------------------------------------
# utilidades de formato
# --------------------------------------------------------------------------
def sombrea(celda, color_hex):
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), color_hex)
    celda._tc.get_or_add_tcPr().append(shd)


def bordes(tabla, color="7F7F7F", tam="4"):
    tblPr = tabla._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for lado in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement("w:" + lado)
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), tam)
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), color)
        borders.append(el)
    tblPr.append(borders)


def ancho(celda, cm):
    celda.width = Cm(cm)
    tcW = celda._tc.get_or_add_tcPr().find(qn("w:tcW"))
    if tcW is None:
        tcW = OxmlElement("w:tcW")
        celda._tc.get_or_add_tcPr().append(tcW)
    tcW.set(qn("w:w"), str(int(cm * 567)))
    tcW.set(qn("w:type"), "dxa")


def escribe(celda, texto, negrita=False, centrado=False, tam=9, color=None):
    celda.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    p = celda.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER if centrado else WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.space_before = Pt(2)
    lineas = texto.split("\n") if isinstance(texto, str) else [str(texto)]
    for i, linea in enumerate(lineas):
        if i:
            p = celda.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if centrado else WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.space_after = Pt(2)
        r = p.add_run(linea)
        r.font.size = Pt(tam)
        r.font.name = "Calibri"
        r.bold = negrita
        if color:
            r.font.color.rgb = color


def celda(tabla, fila, col, texto="", relleno=None, negrita=False, centrado=False, tam=9, cm=None):
    c = tabla.cell(fila, col)
    escribe(c, texto, negrita=negrita, centrado=centrado, tam=tam)
    if relleno:
        sombrea(c, relleno)
    if cm:
        ancho(c, cm)
    return c


def lista(valor):
    """Acepta str o list y devuelve un texto con saltos de línea."""
    if valor is None:
        return ""
    if isinstance(valor, (list, tuple)):
        return "\n".join("• " + str(v).strip() if not str(v).startswith("•") else str(v)
                         for v in valor)
    return str(valor)


def texto_plano(valor):
    if isinstance(valor, (list, tuple)):
        return "\n".join(str(v) for v in valor)
    return "" if valor is None else str(valor)


def documento(titulo_cabecera):
    doc = Document()
    sec = doc.sections[0]
    sec.orientation = WD_ORIENT.LANDSCAPE
    sec.page_width, sec.page_height = Cm(29.7), Cm(21)
    sec.left_margin = sec.right_margin = Cm(1.1)
    sec.top_margin = Cm(1.0)
    sec.bottom_margin = Cm(1.0)
    sec.header_distance = Cm(0.6)

    cab = sec.header.paragraphs[0]
    cab.alignment = WD_ALIGN_PARAGRAPH.LEFT
    if LOGO.exists():
        cab.add_run().add_picture(str(LOGO), width=Cm(3.6))
    r = cab.add_run("     " + titulo_cabecera)
    r.bold = True
    r.font.size = Pt(12)
    r.font.name = "Calibri"
    r.font.color.rgb = AZUL

    estilo = doc.styles["Normal"]
    estilo.font.name = "Calibri"
    estilo.font.size = Pt(9)
    return doc


def diseno_fijo(tabla, anchos):
    """Fija el ancho de las columnas para que Word no reajuste la tabla."""
    tblPr = tabla._tbl.tblPr
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    tblPr.append(layout)
    ind = OxmlElement("w:tblInd")
    ind.set(qn("w:w"), "0")
    ind.set(qn("w:type"), "dxa")
    tblPr.append(ind)
    grid = tabla._tbl.find(qn("w:tblGrid"))
    if grid is not None:
        for col, a in zip(grid.findall(qn("w:gridCol")), anchos):
            col.set(qn("w:w"), str(int(a * 567)))


def no_partir_filas(tabla):
    """Evita que una fila se parta entre dos páginas."""
    for fila in tabla.rows:
        trPr = fila._tr.get_or_add_trPr()
        cant = OxmlElement("w:cantSplit")
        trPr.append(cant)


def mantener_junto(tabla):
    """Mantiene la tabla en la misma página que la tabla siguiente."""
    for fila in tabla.rows:
        for c in fila.cells:
            for p in c.paragraphs:
                p.paragraph_format.keep_with_next = True


def tabla_nueva(doc, filas, cols, anchos=None):
    t = doc.add_table(rows=filas, cols=cols)
    t.autofit = False
    t.style = "Table Grid"
    bordes(t)
    if anchos:
        diseno_fijo(t, anchos)
        for f in t.rows:
            for c, a in zip(f.cells, anchos):
                ancho(c, a)
    no_partir_filas(t)
    return t


def parrafo_titulo(doc, texto, tam=11):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(texto)
    r.bold = True
    r.font.size = Pt(tam)
    r.font.color.rgb = AZUL
    return p


# --------------------------------------------------------------------------
# PLANTILLA 2 · CONCRECIÓN CURRICULAR
# --------------------------------------------------------------------------
def plantilla2(datos, salida):
    doc = documento("CONCRECIÓN CURRICULAR")
    udi = datos.get("udi", {})
    num = udi.get("numero", 1)

    cab = tabla_nueva(doc, 3, 3, [8.8, 11.2, 7.0])
    celda(cab, 0, 0, "ETAPA: " + datos.get("etapa", ""), AMARILLO, negrita=True)
    celda(cab, 0, 1, "CURSO: " + datos.get("curso", ""), AMARILLO, negrita=True)
    celda(cab, 0, 2, "ÁREA: " + datos.get("area", ""), AMARILLO, negrita=True)
    f = cab.rows[1].cells
    f[0].merge(f[2])
    escribe(cab.cell(1, 0), "UDI " + str(num) + ": " + udi.get("titulo", ""), negrita=True)
    sombrea(cab.cell(1, 0), AMARILLO)
    f = cab.rows[2].cells
    f[0].merge(f[2])
    escribe(cab.cell(2, 0),
            "SITUACIÓN DE APRENDIZAJE: " + udi.get("situacion_aprendizaje", ""), negrita=True)
    sombrea(cab.cell(2, 0), AMARILLO)

    for i, comp in enumerate(datos.get("competencias", [])):
        color = PALETA[i % len(PALETA)]
        criterios = comp.get("criterios", [])
        n_filas = 4 + max(1, len(criterios))
        anchos = [1.9, 4.0, 14.1, 7.0]
        t = tabla_nueva(doc, n_filas, 4, anchos)

        # fila 0: encabezados
        celda(t, 0, 0, "OGE", color, negrita=True, centrado=True, tam=9)
        celda(t, 0, 1, "PERFIL DE SALIDA", color, negrita=True, centrado=True)
        c = t.cell(0, 2).merge(t.cell(0, 3))
        escribe(c, "COMPETENCIAS ESPECÍFICAS", negrita=True, centrado=True)
        sombrea(c, color)

        # fila 1: competencia específica
        escribe(t.cell(1, 0), texto_plano(comp.get("oge", "")), centrado=True)
        escribe(t.cell(1, 1), texto_plano(comp.get("perfil_salida", "")), centrado=True)
        cod = comp.get("codigo", "")
        c = t.cell(1, 2).merge(t.cell(1, 3))
        escribe(c, (cod + ". " if cod else "") + comp.get("competencia", ""))

        # fila 2: cabecera de criterios
        celda(t, 2, 2, "CRITERIOS DE EVALUACIÓN", color, negrita=True, centrado=True)
        celda(t, 2, 3, "INSTRUMENTO", color, negrita=True, centrado=True)

        # filas de criterios
        fila = 3
        for cr in criterios or [{}]:
            codigo = cr.get("codigo", "")
            escribe(t.cell(fila, 2), (codigo + ". " if codigo else "") + cr.get("texto", ""))
            escribe(t.cell(fila, 3), texto_plano(cr.get("instrumento", "")), centrado=True)
            fila += 1

        # saberes básicos
        c = t.cell(fila, 2).merge(t.cell(fila, 3))
        escribe(c, "SABERES BÁSICOS", negrita=True, centrado=True)
        sombrea(c, color)
        fila += 1
        t.add_row()
        for cc, a in zip(t.rows[fila].cells, anchos):
            ancho(cc, a)
        c = t.cell(fila, 2).merge(t.cell(fila, 3))
        escribe(c, lista(comp.get("saberes", "")))

        # combinación vertical de las columnas OGE y PERFIL DE SALIDA
        t.cell(1, 0).merge(t.cell(fila, 0))
        t.cell(1, 1).merge(t.cell(fila, 1))

        doc.add_paragraph().paragraph_format.space_after = Pt(3)

    just = datos.get("justificacion_competencial")
    if just:
        parrafo_titulo(doc, "CONTRIBUCIÓN AL DESARROLLO COMPETENCIAL DEL ALUMNADO")
        p = doc.add_paragraph(texto_plano(just))
        p.paragraph_format.space_after = Pt(4)

    evaluacion = datos.get("ponderacion", [])
    if evaluacion:
        parrafo_titulo(doc, "PONDERACIÓN DE LOS INSTRUMENTOS DE EVALUACIÓN")
        t = tabla_nueva(doc, len(evaluacion) + 1, 4, [8.5, 8.0, 5.5, 5.0])
        for j, cab_txt in enumerate(["INSTRUMENTO", "CRITERIOS ASOCIADOS", "MOMENTO", "PESO (%)"]):
            celda(t, 0, j, cab_txt, AMARILLO, negrita=True, centrado=True)
        for j, item in enumerate(evaluacion, start=1):
            escribe(t.cell(j, 0), item.get("instrumento", ""))
            escribe(t.cell(j, 1), texto_plano(item.get("criterios", "")))
            escribe(t.cell(j, 2), item.get("momento", ""), centrado=True)
            escribe(t.cell(j, 3), str(item.get("peso", "")), centrado=True, negrita=True)

    doc.save(salida)
    return salida


# --------------------------------------------------------------------------
# PLANTILLA 3 · TRANSPOSICIÓN DIDÁCTICA
# --------------------------------------------------------------------------
def plantilla3(datos, salida):
    udi = datos.get("udi", {})
    num = udi.get("numero", 1)
    doc = documento("TRANSPOSICIÓN DIDÁCTICA Y PLANIFICACIÓN DEL DESARROLLO DE LA UDI " + str(num))

    vision = tabla_nueva(doc, 2, 1, [27.0])
    celda(vision, 0, 0, "VISIÓN GENERAL DE LA SECUENCIA DIDÁCTICA DE LA TAREA:", AMARILLO, negrita=True)
    escribe(vision.cell(1, 0), texto_plano(datos.get("vision_general", "")))
    doc.add_paragraph().paragraph_format.space_after = Pt(3)

    anchos_act = [1.2, 12.6, 4.4, 4.4, 4.4]
    anchos_ses = [3.8, 1.2, 2.6, 5.0, 3.4, 11.0]
    n_actividad = 0

    for bloque in datos.get("secuencia", []):
        if bloque.get("prueba_objetiva"):
            t = tabla_nueva(doc, 1, 1, [27.0])
            celda(t, 0, 0, bloque["prueba_objetiva"], AMARILLO, negrita=True, centrado=True)
            doc.add_paragraph().paragraph_format.space_after = Pt(3)
            continue

        n_actividad += 1
        color = AZUL_CLARO if n_actividad % 2 else VERDE

        t = tabla_nueva(doc, 2, 5, anchos_act)
        c = t.cell(0, 0).merge(t.cell(0, 1))
        escribe(c, "ACTIVIDAD DESCRITA", negrita=True, centrado=True)
        sombrea(c, color)
        celda(t, 0, 2, "MODELO DE ENSEÑANZA", color, negrita=True, centrado=True)
        celda(t, 0, 3, "METODOLOGÍA", color, negrita=True, centrado=True)
        celda(t, 0, 4, "ORGANIZACIÓN AULA", color, negrita=True, centrado=True)

        escribe(t.cell(1, 0), str(bloque.get("n", n_actividad)), centrado=True, negrita=True)
        titulo = bloque.get("titulo")
        cuerpo = texto_plano(bloque.get("actividad", ""))
        escribe(t.cell(1, 1), (titulo + "\n" if titulo else "") + cuerpo)
        if titulo:
            t.cell(1, 1).paragraphs[0].runs[0].bold = True
        escribe(t.cell(1, 2), texto_plano(bloque.get("modelo_ensenanza", "")), centrado=True)
        escribe(t.cell(1, 3), texto_plano(bloque.get("metodologia", "")), centrado=True)
        escribe(t.cell(1, 4), texto_plano(bloque.get("organizacion_aula", "")), centrado=True)

        mantener_junto(t)
        s = tabla_nueva(doc, 1, 6, anchos_ses)
        celda(s, 0, 0, "NÚMERO DE SESIONES", color, negrita=True, centrado=True)
        escribe(s.cell(0, 1), str(bloque.get("sesiones", "")), centrado=True)
        celda(s, 0, 2, "ESCENARIOS", color, negrita=True, centrado=True)
        escribe(s.cell(0, 3), texto_plano(bloque.get("escenarios", "")))
        celda(s, 0, 4, "MATERIALES", color, negrita=True, centrado=True)
        escribe(s.cell(0, 5), texto_plano(bloque.get("materiales", "")))
        doc.add_paragraph().paragraph_format.space_after = Pt(3)

    anexos = datos.get("anexos", {})

    dua = anexos.get("dua")
    if dua:
        doc.add_page_break()
        parrafo_titulo(doc, "DISEÑO UNIVERSAL PARA EL APRENDIZAJE (DUA)")
        filas = [("Múltiples formas de REPRESENTACIÓN (el qué)", dua.get("representacion")),
                 ("Múltiples formas de IMPLICACIÓN (el porqué)", dua.get("implicacion")),
                 ("Múltiples formas de ACCIÓN Y EXPRESIÓN (el cómo)", dua.get("accion_expresion"))]
        t = tabla_nueva(doc, len(filas) + 1, 2, [7.5, 19.5])
        celda(t, 0, 0, "PRINCIPIO DUA", AZUL_CLARO, negrita=True, centrado=True)
        celda(t, 0, 1, "PAUTAS Y MEDIDAS CONCRETAS EN ESTA UDI", AZUL_CLARO, negrita=True, centrado=True)
        for j, (nombre, contenido) in enumerate(filas, start=1):
            celda(t, j, 0, nombre, GRIS, negrita=True)
            escribe(t.cell(j, 1), lista(contenido))

    div = anexos.get("diversidad")
    if div:
        parrafo_titulo(doc, "ATENCIÓN A LA DIVERSIDAD")
        filas = [("Refuerzo y apoyo (medidas de nivel II-III)", div.get("refuerzo")),
                 ("Profundización y enriquecimiento (altas capacidades)", div.get("profundizacion"))]
        if div.get("otras"):
            filas.append(("Otras medidas de respuesta educativa", div.get("otras")))
        t = tabla_nueva(doc, len(filas) + 1, 2, [7.5, 19.5])
        celda(t, 0, 0, "MEDIDA", VERDE, negrita=True, centrado=True)
        celda(t, 0, 1, "CONCRECIÓN EN LA UDI", VERDE, negrita=True, centrado=True)
        for j, (nombre, contenido) in enumerate(filas, start=1):
            celda(t, j, 0, nombre, GRIS, negrita=True)
            escribe(t.cell(j, 1), lista(contenido))

    rub = anexos.get("rubrica")
    if rub:
        doc.add_page_break()
        parrafo_titulo(doc, "RÚBRICA DE EVALUACIÓN DEL PRODUCTO FINAL" +
                       (": " + rub.get("titulo") if rub.get("titulo") else ""))
        niveles = rub.get("escala", ["1 · En inicio", "2 · En desarrollo",
                                     "3 · Adquirido", "4 · Avanzado"])
        indicadores = rub.get("indicadores", [])
        cols = 2 + len(niveles)
        anchos = [6.0] + [(19.5 / len(niveles))] * len(niveles) + [1.5]
        t = tabla_nueva(doc, len(indicadores) + 1, cols, anchos)
        celda(t, 0, 0, "INDICADOR DE LOGRO", AMARILLO, negrita=True, centrado=True)
        for j, niv in enumerate(niveles, start=1):
            celda(t, 0, j, niv, AMARILLO, negrita=True, centrado=True)
        celda(t, 0, cols - 1, "PESO", AMARILLO, negrita=True, centrado=True)
        for j, ind in enumerate(indicadores, start=1):
            escribe(t.cell(j, 0), (ind.get("criterio", "") + "\n" if ind.get("criterio") else "") +
                    ind.get("indicador", ""))
            for k, desc in enumerate(ind.get("niveles", []), start=1):
                if k < cols - 1:
                    escribe(t.cell(j, k), desc, tam=8)
            escribe(t.cell(j, cols - 1), str(ind.get("peso", "")), centrado=True, negrita=True)

    ods = anexos.get("ods")
    if ods:
        parrafo_titulo(doc, "VALORES, ODS Y CIUDADANÍA")
        t = tabla_nueva(doc, len(ods) + 1, 3, [6.0, 12.0, 9.0])
        for j, cab_txt in enumerate(["ODS / META", "CONCRECIÓN EN LA UDI", "PENSAMIENTO CRÍTICO Y VALORES"]):
            celda(t, 0, j, cab_txt, VERDE, negrita=True, centrado=True)
        for j, item in enumerate(ods, start=1):
            escribe(t.cell(j, 0), item.get("meta", ""), negrita=True)
            escribe(t.cell(j, 1), texto_plano(item.get("concrecion", "")))
            escribe(t.cell(j, 2), texto_plano(item.get("valores", "")))

    doc.save(salida)
    return salida


# --------------------------------------------------------------------------
def comprueba_pesos(datos):
    avisos = []
    pesos = []
    for item in datos.get("ponderacion", []):
        m = re.search(r"(\d+(?:[.,]\d+)?)", str(item.get("peso", "")))
        if m:
            pesos.append(float(m.group(1).replace(",", ".")))
    if pesos and abs(sum(pesos) - 100) > 0.5:
        avisos.append("Los pesos de los instrumentos suman " + str(round(sum(pesos), 2)) +
                      " % (deberían sumar 100 %).")
    n_ses = 0
    for b in datos.get("secuencia", []):
        m = re.search(r"(\d+)", str(b.get("sesiones", "")))
        if m:
            n_ses += int(m.group(1))
    if n_ses:
        avisos.append("Total de sesiones planificadas: " + str(n_ses) + ".")
    return avisos


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    origen = Path(sys.argv[1])
    destino = Path(sys.argv[2]) if len(sys.argv) > 2 else origen.parent
    destino.mkdir(parents=True, exist_ok=True)
    datos = json.loads(origen.read_text(encoding="utf-8"))

    udi = datos.get("udi", {})
    area = unicodedata.normalize("NFKD", datos.get("area", "materia"))
    area = area.encode("ascii", "ignore").decode()
    base = "UDI" + str(udi.get("numero", 1)) + "_" + re.sub(r"[^A-Za-z0-9]+", "-", area).strip("-")

    p2 = plantilla2(datos, destino / (base + "_PLANTILLA-2_CONCRECION-CURRICULAR.docx"))
    p3 = plantilla3(datos, destino / (base + "_PLANTILLA-3_TRANSPOSICION-DIDACTICA.docx"))
    print("Generado: " + str(p2))
    print("Generado: " + str(p3))
    for aviso in comprueba_pesos(datos):
        print("AVISO: " + aviso)


if __name__ == "__main__":
    main()
