# MATEMÁTICAS

> Fuente: Secundaria.pdf, páginas 895-924 (versión en castellano).

MATEMÁTICAS

1. Presentación.

En la sociedad actual, la alfabetización matemática resulta una necesidad básica para el
desempeño de una ciudadanía reflexiva, crítica y participativa. Las formas propias de razonamiento
matemático permiten realizar un análisis e interpretación precisos y rigurosos de las situaciones,
procesos y resultados; son, por tanto, un instrumento esencial para desenvolverse
satisfactoriamente en contextos personales, académicos, sociales, científicos y laborales. Aún más,
como parte del currículo de la educación obligatoria, su aprendizaje es un derecho que debe
satisfacerse.

La aportación del área de matemáticas al perfil de salida debe hacerse desde una
aproximación funcional, es decir, como una forma de comprensión del mundo, lo cual requiere
enseñar y aprender matemáticas como una “manera de hacer”, potenciar el trabajo matemático a
partir de contextos reales, utilizando materiales y herramientas que doten de sentido a la actividad
matemática y faciliten el tránsito de lo concreto a lo abstracto. Esta área contribuye a la educación
obligatoria mediante la adquisición y el desarrollo de competencias específicas que refieren al
conjunto de conocimientos, habilidades y actitudes necesarias para comprender y usar las formas
de razonamiento, desarrollos, representación y expresiones propias de matemáticas en una
variedad de situaciones en las que ejercen o pueden ejercer un papel.

Las competencias específicas del área de matemáticas contribuyen, en consecuencia, a la
adquisición de las competencias clave establecidas en el perfil de salida del alumnado. El
pensamiento y lenguaje matemáticos están implicados en cualquier actividad que requiera
estructurar, sistematizar y encontrar relaciones entre distintos atributos de la realidad. Por otra parte,
el lenguaje matemático, fundamentalmente simbólico, es la forma de comunicación y expresión de
esta materia y, en ese sentido, no puede desligarse de la competencia de comunicación lingüística
y plurilingüe. La utilización de métodos, estrategias o herramientas matemáticas tiene a menudo
reflejo en otras áreas, especialmente en las científico-tecnológicas, pero también en el resto de
áreas: así, la resolución de problemas y situaciones reales favorece el desarrollo de la competencia
en conciencia y expresión culturales, la competencia emprendedora o también la competencia
digital.

Desde el punto de vista de los procesos metacognitivos y socioemocionales, las
matemáticas contribuyen de manera determinante a la adquisición de la competencia personal,
social y de aprender a aprender, tan importante para el aprendizaje a lo largo de toda la vida,
permitiendo así desarraigar prejuicios y falsas ideas preconcebidas relacionadas con el talento
innato, la dificultad intrínseca de la materia o incluso el género. En suma, la alfabetización
matemática permite desarrollar las habilidades necesarias para seguir aprendiendo a lo largo de la
vida y para abordar los retos del siglo XXI desde una perspectiva colectiva y global, inclusiva y
tolerante, facilitando que el conocimiento pueda aplicarse a situaciones nuevas y cambiantes. De
igual modo, desde la educación matemática se trabajará la igualdad de género, la educación para
la paz, la educación para el consumo responsable y el desarrollo sostenible, y la educación para la
salud. Asimismo, se prestará especial atención a la educación emocional y en valores y a la
potenciación del aprendizaje significativo para el desarrollo de la autonomía y la reflexión. Existen
vías variadas para integrar la actividad matemática en temas transversales como, por ejemplo, la
realización de proyectos significativos para el alumnado y la resolución colaborativa de problemas,
que contribuyen a reforzarle la autoestima, la autonomía, la reflexión y la responsabilidad.

El desarrollo de las competencias específicas matemáticas que conducen a la alfabetización
matemática, como parte del perfil de salida del alumnado, se fundamenta en procesos de
matematización de contextos reales y de situaciones de aprendizaje. La actuación del alumnado
requiere movilizar un conjunto de destrezas, procedimientos y conceptos matemáticos que le
permitan abordar con éxito las situaciones de aprendizaje planteadas. Más allá del mero dominio

procedimental, la resolución de problemas formará el núcleo de los aprendizajes de esta materia.
Con este aporte de funcionalidad a los saberes básicos se posibilita el desbloqueo de los
tradicionales prejuicios frente a las matemáticas como un cuerpo de saberes abstracto,
desconectado de la realidad y compuesto por reglas, algoritmos y ejercicios. En definitiva, mediante
el enfoque competencial, los criterios de evaluación y los saberes básicos se vertebran alrededor
de las competencias específicas.

En las siguientes secciones se exponen y desarrollan los elementos fundamentales del
currículo del área de matemáticas.

En la segunda sección se describen las competencias específicas del área: competencia en
resolución de problemas, competencia en razonamiento y conexiones, competencia en
modelización, competencia en pensamiento computacional, competencia en representaciones,
competencia en comunicación; competencia en relevancia social y cultural, competencia en gestión
de las emociones y actitudes. Para cada una de ellas, se proporciona una descripción que incluye
los hitos más importantes de su desarrollo en los tres ciclos de la etapa.

La tercera sección describe las principales conexiones de las competencias específicas
entre sí, con las competencias específicas de otras materias de la Educación Secundaria Obligatoria
y con las competencias clave.

En la cuarta sección se identifican los saberes básicos del área de matemáticas,
estructurados en bloques asociados a los diferentes sentidos matemáticos. Para su mejor
identificación, en este documento los saberes básicos se han distribuido entre los siguientes
sentidos matemáticos: Sentido numérico y de las operaciones, Sentido espacial y geométrico,
Sentido de la medida y la estimación, Sentido estocástico y pensamiento computacional.

En la quinta sección se presentan algunos principios presentes en las situaciones y
actividades que facilitan y promueven el aprendizaje de las matemáticas y se ofrecen criterios y
pautas para su diseño.

Por último, la sexta sección establece los criterios de evaluación para cada una de las
competencias específicas al final del tercer curso y del cuarto curso, en sus modalidades A y B, de
la Educación Secundaria Obligatoria.

2. Competencias específicas del área de matemáticas.

2.1. Competencia específica 1.

Resolver problemas relacionados con situaciones diversas del ámbito social y en la
iniciación a los ámbitos profesional y científico utilizando estrategias formales, representaciones y
conceptos que permitan la generalización y abstracción de las soluciones.

2.1.1. Descripción de la competencia.

La competencia en resolución de problemas se compone de los procesos generales de
comprensión y análisis del enunciado y la situación que plantea, diseño de un plan de resolución,
exploración e implementación de estrategias ligadas al plan y verificación del resultado. La
interpretación y validación de los resultados permite aportar nueva información al problema, de
forma que la competencia en resolución de problemas incluye formular nuevas hipótesis y plantear
nuevas situaciones problemáticas o problemas derivados que permitan adaptar o generalizar el
proceso de resolución. La competencia en resolución de problemas es central en el aprendizaje de
las matemáticas y conecta con el resto de competencias específicas; además, requiere movilizar
conceptos y procedimientos de los distintos bloques de contenido: aritmética, geometría, medida,
estadística y probabilidad, y especialmente en esta etapa, álgebra y funciones. De hecho, el lenguaje
algebraico y funcional permite formalizar y generalizar el proceso de resolución, de manera que el
alumnado sea capaz de transferir las estrategias de resolución y los resultados obtenidos de unos
problemas a otros, aunque el contexto sea distinto. La utilización de determinados programas
informáticos y aplicaciones TIC permite simular procesos de resolución y también facilita la

interpretación y validación de resultados.

Los y las estudiantes tendrían que afrontar las situaciones problemáticas como medio para
desarrollarse como ciudadanía activa y crítica de un mundo en el que el conocimiento y la
cooperación son indispensables para la resolución de problemas y conflictos. De hecho, la
resolución de problemas matemáticos requiere desarrollar competencias relacionadas con la
gestión de las emociones, el trabajo colaborativo y las estrategias de autorregulación. Los i las
estudiantes tendrían que abordar situaciones problemáticas en contextos diversos (personal, social,
educativo, profesional y científico), desde aquellos cercanos a sus experiencias hasta llegar a
situaciones generales o abstractas. Así, tendrían que resolver problemas reales y complejos en
contextos relevantes. También deberían desarrollar procesos de resolución que impliquen
establecer conexiones entre contextos matemáticos y no matemáticos, relacionando diferentes
aspectos de la situación, discriminando la información relevante de la irrelevante y realizando
conversiones entre distintas representaciones. Además, deberían ser capaces de interpretar sus
soluciones y de transferir procesos y conclusiones a otras situaciones.

El alumnado debería adquirir habilidades para resolver problemas de reflexión e
investigación en los que la información es incompleta. Debería tener la capacidad de plantear
resoluciones abiertas, comparando resoluciones con otros compañeros y compañeras, y validando
su resultado con fuentes de información. Asimismo, tendría que ser capaz de realizar
generalizaciones y plantear nuevos problemas en otras situaciones desde contextos relevantes para
la ciudadanía.

Durante esta etapa los y las estudiantes tendrían que ampliar el rango de estrategias
formales en resolución de problemas, incorporando el saber conceptual conectado, un mayor rango
de procedimientos, destrezas y herramientas TIC, y distintos registros de representación. Así, al
finalizar la etapa deberían ser capaces de movilizar una amplia gama de conceptos (numéricos,
algebraicos, geométricos, de medida, probabilísticos, estadísticos y funcionales) y procedimientos
asociados (estimar, calcular, medir, definir variables, cuantificar, encontrar relaciones) dentro de una
estrategia o proceso de resolución de una situación problemática concreta. Los y las estudiantes
serán capaces de servirse del trabajo matemático en la resolución de problemas para reflexionar
críticamente sobre situaciones relacionadas con contextos de importancia para el ciudadano del
siglo XXI, planteando nuevas preguntas y problemas relevantes.

2.2. Competencia específica 2.

Explorar, formular y generalizar conjeturas y propiedades matemáticas, haciendo
demostraciones sencillas y reconociendo y conectando los procedimientos, patrones y estructuras
abstractas implicados en el razonamiento.

2.2.1. Descripción de la competencia

Esta competencia tiene como foco los procesos de construcción de la estructura lógica de
las matemáticas, a partir de la identificación, definición y conexión de conceptos y procedimientos
matemáticos que permiten, a su vez, deducir analíticamente propiedades que enriquecen
formalmente la descripción y definición de los objetos matemáticos. Esta deducción se realizará
mediante la formulación de conjeturas sobre las propiedades y características de un concepto,
generalizando en la medida de lo posible y realizando algunas demostraciones sencillas para
construir estructuras matemáticas y comenzar a formalizar el contenido matemático. La competencia
también implica clasificar grupos de propiedades, relacionándolas y derivando unas de otras, y
estableciendo consecuencias, a partir de conjeturas, razonamientos lógicos y demostraciones
informales de tipo inductivo o deductivo que permitan asegurar o refutar su validez. El uso del
álgebra y las representaciones funcionales permite generalizar y formalizar grupos de repeticiones
(patrones) y establecer conexiones entre estructuras matemáticas (por ejemplo, entre razón de
magnitudes y semejanza geométrica, o entre áreas y resolución de ecuaciones de segundo grado).
La finalidad de esta competencia es desarrollar las bases del razonamiento matemático riguroso y

la construcción de contenido matemático conectado.

Durante esta etapa, el alumnado debería desarrollar el razonamiento matemático a partir de
contextos reales, tanto los relacionados directamente con su experiencia, del ámbito personal, como
contextos de los ámbitos social, educativo, y de iniciación al profesional y científico. Es decir,
contextos de interés para la ciudadanía, relacionados con los retos del siglo XXI. Ahora bien,
partiendo de ese primer proceso inductivo para la construcción de objetos matemáticos, el alumnado
debería lograr desarrollar otro proceso de reflexión sobre el propio objeto, en el contexto formal y
abstracto que constituye la estructura del conocimiento matemático.

El alumnado tendría que ser capaz de conectar el saber conceptual y procedimental, y
transferirlo a nuevas situaciones reales o abstractas. Debería trabajar la construcción razonada de
conceptos matemáticos conectados, integrando procesos distintos y trazando vínculos y analogías
con otros conceptos intra y extra matemáticos. El alumnado tendría que abordar situaciones de
aprendizaje que implican argumentar, formular conjeturas, demostrar propiedades o refutarlas,
diseñar algoritmos, validar resultados y generalizar —en un proceso de abstracción progresiva—
para transferirlos a otros contextos, incluyendo el formal. A través de contextos variados, el
alumnado debería construir, conectar y movilizar todos los contenidos básicos conceptuales y
procedimentales del área de matemáticas.

Al finalizar la etapa, se espera que los y las estudiantes conozcan la estructura lógica de las
matemáticas y sean capaces de construir razonadamente redes conceptuales y procedimentales,
deducir e inferir propiedades, y validar o refutar argumentos matemáticos mediante el uso de la
demostración. También se espera que hayan desarrollado de manera comprensiva una red
conceptual y procedimental que les permita definir con rigor conceptos matemáticos en todos los
bloques de conocimiento, identificar, deducir y derivar propiedades, y establecer nuevas conexiones,
en particular, relaciones entre propiedades y sus consecuencias.

Durante toda la etapa, el alumnado tendría que haber desarrollado fluidez procedimental,
desarrollando la habilidad para llevar a cabo procedimientos matemáticos de forma flexible, precisa
y eficiente, y al término de la misma debería haber comenzado a desarrollar la capacidad de
demostrar algunas propiedades matemáticas usando, de manera informal, razonamientos de tipo
inductivo, deductivo, por analogía y el uso de contraejemplos para refutar conjeturas generales.

2.3. Competencia específica 3.

Construir modelos matemáticos generales utilizando conceptos y procedimientos
matemáticos funcionales con el fin de interpretar, analizar, comparar, valorar y hacer aportaciones
al abordaje de situaciones, fenómenos y problemas relevantes en el ámbito social y en la iniciación
a los ámbitos profesional y científico.

2.3.1. Descripción de la competencia.

Esta competencia implica el abordaje de un fenómeno o situación real mediante el análisis
de sus componentes, la elaboración de un modelo matemático y el uso de herramientas
matemáticas, con el fin de analizar sus características y extraer conclusiones o hacer predicciones
apoyadas por datos y argumentos matemáticos; y también con el fin de justificar de manera crítica
y reflexiva actuaciones acordes con dichas conclusiones. Se trata, por tanto, de establecer
conexiones entre las matemáticas y otras disciplinas, usando procesos indagatorios propios de la
investigación científica (identificación, medición, clasificación, inferencia, explicación, predicción) y
de modelización. A menudo, una situación o un fenómeno real relevante plantea cuestiones que
requieren construir un modelo matemático desarrollando el ciclo de modelización: estructurar la
realidad y la información que ofrece para construirse una representación mental; asumir hipótesis
sobre aspectos desconocidos o no determinados y realizar simplificaciones que permitan elaborar
un primer modelo real; matematizar el modelo real, buscando, formalizando o cuantificando
variables y relaciones, para construir un modelo matemático; trabajar matemáticamente sobre el
modelo matemático con el fin de obtener una solución o unos resultados matemáticos; interpretar

los resultados matemáticos para transformarlos en resultados reales; y validar los resultados reales
contrastándolos con el modelo real y la situación mental de partida.

El proceso de transferencia de las matemáticas a la realidad y de la realidad a las
matemáticas mediado por un modelo implica, por un lado, la inducción de propiedades generales a
partir de características concretas de la realidad, lo que permite inferir de las propiedades generales
consecuencias reales de la situación analizada; y por otro, la particularización de contenidos
matemáticos abstractos para explicar aspectos determinados de la situación real que pueden ser
tratados de manera diferenciada por otras disciplinas, estableciendo conexiones interdisciplinares.
Esta competencia requiere emplear herramientas matemáticas que permiten esta generalización y
particularización, en concreto, el uso de representaciones algebraicas y funcionales.

El alumnado de esta etapa tendría que desarrollar esta competencia como parte de su
competencia ciudadana al enfrentarse a retos y situaciones relevantes para la sociedad del siglo
XXI. En este sentido, el alumnado trabajará sobre situaciones generales de interés para la
ciudadanía que requieran, bien validar una fuente de información, bien extraer conclusiones
basadas en argumentos rigurosos y en datos precisos. Los contextos relacionados con los retos del
siglo XXI irán desde el personal y educativo hasta, especialmente, el social y el de iniciación a los
ámbitos profesional y científico.

El alumnado aplicará procedimientos matemáticos, pudiendo emplear herramientas TIC
para analizar fenómenos reales en contextos auténticos, abordando situaciones de aprendizaje que
exijan la conexión de conceptos y procedimientos matemáticos con contenidos no matemáticos. El
alumnado se enfrentará a problemas de exploración e investigación que impliquen analizar un
fenómeno natural o social, construir un modelo matemático y extraer a partir del mismo
conclusiones, o realizar predicciones y/o tomar decisiones. Mediante el uso de herramientas TIC, el
alumnado podrá simular procesos o evitar cálculos farragosos durante la resolución.

A lo largo de la etapa, los y las estudiantes se enfrentarán a situaciones reales que
requerirán la construcción de un modelo matemático, es decir, asumir hipótesis y simplificar la
realidad, buscar regularidades, patrones, relaciones entre los distintos elementos y fenómenos de
la situación, que permitan transformarla en un modelo matemático sobre el que se puede trabajar
matemáticamente para obtener una respuesta que debe ser validada en la situación real.

El alumnado tendría que ser capaz de justificar acciones y conclusiones sobre una situación
o un fenómeno real haciendo referencia a conceptos y procedimientos matemáticos, estableciendo
conexiones interdisciplinares, es decir, concretando contenidos matemáticos generales (conceptos,
propiedades) útiles para explicar aspectos de la realidad que aparecen trabajados desde otras
perspectivas en distintas disciplinas. El alumnado debería poder usar las matemáticas de una
manera reflexiva y crítica, como medio para demostrar o refutar una afirmación en una situación
real.

2.4. Competencia específica 4.

Implementar algoritmos computacionales organizando datos, descomponiendo un problema
en partes, reconociendo patrones y empleando lenguajes de programación y otras herramientas TIC
como soporte para resolver problemas y afrontar desafíos del ámbito social y de iniciación a los
ámbitos profesional y científico.

2.4.1. Descripción de la competencia

La competencia que tiene como foco el pensamiento computacional implica que el alumnado
de esta etapa resuelva problemas y situaciones de los ámbitos social y de iniciación a los ámbitos
profesional y científico implementando un algoritmo o secuencia finita de instrucciones y reglas
precisas y concisas. Esta solución puede ser ejecutada por un humano, un robot o un sistema
informático en varios niveles de programación. En esta etapa se profundizará en la programación
por bloques (scratch, app inventor, code.org, etc.). El diseño y la implementación de un algoritmo

implica habilidades como la descomposición de un problema en tareas más simples; la identificación
de los aspectos relevantes de una situación para simplificarla y estructurarla, eliminando cualquier
ambigüedad o imprecisión; la ordenación, clasificación y organización de un conjunto de datos; o la
identificación de patrones y estructuras abstractas en el desarrollo de una solución.

El alumnado abordará situaciones en los ámbitos social, profesional y científico que
requieran un uso versátil de recursos tecnológicos para resolver retos vinculados al siglo XXI,
aplicando conocimientos y destrezas matemáticas. En particular, el alumnado trabajará en
problemas de reproducción de algoritmos, programando por bloques con distintas herramientas
tecnológicas (robots, programas informáticos, etc.). También trabajará en problemas cuya
resolución requiera el diseño de algoritmos y un análisis justificado de sus limitaciones y eficiencia,
trabajando en equipo y adoptando distintos roles (programador, revisor, ejecutor, etc.).

Durante esta etapa, el alumnado se enfrentará a situaciones en las que debería diseñar un
algoritmo que pudiera ser implementado mediante programación por bloques y que pudiera ser
ejecutado dentro de una plataforma informática o por un robot. En estas situaciones la solución
computacional contribuirá a profundizar en el conocimiento matemático o en el conocimiento de la
situación real planteada.

Al finalizar la ESO, el alumnado tendría que haber desarrollado habilidades en la
programación por bloques y el uso de herramientas TIC que ayudaran a diseñar, implementar y
ejecutar sus programas, y que le permitieran aplicar el pensamiento computacional para resolver
problemas de conexión y reflexión que impliquen organizar conjuntos de datos, reconocer patrones,
descomponer en partes o simplificar, estructurar y abstraer situaciones.

2.5. Competencia específica 5.

Manejar con precisión el simbolismo matemático haciendo transformaciones y conversiones
entre representaciones icónico-manipulativas, numéricas, simbólico-algebraicas, tabulares,
funcionales, geométricas y gráficas que permitan pensar matemáticamente sobre situaciones del
ámbito social y de iniciación a los ámbitos profesional y científico.

2.5.1. Descripción de la competencia.

Esta competencia implica dominar las reglas y el uso, tratamiento y conversión de los
registros de representación (icónico-manipulativo, numérico, simbólico-algebraico, tabular,
funcional, geométrico y gráfico) que vehiculan la expresión de contenido matemático. Por tanto, se
compone de una serie de habilidades que son condición necesaria para la producción correcta de
mensajes en lenguaje matemático. La expresión de contenido matemático exige capacidad de
precisión, claridad y concisión en el uso de sus elementos en cada registro de representación, y
también la habilidad de usar la representación de contenido matemático más adecuada a las
situaciones reales o formales a las que se refiere. El uso preciso del simbolismo matemático es
condición necesaria para el diseño de algoritmos computacionales, que podrían considerarse como
un tipo de registro de representación propio de las matemáticas.

La capacidad de tratamiento del contenido matemático en cada registro de representación,
es decir, de transformar de manera correcta el contenido matemático en un mismo registro, es
indispensable si se quiere expresar en el mismo una secuencia compleja de procedimientos
matemáticos. Además, la representación de mensajes matemáticos ricos y complejos demanda la
capacidad de conversión bidireccional entre registros; es decir, además de saber representar y tratar
contenido matemático en todos los registros, es necesario poder establecer las equivalencias y
manejar las vías de paso, en ambos sentidos, entre cada registro y los demás.

El alumnado debería usar con corrección y fluidez los distintos registros de representación
que vehiculan el conocimiento matemático útil para enfrentarse a los retos del siglo XXI. El alumnado
debería desarrollar la producción de simbolismo matemático a partir de situaciones reales y
relevantes, pero también de situaciones puramente matemáticas, utilizando todas las

representaciones y haciendo conversiones entre ellas en la medida de lo posible. También debería
ser capaz de combinar representaciones matemáticas con otros medios de expresión
argumentativa.

El alumnado tendría que ser capaz de traducir y realizar conversiones bidireccionales entre
las distintas representaciones con la que se le presenta la información en una situación de
aprendizaje, incluyendo los registros simbólico-algebraico y funcional.

Durante la etapa, el alumnado debería consolidar la capacidad de producir mensajes
matemáticos que respeten las reglas sintácticas del lenguaje matemático. Debería usar con
corrección los registros del lenguaje natural, icónico-manipulativo, numérico, simbólico-algebraico,
gráfico-funcional, tabular y geométrico; y debería tener la capacidad de emplearlos en situaciones
reales de interés general para la ciudadanía y en situaciones formales de las matemáticas.

Al finalizar la etapa, el alumnado tendría que saber representar un concepto o relación
matemática de distintas formas y valorar la más adecuada en cada situación. Debería saber emplear
las conversiones entre distintos registros de representación de manera bidireccional, usándolos
como estrategia de trabajo para enriquecer y ganar en comprensión de los conceptos matemáticos.

2.6. Competencia específica 6.

Producir, comunicar e interpretar mensajes orales y escritos complejos de manera formal,
empleando el lenguaje matemático, para comunicar e intercambiar ideas generales y argumentos
sobre características, conceptos, procedimientos y resultados relacionados con situaciones del
ámbito social y de iniciación a los ámbitos profesional y científico.

2.6.1. Descripción de la competencia.

La competencia en producir, comunicar e interpretar mensajes de contenido matemático
implica la capacidad de aplicar el razonamiento matemático y el uso de registros de representación
a la producción de mensajes matemáticos complejos que tengan sentido, es decir, que sean
comprensibles para los demás. Del mismo modo, implica también la capacidad de interpretar el
significado y comprender las ideas expresadas en mensajes matemáticos ajenos.

Esta competencia se refiere, por tanto, al dominio del lenguaje matemático y especialmente
a su uso comunicativo. El dominio del lenguaje matemático incluye la comunicación clara y eficaz
de ideas matemáticas sobre el mundo real o sobre la propia disciplina, así como la capacidad de
integrar los mensajes de contenido matemático dentro de un discurso argumentativo o de una
discusión. El alumnado de esta etapa tendría que interpretar y comunicar mensajes con y sobre
matemáticas en registro lingüístico neutro y formal. Además, tendría que ser capaz de debatir e
intercambiar ideas generales y complejas integrando el lenguaje matemático en su discurso,
utilizando cuando sean necesarias herramientas TIC que canalicen o abran nuevas vías de
comunicación.

El alumnado debería poder comunicar-se recurriendo al lenguaje matemático y al
conocimiento sobre contextos de los ámbitos personal, educativo, social, y de iniciación a los
ámbitos profesional y científico, haciendo referencia tanto a situaciones concretas, reales y
relevantes, como a contextos puramente matemáticos y formales. También debería saber informar
sobre sus procesos de trabajo matemático estableciendo una reflexión sobre su propia actividad
matemática que facilitara la autorregulación y la competencia de aprender a aprender.

El alumnado tendría que ser capaz de comprender e interpretar problemas en distintos
formatos que combinaran varias fuentes de información y representaciones. También debería ser
capaz de discriminar los datos relevantes y de completar información desconocida en una situación
de aprendizaje.

Los alumnos y las alumnas deberían poder comunicar los resultados matemáticos de
manera individual y por escrito, pero también oralmente y en grupo, siendo capaces de establecer
un debate fructífero en el grupo o entre grupos. Deberían ser capaces, a partir de estas

interacciones, de elaborar discursos orales, escritos o combinaciones de ambos, que recojan la
complejidad de puntos de vista y enriquezcan y complementen el trabajo matemático previo.

Durante esta etapa, se espera que el alumnado perfeccione y amplíe su vocabulario
matemático, de manera que sus medios de expresión sean ricos y domine los distintos significados
y matices de los términos que emplea, y pueda comunicar con claridad, concisión, rigor y precisión
sus ideas con y sobre las matemáticas.

El alumnado debería comprender y producir mensajes complejos con los que pueda
comunicar sus reflexiones acerca de situaciones generales de interés social, natural o cultural de
manera crítica, empleando el lenguaje matemático como herramienta comunicativa apropiada para
expresar ideas precisas y rigurosas basadas en datos y evidencias.

Además, el alumnado tendría que ser capaz de establecer un debate fructífero con sus
compañeros, comparando y conectando las ideas matemáticas que unos y otros comunican,
manejando diferentes fuentes de información y movilizando los registros de representación más
útiles para comunicar sus ideas.

2.7. Competencia específica 7.

Conocer el valor cultural e histórico de las matemáticas e identificar sus aportaciones en los
avances significativos del conocimiento científico y del desarrollo tecnológico especialmente
relevantes para abordar los desafíos con los que se enfrenta actualmente la humanidad.

2.7.1. Descripción de la competencia.

La competencia en la relevancia social, cultural y científica de las matemáticas responde a
la necesidad de que el alumnado perciba el sentido y la función de las matemáticas en la sociedad,
especialmente en el campo científico y tecnológico. Se trata de valorar el papel de las matemáticas
en los desafíos y avances significativos del ámbito científico y tecnológico, pero también sus
aportaciones al ámbito social y cultural. El alumnado de la Educación Secundaria Obligatoria debería
percibir el área de matemáticas como una parte esencial de la cultura humana, ligada a todas las
manifestaciones culturales, pero especialmente vinculada al desarrollo científico, tecnológico y a la
digitalización.

Esta competencia también se vincula a la motivación del aprendizaje que, más allá de su
componente intrínseco (la consecución del propio aprendizaje de las matemáticas), requiere el
desarrollo de la motivación extrínseca que puede favorecer la confirmación de que la matemática
es una herramienta que permite transformar la realidad. Es una competencia con un fuerte
componente actitudinal en tanto que implica creencias, apreciación, motivación e interés.

Durante la etapa, se espera que el alumnado reconozca el contenido matemático en obras
de arte plásticas y visuales, en la música y en la arquitectura, valorando su función estética y
organizadora. También se espera que el alumnado valore la importancia y necesidad de las
matemáticas para la resolución de problemas reales y, por tanto, para el avance social y cultural de
la humanidad. En esta etapa el alumnado debería apreciar las matemáticas como parte de la cultura
humana, especialmente por su carácter de lenguaje universal.

Al finalizar la ESO, el alumnado, además, debería reconocer el papel de las matemáticas
en la ingeniería y la organización social y económica de la sociedad, siendo consciente de su
necesidad para ejercer una ciudadanía crítica, responsable y preparada para afrontar los retos del
siglo XXI. Debería identificar y valorar el papel de las matemáticas en la ciencia y la tecnología como
instrumento para la comprensión del mundo físico. El alumnado debería conocer la relevancia de
las matemáticas en situaciones, fenómenos y problemas importantes a lo largo de la historia.

2.8. Competencia específica 8.

Gestionar y regular las emociones, creencias y actitudes implicadas en los procesos
matemáticos, asumiendo con confianza la incertidumbre, las dificultades y los errores que dichos

procesos conllevan, y regulando la atención para lograr comprender sus propios procesos de
aprendizaje y adaptarlos con éxito a situaciones variadas.

2.8.1. Descripción de la competencia

En los procesos de aprendizaje de las matemáticas intervienen multitud de factores. Hay
componentes cognitivos, pero también afectivos, y son inseparables: no se puede razonar
matemáticamente sin experimentar emociones. La confianza forma parte de un buen rendimiento
en matemáticas, pero también se experimenta otro tipo de sentimientos ligados a dificultades que
experimentan los y las estudiantes: ansiedad, temor, frustración, inseguridad o desinterés.

Los tres descriptores esenciales del dominio afectivo son las emociones, las actitudes y las
creencias. Es importante que el alumnado desarrolle estrategias de regulación de su propio
aprendizaje, lo que implica el control de la atención, pero también regular las emociones. La
consecuencia de la autorregulación es un refuerzo del interés del alumnado y una revisión de sus
creencias respecto a las matemáticas y a cómo percibe sus capacidades en relación con las
matemáticas. Esta competencia se compone, por tanto, de habilidades relacionadas con el dominio
emocional y metacognitivo. La competencia moviliza actitudes, creencias, emociones y la atención
al propio aprendizaje, logrando que los y las estudiantes adquieran un autoconcepto y una
autoestima positivos en relación a las matemáticas. Se deben evitar falsos mitos como que las
matemáticas son para gente muy inteligente o que el talento matemático se relaciona con el género.

Durante la etapa, se espera que el alumnado reconozca las emociones, actitudes y procesos
cognitivos implicados cuando se enfrenta a situaciones de aprendizaje complejas, relacionadas con
las matemáticas. Además, el alumnado debería reforzar el sistema de creencias favorables hacia
las matemáticas y hacia sus capacidades a través de situaciones de aprendizaje que garanticen el
trabajo con errores como oportunidad de aprendizaje y la posibilidad de encontrar vías para evitar
el bloqueo, por ejemplo, comparando distintas estrategias para abordar un problema.

Al finalizar la ESO, el alumnado debería tener la capacidad de gestionar su atención para
focalizar los distintos factores relevantes en la comprensión de los procesos matemáticos. Además,
tendría que ser capaz de emplear el pensamiento matemático como herramienta para desarrollar el
pensamiento crítico y creativo en variedad de situaciones, utilizando estrategias relacionadas con la
competencia de aprender a aprender que permiten transferir procesos en distintos contextos. El
alumnado finalizará la ESO con la capacidad de regular sus emociones cuando se enfrente a la
resolución de problemas matemáticos, y con una actitud positiva hacia las matemáticas que se
refleje en su autoconcepto y autoestima.

3. Conexiones de las competencias específicas entre sí, con las competencias específicas
de otras materias y con las competencias clave

3.1.  Relaciones o conexiones entre las competencias específicas

La CE1, Resolución de problemas, es el punto de unión de todas las competencias
específicas del área de matemáticas. Depende directamente de las bases del razonamiento
matemático riguroso, ya que sin este no es posible llegar a conclusiones válidas y fiables, tal y como
contempla la CE2 Razonamiento y conexiones. Cuando las situaciones problemáticas a abordar
necesitan de la movilización de procesos de abstracción de una situación real, se está conectando
con la CE3 Modelización.

La CE4 Pensamiento computacional es un instrumento para resolver de forma eficiente
problemas matemáticos y situaciones reales que pueden ser tratadas a través de un algoritmo.
Además, los procesos de resolución de problemas y situaciones problemáticas deben ser
representados mediante el simbolismo matemático, lo que conecta la CE1 con la CE5. La manera
de comunicar al resto de compañeras y compañeros cada uno de los avances que vamos realizando
en la resolución de un problema, los pasos que se han seguido y aquellos que se descartan por el
camino, forma parte del proceso de aprendizaje, conectando con la CE6 Comunicación. La

importancia de los procesos de abstracción lleva a tomar conciencia de la importancia que a lo largo
de la historia tienen las matemáticas, objeto de la CE7 Relevancia social, cultural y científica.
Además, en la resolución de problemas interviene la gestión de las emociones y actitudes
implicadas, aceptando la incertidumbre y las dificultades para encontrar una solución, CE8 Gestión
de las emociones y actitudes.

La inducción y la deducción, CE2 Razonamiento y conexiones, como parte del proceso
matemático son intrínsecas al hecho de resolver problemas y su conexión es directa con la CE1
Resolución de problemas. La formulación de conjeturas, entendidas como hipótesis, abre el camino
de la modelización, CE3 Modelización, ya que estas forman parte del proceso de simplificación y
estructuración de la realidad que permite crear modelos. Establecer conexiones entre diferentes
procesos de razonamiento forma parte del proceso de matematización de la realidad, CE2
Razonamiento y conexiones, y también requiere manejar con precisión el simbolismo matemático,
CE5 Representaciones. Entender el lenguaje computacional es un paso más dentro del formalismo
y rigor propios del razonamiento matemático en cualquiera de sus aspectos, CE2 Razonamiento y
conexiones, y de la resolución de problemas, CE1 Resolución de problemas.

Razonar y expresar el motivo por el que seguimos unos modelos, CE 3 Modelización, y no
otros nos ayuda a profundizar en los aspectos matemáticos utilizados y a valorar la contribución de
las matemáticas a nuestras necesidades y a su evolución, lo que pone de manifiesto su relación con
la CE6 Comunicación y la CE7 Relevancia social, cultural y científica. Las representaciones y el
simbolismo matemático, CE5 Representaciones son el vehículo para intercambiar argumentos
sobre diferentes situaciones en contextos cambiantes dándoles un significado matemático, lo que la
conecta con la CE6 Comunicación. Además, la producción de mensajes escritos de una cierta
complejidad precisa de una adecuada interpretación, ya que con ellos se pretende dar respuesta a
determinadas situaciones problemáticas del quehacer diario, y de ahí su directa conexión con la
CE1 Resolución de problemas.

3.2. Relaciones o conexiones con competencias específicas de otras áreas.

Las matemáticas tratan sobre estructuras y las relaciones entre ellas, y se caracterizan por
la precisión y el rigor lógico. Por esa razón, son el lenguaje de la ciencia, que aspira a cuantificar o,
al menos, describir con precisión los fenómenos físicos y naturales, valiéndose de modelos en los
que las matemáticas son la herramienta para lograr esa descripción precisa de la realidad que
permite contrastar hipótesis en forma de datos y realizar predicciones. Es natural, por lo tanto, que
las conexiones más directas y numerosas de las CE del área de Matemáticas se den con las áreas
de ciencias y con la Tecnología. De hecho, las siglas STEM agrupan a todas estas áreas en un gran
ámbito de actuación y/o influencia.

En consecuencia, la CE1, CE2 y CE5 de Matemáticas se vinculan explícitamente con la
CE1 compartida por las materias de Biología y Geología y Física y Química, cuyo foco es resolver
problemas científicos abordables en el ámbito escolar a partir de trabajos de investigación de
carácter experimental. Esto es así porque la resolución de problemas científicos implica, a menudo,
resolver problemas matemáticos (CE1) inherentes a la cuantificación del fenómeno experimentado,
por ejemplo, encontrar una función que se ajuste a un conjunto de datos obtenido en el experimento.
Además, el diseño experimental y la toma de datos a menudo requieren razonamiento matemático
(CE2) y ser representados matemáticamente (CE5).

La CE2 de Matemáticas se relaciona con la CE2 compartida por las materias de Biología y
Geología y Física y Química, centrada en analizar situaciones problemáticas reales utilizando la
lógica científica y explorando las posibles consecuencias de las soluciones propuestas para
afrontarlas. La lógica científica se apoya en el razonamiento lógico-matemático (CE2 de
Matemáticas), que aporta rigor a la inducción de regularidades, leyes o principios generales a partir
de observaciones particulares. El razonamiento matemático también ayuda a desarrollar
deducciones y consecuencias a partir de estructuras generales que deben ser contrastadas
experimentalmente.

La CE3 se vincula directamente con la CE3 y CE4 compartidas por las materias de Biología
y Geología y Física y Química, que ponen el foco en la naturaleza del conocimiento científico y en
la construcción y revisión de modelos científicos. La CE3 de estas materias se refiere a utilizar el
conocimiento científico como instrumento del pensamiento crítico, interpretando y comunicando
mensajes científicos, desarrollando argumentaciones y accediendo a fuentes fiables, para distinguir
la información contrastada de los bulos y las opiniones. La utilización de herramientas matemáticas
para interpretar fenómenos abordados por la ciencia permite contrastar información y desarrollar el
pensamiento crítico. Por su parte, la CE4 de ambas materias, que consiste en justificar la validez
del modelo científico como producto dinámico que se va revisando y reconstruyendo con influencia
del contexto social e histórico, atendiendo a la importancia de la ciencia en el avance de las
sociedades, a los riesgos de un uso inadecuado o interesado de los conocimientos y a sus
limitaciones, se relaciona también con la CE3 de Matemáticas, pues la modelización matemática
forma parte del proceso de construcción de numerosos modelos científicos.

La tecnología y la digitalización son aplicaciones de la ciencia y de las matemáticas para
desarrollar instrumentos que resuelven problemas humanos y llevan a la transformación social. En
este sentido, la CE3 y CE4 se vinculan directamente con la materia de Tecnología y Digitalización,
pues la construcción de modelos matemáticos (CE3 de Matemáticas) es un paso previo al desarrollo
de modelos o productos tecnológicos, y frecuentemente estos modelos requieren del pensamiento
computacional (CE4 de Matemáticas). Ambas conectan también con la CE5 de dicha área (“Crear,
expresar, comprender y comunicar ideas, opiniones y propuestas relacionadas con aspectos
tecnológicos y digitales cotidianos y habituales, tanto en el ámbito académico como en el personal
y social, utilizando correctamente los lenguajes y los medios propios de este ámbito de
conocimiento”), pues los lenguajes propios de la tecnología y la digitalización se fundamentan en
modelos matemáticos y en el pensamiento computacional. Y, por su parte, la CE4 se vincula también
a la CE6 de Tecnología y Digitalización (“Analizar problemas sencillos y plantear sus soluciones
automatizando procesos con lenguajes de programación, sistemas de control o robótica, aplicando
el pensamiento computacional”), pues los algoritmos componen los lenguajes de programación y
robótica.

Además de estas relaciones explícitas dentro del ámbito STEM, las matemáticas están
presentes en todas las áreas de la actividad humana, en la medida que necesitan una descripción
precisa –de tipo numérico, geométrico o estadístico– del fenómeno o aspecto de la realidad
abordados. Por ello, la CE2, relativa al razonamiento matemático y a sus conexiones, la CE3, relativa
a la construcción de modelos matemáticos que permiten interpretar cualquier tipo de fenómeno real,
y la CE5, relacionada con la representación matemática, se relacionan con las ciencias sociales, las
humanidades o las artes. Así, por ejemplo, la CE5 se relaciona con las materias de Educación
Plástica, Visual y Audiovisual, ya que las representaciones geométricas forman parte de dichos
elementos configurativos del lenguaje visual. De hecho, se ha propuesto el término STEAM para
incluir a las artes en ese gran ámbito de actuación en el que las matemáticas juegan un papel
relevante.

3.3.  Relaciones o conexiones con las competencias clave

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE 1 |  |  | X | X | X | X | X |  |
| CE 2 |  |  | X | X |  |  |  | X |
| CE 3 |  |  | X |  |  | X | X |  |
| CE 4 |  |  | X |  |  |  | X |  |
| CE 5 | X |  | X | X | X |  |  |  |
| CE 6 | X | X | X |  |  |  | X |  |
| CE 7 |  |  | X |  | X | X |  | X |
| CE 8 |  |  | X |  | X |  | X |  |

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

•
CCL: Competencia en comunicación lingüística
•
CP: Competencia plurilingüe
•
CMCT: Competencia matemática y competencia en ciencia y tecnología
•
CD: Competencia digital
•
CPSAA: Competencia personal, social y de aprender a aprender
•
CC: Competencia ciudadana
•
CE: Competencia emprendedora
•
CCEC: Competencia en conciencia y expresión culturales

La competencia específica CE1 tiene una fuerte conexión con la competencia clave
personal, social y de aprender a aprender (CPSAA), pues la complejidad de la resolución de un
problema implica que el alumnado reflexione sobre en qué fase del proceso está y planifique, haga
un seguimiento y evalúe su actividad. La resolución de problemas, con un sentido crítico, es
indispensable para ejercer la competencia ciudadana (CC). En la competencia digital (CD) la
resolución de problemas matemáticos tiene un papel instrumental destacado. Conviene destacar
también la resolución de problemas matemáticos como una concreción de la resolución de
problemas en general, aspecto nuclear de la competencia emprendedora (CE).

La CE2 se relaciona con la Competencia en conciencia y expresión culturales (CCEC), pues
el pensamiento matemático es una forma de expresión cultural. Además, los procesos del
razonamiento matemático conectan con la competencia clave personal, social y de aprender a

aprender (CPSAA), en la medida en que el alumnado debe reflexionar sobre cuándo y cómo
aplicarlos en determinadas situaciones de aprendizaje, valorando sus propios procesos y también
los de sus compañeros. El razonamiento matemático es la base del pensamiento computacional y
sustenta, por tanto, la competencia digital (CD) del alumnado.

La competencia específica en modelización (CE3) consiste en aplicar las matemáticas para
reforzar y justificar argumentos en todo tipo de contextos reales y en todos los ámbitos de la realidad
social y natural: científico, tecnológico y digital, económico, sociológico, artístico y cultural. Por lo
tanto, se relaciona directamente con la competencia ciudadana (CC) y con la competencia
emprendedora (CE), además de relacionarse con la competencia en conciencia y expresión
culturales (CCEC).

La competencia específica en pensamiento computacional (CE4) se vincula directamente a
la competencia clave en digitalización (CD). Además, es una herramienta necesaria para la
competencia emprendedora (CE).

La CE5, que implica utilizar diversos registros de representación y realizar conversiones de
un sistema de símbolos a otro, se relaciona con la competencia en comunicación lingüística (CCL),
pues estos sistemas vehiculan la comunicación. Además, puesto que el lenguaje digital está
vehiculado por registros de representación cercanos a los propios del lenguaje matemático, la CE5
también se vincula con la competencia digital (CD). La traducción de un mismo contenido a distintos
modos de representación implica habilidades metacognitivas que relacionan la CE5 con la
competencia personal, social y de aprender a aprender (CPSAA).

La competencia en comunicación matemática (CE 6) forma parte de la competencia clave
en comunicación lingüística (CCL). Además, las matemáticas conforman un lenguaje específico que
se relaciona con distintas lenguas, por lo que la CE6 se relaciona con la competencia plurilingüe
(CP). Comunicar ideas usando las matemáticas es, además, una habilidad necesaria para la
competencia emprendedora (CE).

La CE7, que se relaciona con el papel que las matemáticas juegan en la realidad y en la
propia experiencia del alumnado, está directamente vinculada con la competencia en conciencia y
expresión culturales (CCEC) y con la competencia personal, social y de aprender a aprender
(CPSAA).

Por último, la competencia en autorregulación y gestión de las emociones y actitudes (CE
8) forma parte, de manera específica, de la competencia personal, social y de aprender a aprender
(CPSAA). Además, la autorregulación y la gestión emocional son indispensables para ejercer la
competencia emprendedora (CE).

4. Saberes básicos del área de matemáticas

4.1. Introducción

El desarrollo de la civilización a lo largo de la historia ha requerido los saberes necesarios
para la solución de diferentes desafíos y situaciones problemáticas. Estas diferentes situaciones
han provocado en cada momento histórico la necesidad de descubrir o crear el conocimiento
matemático necesario para su abordaje y/o solución.

En el presente, al igual que en otros períodos históricos anteriores, es necesario promover
la adquisición y el desarrollo de las competencias matemáticas específicas mediante el aprendizaje,
la articulación y la movilización de los saberes básicos que permitan afrontar los retos y desafíos de
nuestro siglo. Así, la necesidad de trabajar con cantidades y sus transformaciones hace
imprescindible el dominio de las estructuras numéricas y sus operaciones. La evolución social, las
comunicaciones sociales, las construcciones emblemáticas o para la vida diaria, el transporte de
mercancías, etc. no podrían desarrollarse sin los conocimientos geométricos y de la medida que se
proponen como saberes básicos en este currículo. En cuanto a la adaptación tecnológica,
numerosos problemas pueden resolverse de manera eficiente con la implementación de algoritmos

computacionales. También es relevante, en términos de predicción y organización social, el papel
de la estadística y la probabilidad para la gestión de datos. La necesidad de aportar soluciones
generales para distintos contextos y problemas exige el desarrollo del pensamiento algebraico y del
concepto de función.

En esta etapa, podemos diferenciar y categorizar los saberes atendiendo a ocho sentidos
matemáticos: numérico y cálculo, magnitudes y medida, del lenguaje algebraico, espacial y
geométrico, relaciones y funciones, de incertidumbre y probabilidad, de análisis de datos y
estadística, y de pensamiento computacional. En cada uno de ellos, a su vez, se señalan los
contenidos o grupos de contenidos cuyo aprendizaje, articulación y movilización son necesarios
para la adquisición y el desarrollo de las ocho competencias específicas de Matemáticas en la
Educación Secundaria Obligatoria y que asegura la continuidad con las etapas educativas
adyacentes (la Educación Primaria, por una parte, y el Bachillerato y la Formación Profesional, por
la otra). En cada uno de estos sentidos matemáticos se añaden, además, habilidades y saberes
relacionados con el dominio afectivo y socioemocional, es decir, con la gestión de las emociones,
con la motivación y con la autorregulación de la atención y los procesos de aprendizaje específicos
del área de matemáticas.

La secuencia de estos contenidos se presenta para el tercer y el cuarto curso de la etapa,
distinguiendo, en este último caso, entre las modalidades A y B de la materia. Los centros
educativos, en la concreción y temporalización de los saberes básicos a lo largo de primero, segundo
y tercero de ESO, deberán garantizar que estos estén distribuidos equitativamente en cada uno de
los cursos.

4.2. Bloque 1. Sentido numérico y cálculo

Se entiende por Sentido numérico y de las operaciones el conjunto de saberes básicos
relacionados con la comprensión del significado del número, su naturaleza, representación,
simbolización y magnitud, además del uso adecuado de los mismos en las relaciones, propiedades,
operaciones y estrategias básicas de cálculo.

Asociados al sentido numérico se establecen, para toda la etapa, dos bloques de
contenidos:  números naturales, enteros, racionales y reales; y las operaciones y sus propiedades,
además de los decimales y las fracciones. Los contenidos de los dos bloques asociados a este
sentido matemático son esenciales para el resto de conocimientos en el área de Matemáticas.

| SABERES BÁSICOS | Tercer curso | Cuarto curso A | Cuarto curso B |
| --- | --- | --- | --- |
| 1. NÚMEROS NATURALES, ENTEROS, RACIONALES Y REALES. |  |  |  |
| Lectura, escritura, representación, ordenación y comparación de números naturales, enteros y racionales. | X |  |  |
| Justificación de los criterios de divisibilidad. | X |  |  |
| Lectura, escritura, representación, aproximación, ordenación y comparación de números irracionales más comunes. | X | X |  |

| Concepto y significado de valor absoluto. | X | X | X |
| --- | --- | --- | --- |
| Equivalencia entre fracciones y números decimales exactos y periódicos. Fracción irreducible. | X |  |  |
| Concepto de número irracional. Aproximación y estimación acotando el error cometido. |  | X | X |
| Notación científica. | X | X | X |
| Potencias de exponente entero o fraccionario y radicales sencillos. | X | X | X |
| Representación de números reales en la recta real. Intervalos. |  | X | X |
| Interés simple. | X | X |  |
| Interés compuesto. |  |  | X |
| Contribución de la humanidad al desarrollo del sentido numérico, referentes femeninos. Usos sociales y científicos de los cuerpos numéricos. | X | X | X |
| Técnicas cooperativas para estimular el trabajo en equipo relacionado con los cuerpos numéricos. | X | X | X |

| SABERES BÁSICOS | Tercer curso | Cuarto curso A | Cuarto curso B |
| --- | --- | --- | --- |
| 2. OPERACIONES Y SUS PROPIEDADES. |  |  |  |
| Operaciones con números naturales, enteros, racionales y raíces. | X | X | X |
| Descomposición de un número natural en factores primos. Divisibilidad. | X |  |  |

| Prioridad de las operaciones. Utilización de las propiedades de las operaciones. | X | X | X |
| --- | --- | --- | --- |
| Transformación de números decimales en fracciones. | X | X | X |
| Estimación, cálculo, simplificación e interpretación de expresiones numéricas. Relaciones inversas entre las operaciones. | X | X | X |
| Potencias de números naturales, enteros, racionales o irracionales. | X | X | X |
| Proporcionalidad. Proporciones y porcentajes (equivalencia). Reducción a la unidad. Aumentos y reducciones. | X | X | X |
| Estrategias de cálculo mental. | X | X | X |
| Concepto de logaritmo decimal de un número. |  |  | X |
| Flexibilidad en el uso de estrategias, técnicas o métodos de resolución de situaciones problemáticas de tipo numérico. | X | X | X |
| Perseverancia en el aprendizaje de los aspectos asociados al sentido numérico y de las operaciones. | X | X | X |

4.3. Bloque 2. Sentido algebraico

El Sentido algebraico se refiere a la capacidad de entender y de utilizar representaciones
simbólicas para explicar o resolver determinadas situaciones, como las asociadas a la modelización,
que requieren superar el cálculo numérico.

El uso de este lenguaje estructurado y el dominio de las operaciones entre estructuras
simbólicas permite conectar con la siguiente etapa educativa. Se hace necesario aprender, articular
y movilizar contenidos como los que se detallan en la tabla siguiente para abordar situaciones
funcionales o bien la modelización de fenómenos físicos y matemáticos susceptibles de predicción
o generalización.

| SABERES BÁSICOS | Tercer curso | Cuarto curso A | Cuarto curso B |
| --- | --- | --- | --- |
| Traducción de expresiones del lenguaje ordinario al algebraico, y viceversa. | X | X | X |

| Monomios y binomios. Operaciones con monomios y binomios. Identidades notables. | X | X | X |
| --- | --- | --- | --- |
| Polinomios. Suma, resta y producto de polinomios. | X | X | X |
| Valor numérico. Raíces de un polinomio. |  | X | X |
| Ecuaciones de primer y segundo grado. Equivalencia entre expresiones algebraicas. | X | X | X |
| Inecuaciones de primer grado. Sistemas de inecuaciones lineales con dos incógnitas. |  | X | X |
| Sistemas de ecuaciones lineales con dos incógnitas. Interpretación geométrica. | X | X | X |
| Factorización de polinomios, búsqueda y representación de raíces. |  | X | X |
| Fracciones algebraicas. |  |  | X |
| Contribución de la humanidad al desarrollo del álgebra y sus aplicaciones, incorporando la perspectiva de género. Valoración de los usos sociales y científicos del sentido algebraico. | X | X | X |
| Flexibilidad en el uso de varias estrategias, técnicas o métodos de resolución de situaciones problemáticas susceptibles de error en la interpretación. | X | X | X |
| Autonomía, tolerancia ante el error y perseverancia en el aprendizaje de aspectos asociados al sentido algebraico. | X | X | X |

4.4. Bloque 3. Sentido de la medida y de la estimación

El Sentido de la medida está asociado a la capacidad de comprender y comparar
magnitudes, las técnicas y estrategias de medición y cálculo, así como a la estimación de resultados
obtenidos eligiendo las unidades apropiadas.

En este bloque se profundiza en habilidades y estrategias que varían de lo informal (uso de
unidades no estándar, experimentación, etc.) a lo formal, incorporando criterios de fiabilidad y
precisión.

| SABERES BÁSICOS | Tercer curso | Cuarto curso A | Cuarto curso B |
| --- | --- | --- | --- |
| Determinación de medidas con la elección de instrumentos adecuados, analizando la precisión y el error aproximado en cada situación. | X | X | X |
| Estimación y análisis de medidas utilizando unidades convencionales. | X |  |  |
| Elección de unidad de medida y escala apropiada para describir magnitudes. Conversión entre unidades de medida. | X | X |  |
| Cambio de herramientas, técnicas, estrategias o métodos relacionados con la medida y con la estimación de magnitudes. | X | X | X |
| Perseverancia, iniciativa y flexibilidad en la resolución de situaciones problemáticas susceptibles de errores o de dificultades relacionados con la medida de magnitudes. | X | X | X |

4.5. Bloque 4. Sentido espacial y geometría

En esta etapa, este sentido está asociado a la capacidad de analizar los elementos y las
propiedades básicas de formas y figuras, utilizando el vocabulario adecuado, y de realizar con ellas
razonamientos, transformaciones o cálculos matemáticos.

Estos contenidos posibilitan el acercamiento a otras disciplinas como el arte y la tecnología.
Apreciar la belleza de las expresiones plásticas pone de manifiesto la importancia del desarrollo de
la creatividad en el ámbito científico.

Abordar este bloque de contenidos permite que el alumnado pueda explorar, clasificar,
representar y describir el entorno físico desde una perspectiva matemática formal, con la posible
utilización de herramientas tecnológicas.

| SABERES BÁSICOS | Tercer curso | Cuarto curso A | Cuarto curso B |
| --- | --- | --- | --- |
| Figuras planas. Elementos básicos de la geometría del plano. | X |  |  |
| Proporcionalidad, semejanza. Teorema de Tales. Escalas. | X |  |  |
| Ángulos en el sistema sexagesimal y en radianes. Relaciones básicas entre sí. | X | X | X |

| Traslaciones, giros y simetrías. | X | X | X |
| --- | --- | --- | --- |
| Teorema de Pitágoras. Aplicaciones. | X | X | X |
| Elementos notables del triángulo. | X | X | X |
| Circunferencia, círculo, arcos y sectores circulares. | X |  |  |
| Reconocimiento de sólidos: prismas rectos, pirámides, cilindros y conos. Cálculo de superficies y volúmenes. | X | X |  |
| Esfera. Coordenadas geográficas y husos horarios. Longitud y latitud de un punto. |  | X | X |
| Iniciación a la geometría analítica en el plano. Paralelismo y perpendicularidad. Posiciones relativas de la recta en el plano. |  | X | X |
| Programas informáticos de geometría dinámica. | X | X | X |
| Relaciones métricas en los triángulos y razones trigonométricas. |  | X | X |
| Iniciación a la geometría analítica en el plano. Coordenadas. Vectores. |  | X | X |
| Geometría en contexto real (arte, ciencia, ingeniería, vida diaria). Contribución de la humanidad al desarrollo de la geometría y a sus aplicaciones, incorporando la perspectiva de género | X | X | X |
| Perseverancia y flexibilidad en el cambio de estrategias, representaciones o técnicas geométricas. | X | X | X |

4.6. Bloque 5. Relaciones y funciones

Los contenidos asociados a las relaciones y funciones, junto con los del álgebra, aportan
las herramientas para la modelización de situaciones matemáticas o del mundo real con expresiones
simbólicas, un lenguaje estructurado y reglas lógicas para los diferentes procedimientos o soportes
tecnológicos.

| SABERES BÁSICOS | Tercer curso | Cuarto curso A | Cuarto curso B |
| --- | --- | --- | --- |
| Variable. Variación y relación entre variables. | X | X |  |
| Funciones lineales. Construcción e interpretación de la tabla de valores y de su gráfica. | X | X | X |
| Identificación de la ecuación de la recta. Interpretación de la pendiente y de los puntos de corte con los ejes. | X |  |  |
| Análisis e interpretación de funciones no lineales a partir de su gráfica. | X | X | X |
| Relación entre una función y su inversa. |  |  | X |
| Programas informáticos de geometría dinámica e iniciación a las calculadoras gráficas. | X | X | X |
| Resolución de problemas y modelización mediante el estudio de funciones y sus propiedades. |  | X | X |
| Contribución de la humanidad al desarrollo del análisis y de sus aplicaciones, incorporando la perspectiva de género. Valoración de los usos sociales y científicos del análisis matemático. | X | X | X |
| Perseverancia y flexibilidad en el cambio de estrategias, técnicas o métodos asociados a las relaciones y a las funciones. | X | X | X |

4.7. Bloque 6. Incertidumbre y probabilidad

El sentido de la incertidumbre y probabilidad implica la capacidad de entender las
situaciones o fenómenos de naturaleza estocástica y la probabilidad como medida de la
incertidumbre, así como de realizar estimaciones y transmitir resultados de manera comprensible
utilizando el vocabulario, las herramientas y estrategias más apropiadas en cada caso.

El bloque de Incertidumbre y probabilidad incluye contenidos como las técnicas de recuento
y la experimentación relacionadas con la aproximación frecuentista. También resultan cruciales el
estudio de casos y la regla de Laplace, el uso de tablas y diagramas para el desarrollo de las
diferentes estrategias que facilitan la comprensión y la toma de decisiones a la hora de resolver
problemas de contexto real.

| SABERES BÁSICOS | Tercer curso | Cuarto curso A | Cuarto curso B |
| --- | --- | --- | --- |
| Espacio muestral en experimentos aleatorios simples: identificación y determinación. | X | X |  |
| Uso de tablas de contingencia y diagramas de árbol para obtener el espacio muestral en experimentos compuestos. | X | X | X |
| Cálculo de probabilidades mediante la regla de Laplace en situaciones de equiprobabilidad, en experimentos simples y compuestos. | X | X | X |
| Estimación de la probabilidad de un suceso en situaciones que no permiten el uso de la regla de Laplace: experimentación y ley de los grandes números. | X | X | X |
| Suceso contrario, suceso seguro y suceso imposible. Sucesos compatibles e incompatibles. | X | X | X |
| Unión e intersección de sucesos: concepto y propiedades. |  | X | X |
| Propiedades de la probabilidad. |  | X | X |
| Probabilidad condicionada: concepto, cálculo e interpretación. Sucesos dependientes e independientes. |  | X | X |
| Introducción a las técnicas de recuento: regla de la suma y del producto. Aplicación al cálculo de probabilidades. | X | X | X |
| Introducción a la combinatoria: variaciones, permutaciones y combinaciones. Aplicación al cálculo de probabilidades. |  |  | X |
| Uso del cálculo de probabilidades en contextos no lúdicos: estimación de riesgos y toma de decisiones. | X |  | X |
| Contribución de la humanidad al desarrollo de la probabilidad y de sus aplicaciones, incorporando la perspectiva de género. Utilidad social y científica de la probabilidad. | X | X | X |

| Perseverancia y flexibilidad en el cambio de estrategias, técnicas o métodos probabilísticos. Aceptación de los errores de interpretación. | X | X | X |
| --- | --- | --- | --- |

4.8. Bloque 7. Análisis de datos y estadística

Este bloque, junto con el de Incertidumbre y Probabilidad, permite, por un lado, comprender
la información que transmiten los distintos medios de comunicación, incluyendo las redes sociales,
y por otro, analizarla y utilizarla de forma crítica, precisa y objetiva.

Tiene especial relevancia la transcripción al lenguaje gráfico y al simbólico propios de la
estadística de problemas, el cálculo de las principales medidas de centralización y dispersión,
además de la elaboración e interpretación de diagramas de barras, histogramas, etc. que facilitan
un análisis y uso crítico de la información, al tiempo que permiten centrar el aprendizaje en la
resolución de problemas.

| SABERES BÁSICOS | Tercer curso | Cuarto curso A | Cuarto curso B |
| --- | --- | --- | --- |
| Concepto de variable estadística (cualitativa, cuantitativa discreta y cuantitativa continua). Características y representación. | X | X | X |
| Diseño y fases de un estudio estadístico. Población, muestra y muestras representativas. | X | X | X |
| Recogida, organización, interpretación y comparación de datos en tablas de frecuencia, tablas de contingencia y gráficas de diversos tipos, con y sin TIC. | X | X | X |
| Cálculo e interpretación de las principales medidas de centralización (moda, mediana y media) con y sin apoyo tecnológico | X | X | X |
| Cálculo e interpretación de las principales medidas de dispersión (rango, desviación media, desviación típica y varianza). | X | X | X |
| Estudio de la variabilidad de las muestras de una población. | X |  |  |
| Comparación de muestras de una o dos variables, a partir de las medidas de centralización y dispersión. Coeficiente de variación. |  |  | X |

| Uso de herramientas tecnológicas para realizar diferentes ajustes mediante regresión e interpretación de dicho ajuste. Correlación de variables. |  |  | X |
| --- | --- | --- | --- |
| Comparación de distribuciones mediante los parámetros de centralización y dispersión. |  |  | X |
| Diagramas de dispersión. Introducción a la correlación. |  |  | X |
| Contribución de la humanidad al desarrollo de la estadística y de sus aplicaciones, incorporando la perspectiva de género. Utilidad social y científica de la estadística y de la gestión de datos. | X | X | X |
| Perseverancia y flexibilidad en el cambio de estrategias, técnicas o métodos estadísticos. | X | X | X |
| Interpretación de datos y estudios estadísticos. Análisis y aceptación del error. |  | X | X |

4.9. Bloque 8. Pensamiento computacional

El Pensamiento computacional permite desarrollar técnicas y estrategias para obtener
soluciones eficientes utilizando secuencias de órdenes. Este sentido matemático, en esta etapa se
aplica en la identificación de regularidades, sucesiones, series o secuencias de instrucciones,
desarrollando la creación de algoritmos o la exploración de distintas opciones y estrategias ante una
situación determinada.

Conviene destacar en este sentido la importancia del uso de las TIC y la programación
mediante bloques en la que se pone de manifiesto habilidades asociadas al reconocimiento, uso de
patrones para el diseño y análisis de soluciones más complejas.

| SABERES BÁSICOS | Tercer curso | Cuarto curso A | Cuarto curso B |
| --- | --- | --- | --- |
| Identificación y establecimiento de regularidades, y predicción de términos en secuencias, sucesiones, series y procesos numéricos. | X | X | X |
| Sistematización de procesos matemáticos mediante secuencias de instrucciones. | X | X | X |

| Reconocimiento de patrones para la generalización y automatización de procesos repetitivos o de algoritmos. | X | X | X |
| --- | --- | --- | --- |
| Diseño y programación de algoritmos, entendidos como patrones de resolución de problemas, con o sin herramientas TIC. | X | X | X |
| Búsqueda y análisis de estrategias en juegos abstractos o problemas sin información oculta ni presencia de azar. | X | X | X |
| Contribución de la humanidad al desarrollo del pensamiento computacional y sus aplicaciones. Importancia en el desarrollo matemático. Referentes femeninos | X | X | X |
| Autonomía, tolerancia ante el error asociado al pensamiento computacional. Mejoras a través del ensayo y error. | X | X | X |
| Perseverancia y flexibilidad en el cambio de estrategias, técnicas o algoritmos computacionales. | X | X | X |

5. Situaciones de aprendizaje del área de matemáticas

Las situaciones de aprendizaje conectan con los “Principales retos del siglo XXI” e integran
todos los elementos que constituyen el proceso de enseñanza y aprendizaje competencial. Su
finalidad es promover la adquisición y el desarrollo de las competencias específicas necesarias para
afrontar los principales desafíos del siglo XXI. Plantean tareas complejas en las que el alumnado
despliega un conjunto de competencias y moviliza los aprendizajes que exige su abordaje. La
capacidad de actuación del alumnado al enfrentarse a una situación de aprendizaje requiere, en
efecto, movilizar todo tipo de saberes implicados en las competencias específicas: conceptos,
procedimientos y actitudes y valores.

En el caso de las matemáticas, las situaciones de aprendizaje deben proponer un problema
real o potencial cuyas tareas impliquen las capacidades y las actuaciones referidas en las
competencias específicas: resolver problemas; razonar matemáticamente y establecer conexiones;
modelizar y aplicar a la realidad las herramientas matemáticas; implementar algoritmos y métodos
del pensamiento computacional; manejar simbolismo matemático y sus representaciones;
comunicar con lenguaje matemático y sobre las matemáticas.

Algunos criterios para diseñar situaciones de aprendizaje desde esta perspectiva serían los
siguientes:

a) Las situaciones de aprendizaje deben plantear una problemática que se corresponda con

una situación real y compleja que sirva para desarrollar más de una competencia.

b) El diseño de situaciones de aprendizaje específicas en el área de matemáticas debe

involucrar conceptos, procedimientos y actitudes vinculados a los sentidos matemáticos:
sentido algebraico, sentido espacial, sentido de la medida, sentido numérico y sentido de la
estadística y la probabilidad.

c) Las situaciones de aprendizaje deben, en la medida de lo posible, ser abiertas y poder

graduarse. Es decir, deben ser suficientemente flexibles, complejas y relevantes para
controlar el grado de accesibilidad y profundización que permita su uso adaptado a los
diferentes niveles del alumnado.

d) Las situaciones de aprendizaje deben diseñarse para incitar a la reflexión, promover la

competencia clave de aprender y aprender, y desarrollar un enfoque crítico respecto de los
grandes retos de nuestro siglo.

e) Las situaciones de aprendizaje deben permitir un tratamiento interdisciplinar y conectar con

otras experiencias de aprendizaje matemático fuera de la escuela, así como establecer
conexiones con los diferentes temas de interés encaminados al abordaje de los principales
retos del siglo XXI.

f) El diseño de las situaciones de aprendizaje debe permitir que sean abordadas tanto de

manera individual como grupal, incorporando un enfoque inclusivo y técnicas de trabajo
cooperativo o colaborativo.

g) El diseño de las situaciones de aprendizaje incluirá enunciados formulados de manera

directa (se demanda al alumnado la respuesta a una cuestión) e indirecta (el alumnado debe
definir, a partir de un texto, cuál es la pregunta y marcarse unos objetivos). Además, se
deben diseñar situaciones en las que se conozca toda la información necesaria para su
resolución, pero también otras en las que se requiera completar información ausente o
discriminar la información relevante de la superflua.

h) El diseño de las situaciones de aprendizaje debe contemplar formatos variados: enunciados

verbales con o sin ilustraciones de apoyo, enunciados con incorporación de distintas fuentes
de información, y enunciados que exijan interpretar tablas o gráficos.

6. Criterios de evaluación

Competencia 1. Resolución de problemas

| 3º ESO | 4º ESO |
| --- | --- |
| 1.1. Extraer la información necesaria del enunciado de problemas sencillos del ámbito social o de iniciación al ámbito profesional y científico, y estructurar el proceso de resolución en distintas etapas. | 1.1. Aplicar diferentes estrategias para resolver problemas del ámbito social o de iniciación al ámbito profesional y científico, seleccionando la más adecuada atendiendo a criterios de eficiencia y/o sencillez. |
| 1.2. Resolver problemas sencillos del ámbito social o de iniciación a los ámbitos profesional y científico movilizando de manera adecuada y justificada los conceptos y procedimientos necesarios. | 1.2. Analizar críticamente los procedimientos de resolución seguidos y aprender de los errores cometidos, incorporando alternativas planteadas por los compañeros y compañeras y proponiendo mejoras. |
| 1.3. Comparar la solución obtenida con la de sus compañeros y compañeras, valorando si se requiere una revisión o rectificación del proceso de | 1.3. Comparar la solución obtenida con la solución esperada de un problema, o con la encontrada en fuentes de información, valorando si |

| resolución seguido. | se requiere una revisión o rectificación del proceso de resolución seguido. |
| --- | --- |
| 1.4. Generalizar la resolución de algunos problemas sencillos para solucionar problemas similares o más complejos. | 1.4. Generalizar el proceso de resolución de un problema dado y transferirlo a otras situaciones y contextos matemáticamente equivalentes o de mayor complejidad. |

Competencia 2. Razonamiento y conexiones

| 3º ESO | 4º ESO |
| --- | --- |
| 2.1. Usar contraejemplos para refutar conjeturas de naturaleza matemática. | 2.1. Formular conjeturas sobre propiedades o relaciones matemáticas y explorar su validez reconociendo patrones o desarrollando una cadena de procedimientos matemáticos. |
| 2.2. Validar informalmente algunas conjeturas sobre propiedades o relaciones matemáticas adecuadas al nivel madurativo, cognitivo y evolutivo del alumnado, a partir de casos particulares. | 2.2. Justificar los pasos de una argumentación o procedimiento matemático y generalizar algunos argumentos para hacer demostraciones sencillas. |
| 2.3. Conectar diferentes conceptos y procedimientos matemáticos adecuados al nivel madurativo, cognitivo y evolutivo del alumnado, argumentando el razonamiento empleado. | 2.3. Comparar y conectar diferentes conceptos y procedimientos matemáticos, argumentando las equivalencias y diferencias en el razonamiento empleado. |

Competencia 3. Modelización

| 3º ESO | 4º ESO |
| --- | --- |
| 3.1. Establecer conexiones entre los saberes propios de las matemáticas y los de otras disciplinas, empleando procedimientos de indagación como la identificación, medición y | 3.1. Establecer conexiones bidireccionales entre las matemáticas y otras disciplinas, empleando procedimientos de indagación como la identificación, inferencia, medición y clasificación. |

| clasificación. |  |
| --- | --- |
| 3.2. Seleccionar información relevante, identificar conceptos matemáticos, patrones y regularidades en situaciones o fenómenos reales y, a partir de ellos, construir modelos matemáticos concretos y algunos generales, empleando herramientas algebraicas y funcionales básicas. | 3.2. Construir modelos matemáticos generales a nivel básico, empleando herramientas algebraicas y funcionales, que representen distintas situaciones y fenómenos reales, para interpretarlos, analizarlos y hacer predicciones. |
| 3.3. Analizar, interpretar y hacer predicciones sobre situaciones o fenómenos reales a partir del desarrollo y tratamiento de un modelo matemático. | 3.3. Comparar y valorar distintos modelos matemáticos a nivel básico que describan una situación o fenómeno real. |
| 3.4. Comparar y valorar distintos modelos matemáticos que describan una situación o fenómeno real. | 3.4. Construir nuevos modelos matemáticos para describir fenómenos reales a partir de la transformación de otros modelos conocidos, adaptando su estructura a la situación planteada. |

Competencia 4. Pensamiento computacional

| 3º ESO | 4º ESO |
| --- | --- |
| 4.1. Conocer aspectos básicos de la hoja de cálculo y de programas de cálculo simbólico. | 4.1. Diseñar e implementar algoritmos utilizando la hoja de cálculo y programas de cálculo simbólico. |
| 4.2. Reproducir y diseñar algoritmos sencillos mediante programación por bloques para resolver situaciones problemáticas del ámbito social o de iniciación a los ámbitos profesional y científico. | 4.2. Reproducir y diseñar algoritmos mediante programación por bloques para resolver situaciones problemáticas. |
| 4.3. Resolver situaciones problemáticas descomponiendo y estructurando sus partes mediante algoritmos. | 4.3. Resolver situaciones problemáticas de cierta complejidad descomponiendo y estructurando sus partes mediante algoritmos y analizando las diferentes opciones que se plantean. |

| 4.4. Analizar situaciones de cierto nivel de complejidad en juegos de lógica o de tablero abstractos, estudiando las alternativas para tomar la decisión más adecuada, o determinar la estrategia ganadora, en caso de existir. | 4.4. Analizar situaciones complejas en juegos de lógica o de tablero abstractos, desarrollando un método sistemático y creativo para tomar la decisión más adecuada, o determinar la estrategia ganadora, en caso de existir. |
| --- | --- |
|  | 4.5. Tomar decisiones adecuadas en situaciones de reto, adecuadas al nivel madurativo, cognitivo y evolutivo del alumnado, mediante el análisis lógico y la implementación de estrategias algorítmicas. |

Competencia 5. Representaciones

| 3º ESO | 4º ESO |
| --- | --- |
| 5.1. Manejar las representaciones icónico- manipulativas, numéricas, simbólico-algebraicas, tabulares, funcionales, geométricas y gráficas de objetos matemáticos respetando las reglas que las rigen. | 5.1. Manejar con precisión las representaciones icónico-manipulativas, numéricas, simbólico-algebraicas, tabulares, funcionales, geométricas y gráficas de objetos matemáticos. |
| 5.2. Realizar conversiones, en al menos una dirección, entre las representaciones icónico- manipulativas, numéricas, simbólico-algebraicas, tabulares, funcionales, geométricas y gráficas de objetos matemáticos. | 5.2. Realizar conversiones bidireccionales entre las representaciones icónico-manipulativas, numéricas, simbólico-algebraicas, tabulares, funcionales, geométricas y gráficas de objetos matemáticos. |
| 5.3. Seleccionar el simbolismo adecuado para describir matemáticamente situaciones correspondientes al ámbito social. | 5.3. Seleccionar el simbolismo matemático adecuado para describir matemáticamente situaciones correspondientes al ámbito social y de iniciación a los ámbitos profesional y científico. |

Competencia 6. Comunicación

| 3º ESO | 4º ESO |
| --- | --- |
| 6.1. Interpretar correctamente mensajes orales y escritos relativos al ámbito social que incluyan informaciones con contenido matemático. | 6.1. Comunicar ideas matemáticas empleando el nivel de lenguaje formal adecuado a la situación madurativa, cognitiva y evolutiva del |

|  | alumnado. |
| --- | --- |
| 6.2. Comunicar ideas matemáticas introduciendo aspectos básicos del lenguaje formal. | 6.2. Explicar y dar significado matemático a informaciones relativas a situaciones problemáticas del ámbito social o de iniciación a ámbitos profesional y científico. |
| 6.3. Explicar y dar significado matemático a resultados provenientes de situaciones problemáticas del ámbito social. | 6.3. Argumentar y debatir sobre situaciones relevantes con claridad y solidez apoyándose en el lenguaje matemático. |
| 6.4. Utilizar el lenguaje matemático para argumentar y defender los razonamientos propios en situaciones de intercambio comunicativo relativas al ámbito social. |  |

Competencia 7. Relevancia social, cultural y científica

| 3º ESO | 4º ESO |
| --- | --- |
| 7.1. Reconocer contenido matemático elemental de carácter numérico, espacial o geométrico presente en manifestaciones artísticas y culturales. | 7.1. Reconocer el contenido matemático de carácter numérico, espacial, geométrico, algebraico o funcional presente en el arte, la ingeniería y la organización económica y social. |
| 7.2. Valorar la importancia del desarrollo de las matemáticas como herramienta para el avance social y cultural de la humanidad. | 7.2. Valorar la importancia del desarrollo de las matemáticas como motor del avance científico y tecnológico, y como medio para afrontar los principales desafíos del siglo XXI. |
| 7.3. Valorar las matemáticas como vehículo para la resolución de problemas cotidianos del ámbito social y cultural. | 7.3. Valorar los aspectos históricos de las matemáticas más relevantes y su relación con la historia de la humanidad. |
| 7.4. Apreciar el carácter universal de las matemáticas, por su versatilidad, su lenguaje propio y su funcionalidad. | 7.4. Reconocer el carácter universal de las matemáticas y su importancia clave en la comprensión del universo. |

Competencia 8. Gestión de las emociones y de las actitudes

| 3º ESO | 4º ESO |
| --- | --- |
| 8.1. Gestionar las emociones, las actitudes y los procesos cognitivos implicados al enfrentarse a situaciones de aprendizaje complejas relacionadas con las matemáticas. | 8.1. Identificar los factores relevantes en la comprensión y aprendizaje de los procesos matemáticos, y tomar la actitud adecuada para la superación y la mejora personal. |
| 8.2. Desarrollar creencias favorables hacia las matemáticas y hacia las propias capacidades en el quehacer matemático, tanto de carácter individual como en el trabajo colaborativo. | 8.2. Desarrollar el pensamiento crítico y creativo en una variedad de situaciones a partir del trabajo matemático, tanto individual como en equipo. |
| 8.3. Transformar los errores en oportunidades de aprendizaje y encontrar vías para evitar el bloqueo en situaciones problemáticas y del trabajo matemático, así como en la gestión del trabajo en equipo. | 8.3. Reforzar la autoestima y mejorar el autoconcepto a través de la resolución de situaciones problemáticas y de aprendizaje que involucren destrezas y procedimientos matemáticos. |
