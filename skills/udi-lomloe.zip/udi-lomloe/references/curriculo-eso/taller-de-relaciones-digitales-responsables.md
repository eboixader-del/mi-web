# TALLER DE RELACIONES DIGITALES RESPONSABLES

> Fuente: Secundaria.pdf, páginas 1203-1215 (versión en castellano).

TALLER DE RELACIONES DIGITALES RESPONSABLES

1. Presentación

La sociedad actual y los avances tecnológicos propician que la comunicación entre
personas y entidades se produzca de una manera creciente en entornos digitales en los cuales
el emisor y receptor no comparten el mismo tiempo y/o espacio y deja de percibirse otro tipo de
información. El hecho de no encontrarse presencialmente con la otra persona provoca un
empobrecimiento de la comunicación y otorga una mayor importancia al contenido y la forma de
los mensajes, ya que la ausencia del lenguaje no verbal puede llevar a interpretaciones no
deseadas e incluso derivar en un conflicto.

Esta materia aborda la necesidad de construir relaciones adecuadas con las demás
personas, ejerciendo conductas positivas que fomenten el respeto, también en la red. La base
de este respeto es el empleo de forma saludable de los dispositivos digitales, tomando conciencia
de que las interacciones que se realizan con ellos van conformando la huella digital y, por ende,
la propia identidad del alumnado en este medio. También se pone de relieve la importancia de
establecer una perspectiva crítica ante la constante recepción de información, que debe ser
tratada y seleccionada.

En esta materia se pretende, mediante un proceso de concienciación, que la relación por
medios digitales se efectúe con los mismos criterios que cuando se realiza presencialmente, en
cuanto a normas de educación, respeto, contenido y gestión emocional. En el caso de
comunicaciones audiovisuales, además se han de tener en cuenta multitud de factores
adicionales como la privacidad y el derecho de imagen, adquiriendo estos una mayor relevancia
si en ellas intervienen menores de edad.

La materia contribuye al logro de los objetivos de la educación básica mediante el
fortalecimiento de las capacidades afectivas en todos los ámbitos de la personalidad y en sus
relaciones con las demás personas, así como el rechazo a la violencia, a los prejuicios de
cualquier tipo, y a los comportamientos sexistas, y propone la resolución pacífica de los
conflictos. Se desarrollan aspectos tales como un desarrollo práctico, colaborativo y crítico, que
permita el crecimiento personal y académico, y el ejercicio de una ciudadanía digital democrática
que permita una interacción tolerante y solidaria, que respete las diferencias y rechace los
estereotipos que conducen a discriminación. También se favorecen las destrezas básicas en el
uso de fuentes de información de manera crítica como medio para adquirir conocimiento,
desarrollándose a su vez las competencias tecnológicas básicas necesarias. Además, alcanzar
los objetivos de la materia contribuye a afianzar los hábitos del cuidado y la salud.

Se pretende la consecución del doble objetivo de dotar al alumnado de las herramientas
imprescindibles para alcanzar un proyecto de vida personal, social y profesional satisfactorio, y
a la vez, de proporcionarle situaciones de aprendizaje significativas y reales para afrontar los
principales retos del S. XXI. Desde esta materia se abordan temas como la sostenibilidad, el
bienestar, el rechazo a la inequidad, estereotipos y exclusión o la resolución pacífica de conflictos
en entornos virtuales y el aprovechamiento crítico ético y responsable de la cultura digital, entre
otros.

En esta materia, el alumnado responde a los desafíos ecosociales del desarrollo
tecnológico mediante un consumo responsable y una sociedad en la que se minimice la brecha
digital. La materia favorece el análisis crítico y el aprovechamiento de las oportunidades que
ofrece la cultura digital, evaluando sus beneficios y riesgos y haciendo un uso ético y responsable
que contribuya al aprendizaje a lo largo de la vida. Esta materia proporciona estrategias para

manejar la incertidumbre que supone establecer relaciones sociales a través de las redes
resolviendo pacíficamente conflictos y valorando la diversidad personal y cultural. Contribuye al
desarrollo de la competencia clave personal, social y de aprender a aprender, ya que motiva al
alumnado a procurar su bienestar físico y emocional, así como a expresar empatía y gestionar
los conflictos. La materia contribuye, además. especialmente a desarrollar la competencia clave
digital, ya que implica el uso seguro, saludable, sostenible, crítico y responsable de las
tecnologías digitales para el aprendizaje y la participación en la sociedad. En el desarrollo de la
materia se moviliza el conjunto de conocimientos, destrezas, habilidades y actitudes que
permiten comprender, interpretar y valorar críticamente mensajes e informaciones evitando los
riesgos de manipulación y desinformación.

La materia Taller de Relaciones Digitales Responsables sigue los principios pedagógicos
de la LOMLOE, ya que las situaciones de aprendizaje planteadas abordan diferentes
capacidades del alumnado promoviendo unos hábitos saludables que lo ayuden en el
mantenimiento de una identidad digital adecuada, fomentando la comprensión y expresión oral,
escrita y audiovisual que, desde la educación y el respeto, estimulen y promuevan unas
relaciones digitales saludables y favorezcan la convivencia. Además, los conocimientos técnicos
adquiridos mejoran los aspectos de seguridad necesarios con el fin de salvaguardar tanto los
datos personales como la identidad digital y los dispositivos personales.

La materia tiene una dimensión eminentemente práctica que, a través de la búsqueda
de soluciones técnicas, la salvaguarda de la identidad y huellas digitales y unas normas básicas
de buenas prácticas, aborda retos cotidianos derivados de una sociedad cada vez más
dependiente de la socialización digital. Se le otorga el protagonismo a los y las estudiantes,
quienes de manera individual o en equipos de trabajo son capaces de movilizar los saberes
necesarios para conseguir éxito en los proyectos digitales propuestos. El enfoque competencial
implica el aprendizaje, la articulación y la movilización de conocimientos, destrezas y actitudes
de naturaleza interdisciplinar relacionados con el ámbito de la informática, la ética y la
comunicación lingüística y audiovisual.

En la Educación Primaria el alumnado realiza una toma de contacto con los dispositivos
conectados a la red iniciando de este modo un proceso de alfabetización digital. Es durante los
últimos años en esta etapa y los primeros de la Educación Secundaria Obligatoria cuando el
alumnado empieza a interactuar en entornos digitales, comenzando así una andadura por un
mundo desconocido en cuanto a sus normas y funcionamiento. En la materia Taller de
Relaciones Digitales Responsables se ayuda al alumnado a establecer una interacción
respetuosa, crítica y de bienestar personal y social en la red.  La materia Tecnología y
Digitalización comienza a abordar retos tecnológicos sencillos mediante el análisis de soluciones
tecnológicas, el uso de dispositivos, la búsqueda de información con sentido crítico o las
diferentes formas de expresión del conocimiento. Posteriormente, la materia Digitalización da
respuesta a la necesidad de adaptación a un entorno cambiante diseñando soluciones creativas
y accesibles desde una perspectiva integradora.

A continuación, se presentan los aprendizajes esenciales de la materia tomando como
ideas vertebradoras el aprendizaje en el uso de dispositivos, la búsqueda y selección de
información digital de manera crítica, la construcción, cuidado y protección de una identidad
digital adecuada, la promoción de actitudes que fomenten el bienestar en las relaciones a través
de entornos digitales.

Estos aprendizajes se concretan en cuatro competencias específicas, de carácter
técnico, educativo, personal, y social y ciudadano, respectivamente, y cuatro bloques de saberes
básicos interrelacionados. La primera competencia concierne al uso saludable y ético de los
dispositivos digitales. La segunda aborda, desde una perspectiva crítica, la búsqueda y selección

de la información. La tercera competencia tiene como foco los aspectos relacionados con la
identidad y la huella digital. Y la cuarta se centra en la interacción saludable en entornos digitales
a los que el alumnado se enfrenta en su ámbito personal, educativo y social. Por otra parte, las
últimas dos competencias refieren también a la gestión de las emociones a nivel personal y
social. Las cuatro competencias específicas están interrelacionadas y contribuyen directamente
a la adquisición y desarrollo de algunas competencias clave, especialmente la digital, la
ciudadana y la personal, social y de aprender a aprender.

Los saberes básicos necesarios para la adquisición y desarrollo de las competencias
específicas se organizan en cuatro bloques: dispositivos digitales e Internet; búsqueda,
selección, organización y creación de contenidos digitales; identidad digital; y relaciones en
entornos digitales.

Con el fin de articular los saberes mediante tareas significativas y relevantes para
resolver retos de manera autónoma y creativa y hacer así posible la adquisición y desarrollo de
las competencias específicas, en el apartado dedicado a las situaciones de aprendizaje se
presentan algunas directrices para diseñar de la forma más adecuada esas tareas conectándolas
con la realidad del alumnado para promover la transferencia de lo aprendido a situaciones
cercanas a su vida cotidiana. Siempre desde procesos pedagógicos flexibles y accesibles,
ajustados a las características y diferentes ritmos de aprendizaje del alumnado siguiendo los
principios del Diseño Universal para el Aprendizaje Accesible.

Por último, se establecen los criterios de evaluación para las cuatro competencias
específicas de la materia, en los que se especifican los aspectos más representativos del grado
de desarrollo competencial que se espera que el alumnado alcance mediante la movilización de
saberes básicos en las distintas situaciones de aprendizaje.

2. Competencias específicas

2.1.
Competencia específica 1

Utilizar dispositivos digitales de uso personal en el entorno doméstico y educativo de
manera saludable, segura y sostenible.

2.1.1
Descripción de la competencia 1

Existe una gran variedad de dispositivos móviles y personales como relojes inteligentes
o electrodomésticos, además de los ordenadores personales, con los que la mayoría de los
miembros de la sociedad actual, incluido el alumnado, interaccionan cada día. Estos dispositivos
normalmente se utilizan en red, conectados entre sí o a Internet a través de diferentes modos de
acceso. Su uso puede conllevar la cesión de información personal, lo que implica unos riesgos,
pero también unos beneficios, que se deben valorar y asumir conscientemente. Por este motivo,
es necesario tener unas nociones básicas sobre su funcionamiento y características más
importantes que ayuden a seleccionar qué dispositivo es el más adecuado, qué componente ha
de incorporar o cómo conectarlo de forma segura a Internet, y qué implicaciones tiene su uso
para la salud y para cubrir las necesidades en el entorno doméstico y educativo.

Con el desarrollo de esta competencia se favorece la selección y uso correcto de los
dispositivos teniendo en cuenta sus parámetros técnicos y las implicaciones ecosociales y
éticas. También se pretende que el alumnado sepa movilizar los aprendizajes adquiridos para
responder a los desafíos ecosociales, en los que se conjugan las necesidades tecnológicas con
los efectos de la tecnología sobre el medioambiente y se movilizan saberes relacionados con el
consumo responsable, la vida saludable y la situación de inequidad y exclusión que supone la
brecha digital. Además, se examinan las causas de la brecha digital y se valoran sus posibles
soluciones. El consumo desmesurado de tecnología, el impacto ambiental o la obsolescencia

programada son cuestiones que se abordan también en esta competencia, con la que más allá
de mostrar configuraciones de equipos, se pretende contribuir a la adquisición de hábitos de
buen uso y de seguridad para proteger los dispositivos y la información.

2.2. Competencia específica 2

Buscar y seleccionar críticamente información digital de distintas fuentes, interpretarla,
organizarla en el entorno personal de aprendizaje y crear contenidos digitales.

2.2.1
Descripción de la competencia 2

Esta competencia abarca aspectos básicos relacionados con la alfabetización
informacional, el aprovechamiento apropiado de las estrategias de búsqueda y tratamiento de
información, y la generación de nuevo conocimiento. La posibilidad de acceder al ingente
volumen de información disponible en Internet exige que el alumnado desarrolle una actitud
crítica frente a los contenidos que encuentra, proporcionándole esta materia los criterios y
herramientas que le permiten filtrar y analizar la veracidad de la información para poder
organizarla de acuerdo con sus objetivos y necesidades, en el ámbito personal y educativo. El
alumnado ha normalizado el acceso a contenidos en línea y es importante que sea consciente
de las estrategias existentes tras ellos. En buscadores, contenidos o aplicaciones específicas se
puede incitar al consumo de ciertos contenidos sin control alguno sobre su significado ni
adecuación al público que puede acceder a ellos. Por ello, se debe fomentar en el alumnado de
estas edades el pensamiento crítico. Adicionalmente a la búsqueda y la organización de la
información, en esta competencia también se abordan pautas básicas para crear contenidos
digitales con sentido estético mediante herramientas de autoría.

En suma, mediante esta materia el alumnado adquiere estrategias para seleccionar e
interpretar con sentido crítico la información obtenida tras la búsqueda en diferentes medios
digitales, contrastando su veracidad, lo que permite detectar los discursos de odio y reconocer
la importancia de las noticias falsas en la desinformación de la sociedad. Además, toma
conciencia del método de redireccionamiento hacia ciertos contenidos de las plataformas
audiovisuales o buscadores con la intención de afianzar su pensamiento crítico. El alumnado
también es capaz de integrar la información seleccionada en el entorno personal de aprendizaje
y de utilizarla respetando los derechos de autoría para componer contenidos digitales con sentido
estético.

2.3. Competencia específica 3

Construir una identidad digital adecuada y aplicar estrategias básicas para cuidarla y
protegerla.

2.3.1.
Descripción de la competencia 3

Esta competencia específica ayuda a gestionar eficazmente la identidad digital teniendo
en cuenta la imagen que se proyecta, la huella que se deja y la carga emocional subyacente. El
alumnado está construyendo su identidad en entornos digitales y es necesario que lo haga
gestionando adecuadamente los factores socioculturales que pueden influir, el concepto que
tienen de sí mismos y la percepción externa que se proyecta de ellos y ellas. La exposición
personal en la red también se debe controlar debido a que la información publicada es fácilmente
distribuible y su difusión puede acarrear consecuencias negativas. Por esta razón, es necesario
concienciar de los riesgos y las consecuencias que implica la difusión de contenido en entornos
digitales desarrollando conductas y hábitos que permitan preservar una identidad digital
adecuada.

Con esta competencia específica se contribuye significativamente al aprovechamiento
crítico, ético y responsable de la cultura digital mediante el desarrollo de situaciones de

aprendizaje en las que el alumnado puede constatar la facilidad y rapidez con la que cualquier
publicación que se hace en Internet llega a cualquier punto del planeta. Pero también cómo afecta
la globalización de la red a la información que en ella se encuentra desde el punto de vista
personal, social, emocional, cultural, del bienestar y de la integridad. Una vez se ha llegado a
este punto, se deben abordar retos como la gestión de la incertidumbre, la igualdad, la equidad
y la inclusión con el alumnado.

En resumen, mediante esta competencia el alumnado entiende cómo se gestiona su
identidad en Internet y toma conciencia de la huella que deja, analizando críticamente su impacto
posterior. Se le proporcionan mecanismos para gestionar adecuadamente la exposición en la
red, para reconocer qué implicaciones tiene la difusión de información personal en Internet y
adoptar conductas básicas que protejan la identidad digital y los datos personales.

2.4. Competencia específica 4

Mostrar hábitos básicos que fomenten el bienestar en las relaciones a través de entornos
digitales.

2.4.1. Descripción de la competencia 4

El bienestar personal en los entornos digitales es fundamental para un desarrollo
adecuado durante la adolescencia. El equilibrio entre el uso de dispositivos digitales y el resto de
las actividades cotidianas, al igual que las interacciones y relaciones personales respetuosas y
enriquecedoras en todos los contextos de actividad, ayuda a conseguirlo. El falso anonimato o
la presión del grupo en los entornos de comunicación pueden dar lugar a conductas inapropiadas
que se deben prevenir por todas las personas directa o indirectamente implicadas. Las
repercusiones de los actos llevados a cabo en la red pueden causar daños graves con una
duración indeterminada. Los primeros contactos con personas desconocidas a través de Internet
suelen darse a través de juegos en línea, lo que puede implicar el intercambio de información
sensible. Por estas razones, esta materia contempla las actitudes positivas que se deben seguir
en el juego en línea y los riesgos asociados. Estos escenarios conectan con el pensamiento
crítico que se debe desarrollar antes de enfrentarse a otros servicios de Internet más complejos
como las redes sociales. Además, cuestiones relacionadas con la amistad digital, las adicciones,
la nomofobia, los diferentes tipos riesgos en la red como el ciberacoso, así como la
responsabilidad legal de las actuaciones, son saberes que se movilizan en el desarrollo de esta
competencia específica.

La incertidumbre que supone establecer las primeras relaciones sociales a través de las
redes es un desafío que esta competencia específica ayuda a manejar con una actitud positiva
articulando las estrategias que persiguen la resolución pacífica de los conflictos valorando la
diversidad personal y cultural. Al igual que en el resto de competencias específicas de esta
materia, el aprovechamiento crítico de la cultura digital, evaluando sus beneficios y riesgos, está
relacionado con esta competencia, y los hábitos que se desarrollan ayudan a aprender a
aprender, ya que las relaciones en la red también son una constante en la vida adulta.

En síntesis, mediante esta competencia específica el alumnado conoce diferentes
herramientas de comunicación y diversas conductas en línea, las implicaciones que conllevan y
reflexiona sobre ellas. El alumnado es capaz de mantener una actitud respetuosa en sus
interacciones en la red y aplica mecanismos para resolver conflictos en entornos virtuales con
un nivel de autonomía creciente. El alumnado toma conciencia de la existencia de riesgos y
amenazas en la red y sabe desplegar actuaciones básicas para prevenir, extinguir y minimizar

sus efectos. Además de cuidar el bienestar emocional, con el desarrollo de esta competencia el
alumnado es capaz de prevenir su salud física y mental ante el uso continuado de dispositivos
digitales.

3. Conexiones de las competencias específicas entre sí, con las competencias de otras
materias y con las competencias clave

3.1.
Relaciones o conexiones con las otras CE de la materia

A continuación, se presentan de forma sucinta las relaciones que mantienen entre sí las
cuatro competencias específicas de la materia.

3.1.1.
Competencia Específica 1

La CE 1 versa sobre la selección y el uso de los dispositivos digitales a través de los
cuales el alumnado se relaciona en la red. En este caso, la relación se establece
fundamentalmente con la CE 2 porque cada dispositivo y medio de acceso a Internet dispone de
un catálogo distinto de herramientas y funcionalidades.

3.1.2.
Competencia Específica 2

La selección de información tras una búsqueda crítica es útil a la hora de componer
nuestra identidad digital sobre la base de la veracidad, lo que conecta directamente esta
competencia con la CE 3. Asimismo, en la medida que permite descartar informaciones erróneas
o malentendidos para preservar las relaciones personales en línea, se relaciona también de
manera estrecha con la CE 4.

3.1.3.
 Competencia Específica 3

La manera en que cada individuo interpreta la información que encuentra en Internet
relaciona directamente esta competencia con la CE 2. La seguridad que proporciona un
determinado dispositivo electrónico puede ayudar a salvaguardar información sensible, y de esta
forma, a preservar la identidad digital. El seguimiento adecuado de unas normas básicas
contribuye también a disfrutar de unas relaciones saludables en la red y a proteger la identidad
digital, por lo que la relaciona con la CE 4.

3.1.4.
Competencia Específica 4

Las relaciones que se establecen en la red contribuyen a la construcción de una
identidad, por lo que la CE 3 y la CE 4 están interconectadas.

3.2.
Relaciones o conexiones con las CE de otras áreas/materias de la etapa

La materia Taller de Relaciones Digitales Responsables aborda aspectos éticos,
tecnológicos y de expresión y comprensión de los mensajes extraídos de la información difundida
en la red, lo que hace que las competencias específicas mantengan relaciones estrechas con las
de otras materias de los ámbitos lingüístico, ético, artístico y tecnológico.

3.2.1.
Competencia Específica 1

Esta competencia específica guarda relación directa con las de las materias de primer y
tercer curso Tecnología y Digitalización I y II, las materias de opción Digitalización de cuarto
curso y Tecnología también de cuarto curso, así como con la materia también optativa
Inteligencia artificial, programación y robótica I y II de segundo y tercer curso, en lo que respecta
al uso seguro, responsable y sostenible de dispositivos digitales en el entorno personal y
educativo.

3.2.2.
Competencia Específica 2

La CE 2 se relaciona estrechamente con las competencias específicas del ámbito
lingüístico que ponen el foco en la capacidad de entender los mensajes que contienen la
información localizada en las fuentes consultadas en la red. El ámbito artístico cobra una mayor
relevancia en su relación con esta competencia cuando los mensajes son de naturaleza
audiovisual, y con el ámbito ético en lo que concierne a la creación de contenidos inclusivos y no
discriminatorios.

3.2.3.
Competencia Específica 3

Esta competencia guarda relación directa con el área artística y la materia optativa
Digitalización de cuarto curso. Por un lado, la identidad digital y su huella se ven afectadas por
la imagen y la percepción que los demás tengan de las publicaciones realizadas en la red,
muchas de ellas audiovisuales. Y, por otro lado, el uso seguro, responsable y sostenible de los
dispositivos digitales en el entorno personal y educativo ayuda a la salvaguarda de ambas.

3.2.4.
Competencia Específica 4

La CE 4 se relaciona estrechamente con las competencias específicas del ámbito
lingüístico y ético asociadas a la capacidad de entender y hacerse entender a nivel escrito y oral,
y la gestión de las emociones, la mediación y el debate adecuados, respectivamente.

3.3.
Relaciones o conexiones con las competencias clave

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 |  |  | X | X |  |  |  |  |
| CE2 | X | X |  | X | X |  |  | X |
| CE3 |  |  |  | X | X | X |  |  |
| CE4 |  |  |  | X | X | X |  |  |

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

−
CCL: competencia en comunicación lingüística
−
CP: competencia plurilingüe
−
CMCT: competencia matemática, ciencia y tecnológica
−
CD: competencia digital
−
CPSAA: competencia personal, social y de aprender a aprender
−
CC: competencia ciudadana
−
CE: competencia emprendedora
−
CCEC: competencia en conciencia y expresión culturales

Las cuatro competencias específicas de la materia Taller de Relaciones Digitales
Responsables promueven el desarrollo de la competencia clave digital, ya que implican el uso
creativo, crítico y seguro de las tecnologías de la información y de la comunicación para alcanzar
los objetivos relacionados con el buen uso de la información que se publica en las redes. Más
allá de esta conexión, se señalan seguidamente las otras conexiones relevantes de las
competencias específicas de la materia con el resto de las competencias clave.

3.3.1.
Competencia Específica 1

Las características y funcionalidades de los dispositivos electrónicos que se utilizan en
la búsqueda de información, la creación de contenido, el ocio y el establecimiento de relaciones
en la red hacen que esta competencia específica contribuya especialmente a la adquisición de
la competencia clave digital. En la medida en que se utilizan los procedimientos y métodos
propios de la ingeniería en la toma de decisiones para transformar el entorno de forma
comprometida, responsable y sostenible, también contribuye a la adquisición de la competencia
clave matemática y en ciencia, tecnología e ingeniería.

3.3.2.
Competencia Específica 2

Conecta estrechamente con las competencias clave en comunicación lingüística y
plurilingüe, ya que su desarrollo implica localizar, seleccionar y contrastar información
procedente de diferentes fuentes evaluando su fiabilidad y pertinencia y evitando los riesgos de
manipulación y desinformación. Además, el alumnado integra y transforma esta información en
conocimiento en su entorno personal de aprendizaje. Esta competencia favorece el análisis
crítico y el aprovechamiento de las oportunidades que ofrece la cultura digital y la confianza en
el conocimiento como motor de desarrollo. La evaluación de sus beneficios, riesgos y su uso
ético y responsable contribuye a desarrollar la competencia clave personal, social y de aprender
a aprender. La alfabetización informacional, la educación mediática o la creación de contenidos
digitales que recoge la competencia clave digital se abordan igualmente en esta competencia
específica. Por otra parte, en los procesos creativos que potencia se utilizan distintas
representaciones y expresiones artísticas en diversos medios con distintas técnicas digitales
fundamentales, lo que contribuye al desarrollo de la competencia clave en conciencia y expresión
culturales.

3.3.3.
Competencia Específica 3

Esta competencia específica guarda relación directa con la competencia clave digital por
el uso seguro, saludable, crítico y responsable de los dispositivos digitales. También se trabaja
la alfabetización en información y datos, la educación mediática, la creación de contenidos
digitales y la propiedad intelectual. Además, se relaciona con la competencia clave personal,
social y de aprender a aprender por la capacidad de reflexionar sobre uno mismo para
autoconocerse y su contribución al bienestar mental y emocional propio y de las demás personas.
Y, por último, la participación en la toma de decisiones y resolución de los conflictos de forma
dialogada, respetuosa y democrática la relaciona directamente con la competencia clave
ciudadana.

3.3.4.
Competencia Específica 4

Esta competencia específica motiva al alumnado a procurar el bienestar físico y
emocional propio y el de las demás personas. La identificación de conductas contrarias a la
convivencia y el desarrollo de estrategias con las que superarlas hacen que esta competencia
específica se relacione directamente con la competencia clave personal, social y de aprender a
aprender.  Adicionalmente, en la medida en que se abordan los conflictos en un contexto
integrador y de apoyo, se vincula también con la competencia clave ciudadana. Por último, se
relaciona también con la competencia clave digital debido a la utilización segura, crítica y
responsable de las tecnologías digitales para la interacción y la participación en la sociedad que
promueve.

4. Saberes básicos

4.1. Introducción.

Mientras que las competencias específicas identifican las actuaciones o tipos de
actuaciones que el alumnado debe desplegar en determinadas situaciones, los saberes básicos
son los conocimientos, destrezas, actitudes, habilidades y valores cuyo aprendizaje es necesario
para la adquisición y desarrollo de dichas competencias, conformando ambos los contenidos
propios de la materia. Esta materia articula saberes relativos a la protección e integridad de la
imagen que las personas crean en la red y que perdura aún después de su desaparición. Así
pues, los saberes básicos de la materia Taller de Relaciones Digitales Responsables han sido
agrupados en cuatro bloques que identifican los contenidos que el alumnado debe aprender,
articular y movilizar para las cuatro competencias específicas.

El primer bloque, denominado Dispositivos digitales e Internet, incluye los contenidos
necesarios para poder conocer las características de los distintos tipos de dispositivos digitales
y cómo utilizarlos de manera segura y sostenible. La búsqueda y selección de información
contrastada de fuentes fiables, la interpretación con el fin de detectar su veracidad y la posterior
organización y edición de contenidos digitales constituyen el segundo bloque de saberes básicos
llamado Búsqueda, selección, organización y creación de contenidos digitales. En el tercer
bloque, Identidad digital, se conjugan saberes que permiten construir, cuidar y proteger la
identidad digital de una persona y la huella digital asociada a la misma. Y finalmente, el cuarto
bloque, denominado Relaciones en entorno digital fomenta el bienestar en las relaciones que
tienen lugar en la red mediante la adopción de unas estrategias y normas básicas de conducta.

4.2. Bloque 1: Dispositivos digitales e Internet. CE 1

CONTENIDOS

Ordenador personal, dispositivos móviles y otros dispositivos de uso doméstico y
educativo.

Funcionamiento básico y características más importantes de los dispositivos digitales.

Sistemas operativos comunes y aplicaciones.

Redes de dispositivos. Fundamentos y modos de acceso a Internet.

La brecha digital.

Hábitos básicos de seguridad para proteger los dispositivos.

Implicaciones del uso de los dispositivos digitales para la salud, la sostenibilidad y el medio
ambiente. Obsolescencia.

4.3. Bloque 2: Búsqueda, selección, organización y creación de contenidos
digitales. CE 2

CONTENIDOS

Tipos de buscadores web y sus herramientas de filtrado.

Selección de información en medios digitales a través de buscadores web contrastando su
veracidad.

Lectura e interpretación de información de medios digitales.

Propiedad intelectual y derechos de autoría.

Detección de noticias falsas, bulos y discursos de odio. Implicaciones sociales.

Organización de la información. Operaciones básicas con archivos y carpetas.

Personalización del entorno de trabajo.

Creación básica de contenidos con herramientas digitales.

Estética y lenguaje audiovisual.

4.4. Bloque 3: Identidad digital. CE 3

CONTENIDOS

La identidad personal en Internet. Alias y avatares.

Autoconcepto y percepción externa de la identidad digital.

Referencias socioculturales en la construcción de la identidad digital. Personas influyentes.

Exposición personal en la red. La huella digital.

Conductas y hábitos para cuidar la identidad digital.

La privacidad en la red. La protección de los datos de carácter personal. Información y
consentimiento.

4.5. Bloque 4: Relaciones en entorno digital. CE 4

CONTENIDOS

Amistad virtual y física.

Entornos digitales de intercambio social y juegos en línea.

Estrategias para una ciberconvivencia igualitaria, segura y saludable. Etiqueta digital.

Ventajas y beneficios de las interacciones en entorno digital

Riesgos y amenazas del uso de dispositivos y relaciones en red: ciberacoso y fraudes.

Adicciones: tecnoadicción, nomofobia y ludopatía en línea.

5. Situaciones de aprendizaje para el conjunto de las competencias de la materia

El diseño de las situaciones de aprendizaje debe ofrecer la posibilidad de generalizar los
aprendizajes y adquirir otros nuevos mediante la realización de tareas que movilizan los
conocimientos, destrezas, habilidades y actitudes implicados en el desarrollo de las
competencias específicas. Las actividades que se planteen en las situaciones de aprendizaje
deben tener las características adecuadas para asegurar el nivel de desarrollo competencial que
indican las competencias específicas.

Con la intención de diseñar situaciones de aprendizaje que sean relevantes, se propone
combinar una serie de elementos que se enumeran a continuación de forma que finalmente se
obtenga el modelo de una situación adecuada de aprendizaje.

En el diseño de las situaciones de aprendizaje se especificarán claramente los objetivos
que se pretenden conseguir, enumerando los pasos para abordar las actividades y tareas. En un
primer momento, el papel del profesorado será el de guía y, paulatinamente, irá cambiándolo por
el de observador, que en ocasiones puntuales y justificadas cambiará para hacer aportaciones
que sirvan para mejorar o reconducir el trabajo autónomo del alumnado o del equipo. Esa
retroalimentación del profesorado tiene como finalidad corregir errores, mejorar el desempeño
del alumnado y afianzar los procedimientos y sus respuestas correctas con el fin de que el
alumnado conozca su rendimiento actual, identifique como puede mejorarlo y aprenda a
autorregularse en la ejecución de las tareas. Es conveniente incluir en la práctica docente el
proceso metacognitivo, facilitando que el alumnado reflexione sobre qué ha aprendido y cómo lo
ha hecho, y promoviendo la adquisición de las estrategias, procedimientos, recursos y técnicas
que le ayudarán a saber qué ha hecho bien y por qué, así como qué debe mejorar y de qué
manera.

Se plantearán retos basados en situaciones reales o cercanas a las que el alumnado
pueda enfrentarse o se haya enfrentado en algún momento de sus vidas con el fin de que den
lugar a experiencias auténticas y motivadoras. Dichas situaciones pueden suponer una alta carga
emocional para el alumnado de forma individual y para el grupo en su conjunto, por lo que el
profesorado ha de ser consciente de este aspecto y gestionarlo adecuadamente. Debido a que
este taller aborda las relaciones entre personas, las dinámicas que se llevan a cabo en el aula
deben ser grupales en la mayoría de las ocasiones, con la ayuda del aprendizaje dialógico, la
tutoría entre iguales o la mediación como posibles estrategias para que el alumnado llegue a
conclusiones aumentando progresivamente su autonomía. La aceptación de la diversidad como
fuente generadora de sinergias facilita que el alumnado asuma los beneficios de situaciones
diseñadas siguiendo los principios del Diseño Universal para el Aprendizaje que persigue la
presencia, participación y aprendizaje de todo el alumnado, ajustándose a sus características y
diferentes ritmos de aprendizaje. Es aconsejable que se promuevan diversos modos de
expresión y representación del conocimiento, que se valore y reconozca lo que se aprende fuera

del aula, y que se incluyen instrucciones claras y precisas de las actividades y tareas que tienen
que llevar a cabo los participantes.

Las situaciones de aprendizaje deben vincular las competencias y los saberes básicos,
favoreciendo la realización de nuevos aprendizajes y planteando nuevas perspectivas que se
pueden encontrar en otras materias o fuera del contexto escolar. Por eso, el diseño de las
situaciones de aprendizaje de esta materia se puede plantear como punto de partida de un
trabajo interdisciplinar en el que los retos elaborados también puedan trabajarse desde otras
materias e incluso con la colaboración de entidades externas en actividades complementarias.

6. Criterios de evaluación

6.1. Competencia específica 1. Criterios de evaluación

CE 1. Utilizar dispositivos digitales de uso personal en el entorno doméstico y educativo
de manera saludable, segura y sostenible.

1º ESO

1.1. Identificar características básicas de los dispositivos digitales de uso personal en el
entorno doméstico y educativo.

1.2. Determinar qué dispositivo y modo de acceso a Internet es el más adecuado a las
necesidades.

1.3. Conectar dispositivos digitales a Internet de manera segura.

1.4. Reconocer las implicaciones del uso y consumo de tecnología sobre la salud y el
medio ambiente.

1.5. Mostrar hábitos básicos de seguridad para proteger los dispositivos.

6.2. Competencia específica 2. Criterios de evaluación

CE 2. Buscar y seleccionar críticamente información digital de distintas fuentes,
interpretarla, organizarla en el entorno personal de aprendizaje y crear contenidos digitales.

1º ESO

2.1. Buscar, seleccionar e interpretar información en función de las necesidades a partir
de diversas fuentes con sentido crítico, contrastando su veracidad.

2.2. Reconocer la importancia de las noticias falsas en la desinformación de la sociedad.

2.3. Detectar los discursos de odio y reconocer sus implicaciones en el desarrollo de la
sociedad.

2.4. Identificar y describir las estrategias subyacentes a la difusión y al consumo de
contenido en línea.

2.5.  Organizar y gestionar el entorno personal de aprendizaje mediante la integración
de recursos digitales.

2.6.  Crear, integrar y editar contenidos digitales con sentido estético de manera creativa
y respetando los derechos de autoría.

6.3. Competencia específica 3. Criterios de evaluación

CE 3. Construir una identidad digital adecuada y aplicar estrategias básicas para cuidarla
y protegerla.

1º ESO

3.1. Identificar y valorar diferentes formas de representar la identidad en Internet y la
huella digital que dejan.

3.2. Gestionar adecuadamente el autoconcepto y la percepción externa a través de la
imagen personal en entornos digitales.

3.3. Reconocer las implicaciones de la publicación de datos personales en la red.

3.4. Adoptar conductas básicas que protejan la identidad digital y los datos personales.

6.4. Competencia específica 4. Criterios de evaluación

CE 4. Mostrar hábitos básicos que fomenten el bienestar en las relaciones a través de
entornos digitales.

1º ESO

4.1. Analizar el funcionamiento de plataformas de interacción social y juego en red.

4.2. Adoptar conductas básicas que fomenten relaciones personales respetuosas y
enriquecedoras.

4.3. Comprender y aprovechar las ventajas de las interacciones en entorno digital.

4.4. Identificar y saber reaccionar de manera básica ante situaciones que representen
comportamientos abusivos o amenazas a través de dispositivos digitales valorando el bienestar
personal y colectivo.

4.5. Tomar medidas básicas de prevención ante el uso continuado de dispositivos
digitales.

4.6. Mostrar empatía hacia los miembros del grupo reconociendo sus aportaciones y
estableciendo un diálogo igualitario e inclusivo para resolver conflictos y discrepancias.
