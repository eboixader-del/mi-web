# TECNOLOGÍA

> Fuente: Secundaria.pdf, páginas 973-991 (versión en castellano).

TECNOLOGÍA

1. Presentación

La tecnología es, especialmente en el momento actual, uno de los factores más determinantes de la
transformación integral de la sociedad en que vivimos y, por ende, de las distintas consecuencias y soluciones
que sobre las problemáticas globales y locales se generan.  Su importancia en nuestras vidas es creciente y
cada vez más relevante ante los desafíos y retos que, de forma recurrente y continua, se deben abordar en
busca de soluciones. Por ello, la materia de Tecnología ofrece recursos para contribuir y participar
activamente de esa transformación con criterios técnicos, científicos y éticos que fomenten el desarrollo
tecnológico y mejoren nuestras sociedades, minimizando las repercusiones negativas que su desarrollo
puede tener para las mismas.

La contribución de la materia al logro de los objetivos de etapa es muy relevante para la mayor parte
de ellos, pero especialmente para el de desarrollar las competencias tecnológicas básicas y avanzar en una
reflexión ética sobre su funcionamiento y utilización. El desarrollo de actividades de aprendizaje mediante
metodologías como el método de proyectos favorece, por lo demás, el desarrollo del espíritu emprendedor y
la confianza en sí mismo, la participación, el sentido crítico, la iniciativa personal y la capacidad para aprender
a aprender, planificar, tomar decisiones y asumir responsabilidades.

La materia propicia una valiosa oportunidad para considerar los desafíos del siglo XXI a los que nos
enfrentamos como sociedad, y que condicionan al alumnado a la hora de desarrollar sus proyectos vitales,
sociales y profesionales, como, por ejemplo, la aceptación de las cada día más recurrentes situaciones de
incertidumbre a las que hacer frente con la confianza en el conocimiento como motor del desarrollo. Siempre
desde dentro de un marco ético, con responsabilidad y sostenible, fomentando una ciudadanía comprometida
en actuar en el entorno próximo para abrir horizontes y empatizar con situaciones problemáticas más lejanas
o globales.

En el desarrollo de esta materia se abordan aspectos económicos, sociales y ambientales
relacionados con la influencia del desarrollo tecnológico, y de la automatización y robotización, tanto en la
organización del trabajo, como en otros ámbitos de la sociedad, útiles para la gestión de la incertidumbre ante
situaciones de inequidad y exclusión, favoreciendo la igualdad de oportunidades entre mujeres y hombres.
Por otro lado, la tecnología proporciona medios esenciales para abordar los Objetivos de Desarrollo
Sostenible como el acceso universal a la energía asequible y no contaminante, lograr que las ciudades y los
asentamientos humanos sean inclusivos, seguros y sostenibles, o garantizar modalidades de consumo y
producción también sostenibles entre otros. La accesibilidad es también un componente necesario del
proceso tecnológico, pues, quien diseña ha de tener en cuenta las diferentes necesidades, contemplando la
diversidad y favoreciendo así la inclusión efectiva de todas las personas en una sociedad moderna y plural.

La contribución a la adquisición de las competencias clave está especialmente relacionada con la
competencia matemática y en ciencia, tecnología e ingeniería. La otra competencia clave a la que se realiza
una importante contribución es la Digital. La aplicación de aprendizajes relacionados con bloques de
contenidos como el Pensamiento Computacional, la robótica o la inteligencia artificial contribuye a que el
grado de desarrollo de esta competencia sea el adecuado. De forma también relevante y fundamentalmente
por el desarrollo de proyectos en grupo en los que afrontar constructivamente los nuevos retos que se les
planteen en las diferentes situaciones de aprendizaje, esta materia contribuye a la competencia
emprendedora, y a la competencia personal, social y aprender a aprender. De forma más transversal,
contribuye al desarrollo de las competencias lingüística y plurilingüe.

Desde un enfoque didáctico fundamentalmente práctico que favorece la implicación, el alumnado
tiene la oportunidad de afrontar retos, desafíos o necesidades en torno a situaciones de aprendizaje bien
diseñadas, para las que el desarrollo de proyectos es una alternativa prioritaria. Así, se explora, se analizan
objetos y productos, se investiga, se planifica y se crea. Para ello, se implementan diferentes tecnologías y
técnicas de fabricación, el diseño, la simulación, la comunicación o la difusión de ideas o soluciones. Por

último, algo que debe estar presente en todas las actividades, se reflexiona sobre lo que se hace de manera
que se potencien las habilidades y estrategias metacognitivas. La exigencia de conectar distintos
conocimientos interdisciplinares, técnicas y procesos en la búsqueda de soluciones con el propósito de
satisfacer necesidades o deseos de las personas hace de la tecnología una materia idónea para favorecer
aprendizajes significativos y duraderos.

En la etapa de Educación Primaria el alumnado ya se ha iniciado en realizar proyectos guiados de
diseño utilizando operadores tecnológicos sencillos para dar solución a problemas concretos, así como en
desarrollar el pensamiento computacional. Esto proporciona la base sobre la que se profundiza en la materia
de Tecnología y Digitalización en la Educación Secundaria Obligatoria, consolidando las competencias
digitales y tecnológicas que, a su vez, tienen continuidad en esta materia y que seguirá desarrollando en
estudios posteriores o en el desempeño de actividades profesionales.

A continuación, se presentan los aprendizajes esenciales en Tecnología que se espera que alcance
el alumnado que curse esta materia tomando como ideas vertebradoras el método de resolución de problemas
basado en el desarrollo de proyectos, el carácter eminentemente práctico de la materia, su naturaleza
transversal, el impulso de la colaboración y el trabajo en equipo, la importancia del pensamiento
computacional, y el fomento de actitudes de perseverancia y responsabilidad relativas al desarrollo sostenible.

Se formulan seis competencias específicas, de las que se proporciona posteriormente una explicación
más extensa en la descripción. Todas ellas mantienen conexiones entre sí, con las del resto de las materias
de la etapa y con algunas de las competencias clave, que se presentan también brevemente.

Los saberes básicos exigidos para la adquisición y desarrollo de las competencias específicas se
organizan en cinco bloques: proceso de resolución de problemas; operadores tecnológicos; pensamiento
computacional, automatización y robótica; instalaciones en viviendas, y tecnología sostenible.

Con el fin de articular los saberes mediante tareas significativas y relevantes para resolver retos de
manera autónoma y creativa, en el apartado dedicado a las situaciones de aprendizaje se presentan algunas
directrices para diseñar de la forma más adecuada ese contexto y promover la transferencia de lo aprendido
a situaciones cercanas a la vida real. Siempre desde procesos pedagógicos flexibles y accesibles, ajustados
a las características y diferentes ritmos de aprendizaje del alumnado y siguiendo los principios del Diseño
Universal de Aprendizaje Accesible.

Por último, se formulan unos criterios de evaluación para cada competencia específica, en los que se
precisan los aspectos más representativos del grado de desarrollo competencial que se espera que el
alumnado alcance mediante el aprendizaje, la articulación y la movilización de los saberes básicos en
diferentes situaciones.

2. Competencias específicas

2.1. Competencia específica 1

|  | Identificar problemas tecnológicos a partir del estudio de las necesidades presentes en el entorno |
| --- | --- |
| próximo, formular propuestas para abordarlos, y resolverlos de manera eficiente e innovadora mediante |  |
| procesos de trabajo colaborativo y utilizando estrategias propias del método de proyectos. |  |

2.1.1. Descripción de la competencia 1

Esta competencia parte del estudio de las necesidades del entorno cercano (centro, barrio, localidad,
región...) para detectar y abordar los problemas tecnológicos encontrados que, posteriormente y tras su
análisis, serán la base del proceso de resolución de problemas, aportando soluciones novedosas y útiles en
respuesta a las necesidades detectadas. Que pueden exigir resolver problemas sencillos del ámbito
tecnológico transfiriendo y aplicando saberes interdisciplinares. Se incluyen en esta competencia los aspectos
relativos a la participación colaborativa en equipos de trabajo para conseguir metas comunes asumiendo
diversos roles con eficacia y responsabilidad, así como demostrando empatía y utilizando el diálogo para

resolver conflictos y discrepancias. Esta competencia hace referencia también a las propuestas para abordar
los problemas tecnológicos, a la generación de ideas y a la planificación de tareas, cuya gestión debe
desembocar en una solución tecnológica de manera eficiente, accesible, sostenible e innovadora en un
proceso iterativo.

La toma de decisiones ha de considerar principios éticos y realizarse con sentido crítico, de manera
que los problemas tecnológicos propuestos y sus posibles soluciones repercutan positivamente y transformen
ecosocialmente el entorno. Además, se ha de mostrar una actitud de presencia en la realidad, de atención y
de hacerse preguntas con el fin de identificar las necesidades que deben ser resueltas. Finalmente, fomentar
el espíritu emprendedor implica adoptar un enfoque que incluye el liderazgo y la coordinación de equipos de
trabajo, con una visión global y un tratamiento coeducativo, garantizando el desarrollo de la iniciativa y la
proactividad.

2.2. Competencia específica 2

Fabricar soluciones tecnológicas utilizando los conocimientos interdisciplinares, las técnicas y los
recursos disponibles de forma apropiada y segura para dar una respuesta satisfactoria a las necesidades
planteadas.

2.2.1. Descripción de la competencia 2

Esta competencia hace referencia al proceso de fabricación de productos o desarrollo de sistemas
que aportan soluciones accesibles y sostenibles tanto a las necesidades y problemas planteados como a las
actuaciones implicadas en dicho proceso. Se relaciona con el saber hacer, y está siempre conectada con el
entorno, con los recursos naturales, así como con los recursos y técnicas disponibles. Permite materializar
los más diversos objetos o sistemas gracias a la convergencia de diversos conocimientos y al uso seguro y
responsable de diferentes técnicas de fabricación.

Se abordan las técnicas y procedimientos necesarios para la construcción y creación de productos o
sistemas tecnológicos, incluyendo tanto la fabricación manual como la fabricación mediante tecnologías
asistidas por ordenador. De esta forma, se pretende que el alumnado adquiera las destrezas necesarias para
la creación de productos, fomentando la aplicación de técnicas de fabricación digitales, el aprovechamiento
de los recursos tecnológicos y el cumplimiento de las medidas de seguridad. Las distintas actuaciones que
se desencadenan en el proceso de creación implican la intervención de saberes propios de esta materia
(operadores mecánicos, eléctricos y electrónicos), que se integran con saberes de otras materias,
contribuyendo así a un aprendizaje competencial en el que intervienen distintos ámbitos curriculares.

Por otro lado, esta competencia fomenta la iniciativa para emprender y proponer acciones mostrando
curiosidad e interés mientras se desarrolla el proceso de fabricación, lo cual supone flexibilidad para adaptarse
y buscar soluciones alternativas a los problemas que van surgiendo durante el proceso. También incluye la
necesidad de hacer un uso responsable de los materiales, así como de proponer medidas de reducción,
reutilización y reciclaje de materiales durante el proceso de fabricación.

2.3. Competencia específica 3

Expresar, difundir e interpretar ideas, propuestas o soluciones tecnológicas de manera efectiva,
empleando los recursos disponibles y participando en espacios de intercambio de información.

2.3.1. Descripción de la competencia 3

Esta competencia abarca aspectos necesarios para comunicar, expresar, interpretar y difundir ideas,
de forma que las propuestas y opiniones se expresen de manera clara y fluida en los diversos contextos,
medios y canales que habitualmente se emplean durante el proceso de diseño, creación y difusión de
soluciones tecnológicas. Se hace referencia por tanto al buen uso de los lenguajes (lingüísticos, matemáticos
y plástico-visuales) y a la incorporación adecuada de la terminología técnica en los diferentes formatos de

expresión del conocimiento, textos escritos, exposiciones orales, representaciones gráficas, audiovisuales,
etc. Con ello, se pretende garantizar una comunicación adecuada de ideas, conceptos y opiniones

La necesidad de intercambiar información con otras personas implica una actitud responsable y de
respeto hacia el equipo de trabajo, así como hacia los protocolos establecidos en el trabajo colaborativo,
aplicables tanto en el contexto personal como en las interacciones en la red a través de herramientas digitales,
plataformas virtuales o redes sociales de comunicación que tienen una creciente importancia para difundir y
compartir recursos, documentos e información.

En este sentido, la competencia incluye aspectos necesarios para una comunicación efectiva en el
marco del trabajo en equipo como, por ejemplo, la asertividad, la gestión adecuada del tiempo de exposición,
la buena expresión, la entonación, la adaptación al contexto, y uso de un lenguaje no discriminatorio, inclusivo
y no sexista, entre otros.

2.4. Competencia específica 4

Diseñar y construir sistemas de control programables y robóticos, desarrollando soluciones
automatizadas mediante la implementación de algoritmos y operadores tecnológicos.

2.4.1. Descripción de la competencia 4

Esta competencia hace referencia a la aplicación de los conocimientos científico-tecnológicos y de
los principios del pensamiento computacional al proceso de diseño, simulación y construcción de sistemas
capaces de realizar funciones de forma autónoma. Para desarrollarla plenamente, es necesario abordar tanto
la parte física, “hardware”, como la de programación, “software”, de la solución automatizada. Así, por un lado,
en la parte física se tendrá que modelizar y dimensionar el proceso que se pretende robotizar o automatizar,
para diseñarlo y posteriormente construirlo empleando sensores, materiales estructurales, actuadores y
sistemas electromecánicos. Su implementación permitirá que el proyecto automatizado que se desarrolle
opere en el entorno real. Por otro lado, como “software”, se programará el sistema de control del robot o
máquina automatizada. Se incluyen aquí aspectos relativos a la implementación de los algoritmos adecuados
para lograr de la forma más eficiente posible, mediante una secuencia de pasos ordenados y bucles en un
lenguaje de programación (por bloques o por código), el control automático de máquinas, o para desarrollar
aplicaciones informáticas que resuelvan un problema concreto en diversos dispositivos: computadores,
dispositivos móviles y placas microcontroladoras. Todo ello requiere de la aplicación de los principios del
diseño multiplataforma, la validación y depuración de las soluciones a los problemas planteados, y su
mantenimiento o posible generalización y reutilización para resolver otros nuevos problemas.

Se incluye la iniciación en las tecnologías emergentes, como son el internet de las cosas, el Big Data
o la inteligencia artificial (IA), ante la necesidad de interactuar con el entorno del proyecto automatizado o
robot. La incorporación de estas tecnologías enfocadas a automatizar procesos se hará con sentido crítico y
ético ante el impacto que las mismas pueden tener.

2.5. Competencia específica 5

Aprovechar las posibilidades que ofrecen las herramientas digitales para la realización eficiente de
tareas tecnológicas, configurándolas y aplicando los conocimientos interdisciplinares adecuados.

2.5.1. Descripción de la competencia 5

La integración de la tecnología digital en multitud de situaciones es un hecho en la actualidad y, en
este sentido, se hace imprescindible en el proceso de aprendizaje permanente. Saber utilizar y configurar las
herramientas digitales es un aprendizaje importante tanto desde el punto de vista del futuro laboral del
alumnado, como desde la perspectiva de que una sociedad que maneja adecuadamente la tecnología puede
reducir la desigualdad. Además, fomentar la autoestima y la confianza en las propias posibilidades al tener
que afrontar cambios constantes encaja perfectamente con la metodología de resolución de problemas
tecnológicos, favoreciendo e impulsando la capacidad de innovar y la creatividad a la hora de aportar las
mejores soluciones posibles a través de los medios más convenientes en cada momento.

Esta competencia aborda la incorporación de las herramientas y de los dispositivos digitales en las

distintas fases del proceso de resolución de problemas. Es el caso, por ejemplo, del uso de herramientas de
diseño 3D, la experimentación mediante simuladores en el diseño de soluciones, la aplicación de tecnologías
CAM/CAE en la fabricación de productos, el uso de gestores de presentación o herramientas de difusión en
la comunicación o publicación de información, el desarrollo de programas o aplicaciones informáticas en el
control de sistemas, el buen aprovechamiento de herramientas de colaboración en el trabajo grupal, etc. Esta
incorporación debe respetar, en todos los casos, las licencias de uso y los derechos de autoría. La
incorporación de la tecnología digital se hace necesaria en todas las fases de la metodología de proyectos
para mejorar los resultados.

En suma, esta competencia se centra en el uso responsable y eficiente de la tecnología digital
aplicada al proceso de aprendizaje. Ello implica el conocimiento y comprensión del funcionamiento de los
dispositivos y aplicaciones empleados, permitiendo adaptarlos a las necesidades personales. Se trata de
aprovechar, por un lado, la diversidad de posibilidades que ofrece la tecnología digital y, por otro, las
aportaciones de los conocimientos interdisciplinares para mejorar las soluciones aportadas con el menor
número posible de recursos utilizados.

2.6. Competencia específica 6

Contribuir al desarrollo sostenible analizando críticamente el uso de objetos, materiales, productos,
instalaciones y procesos tecnológicos, valorando los impactos y repercusiones ambientales, sociales y éticas
de estos, y proponiendo alternativas realistas.

2.6.1. Descripción de la competencia 6

La tecnología como respuesta a las necesidades humanas ha proporcionado una mejora en las
condiciones de vida de las personas, pero, al mismo tiempo, ha tenido repercusiones negativas tanto en el
medio ambiente como en algunos aspectos de la calidad de vida. A nuestro alrededor, multitud de objetos y
productos cotidianos son fruto del avance tecnológico. El funcionamiento de nuestra sociedad demanda, cada
día más, la generación de nuevos objetos, aunque en algunos casos el uso de estos se realiza de manera
poco reflexiva, dejándose guiar por la comodidad, el pragmatismo y, en ocasiones, el mero consumismo.

Todas las soluciones tecnológicas provienen de un proceso productivo, iniciado con un diseño y una
propuesta basada tanto en las necesidades de las personas usuarias como en los intereses de las personas
productoras. El uso de estos objetos, productos o soluciones implica la aceptación de las consecuencias y
repercusiones asociadas y requiere un conocimiento básico de sus características y una comprensión
adecuada de su propósito, diseño y funcionamiento.

Esta competencia incluye el análisis necesario de los criterios de sostenibilidad y accesibilidad en el
diseño y en la fabricación de bienes tecnológicos a través del estudio del consumo energético, la
contaminación ambiental y el impacto ecosocial. Este análisis debe ser conocido y tenido en cuenta a la hora
de adquirir o desechar un bien tecnológico. De esta forma, se garantiza que la toma de decisiones se haga
con conocimiento de causa, con respeto hacia el entorno y con atención a la salud y el bienestar personal.

Se pretende mostrar en ella tanto la actividad de determinados equipos de trabajo en internet y la
repercusión que pueden tener algunos proyectos sociales por medio de comunidades abiertas, acciones de
voluntariado o proyectos de servicio a la comunidad, como el efecto de la selección de materiales, del sistema
mecánico o de la elección de las fuentes de energía y sus conversiones.

El objetivo es fomentar el desarrollo tecnológico para mejorar el bienestar social minimizando las
repercusiones negativas en otros ámbitos. Para ello, se deben tener presentes todos los criterios de
sostenibilidad desde el momento inicial de detección de la necesidad y estimarlos y valorarlos en cada una
de las fases del proceso creativo. Estos criterios deben aplicarse en todos los ámbitos del desarrollo
tecnológico, desde el diseño de la arquitectura bioclimática en edificios, hasta las instalaciones necesarias en
las viviendas, la sostenibilidad de los medios de transporte o el análisis del ciclo de vida de los productos
creados, por mencionar solo algunos casos.

Finalmente, la competencia incluye también aspectos actitudinales relativos a la valoración del ahorro
energético en beneficio del medio ambiente y la contribución de las nuevas tecnologías a la consecución de
los Objetivos de Desarrollo Sostenible.

3. Conexiones de las competencias específicas entre sí, con las competencias de otras materias y con
las competencias clave

Tecnología es una materia en la que se desarrollan seis competencias específicas. La primera de
ellas, CE 1, aborda la identificación y resolución de problemas tecnológicos; la segunda, CE 2, tiene como
foco la fabricación de dichas soluciones; en el desarrollo de la tercera competencia, CE 3, se asume la
relevancia de la comunicación e interpretación de ideas o soluciones tecnológicas; la cuarta, CE 4, se centra
en el desarrollo de soluciones automatizadas y robots; la quinta, CE 5, recoge el aprovechamiento de las
herramientas digitales; por último, la CE 6 tiene como finalidad contribuir al desarrollo sostenible. Cada una
de ellas se puede conectar con otras competencias específicas de la materia, con otras del resto de materias
de la etapa y con las competencias clave.

3.1. Relaciones o conexiones con las otras CE de la materia

Competencia 1 Conexiones

Esta competencia conecta con otras que llaman la atención sobre los procesos cognitivos implicados
en la detección e identificación de problemas y soluciones tecnológicas. Es el caso de la CE 6, que se centra
en el análisis de los procesos tecnológicos teniendo en cuenta sus repercusiones en términos de
sostenibilidad, impactos y repercusiones medioambientales, sociales y éticas, proporcionando así una
perspectiva relevante para que el alumnado identifique problemas tecnológicos. La CE 5, relativa al uso de
herramientas digitales para la realización eficiente de tareas tecnológicas tiene una relación directa con la CE
1 al incorporar los dispositivos digitales en las primeras fases del proceso de resolución de problemas
tecnológicos.  El dominio de los lenguajes adecuados para identificar problemas tecnológicos y la formulación
de propuestas para abordarlos la conectan con la CE 3.

Competencia 2 Conexiones

El proceso de fabricación de productos y el desarrollo de sistemas que aportan soluciones a
necesidades y problemas planteados está relacionado con la adquisición de la CE 1, con el foco puesto en la
identificación de problemas tecnológicos y en la formulación de propuestas para abordarlos. Así como la
necesidad de seguir la planificación previa a la hora de resolver esos problemas y retos tecnológicos cercanos
al alumnado. Además, está relacionada con la CE 4, centrada en el diseño y construcción de sistemas de
control programables robóticos. La CE 5, por su parte, asegura el aprovechamiento de herramientas digitales
a la hora de fabricar soluciones tecnológicas. Por último, el análisis crítico de los procesos de fabricación
valorando su impacto y las repercusiones ecosociales la conectan con la CE 6.

Competencia 3 Conexiones

La dimensión comunicativa y la producción y comprensión de mensajes relacionados con aspectos
tecnológicos sobre situaciones reales vincula esta competencia con el resto de competencias específicas.
Expresar, comprender y difundir ideas, opiniones y propuestas relacionadas con aspectos tecnológicos
conecta necesariamente con otras competencias como la CE 1 relativa a la identificación de problemas; con
la necesidad de comunicar correctamente toda la planificación de las ideas; con la utilización de herramientas
digitales para este propósito (CE 5); y con el análisis de los procesos tecnológicos (CE 6) considerando los
impactos y las repercusiones sociales, ambientales y éticas que su fabricación (CE 2) y uso pueden tener.
Para todo ello es necesario una comprensión adecuada y utilización correcta de los lenguajes propios de este
ámbito de conocimiento.

Competencia 4 Conexiones

El desarrollo de soluciones automatizadas para diseñar y construir robots, entre otras opciones,
conecta con la CE 1, en la medida en que es necesario identificar problemáticas susceptibles de ser
abordadas con esta tecnología, realizar una planificación para poder desarrollar la idea, y poder comunicar
(CE 3). En el diseño, construcción y programación de las soluciones automatizadas se utilizan habitualmente
herramientas digitales (CE 5). Por último, cabe destacar la importante conexión con la CE 6, puesto que las
soluciones automatizadas que se diseñen han de ser revisadas críticamente valorando sus impactos y
repercusiones ambientales, sociales y éticas.

Competencia 5 Conexiones

Convertir las ideas planteadas en una solución digital requiere una planificación y gestión de
proyectos (CE 1) con un enfoque social y cultural que implica creatividad, la asunción de retos, la gestión de
éxitos y fracasos para la innovación y el progreso tecnológico. Las implicaciones sociales y éticas del diseño
y desarrollo de aplicaciones hacen que esta competencia esté relacionada con la CE 6. Del mismo modo, las
herramientas digitales se pueden utilizar tanto para idear y planificar las soluciones tecnológicas (CE 1), como
para fabricarlas (CE 2), o para el diseño, fabricación y programación de soluciones automatizadas (CE 4).

Competencia 6 Conexiones

Esta competencia específica se relaciona con el resto de competencias de la materia. Así, en la
identificación de problemas tecnológicos y la formulación de propuestas para abordarlos (CE 1) se han de
tener en cuenta aspectos relacionados con la sostenibilidad y el impacto ambiental, social y ético de los
problemas y de sus posibles soluciones. Igualmente, estos aspectos se han de tener en cuenta cuando se
construyan o fabriquen las soluciones (CE 2) y se diseñen y construyan sistemas automatizados o robotizados
(CE 4). De este modo, las CE 1, CE 2 y CE 4 contribuyen a poder hacer un uso responsable y sostenible de
los materiales, objetos, productos y soluciones tecnológicas a la hora de comprender su funcionamiento,
diseño y propósito.

3.2. Relaciones o conexiones con las CE de otras materias de la etapa

La materia de Tecnología incorpora en sus competencias específicas y los saberes básicos asociados
una buena parte del ámbito de conocimiento y de actividad de la ciencia, la tecnología y las matemáticas. Por
esta razón, mantiene relaciones estrechas con competencias, sobre todo, del ámbito científico-matemático

Competencia 1 Conexiones

Así, la CE 1, relativa a la identificación de problemas tecnológicos y la formulación de propuestas
para abordarlos, se vincula con las competencias matemáticas, puesto que durante la identificación de dichos
problemas se ponen en juego a menudo modelos matemáticos de la realidad. Así mismo, lo hace también
con competencias de las materias de Física y Química y Biología y Geología, centradas en el análisis de
situaciones problemáticas reales utilizando la lógica científica y explorando las posibles consecuencias de las
soluciones propuestas para afrontarlas. Por otro lado, la conexión con las competencias de Geografía e
Historia se basa en el hecho de que la identificación y propuesta de problemas tecnológicos va unido a la
promoción y participación en proyectos cooperativos de convivencia, que favorecen un entorno más justo y
solidario. Por último, para poder identificar y proponer los problemas tecnológicos a los que se refiere la CE
1, es necesario, por un lado, dialogar y debatir de manera asertiva, respetuosa y argumentada sobre los
problemas morales que surgen en nuestro entorno y, por otro, proponer acciones responsables y justas,
comprometidas con la transformación social y la lucha efectiva contra las desigualdades en cualquier situación
real, que conectan con las competencias específicas de la materia de Valores Éticos y Cívicos.

Competencia 2 Conexiones

La CE 2, relativa a la fabricación de soluciones tecnológicas, se vincula directamente con las

competencias específicas de la materia de matemáticas, puesto que la construcción de modelos matemáticos
es un paso previo al desarrollo de productos tecnológicos y requiere de un pensamiento computacional.
También con competencias específicas de Física y Química en la identificación y caracterización de los
materiales, que permiten hacer un uso adecuado tanto de los materiales clásicos como de nuevos materiales
durante el proceso de fabricación de soluciones tecnológicas. Por otro lado, el reconocimiento de los
estereotipos y roles sociales que nos guían hacia una práctica igualitaria e inclusiva, reflejado en las
competencias específicas de la materia de Valores Éticos y Cívicos, está estrechamente conectado con los
roles que tradicionalmente se han establecido en los espacios de trabajo y durante los procesos de fabricación
tecnológicos. Por último, esta competencia conecta con la materia de Educación Plástica, Visual y Audiovisual
a través de su competencia relativa a la elaboración de producciones artísticas con diferentes técnicas y
materiales, en la medida en que en el manejo de máquinas y herramientas se experimenta con la utilización
de diferentes materiales.

Competencia 3 Conexiones

La CE 3, cuyo foco es la expresión, difusión e interpretación de ideas tecnológicas, se relaciona
lógicamente con las competencias sobre los distintos lenguajes que es necesario emplear en tecnología:
plástico y visual, matemático y lingüístico. Se relaciona más estrechamente con las competencias específicas
del ámbito lingüístico que ponen el foco en la capacidad de entender y hacerse entender, tanto a nivel escrito
como oral, y mediar correctamente, utilizando el registro adecuado dependiendo de la situación en la que se
produce la comunicación, cuando se trabaja en un grupo de trabajo y cuando se exponen ideas y opiniones.
Asimismo, mantiene una estrecha relación con las competencias específicas de Matemáticas centradas en
interpretar, analizar y valorar problemas relevantes mediante modelos matemáticos, y en el manejo del
simbolismo matemático, produciendo, comunicando e interpretando mensajes orales y escritos complejos de
manera formal.

Competencia 4 Conexiones

La CE 4, relativa al diseño y construcción de automatismos mediante la aplicación del pensamiento
computacional, tiene relación directa con las competencias específicas de la materia de Matemáticas que
versan, respectivamente, sobre la modelización matemática y la implementación de algoritmos
computacionales organizando datos, descomponiendo un problema en partes, reconociendo patrones y
empleando lenguajes de programación y otras herramientas TIC.

Competencia 5 Conexiones

La CE 5, relativa al aprovechamiento de las herramientas digitales, mantiene una estrecha relación
con las competencias específicas de Digitalización, así como con las competencias específicas de
Matemáticas, en la medida en que en esta última se contempla la utilización de programas informáticos y
aplicaciones TIC para simular procesos de resolución y para la interpretación y validación de resultados. Así
mismo, tiene conexión con la materia de Valores Cívicos y Éticos, ya que un uso inadecuado de herramientas
digitales y aplicaciones puede tener repercusiones, en términos de sostenibilidad, que deben abordarse de
manera crítica. Igualmente, el uso inadecuado de los elementos tecnológicos y digitales puede tener un
impacto en el bienestar físico y mental, especialmente en lo que respecta a los potenciales problemas psico-
sociales asociados al abuso de determinados dispositivos y aplicaciones digitales, lo que vincula esta
competencia con algunas competencias de Educación Física.

Competencia 6 Conexiones

La CE 6, relativa al análisis de las repercusiones ambientales, sociales y éticas de cualquier solución
tecnológica, así como a su uso responsable y sostenible, tiene una estrecha conexión con las competencias
específicas de Biología y Geología relacionadas, respectivamente, con la adopción de hábitos responsables
con el entorno y la búsqueda de soluciones científicas a los problemas de naturaleza ecosocial. El desarrollo
de esta competencia y de todas aquellas que la complementan necesita de una sensibilización que debe
sustentarse en datos objetivos y en la reflexión asociada a un pensamiento crítico. Esta competencia se
vincula directamente con varias competencias específicas de la materia Digitalización. En concreto, con las

relativas a la promoción del activismo responsable y ético desplegando acciones responsables, justas y
comprometidas con la transformación social y adecuadas a un objetivo de desarrollo sostenible. Por otra
parte, las implicaciones económicas, sociales y éticas que se derivan de la cultura de la sostenibilidad la
conectan con las competencias específicas de Geografía e Historia, habida cuenta de la necesidad de generar
argumentos críticos sobre estas problemáticas relevantes siempre desde la asunción de los valores
democráticos fundamentales. Igualmente, se relaciona con varias competencias de Matemáticas en la medida
en que el alumnado ha de ser capaz de servirse del trabajo matemático en resolución de problemas para
reflexionar críticamente sobre situaciones relacionadas con contextos de importancia para el ciudadano del
siglo XXI, como son la sostenibilidad, impacto ambiental o el consumo responsable; también por el hecho de
contextualizar la exploración, formulación y elaboración de conjeturas matemáticas en  contextos de interés
para la ciudadanía, relacionados con los retos del siglo XXI; y porque el alumnado ha de conocer las
aportaciones de las matemáticas a los avances significativos del conocimiento científico y del desarrollo
tecnológico especialmente relevantes para abordar los desafíos con los que se enfrenta actualmente la
humanidad.

3.3. Relaciones o conexiones con las competencias clave

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE 1 |  |  | X | X | X | X | X |  |
| CE 2 |  |  | X |  | X | X |  | X |
| CE 3 | X | X | X | X |  | X |  |  |
| CE 4 |  | X | X | X | X |  | X |  |
| CE 5 |  | X |  | X | X |  |  |  |
| CE 6 |  |  | X | X |  | X |  |  |

Competencias específicas de la materia que mantienen relaciones especialmente significativas y
relevantes con las competencias clave:

•
CE1: Identificar problemas tecnológicos a partir del estudio de las necesidades presentes en
el entorno próximo, formular propuestas para abordarlos, y resolverlos de manera eficiente e
innovadora mediante procesos de trabajo colaborativo y utilizando estrategias propias del
método de proyectos.

•
CE2: Fabricar soluciones tecnológicas utilizando los conocimientos interdisciplinares, las
técnicas y los recursos disponibles de forma apropiada y segura para dar una respuesta
satisfactoria a las necesidades planteadas.

•
CE3: Expresar, difundir e interpretar ideas, propuestas o soluciones tecnológicas de manera
efectiva, empleando los recursos disponibles y participando en espacios de intercambio de
información.

•
CE4: Diseñar y construir sistemas de control programables robóticos desarrollando
soluciones automatizadas mediante la implementación de algoritmos y de operadores
tecnológicos.

•
CE5: Aprovechar las posibilidades que ofrecen las herramientas digitales para la realización
eficiente de tareas tecnológicas, configurándolas y aplicando los conocimientos
interdisciplinares adecuados

•
CE6: Contribuir al desarrollo sostenible analizando críticamente el uso de objetos, materiales,
productos, instalaciones y procesos tecnológicos, valorando los impactos y repercusiones
ambientales, sociales y éticas de estos, y proponiendo alternativas realistas.

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

•
CCL: competencia en comunicación lingüística

•
CP: competencia plurilingüe

•
CMCT: competencia en matemáticas y en ciencia, tecnología e ingeniería

•
CD: competencia digital

•
CPSAA: competencia personal, social y de aprender a aprender

•
CC: competencia ciudadana

•
CE: competencia emprendedora

•
CCEC: competencia en conciencia y expresión cultural

CE 1

Tanto en el proceso de búsqueda de información como en la fase de diseño, se pone en juego la
competencia clave digital, que impregna estas mismas fases o se aplica de pleno en el caso de que la solución
diseñada sea un producto digital. El trabajo colaborativo y/o cooperativo propio del método de diseño de la
ingeniería apela tanto a la competencia clave ciudadana, al tener que asumir responsabilidades valorando y
respetando el saber y las opiniones de todo el equipo, como a la personal, social y de aprender a aprender,
en el planeamiento de objetivos a medio plazo y el desarrollo de procesos de aprendizaje a partir de los
errores. Del mismo modo, la iniciativa en la búsqueda y propuesta de soluciones hace uso de un conocimiento
propio del ámbito de la competencia clave en matemáticas y en ciencia, tecnología e ingeniería y también de
la competencia emprendedora, puesto que se emplean las destrezas creativas para proponer soluciones
originales, éticas y sostenibles, tomando conciencia de su impacto.

CE 2

Esta competencia específica mantiene una estrecha relación con la competencia clave en
matemáticas y en ciencia y tecnología, tanto por la necesidad de poner esta en práctica en multitud de técnicas
de fabricación como de emplear múltiples conocimientos interdisciplinares. Entre otras competencias clave
con las se relaciona, cabe citar la personal, social y de aprender a aprender, puesto que la creación de
soluciones tecnológicas requiere de una autoevaluación del proceso, y la ciudadana, en lo relativo a la
comprensión de las relaciones sistémicas entre las soluciones fabricadas y la sostenibilidad. Por último, la
posibilidad de emplear diversos formatos de expresión para las creaciones, así como el hecho de que estas
sean, a su vez manifestaciones culturales, la conecta con la competencia clave en conciencia y expresiones
culturales.

CE 3

Sin duda, las competencias clave en comunicación lingüística, y por extensión la plurilingüe, son, por
motivos obvios, las que presentan una relación más directa con esta competencia específica. Pero también
con la competencia en matemáticas y en ciencia, tecnología e ingeniería, puesto que progresivamente se han
de incorporar tecnicismos, simbología y distintas representaciones gráficas que permitan comunicar con
mayor precisión y rigor las ideas. La competencia clave digital es inherente a la necesidad de establecer esa
comunicación en entornos digitales. Finalmente, la integración del discurso sobre una situación para justificar
argumentos es un instrumento poderoso de pensamiento crítico y de confianza en sí mismo, lo cual la
relaciona con la competencia clave ciudadana.

CE 4

Esta competencia específica es la que mayor conexión tiene con la competencia clave en
matemáticas y en ciencia, tecnología e ingeniería; y, por supuesto, con la competencia digital, puesto que las
soluciones robóticas o automatizadas exigen tanto el diseño, fabricación y evaluación de diferentes prototipos
o modelos como el despliegue de aplicaciones informáticas. En el proceso de desarrollo de software es
imprescindible la comprensión, selección de información y expresión a través de lenguas oficiales y
extranjeras, lo que vincula esta competencia específica con las competencias clave en comunicación
lingüística y plurilingüe. La autonomía personal que favorece esta competencia específica está relacionada
con la competencia personal, social y de aprender a aprender, ya que se han de gestionar los retos que
plantea la programación, aumentando su motivación para aprender, usar fuentes fiables para validar los
aprendizajes y plantear mecanismos para aprender de los errores a medio plazo. Y, finalmente, es también
relevante la relación con la competencia emprendedora, puesto que se emplean las destrezas creativas para
proponer soluciones originales, éticas y sostenibles, tomando conciencia de su impacto.

CE 5

Como sucede con las otras competencias específicas de la materia, las competencias clave en
matemáticas y en ciencia, tecnología e ingeniería, y digital son consustanciales a esta competencia. Entre el
resto de competencias clave, conviene resaltar la conexión con las competencias en comunicación lingüística
y plurilingüe en lo que concierne al análisis de las descripciones de las diferentes técnicas y herramientas. El
uso de estas requiere a menudo la interpretación de textos instructivos y del dominio del lenguaje propio del
área. La competencia clave personal, social y de aprender a aprender está también directa y estrechamente
relacionada con esta competencia específica, en lo relativo a la activación de procesos metacognitivos de
retroalimentación que permiten aprender de los errores.

CE 6

Como sucede con las competencias específicas precedentes, esta competencia está estrechamente
relacionada con la competencia clave en matemáticas y en ciencia, tecnología e ingeniería, Y también con la
digital, debido a la necesidad de comprender e interpretar de manera crítica y responsable la información
disponible sobre los productos tecnológicos. Del mismo modo, el impacto de los productos tecnológicos
confiere especial importancia a la competencia clave ciudadana. La tecnología plantea constantemente
nuevos dilemas éticos cuya respuesta puede tener consecuencias en la forma de vida de las personas y, en
última instancia, de su entorno social. Finalmente, la sostenibilidad emerge como término vertebrador del
desarrollo de esta conexión competencial.

4. Saberes básicos (para el conjunto de la materia)

4.1. Introducción

Los saberes o contenidos básicos son los que se consideran necesarios para la adquisición y el
desarrollo de las competencias específicas, siendo por tanto estas competencias el criterio utilizado para su
selección.

Los saberes se han agrupado en cinco bloques que abarcan toda la materia. Mediante el aprendizaje,
articulación y movilización de los saberes incluidos en estos bloques se asegura que el alumnado sea capaz
de comprender, reflexionar y actuar frente a los profundos cambios que el desarrollo tecnológico está
imprimiendo en la sociedad, de acuerdo con lo establecido en las competencias específicas.

La organización de los contenidos en bloques tiene como finalidad facilitar su comprensión y no debe
interpretarse en ningún caso como una propuesta para abordarlos y trabajarlos por separado. Su tratamiento
será integral y no deben entenderse de forma aislada. Su adquisición y movilización mediante situaciones de
aprendizaje adecuadas permitirá el desarrollo de las competencias específicas y, con ello, el de las
competencias clave incluidas en el perfil de salida del alumnado.

El bloque referido al proceso de resolución de problemas es el eje vertebrador de todos los saberes
básicos. Se aborda el desarrollo de estrategias y métodos para, partiendo de la identificación de un problema
o necesidad, llegar al desarrollo de una solución, pasando por las distintas fases intermedias de forma
planificada e incorporando técnicas adaptadas del mundo empresarial e industrial. Destaca la importancia
que se da dentro de las fases a la presentación y comunicación de resultados como aspecto clave para la
difusión de los trabajos realizados.

El bloque de Operadores tecnológicos ofrece ampliar las tecnologías y operadores disponibles para
encontrar soluciones. La electrónica analógica y digital básicas y la neumática son fundamentales, junto con
el resto de operadores y soluciones tecnológicas trabajadas en cursos anteriores en la materia de Tecnología
y digitalización, para poder abordar las diversas situaciones que se planteen.

El bloque de Pensamiento computacional, automatización y robótica incluye los fundamentos para
entender, diseñar e implementar sistemas de control programado. La incorporación de módulos de inteligencia
artificial, de ingeniería y un acercamiento al internet de las cosas permite el diseño de programas sencillos y
de la automatización de los procesos como respuesta a necesidades presentes en la cotidianidad del
alumnado.

El bloque de Instalaciones en viviendas recoge el estudio básico de los elementos que conforman las
instalaciones básicas que debe tener una vivienda para su habitabilidad en condiciones normales, sin dejar
de lado las diferentes medidas de ahorro energético que están al alcance de todos. También se abordará la
evolución que este tipo de instalaciones han ido experimentando, dando lugar a lo que hoy día conocemos
como la domótica.

El bloque de Tecnología sostenible aborda el conocimiento y aplicación de criterios de sostenibilidad
en el uso de materiales, el diseño de procesos y en cuestiones energéticas, que sirven de fundamento a
procesos de reflexión sobre las respuestas tecnológicas, las propias medidas, soluciones y diseños que el
alumnado desarrolla en el aprendizaje de la materia.

4.2. Bloque 1: Proceso de resolución de problemas

| PROCESO DE RESOLUCIÓN DE PROBLEMAS. |  |  |
| --- | --- | --- |
| ESTRATEGIAS Y TÉCNICAS |  |  |
|  | • Estrategias de gestión de proyectos colaborativos y técnicas de resolución de |  |
|  | problemas iterativas. |  |
|  | • Estudio de necesidades del centro, locales, regionales, etc. Planteamiento de |  |
|  | proyectos colaborativos, proyectos de aprendizaje servicio y/o voluntariado |  |
|  | tecnológico. |  |
|  | • Técnicas de ideación. |  |
|  | • Emprendimiento, perseverancia y creatividad en la resolución de problemas |  |
|  | desde una perspectiva interdisciplinar de la actividad tecnológica. |  |
|  | • Satisfacción e interés por el trabajo y la calidad del mismo. |  |
|  | PRODUCTOS Y MATERIALES |  |
|  | • Ciclo de vida de un producto y sus fases. Análisis sencillos. |  |
|  | • Estrategias de selección de materiales en base a sus propiedades o requisitos |  |
|  | FABRICACIÓN |  |
|  | • Herramientas de diseño asistido por computador en 3D en la representación |  |
|  | y/o fabricación de piezas aplicadas a proyectos. |  |

• Técnicas de fabricación manual y mecánica. Aplicaciones prácticas.
• Técnicas de fabricación digital. Impresión 3D y corte. Aplicaciones prácticas.
• Seguridad e higiene uso responsable.

DIFUSIÓN

• Presentación y difusión del proyecto. Elementos, técnicas y herramientas.
• Comunicación efectiva: entonación, expresión, gestión del tiempo, adaptación
del discurso y uso de un lenguaje inclusivo, libre de estereotipos sexistas.

4.3. Bloque 2: Operadores tecnológicos.

OPERADORES TECNOLÓGICOS.

ELECTRÓNICA ANALÓGICA

• Componentes básicos y simbología.
• Análisis y montaje de circuitos elementales.
• Circuitos impresos.
• Uso de simuladores para analizar el comportamiento de los circuitos.
• Elementos aplicados a la robótica.

ELECTRÓNICA DIGITAL

• Componentes básicos y simbología.
• Introducción al álgebra de Boole y puertas lógicas.
• Análisis y montaje de circuitos elementales.
• Uso de simuladores para analizar el comportamiento de los circuitos.
• Elementos aplicados a la robótica.

NEUMÁTICA E HIDRÁULICA BÁSICA

• Sistemas hidráulicos y neumáticos: ámbitos de aplicación.
• Instalaciones hidráulicas y neumáticas: configuración básica.
• Componentes neumáticos: simbología y funcionamiento.
• Circuitos neumáticos básicos.
• Simulación de circuitos neumáticos.

4.4. Bloque 3: Pensamiento computacional, automatización y robótica.

PENSAMIENTO COMPUTACIONAL, AUTOMATIZACIÓN Y ROBÓTICA

SISTEMAS DE CONTROL PROGRAMADO

• Sistemas automáticos: funcionamiento, tipos y componentes de control.
• Sensores.

• Actuadores.
• Controladores.

PROGRAMACIÓN Y CONTROL

• El ordenador y dispositivos móviles como elementos de programación y
control.
• Trabajo con simuladores informáticos en la verificación y comprobación del
funcionamiento de los sistemas diseñados.
• Espacios compartidos y discos virtuales.
• Aplicaciones de la Inteligencia. Artificial. y Big Data.
• Telecomunicaciones en sistemas de control.
• Internet de las cosas: elementos, comunicaciones y control.
• Aplicaciones prácticas.

ROBÓTICA

• Robots: tipos, grados de libertad y características técnicas.
• Programación y aplicación de microcontroladoras en la experimentación con
prototipos diseñados.
• Diseño, construcción y control de robots sencillos de manera física o
simulada.
• Elementos neumáticos aplicados a la robótica.

4.5. Bloque 4: Instalaciones en viviendas

INTRODUCCIÓN A LAS INSTALACIONES EN VIVIENDAS

INSTALACIONES ESENCIALES

• Instalación eléctrica.
• Instalación de agua sanitaria.
• Instalación de saneamiento.
• Normativa, simbología, análisis y montaje básico de las instalaciones.
• Criterios y medidas de ahorro energético en una vivienda.

OTRAS INSTALACIONES

• Instalación de calefacción.
• Instalación de gas.
• Instalación de climatización.
• Domótica
• Criterios y medidas de ahorro energético en una vivienda.

4.6. Bloque 5: Tecnología sostenible.

TECNOLOGÍA SOSTENIBLE

|  | • Sostenibilidad. |  |
| --- | --- | --- |
|  | • Selección de materiales con criterios de sostenibilidad. |  |
|  | • Técnicas y estrategias para el aprovechamiento de materias primas y recursos |  |
|  | naturales. |  |
|  | • Hábitos que potencian el desarrollo sostenible. |  |
|  | • Diseño de procesos, de productos y de sistemas tecnológicos. |  |
|  | • Ciclo de vida de productos tecnológicos. |  |
|  | • Obsolescencia de productos tecnológicos. |  |
|  | • Arquitectura bioclimática. |  |
|  | • Elementos que condicionan el diseño de un edificio. |  |
|  | • Criterios y medidas de ahorro energético y de agua en edificios. |  |
|  | • Eficiencia energética y ambiental en el transporte. |  |
|  | • Sistemas inteligentes de transporte. |  |
|  | • Vehículos eléctricos y energías renovables. |  |
|  | • Comunidades abiertas, voluntariado tecnológico y proyectos de servicio a la |  |
|  | comunidad. |  |

5. Situaciones de aprendizaje

Las situaciones de aprendizaje integran todos los elementos que constituyen el proceso de
enseñanza y aprendizaje competencial, ya que con ellas se plantean tareas complejas en las que el alumnado
moviliza el conjunto de saberes necesarios para afrontar dichas situaciones.  El diseño de las situaciones
debe ofrecer oportunidades para la generalización de los aprendizajes y la adquisición de otros nuevos
mediante la realización de tareas complejas que articulen y movilicen de forma coherente y eficaz los
conocimientos, destrezas y actitudes implicados en las competencias específicas. Las actividades que se
planteen en las situaciones de aprendizaje deben tener las características adecuadas para asegurar el nivel
de desarrollo competencial que indican las competencias específicas.

Con el fin de diseñar situaciones de aprendizaje que sean relevantes se propone combinar una serie
de elementos que se enumeran a continuación de forma que finalmente se obtenga el bosquejo de una
situación de aprendizaje ideal.

Para comenzar, conviene inspirarse en alguno de los complejos retos globales a los que se enfrenta
la humanidad en el siglo XXI, o bien hacerlo a través de alguna situación local o próxima a la que enfrentarse
como personas, profesionales, o miembros de la sociedad. Si se hace de esta última forma, se recomienda
establecer la conexión inversa de lo local hacia retos de carácter global tomando como referencia, por
ejemplo, los Objetivos de Desarrollo Sostenible.

Una vez seleccionado un reto, conviene adoptar algunas perspectivas desde las que se desean
enfocar las soluciones: consumo responsable, respeto al medio ambiente, vida saludable, resolución pacífica
de conflictos, aceptación y manejo de la incertidumbre, compromiso ante las situaciones de inequidad y
exclusión, valoración de la diversidad personal y cultural, compromiso ciudadano en el ámbito local y global,
confianza en el conocimiento como motor del desarrollo, aprovechamiento crítico, ético y responsable de la
cultura digital.

Habitualmente, en el ámbito de la tecnología se aborda el desarrollo de soluciones a las problemáticas
o necesidades mediante proyectos a escala de la que sería la solución real. Se debe promover que los
saberes que se movilizan para resolver la situación sean esenciales y estén en el centro del desafío o reto
que la situación plantea. Por ejemplo, en un aparcamiento automatizado, la electrónica y el pensamiento
computacional serían esenciales para abordar la situación.

Otra de las claves para definir una situación óptima de aprendizaje es el nivel de autonomía del
alumnado. Al ser una materia que se imparte en el cuarto curso de la Educación Secundaria Obligatoria y,
por tanto, a un alumnado con un mayor nivel de desarrollo competencial, su nivel de autonomía puede ser
también mayor, contemplando la posibilidad de que puedan decidir qué tecnologías, materiales, productos y
herramientas utilizar. Aprovechando la posibilidad de proceder de acuerdo con un mayor nivel de autonomía
del alumnado, se puede realizar el proceso inverso, es decir, partir de los saberes para buscar una aplicación
orientada a satisfacer necesidades detectadas en el entorno.

Mediante la búsqueda y explotación de oportunidades para conectar los aprendizajes realizados y
desarrollar nuevos aprendizajes en diferentes contextos, se pretende que la adquisición de las competencias
específicas de la materia sea lo más efectiva posible.

Es recomendable, además, que el conjunto de la información, datos y soluciones generadas mediante
la construcción de prototipos o el análisis de objetos permitan argumentar y fundamentar la toma de
decisiones, favoreciendo así un posicionamiento crítico y reflexivo del alumnado. Con el fin de movilizar las
competencias específicas en situaciones y condiciones nuevas o relativamente nuevas respecto a las
situaciones en las que se han aprendido, conviene incluir reflexiones en torno a lo que sucedería en el reto o
problema si se modifican algunas de las variables que lo definen. Además, se pueden presentar nuevas y
más amplias perspectivas para afrontarlo, o sencillamente plantear nuevas situaciones o actividades
susceptibles de ser abordadas a partir de las competencias aprendidas, utilizando espacios del centro más
allá del aula o taller, explorando las posibilidades del contexto comunitario más cercano (espacios
tecnológicos, museos, empresas) y estableciendo relaciones con profesionales del mundo de la tecnología.

Con el fin de que los aprendizajes sean accesibles y se adapten a las necesidades, características y
diferentes ritmos de aprendizaje del alumnado, hay que alinear su diseño con los principios del Diseño
Universal y Aprendizaje Accesible.

Las situaciones finalmente planteadas deben promover el respeto por los tiempos de trabajo y sus
distintos ritmos, lo cual supone aceptar la incertidumbre como parte ineludible del aprendizaje. En este
sentido, cabe destacar que los tiempos de trabajo amplios favorecen el diseño de secuencias didácticas que
permiten explorar todas las fases del proceso tecnológico y valorar el error como una oportunidad para
aprender.

6. Criterios de evaluación.

Competencia específica 1. Criterios de evaluación

Identificar problemas tecnológicos a partir del estudio de las necesidades presentes en el entorno
próximo, formular propuestas para abordarlos, y resolverlos de manera eficiente e innovadora mediante
procesos de trabajo colaborativo y utilizando estrategias propias del método de proyectos.

Criterios de evaluación CE1

1.1. Identificar problemas tecnológicos a partir de la observación y el análisis del
entorno más cercano, estudiando sus necesidades, con sentido crítico y principios éticos, de
manera que conduzcan a posibles soluciones que repercutan positivamente en la comunidad.

1.2. Idear soluciones tecnológicas lo más eficientes, accesibles e innovadoras
posibles, considerando las necesidades, requisitos y posibilidades de mejora del entorno más
cercano.

1.3. Planificar un proyecto tecnológico de forma creativa, proponiendo soluciones
tecnológicas emprendedoras que generen un valor para la comunidad.

1.4. Gestionar de forma creativa el desarrollo de un proyecto, el tiempo, materiales y
recursos disponibles, aplicando las estrategias y técnicas colaborativas pertinentes con una
perspectiva interdisciplinar y siguiendo un proceso iterativo de validación, desde la fase de
ideación hasta la difusión de la solución.

Competencia específica 2. Criterios de evaluación

Fabricar soluciones tecnológicas utilizando los conocimientos interdisciplinares, las técnicas y los
recursos disponibles de forma apropiada y segura para dar una respuesta satisfactoria a las necesidades
planteadas.

Criterios de evaluación CE 2

2.1. Fabricar productos y soluciones tecnológicas que den respuesta a necesidades
del entorno más cercano, aplicando herramientas de diseño asistido, técnicas de elaboración
manual, mecánica y digital, y utilizando los materiales y recursos mecánicos, eléctricos,
electrónicos y digitales adecuadas.

2.2. Seleccionar los materiales y recursos mecánicos, eléctricos, electrónicos,
neumáticos y digitales adecuados a la hora de crear productos y soluciones tecnológicas que
den respuesta a problemas o retos tecnológicos planteados.

2.3. Desarrollar las destrezas necesarias para la utilización de las distintas técnicas de
fabricación manual y digital aplicadas a proyectos, que permitan construir soluciones
tecnológicas que resuelvan problemas o retos tecnológicos planteados.

2.4. Utilizar correctamente herramientas, máquinas y recursos, observando las
medidas de seguridad correspondientes y escogiendo las que son adecuadas en función de la
operación a realizar y del material sobre el que se actúa.

2.5. Valorar la necesidad de hacer un uso responsable de los materiales respecto a la
sostenibilidad evitando su despilfarro durante el proceso de fabricación.

Competencia específica 3. Criterios de evaluación

Expresar, difundir e interpretar ideas, propuestas o soluciones tecnológicas de manera efectiva,
empleando los recursos disponibles y participando en espacios de intercambio de información.

Criterios de evaluación CE 3

3.1. Comunicar e interpretar información con el vocabulario técnico, símbolos y
esquemas de sistemas tecnológicos apropiados.

3.2. Difundir e intercambiar información tecnológica empleando las herramientas
digitales adecuadas.

3.3. Presentar y difundir las propuestas o soluciones tecnológicas de manera efectiva.

3.4. Expresar la información relevante en el desarrollo del trabajo en equipo de forma
asertiva.

3.5. Utilizar la entonación, expresión, gestión del tiempo y adaptación adecuada del
discurso, y un lenguaje inclusivo, no sexista y no discriminatorio en la presentación y difusión
de problemas, necesidades, proyectos y soluciones tecnológicas

Competencia específica 4. Criterios de evaluación

Diseñar y construir sistemas de control programables robóticos desarrollando soluciones
automatizadas mediante la implementación de algoritmos y de operadores tecnológicos.

Criterios de evaluación CE 4

4.1. Diseñar sistemas automáticos programables y robots que sean capaces de realizar
tareas que resuelvan problemas o retos tecnológicos planteados de forma autónoma,
aplicando conocimientos de mecánica, electrónica, neumática y componentes de los sistemas
de control, así como otros conocimientos interdisciplinares.

4.2. Construir sistemas automáticos programables y robots que sean capaces de
realizar tareas que resuelvan problemas o retos tecnológicos planteados de forma autónoma,
aplicando conocimientos de mecánica, electrónica, neumática y componentes de los sistemas
de control, así como otros conocimientos interdisciplinares.

4.3. Programar por bloques o con código el algoritmo de control del robot o sistema
automático que permite que interactúe con el entorno.

4.4. Controlar y/o simular sistemas automáticos programables y robots mediante
computadores, dispositivos móviles o placas microcontroladoras.

4.5. Integrar en las máquinas y sistemas tecnológicos aplicaciones informáticas y
tecnologías digitales emergentes de control y simulación como Internet de las cosas, Big Data
e Inteligencia Artificial con sentido crítico y ético.

Competencia específica 5. Criterios de evaluación

Aprovechar las posibilidades que ofrecen las herramientas digitales para la realización eficiente de
tareas tecnológicas, configurándolas y aplicando los conocimientos interdisciplinares adecuados.

Criterios de evaluación CE 5

5.1. Configurar diferentes aplicaciones y herramientas digitales teniendo en cuenta las
necesidades personales y en función de los problemas o retos tecnológicos planteados

5.2. Realizar tareas tecnológicas de manera eficiente mediante el uso de herramientas
digitales, aplicando conocimientos interdisciplinares con autonomía.

5.3. Emplear ética y responsablemente las herramientas digitales.

5.4. Utilizar y respetar las licencias y derechos de autoría propios de las herramientas
digitales

Competencia específica 6. Criterios de evaluación

Contribuir al desarrollo sostenible analizando críticamente el uso de objetos, materiales, productos,
instalaciones y procesos tecnológicos y valorando los impactos y repercusiones ambientales, sociales y éticas
de estos

Criterios de evaluación CE 6

6.1. Hacer un uso responsable de la tecnología, mediante el análisis y aplicación de
criterios de sostenibilidad y accesibilidad en el diseño de los productos tecnológicos, en la
selección de los materiales, en los procesos de fabricación y en su reciclaje, minimizando el
impacto negativo en la sociedad y en el planeta.

6.2. Evaluar y opinar críticamente sobre los procesos productivos asociados a la
explotación y transformación de los diferentes recursos naturales utilizados en la elaboración
de productos tecnológicos.

6.3. Valorar la repercusión y los beneficios del desarrollo de proyectos tecnológicos de
carácter social por medio de comunidades abiertas, acciones de voluntariado o proyectos de
servicio a la comunidad.

6.4. Analizar las repercusiones medioambientales provocadas por la arquitectura
bioclimática, el ecotransporte y las instalaciones domésticas valorando la contribución de las
tecnologías al desarrollo sostenible.

6.5. Analizar el diseño y fabricación de un producto que dé respuesta a una necesidad
planteada, evaluando su demanda, evolución y previsión de fin de ciclo de vida con un criterio
ético, responsable e inclusivo.
