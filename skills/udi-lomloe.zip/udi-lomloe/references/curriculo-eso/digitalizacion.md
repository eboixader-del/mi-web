# DIGITALIZACIÓN

> Fuente: Secundaria.pdf, páginas 668-683 (versión en castellano).

DIGITALIZACIÓN

1. Presentación

La sociedad digital y de la información plantea la necesidad de conocer de una forma
más profunda los elementos que permiten desarrollar en ella nuestras vidas de una forma crítica
y segura. En este sentido, los sistemas informáticos ofrecen todo su potencial para conseguir
una sociedad más justa, plural e igualitaria, en la que tenga cabida toda la ciudadanía sin
condicionantes ni barreras, favoreciendo a su vez el aprendizaje permanente y el desarrollo
personal. La materia Digitalización da respuesta a la necesidad de adaptación al entorno tan
cambiante que tenemos en la sociedad, al cual el alumnado de la educación básica ha de
enfrentarse con garantías para poder participar activamente diseñando soluciones creativas y
accesibles desde una perspectiva integradora.

Esta materia contribuye a afrontar de manera crítica la existencia de la brecha digital, los
condicionantes para la salud y la sostenibilidad que suponen el uso de medios informáticos, las
relaciones interpersonales, la producción y divulgación de conocimiento, y el uso ético de los
medios digitales. También se abordan temas como la resolución pacífica de conflictos en
entornos virtuales y el compromiso ciudadano en el ámbito local y global. De igual modo, se trata
de favorecer aprendizajes que permitan al alumnado hacer un uso competente de entornos
digitales, tanto en la gestión de dispositivos y entornos de aprendizaje, como en el fomento del
bienestar digital, posibilitando al alumnado tomar conciencia y construir una identidad digital
adecuada.

La materia Digitalización favorece la consecución de los objetivos de la Educación
Secundaria Obligatoria gracias a su desarrollo práctico, colaborativo y crítico, lo que permite al
alumnado su crecimiento personal y académico. El ejercicio de una ciudadanía digital
democrática implica una interacción tolerante y solidaria que respete las diferencias y rechace
los estereotipos que conducen a la discriminación. También se favorecen las destrezas básicas
en el uso de fuentes de información de manera crítica como medio para adquirir conocimiento,
desarrollándose a su vez las competencias tecnológicas básicas necesarias. La realización en
grupo de proyectos de digitalización ayuda a fortalecer la autonomía, la confianza en sí mismo y
la iniciativa personal, así como la capacidad de planificar, tomar decisiones y asumir
responsabilidades proactivamente en el trabajo diario de la materia. Además, alcanzar los
objetivos de la materia contribuye a la mejora en el alumnado de la comprensión de textos y la
expresión oral y escrita.

Se pretende la consecución del doble objetivo de dotar al alumnado de las herramientas
imprescindibles para alcanzar un proyecto de vida personal, social y profesional satisfactorio, y
a la par, de proporcionarle situaciones de aprendizaje significativas y reales para afrontar los
principales retos del siglo XXI. En efecto, desde esta materia se abordan temas como la
sostenibilidad, el bienestar, el rechazo a la inequidad y exclusión o la resolución pacífica de
conflictos en entornos virtuales, el aprovechamiento crítico ético y responsable de la cultura
digital, entre otros.

El desarrollo curricular de esta materia sigue los principios pedagógicos de la LOMLOE,
ya que las situaciones de aprendizaje planteadas contemplan las diferentes capacidades del
alumnado y promueven el trabajo autónomo individual o en equipo, así como la reflexión crítica.
La realización de proyectos de digitalización supone una tarea significativa y relevante para el
alumnado adolescente, mediante la cual se consigue potenciar la creatividad y reforzar la
reflexión, la autoestima, la responsabilidad, así como se desarrolla la comprensión y expresión
oral, escrita y audiovisual. También cabe destacar que el carácter científico-técnico de la
asignatura tiene importantes implicaciones en el uso de las matemáticas.

La materia Digitalización tiene una dimensión eminentemente práctica que es abordada
a través de la búsqueda de soluciones técnicas a retos cotidianos derivados de una sociedad

cada vez más digitalizada. Se le otorga el protagonismo a los y las estudiantes, quienes de
manera individual o en equipos de trabajo son capaces de movilizar los saberes necesarios para
conseguir éxito en los proyectos digitales propuestos. El enfoque competencial implica el
aprendizaje de conocimientos, destrezas y actitudes de naturaleza interdisciplinar relacionados
con el ámbito de la ingeniería y la informática. En esta materia, el alumnado desarrolla una serie
de competencias específicas cuyo grado de consecución se valora mediante los
correspondientes criterios de evaluación. Por último, en las situaciones de aprendizaje se
favorece la reflexión sobre los propios procesos de aprendizaje, de manera que se potencian
habilidades y estrategias metacognitivas.

Durante la etapa de Educación Primaria el alumnado toma contacto con los dispositivos
informáticos y comienza un proceso de alfabetización digital. Es durante la Educación
Secundaria Obligatoria cuando el alumnado interactúa en entornos digitales. La materia Taller
de Relaciones Digitales Responsables aborda cómo establecer las primeras relaciones a través
de medios digitales de una manera saludable y enriquecedora. En la materia Tecnología y
Digitalización se comienzan a abordar retos tecnológicos sencillos con el análisis de soluciones
tecnológicas, el uso de dispositivos, la búsqueda de información con sentido crítico o las
diferentes formas de expresión del conocimiento. La materia Inteligencia Artificial, Programación
y Robótica centra el foco en solucionar retos aplicando técnicas del mundo de la ingeniería. En
la materia Digitalización, además de ampliar y profundizar en estas cuestiones, se da el salto al
diseño de equipos y redes, y al desarrollo de una ciudadanía digital crítica comprometida con el
bienestar, la igualdad y la sostenibilidad.

A continuación, se describen los aprendizajes esenciales que se espera que el alumnado
adquiera cursando esta materia. Estos aprendizajes se concretan en cinco competencias
específicas, de carácter técnico, educativo, personal, social y ciudadano, respectivamente, y
cuatro bloques de saberes básicos interrelacionados. Las cuatro primeras competencias están
directamente relacionadas con cada uno de los cuatro grupos de saberes, mientras que mediante
la última competencia se abordan, desde una perspectiva integradora, los retos digitales a los
que el alumnado se enfrenta en su ámbito personal, educativo y social. Las competencias
específicas están interrelacionadas, al mismo tiempo que mantienen conexiones con algunas
competencias clave y con las del resto de las materias de la etapa.

Los saberes básicos necesarios para la adquisición y desarrollo de las competencias
específicas se organizan en cuatro bloques: dispositivos digitales, sistemas operativos y de
comunicación; digitalización del entorno personal de aprendizaje; seguridad y bienestar digital; y
ciudadanía digital crítica. Como se ha indicado previamente, cada bloque está relacionado
directamente con una competencia específica, mientras que la quinta competencia implica el
aprendizaje, articulación y movilización de los saberes de los cuatro bloques.

En el apartado dedicado a las situaciones de aprendizaje se presentan algunas
directrices para diseñar de la forma más adecuada situaciones y actividades de aprendizaje que
promueven la adquisición y desarrollo de las competencias específicas y facilitan la transferencia
de lo aprendido a situaciones de la vida real. En el diseño de los posibles escenarios pedagógicos
se tienen en cuenta los principios del diseño universal de aprendizaje con la finalidad de
conseguir una inclusión plena en las aulas.

Por último, en el apartado de criterios de evaluación se detalla el nivel de desarrollo
competencial que se espera que el alumnado alcance en cada competencia específica mediante
el aprendizaje, articulación y movilización de los saberes básicos.

2. Competencias específicas

2.1. Competencia específica 1

Diseñar equipos y redes de comunicación de uso personal y doméstico, y administrarlos
y utilizarlos de manera segura y sostenible.

2.1.1. Descripción de la competencia 1

La sociedad actual precisa de equipos digitales para el desarrollo personal y laboral. Por
ello, se considera fundamental abordar las funcionalidades de los dispositivos informáticos y de
comunicaciones y desarrollar la capacidad de incorporar nuevos elementos respetando las
normativas de seguridad vigentes y analizando sus implicaciones medioambientales.

Esta competencia específica hace referencia a los dispositivos digitales habituales en el
entorno del alumnado, incluidos los dispositivos móviles o de comunicación personal, y el
desarrollo de una actitud proactiva para utilizarlos de manera correcta en situaciones cotidianas
a nivel personal y doméstico. La competencia recorre el ciclo de vida de los equipos y las redes.

Para el diseño de los sistemas se deben tomar decisiones razonadas, en base a sus
requerimientos de uso, funcionalidad y rendimiento deseado, así como de sostenibilidad y de
consumo responsable. Implica la elaboración de presupuestos con la ayuda de plataformas
virtuales especializadas, procurando adaptarlos a un gasto coherente y responsable según las
necesidades. La participación en equipos de trabajo forma parte del desarrollo de esta
competencia específica, respetando los roles asignados y las aportaciones del resto de
integrantes del grupo. Las actuaciones del proceso de diseño incluyen montajes físicos o
simulados de equipos para conseguir su integración, verificando la compatibilidad y conexiones
de los componentes elegidos.

Además, el desarrollo de esta competencia involucra la instalación, administración y
mantenimiento del sistema operativo y aplicaciones de gestión básicas en función del uso al que
se destinan. Por lo tanto, el alumnado será capaz de utilizar de manera eficiente y segura
dispositivos móviles, ordenadores personales aislados o conectados en red, así como influir en
su diseño, montaje y administración.

2.2. Competencia específica 2

Buscar, seleccionar y organizar la información en el entorno personal de aprendizaje, y
utilizarla para la creación, edición, publicación y difusión de contenidos digitales.

2.2.1. Descripción de la competencia 2

La presencia de elementos tecnológicos y medios digitales en nuestras vidas es un
hecho que adquiere cada vez mayor trascendencia. Por ello, con el fin de favorecer y garantizar
un aprendizaje permanente y autónomo en todos los ámbitos, se hace necesaria la integración
de recursos digitales en el proceso formativo del alumnado, así como la gestión adecuada del
entorno personal de aprendizaje.

La competencia abarca aspectos relacionados con la alfabetización informacional, el
aprovechamiento apropiado de las estrategias de búsqueda y tratamiento de información, así
como con la generación de nuevo conocimiento, de manera individual o colectiva. Para ello se
seleccionarán las herramientas de autoría más apropiadas para generar nuevo conocimiento y
contenidos digitales, de modo que el alumnado pueda desarrollar la creatividad y el espíritu de
innovación para responder a los retos que se presentan en su vida personal, académica y
profesional. En el desarrollo de esta competencia específica, se crean aplicaciones informáticas
para ordenadores personales, dispositivos móviles y web, las cuales pueden incorporar módulos
de realidad extendida e inteligencia artificial.

Asimismo, se abordan las posibilidades que aportan las herramientas para el trabajo
colaborativo y la comunicación, permitiendo compartir y publicar experiencias, ideas e
información. Se hará uso responsable de las herramientas y contenidos empleados respetando
sus licencias y derechos de autoría, y se justificarán las escogidas para distribuir las
producciones. Todas las interacciones para el desarrollo de esta competencia se llevarán a cabo
con una actitud tolerante y participativa.

2.3. Competencia específica 3

Mostrar hábitos que fomenten el bienestar en entornos digitales, aplicando medidas
preventivas y correctivas para proteger dispositivos, datos personales y la propia salud.

2.3.1. Descripción de la competencia 3

Al igual que la salud se considera esencial para el desarrollo humano, garantizar una
vida sana y la promoción del bienestar es esencial para un desarrollo sostenible. El bienestar en
los entornos digitales es muy importante a la hora de conseguir un desarrollo personal saludable
en la adolescencia, ya que demuestra un equilibrio entre el uso de dispositivos digitales y el resto
de las actividades cotidianas.

Esta competencia hace referencia a las conductas y medidas de seguridad que han de
adoptarse para el uso de dispositivos, para proteger los datos personales y la salud tanto física,
mental y emocional como social. En esta materia el alumnado adquirirá hábitos que le permitirán
preservar y cuidar su bienestar en entornos digitales, identificando y sabiendo reaccionar ante
posibles amenazas. En este sentido, es especialmente determinante la adopción de conductas
proactivas que protejan a las personas y fomenten relaciones personales respetuosas y
enriquecedoras en todos los contextos de actividad. Estas medidas y conductas promoverán una
ciberconvivencia saludable, ya sea individual o consensuada, tras un diálogo que ayude a
resolver conflictos.

En esta competencia específica se incluye el uso de estrategias que permitan
salvaguardar los datos y la configuración de las aplicaciones instaladas en los dispositivos y
sistemas empleados; además de la configuración de las redes sociales que ayude a proteger la
privacidad en la red. Asimismo, se incide en la gestión eficaz de la identidad digital del alumnado,
orientada a una presencia cuidada en la red teniendo en cuenta la imagen que se proyecta y la
huella que se deja. Igualmente, un punto no menos importante del desarrollo de esta
competencia se refiere a las medidas y hábitos necesarios para prevenir los riesgos derivados
del uso continuado de dispositivos digitales.

2.4. Competencia específica 4

Ejercer una ciudadanía digital crítica mediante un uso activo, responsable y ético de los
medios digitales, el comercio electrónico y la administración digital en la sociedad de la
información.

2.4.1. Descripción de la competencia 4

En una sociedad cada vez más digitalizada crece la necesidad de ejercer una ciudadanía
digital gracias a la participación activa y crítica. El uso extendido de las gestiones digitales que
se realizan con las administraciones públicas y empresas exige conocimientos específicos para
realizarlas, así como tomar conciencia de la brecha digital que existe por diferentes causas.

Esta competencia aborda la instalación y uso de firmas y certificados digitales para
realizar gestiones administrativas a través de plataformas digitales, así como el comercio
electrónico, a través de estándares de intercambio electrónico de datos. Asimismo, implica la
reflexión del alumnado sobre el uso ético en la gestión del gran volumen de información
proporcionada por estas herramientas y su procesamiento mediante la inteligencia artificial. Su
desarrollo debe fomentar la creación de una sociedad más sensible e igualitaria, ecosocialmente
responsable, accesible y sostenible.

En el desarrollo de esta competencia se analizan las plataformas e iniciativas que
permiten a la ciudadanía llegar a ser una sociedad plural y libre, ejercer plenamente sus derechos
y deberes democráticos, pudiendo desempeñar un activismo en línea respetuoso. También tiene
especial importancia la alfabetización mediática entendida como la capacidad de acceder,
analizar críticamente y evaluar el poder de las imágenes, los sonidos y los mensajes a los que

nos enfrentamos día a día para detectar noticias falsas, sesgadas y bulos, ante los que poder
reaccionar.

2.5. Competencia específica 5

Afrontar los desafíos informáticos y digitales que la sociedad de la información plantea
en los ámbitos personal, doméstico y educativo, y formular posibles soluciones.

2.5.1. Descripción de la competencia 5

La sociedad digitalizada en la que vivimos y trabajamos constituye un entorno en
constante cambio y evolución al cual el alumnado debe saber adaptarse para conseguir su plena
integración en la vida adulta. En el mundo actual, la ciudadanía afronta retos informáticos y
digitales que necesitan ser abordados desde una perspectiva global. Y es en esta materia, y más
concretamente mediante esta competencia específica, desde donde la educación básica
responde a esta necesidad.

El alumnado se enfrenta a escenarios digitales cambiantes e inciertos con una actitud
resiliente y proactiva, proponiendo soluciones creativas que mejoren su bienestar digital. El
desarrollo de esta competencia específica permite que el alumnado sea capaz de superar retos
personales y sociales seleccionando de manera idónea los medios digitales para llegar a la mejor
solución posible. Las estrategias se determinan tanto de manera individual como colectiva para
conseguir una meta común en la que se tengan en cuenta diferentes opiniones y puntos de vista.

Las situaciones a las que el alumnado ha de hacer frente son de diversa naturaleza,
desde el manejo de equipamiento informático pasando por contextos derivados de la
digitalización del entorno de aprendizaje y de la colaboración en red segura, hasta el desarrollo
de una ciudadanía digital crítica. En la identificación y resolución de los problemas que surjan
durante el proceso se analizarán críticamente las implicaciones y repercusiones ambientales,
sociales y éticas de las posibles soluciones, así como el ciclo de vida de los dispositivos.

El uso de equipos informáticos y medios digitales en los proyectos implica que el
alumnado debe adquirir habilidades relativas al mantenimiento de los dispositivos, a su ajuste y
a la identificación y resolución de problemas técnicos habituales, garantizando el máximo
aprovechamiento de los equipos, redes y entornos de interacción en la red. Así pues, para
desarrollar esta competencia específica se movilizarán de una manera integrada todos los
contenidos, de conocimientos, procedimentales, actitudinales y axiológicos, incluidos en los
bloques de saberes básicos.

3. Conexiones

Digitalización es una materia en la que se desarrollan cinco competencias específicas.
La primera de ellas, CE1, aborda el diseño, configuración y uso de equipos; la segunda, CE2,
tiene como foco el entorno personal de aprendizaje digital; en el desarrollo de la tercera
competencia, CE3, se asumen hábitos que promueven el bienestar digital; además, el ejercicio
de la ciudadanía digital crítica se desarrolla en la cuarta competencia, CE4. Por último, la CE5
tiene como finalidad formar al alumnado para afrontar desafíos informáticos y digitales. Cada una
de ellas se puede conectar con otras competencias específicas de la materia, con otras del resto
de materias de la etapa y con las competencias clave.

3.1. Relaciones o conexiones con las otras CE de la materia

3.1.1. Conexiones de la competencia específica 1

El diseño, administración y uso de equipos y redes de comunicación puede formar parte
de una solución propuesta en un proyecto de digitalización, por lo que la CE1 se relaciona
estrechamente con la CE5. Además, realizar un uso responsable de los dispositivos implica la
promoción de la salud y el bienestar digital, aspecto cubierto por la CE3.

3.1.2. Conexiones de la competencia específica 2

En la configuración del entorno personal de aprendizaje juegan un papel importante las
herramientas digitales, por lo que el diseño, la administración y el uso de equipos y redes,
recogido en la CE1, son imprescindibles para desarrollar esta competencia. Además, se
relaciona con la CE3, debido a que el uso seguro y saludable de dispositivos y datos juega un
papel destacado en el proceso de aprendizaje permanente. Además, facilita poder afrontar
desafíos y obtener soluciones, lo cual la conecta con la CE5.

3.1.3. Conexiones de la competencia específica 3

Desde esta competencia específica se motiva al alumnado a proteger tanto sus datos y
dispositivos digitales, como a procurar su bienestar físico y mental. A causa de las connotaciones
tan cambiantes que tiene esta temática, muy influenciada por el desarrollo tecnológico, está
relacionada con la CE2, orientada a favorecer el aprendizaje permanente del alumnado, y con la
CE1, debido al uso de dispositivos digitales. Además, se conecta también con la CE5, mediante
la adaptación a los escenarios inciertos y la resolución de desafíos orientados a la vida real que
se proponen en su desarrollo.

3.1.4. Conexiones de la competencia específica 4

Mediante esta competencia se pretende que el alumnado desarrolle una actitud crítica,
ética y proactiva frente a los desafíos que plantea la sociedad de la información. El uso de
dispositivos digitales permite la realización de un amplio abanico de acciones, tanto a nivel
personal como doméstico y educativo, que se deben conocer para poder ejercer una ciudadanía
digital plena y satisfactoria. Así, esta competencia se relaciona con la CE5, en la que se debe
desplegar la faceta proactiva y crítica ante los retos planteados. Además, está relacionada con
la CE2 en la medida que, para desarrollar el sentido crítico, se debe contrastar la veracidad de
la información de la que se dispone proveniente de diversas fuentes. Pero también, al mismo
tiempo, se está ampliando la huella digital, con lo que se debe tener en cuenta las medidas
necesarias para preservarla adecuadamente, y de ahí su relación con la CE3.

3.1.5. Conexiones de la competencia específica 5

La CE5 es la más transversal de las competencias específicas de Digitalización, centrada
en los desafíos informáticos y digitales que la sociedad de la información suscita y en la búsqueda
de soluciones. Está relacionada con el resto de las competencias de la materia, ya que el
alumnado puede afrontar los retos digitales gracias a la adquisición y desarrollo de las
competencias relativas al diseño, configuración y uso de equipos, CE1; el aprovechamiento de
las posibilidades de la digitalización del entorno personal de aprendizaje, CE2; la adquisición y
práctica de hábitos que promueven el bienestar digital, CE3; y el ejercicio de una ciudadanía
digital crítica, CE4.

3.2. Relaciones o conexiones con las CE de otras materias de la etapa

La materia Digitalización, al abordar aspectos tanto puramente tecnológicos como de
expresión y comprensión utilizados en los diferentes canales de comunicación, mantiene
relaciones estrechas con competencias, sobre todo, del ámbito científico-matemático, y también
del ámbito lingüístico debido a la importancia de la expresión, comprensión, interacción e incluso
de mediación lingüística en la materia.

3.2.1. Conexiones de la competencia específica 1

Esta competencia específica guarda relación directa con las de la materia Tecnología y
Digitalización relativas al uso responsable y sostenible de soluciones digitales en el entorno
diario, la configuración, uso, mantenimiento y selección idónea de aplicaciones y sistemas

digitales en función de su naturaleza y características, y el diseño y planificación de soluciones
tecnológicas.

3.2.2. Conexiones de la competencia específica 2

La CE2 se relaciona estrechamente con las competencias específicas del ámbito
lingüístico que ponen el foco en la capacidad de entender y hacerse entender, tanto a nivel escrito
como oral, y mediar correctamente, utilizando el registro adecuado dependiendo de la situación
en la que se produce la comunicación, cuando se trabaja en un grupo de trabajo y cuando se
exponen ideas y opiniones.

Del mismo modo se relaciona la competencia específica de Tecnología relativa a la
expresión, difusión e interpretación de ideas, así como con la de la materia Educación Plástica,
Visual y Audiovisual en lo que concierne al sentido estético de la comunicación de ideas,
sentimientos y emociones.

3.2.3. Conexiones de la competencia específica 3

Esta competencia específica tiene un gran peso actitudinal, lo que la conecta con las de
la materia Valores Cívicos y Éticos, especialmente en lo que atañe a la importancia del trabajo
colaborativo y de la inclusión en el abordaje y búsqueda de soluciones a los principales desafíos
y retos del siglo XXI.

3.2.4. Conexiones de la competencia específica 4

Esta competencia se vincula directamente con varias competencias específicas de la
materia Tecnología. En concreto, con las relativas a la promoción del activismo responsable y
ético desplegando acciones responsables, justas y comprometidas con la transformación social
y adecuadas a un objetivo de desarrollo sostenible. También está conectada con la competencia
específica de la materia Geografía e Historia relativa al contraste de las identidades individuales
con las colectivas, identificando las aportaciones decisivas en su construcción y reconociendo y
valorando las actuaciones de tolerancia y respeto; y con la que destaca la base histórica de la
Unión Europea y la importancia del trabajo cooperativo en el ejercicio de una ciudadanía crítica,
responsable y ética. La conexión es igualmente estrecha con las competencias específicas de la
materia Valores, especialmente en lo que concierne al carácter crítico, responsable y ético que
debe mostrar el alumnado para poder ejercer una ciudadanía digital crítica. Por último, cabe
mencionar la relación con las competencias específicas de Física y Química y de Biología y
Geología, en lo relativo a la importancia del conocimiento científico para aplicar el pensamiento
crítico y la capacidad de distinguir, de este modo, los bulos y opiniones de las informaciones
contrastadas.

3.2.5. Conexiones de la competencia específica 5

Esta competencia específica comparte con otras de Tecnología una visión de la
metodología adecuada para afrontar los desafíos que la sociedad actual plantea con soluciones
que incorporan un punto de vista digital y tecnológico. También se relaciona con las
competencias específicas de la materia Matemáticas que tienen como foco la resolución de
problemas relacionados con situaciones diversas del ámbito social y de iniciación a los ámbitos
profesional y científico utilizando estrategias formales, representaciones y conceptos que
permiten la generalización y abstracción de las soluciones.

3.3. Relaciones o conexiones con las competencias clave

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 |  |  | X | X |  |  |  |  |
| CE | X | X |  | X | X |  |  | X |
| CE3 |  |  | X | X | X |  |  |  |
| CE4 | X |  |  | X |  | X | X |  |
| CE5 | X |  | X | X | X |  | X |  |

Competencias clave del perfil de salida del alumnado al término de la enseñanza
básica:

•
CCL. Competencia en comunicación lingüística

•
CP. Competencia plurilingüe

•
CMCT. Competencia matemática, científica y tecnológica

•
CD. Competencia digital

•
CPSAA. Competencia personal, social y de aprender a aprender

•
CC. Competencia ciudadana

•
CE. Competencia emprendedora

•
CCEC. Competencia en conciencia y expresión cultural

Es evidente que en la materia de Digitalización todas las competencias específicas
favorecen el desarrollo de la competencia clave digital. Esta materia implica el uso creativo,
crítico y seguro de las tecnologías de la información y de la comunicación para alcanzar los
objetivos relacionados con el trabajo, la empleabilidad, el aprendizaje permanente, el uso del
tiempo libre, la inclusión y participación en la sociedad. Así pues, se considera que la
competencia digital está conectada con las cinco competencias específicas de la materia.

3.3.1. Conexiones de la competencia específica 1

La representación de la información, la consideración de características técnicas o el
análisis de gráficos y representaciones matemáticas se abordan en el desarrollo de esta
competencia específica, lo que la conecta con la competencia clave matemática, científica y
tecnológica.

3.3.2. Conexiones de la competencia específica 2

Tanto en el proceso de búsqueda de información como en el resto de las acciones
involucradas en el desarrollo de esta competencia específica se ponen en juego la competencia
clave en comunicación lingüística y la plurilingüe. El trabajo en equipo que se realiza en el
desarrollo de esta competencia conecta con la competencia clave personal, social y de aprender
a aprender, al tener que asumir responsabilidades valorando y respetando el saber y las
opiniones de todos los miembros del equipo. El proceso creativo implica conocer, comprender,

apreciar y valorar las diferentes manifestaciones culturales y artísticas, así como utilizarlas como
fuente, lo que conecta esta competencia con la competencia clave en conciencia y expresiones
culturales.

3.3.3. Conexiones de la competencia específica 3

Las medidas preventivas y correctivas que se deben tomar para proteger los datos y la
salud de las personas, tanto a nivel de dispositivos digitales como de los entornos de trabajo,
domésticos y de ocio, responden a parámetros científicos evaluables de una manera objetiva
mediante la observación y la experimentación. De este modo, se conecta con la competencia
clave matemática, científica y tecnológica. Asimismo, el foco de esta competencia en contribuir
al propio bienestar físico y emocional, conservar la salud y ser capaz de llevar una vida saludable
y orientada al futuro, así como de expresar empatía y gestionar los conflictos en un contexto
integrador y de apoyo, la vincula con la competencia clave personal, social y de aprender a
aprender.

3.3.4. Conexiones de la competencia específica 4

La competencia clave ciudadana se refiere a la capacidad de actuar como ciudadanos y
ciudadanas responsables y participar plenamente en la vida social y cívica, lo que la conecta
directamente con esta competencia. Al mismo tiempo, la participación en una sociedad
digitalizada que permite la conexión mediante medios digitales con la administración pública y el
mundo de la empresa también está vinculada con la competencia clave emprendedora, ya que
utilizando los conocimientos específicos necesarios se pueden generar resultados de valor para
otras personas. Debido a que esta competencia específica permite comprender, interpretar y
valorar críticamente mensajes evitando los riesgos de manipulación y desinformación, así como
comunicarse eficazmente con otras personas de manera cooperativa, creativa, ética y
respetuosa, se relaciona igualmente con la competencia clave en comunicación lingüística.

3.3.5. Conexiones de la competencia específica 5

Como ya se ha señalado, esta competencia específica moviliza todos los saberes
básicos y se interrelaciona con el resto de competencias específicas de la materia. Aunque
también tiene conexiones con todas las competencias clave, su relación más estrecha y directa
es con las competencias clave emprendedora y personal, social y de aprender a aprender. En el
desarrollo de esta competencia específica se reconocen las oportunidades digitales existentes
en el entorno del alumnado para las actividades personales, profesionales y comerciales, y se
mejora la capacidad de adaptación a los cambios y la resolución de problemas de cualquier tipo.
Para desarrollarla, el alumnado ha de apropiarse de los saberes propios de la materia, pero
también ha de adquirir y ser capaz de aplicar distintas estrategias para afrontar los retos, así
como de utilizar las capacidades desarrolladas en otros contextos.

4. Saberes básicos (para el conjunto de las competencias del área/materia)

4.1. Introducción

Mientras que las competencias específicas identifican las actuaciones o tipos de
actuaciones que el alumnado debe poder desplegar en determinadas situaciones, los saberes
básicos son los conocimientos, destrezas, actitudes y valores cuyo aprendizaje es necesario para
la adquisición y desarrollo de dichas competencias, y conforman los contenidos propios de la
materia. Así pues, los saberes básicos de la materia Digitalización han sido agrupados en cuatro
bloques de contenidos e identifican los contenidos que el alumnado debería aprender, articular
y movilizar para las cinco competencias específicas.

El primer bloque, denominado Dispositivos digitales, sistemas operativos y de
comunicación, incluye los contenidos necesarios para poder diseñar, administrar y utilizar

dispositivos digitales. Desde la arquitectura de los ordenadores personales con sus componentes
físicos y lógicos, pasando por los sistemas de comunicación e Internet, hasta la resolución de
problemas, son grupos de saberes incluidos en este bloque, con un marcado carácter científico-
técnico.

Digitalización del entorno personal de aprendizaje constituye el segundo bloque de
saberes básicos y en él se recoge todo lo necesario para buscar, generar y expresar
conocimiento en un entorno digital. Incluye la búsqueda y selección de información, su posterior
organización en un entorno de trabajo digitalizado, la creación de contenido digital de diversos
tipos, la comunicación y colaboración en red, y la publicación y difusión responsable en redes.
Se avanza respecto a materias que el alumnado ha cursado anteriormente en la medida en que
se maximiza la posibilidad que ofrece la red de favorecer el aprendizaje permanente mediante
entornos digitales y la creatividad en la edición de contenidos.

El tercer bloque, Seguridad y bienestar digital, incluye dos grupos de saberes centrados,
respectivamente, en el uso de dispositivos y datos, y en el bienestar en entornos digitales. En
este bloque se conjugan saberes que permiten diseñar, utilizar y mantener estrategias de
seguridad tanto para proteger dispositivos físicos como datos, junto con las medidas que es
necesario conocer y aplicar para preservar el bienestar digital. Es importante que el alumnado
adolescente aprenda a gestionar su imagen digital y sea consciente de la huella que se deja en
los entornos digitales. Se hace especial hincapié en la adopción de conductas que protejan a las
personas y fomenten relaciones personales respetuosas y enriquecedoras. Por lo tanto, este es
un bloque con una gran carga actitudinal.

El cuarto y último bloque, Ciudadanía digital crítica, deriva de la necesidad de
desenvolverse en la sociedad de la información como ciudadanos y ciudadanas de pleno
derecho, incluido el activismo en línea y ecosocialmente responsable. Tiene por objeto que el
alumnado reflexione sobre las interacciones que realiza en la red, considerando que la libertad
de expresión y la etiqueta digital deben primar en sus interacciones. Es necesario reconocer el
papel de los medios y plataformas digitales para poder descartar noticias falsas, conocer los
mecanismos de funcionamiento de las gestiones administrativas y del comercio electrónico, así
como las implicaciones éticas del uso de datos personales y herramientas digitales.

4.2. Bloque 1. Dispositivos digitales, sistemas operativos y de comunicación

|  | Dispositivos digitales, sistemas operativos y de comunicación. CE1 |  |
| --- | --- | --- |
| Arquitectura de ordenadores |  |  |
| • La representación digital de la información. Unidades de medida. • Diseño de un ordenador personal. Elementos, componentes físicos y sus características. • Criterios de selección de los componentes de un ordenador personal. Montaje de ordenadores personales. Simuladores de hardware. Configuración de componentes. • Actitud crítica y razonada para la utilización de los equipos informáticos. Consumo responsable de equipamiento informático. Sostenibilidad. • Interacción de los componentes del equipo informático en su funcionamiento. Prestaciones y rendimiento. • Dispositivos móviles. Características básicas. |  |  |
| Sistemas operativos |  |  |
| • Sistemas operativos comunes para ordenadores personales y dispositivos móviles. |  |  |

• Instalación, configuración, actualización y desinstalación de aplicaciones.

Sistemas de comunicación e Internet

• Tipos de redes de ordenadores. Redes cableadas e inalámbricas.

• Dispositivos de red. Internet de las cosas

• Instalación, configuración y mantenimiento de redes personales y domésticas.
Simulación de redes.

Resolución de problemas

• Estrategias para la prevención de problemas técnicos.

• Herramientas de monitorización.

• Detección y solución de problemas en equipos informáticos y redes.

4.3. Bloque 2. Digitalización del entorno personal de aprendizaje

|  | Digitalización del entorno personal de aprendizaje. CE2 |  |
| --- | --- | --- |
| Búsqueda y selección de información |  |  |
| • Tipos de buscadores web y sus herramientas de filtrado. • Selección de información en medios digitales a través de buscadores web contrastando su veracidad. • Propiedad intelectual. Tipos de derechos, duración, límites a los derechos de autoría y licencias de distribución y explotación. |  |  |
| Organización del entorno de trabajo digital |  |  |
| • Organización de la información en el almacenamiento secundario y en red. • Operaciones básicas con archivos y carpetas. • Personalización del entorno de trabajo. |  |  |
| Creación de contenidos digitales |  |  |
| • Estética y lenguaje audiovisual. • Creación de contenidos digitales con herramientas ofimáticas, multimedia y de desarrollo web. • Derechos de autoría en las aplicaciones. Tipos de software: el software libre y el software propietario. Licencias de software. • Gestión y organización del trabajo en pequeños grupos. Roles en el diseño, producción y publicación. |  |  |
| Programación de aplicaciones |  |  |
| • Algoritmos y entornos de desarrollo de software. • Desarrollo de aplicaciones sencillas para ordenadores personales, dispositivos móviles y web. Aplicaciones de realidad virtual, aumentada y mixta. • Inteligencia artificial en aplicaciones informáticas. |  |  |
| Comunicación y colaboración en red |  |  |
| • Servicios de Internet: www, correo electrónico, videoconferencia, mensajería |  |  |

instantánea, etc.

• Tipos, finalidad y características de comunidades virtuales: redes sociales, entornos
virtuales de aprendizaje, portales web sociales, etc.

• Herramientas colaborativas de edición de contenidos digitales.

• Entornos y redes personales de aprendizaje.

• Hábitos y conductas para el debate crítico sobre conocimientos a través del correo
electrónico y las redes sociales. Estrategias para una ciberconvivencia igualitaria,
segura y saludable.

• Implicaciones que el uso de los dispositivos digitales tiene sobre la salud, la
sostenibilidad y el medio ambiente.

Publicación y difusión responsable en redes

• Publicación multimedia. Publicación web en servidores web y sistemas gestores de
contenidos.

• Blogs y foros como herramientas de publicación y colaboración en línea.

4.4. Bloque 3. Seguridad y bienestar digital

|  | Seguridad y bienestar digital. CE3 |  |
| --- | --- | --- |
| Seguridad en el uso de dispositivos y datos |  |  |
| • Uso seguro de dispositivos y datos. Herramientas de seguridad. • Medidas preventivas y correctivas para hacer frente a riesgos, amenazas y ataques a dispositivos. • Gestión de la identidad digital. La huella digital. • La privacidad en la red. Configuración en redes sociales La protección de los datos de carácter personal. Información y consentimiento. |  |  |
| Bienestar en entornos digitales |  |  |
| • Medidas para proteger la salud física. Ergonomía. Medidas para salvaguardar el bienestar personal. • Implicaciones del uso de los dispositivos digitales sobre la salud, la sostenibilidad y el medio ambiente. • Protección contra situaciones de violencia y de riesgo en la red. • Actitudes para preservar el bienestar digital aplicando las medidas necesarias. |  |  |

4.5. Bloque 4. Ciudadanía digital crítica.

|  | Ciudadanía digital crítica. CE4 |  |
| --- | --- | --- |
| Interactividad en la red |  |  |
| • Estrategias para una ciberconvivencia igualitaria, segura y saludable. Etiqueta digital. • La privacidad en la red. La protección de los datos de carácter personal. Información y consentimiento. |  |  |
| Educación mediática |  |  |

• Alfabetización mediática y libertad de expresión.
• Hábitos, conductas y estrategias comunicativas para el debate crítico a través de la
red.
• Herramientas para detectar noticias falsas y bulos.
Gestiones administrativas

• Ciudadanía digital. Servicios públicos en línea. Registros digitales.
• Sistemas de identificación en la red. El certificado y la firma digital. Contraseñas
seguras.

Comercio electrónico

• El comercio electrónico. Estándares de intercambio electrónico de datos.
• Formas de pago. Monedas digitales. Criptomonedas.
• Estrategias para detección de fraudes.
Ética en el uso de datos y herramientas digitales

• Implicaciones éticas del big data y la inteligencia artificial.
• Sesgos algorítmicos e ideológicos.
• Obsolescencia programada.
• Soberanía tecnológica y digitalización sostenible.
Activismo en línea

• Plataformas de iniciativa ciudadana.
• Activismo digital. Cibervoluntariado.
• Comunidades de desarrollo de hardware y software libres.
• Responsabilidad ecosocial de las tecnologías digitales. Criterios de accesibilidad,
sostenibilidad e impacto medioambiental.

5. Situaciones de aprendizaje para el conjunto de las competencias del área/materia

Las situaciones de aprendizaje integran todos los elementos que constituyen el proceso
de enseñanza y aprendizaje competencial, ya que con ellas se plantean tareas complejas en las
que el alumnado moviliza el conjunto de saberes necesarios para afrontar dichas situaciones. El
diseño de las situaciones debe brindar la posibilidad de generalizar los aprendizajes y adquirir
otros nuevos mediante la realización de tareas complejas que movilizan los conocimientos,
destrezas y actitudes implicados en el desarrollo de las competencias específicas. Las
actividades que se planteen en las situaciones de aprendizaje deben tener las características
adecuadas para asegurar el nivel de desarrollo de la competencia que indican las competencias
específicas.

Con la intención de diseñar situaciones de aprendizaje que sean relevantes, se propone
combinar una serie de elementos que se enumeran a continuación de forma que finalmente se
obtenga el bosquejo del modelo de una situación adecuada de aprendizaje.

En el desarrollo de las situaciones de aprendizaje en el aula se especificarán claramente
los objetivos que se intentan conseguir, mostrando los pasos para abordar las actividades y
tareas de aprendizaje. En un primer momento, el papel del profesorado será el de guía y,
paulatinamente, irá adquiriendo el papel de observador, que en ocasiones puntuales y
justificadas cambiará para hacer aportaciones que sirvan para mejorar o reconducir el trabajo
autónomo del alumnado o del equipo. Esa retroalimentación del profesorado tiene como finalidad
corregir errores, mejorar el desempeño del alumnado y afianzar los procedimientos y sus
respuestas correctas para que el alumnado conozca su rendimiento actual, identifique cómo
puede mejorarlo y aprenda a autorregularse en la ejecución de las tareas de aprendizaje. Es
conveniente incluir en la práctica docente el proceso metacognitivo, facilitando así que el
alumnado reflexione sobre qué ha aprendido y cómo lo ha hecho, y promoviendo la adquisición

de las estrategias, procedimientos, recursos o técnicas que le ayudarán a saber qué ha hecho
bien y porqué, así como qué debe mejorar y de qué manera.

Para empezar, se propone plantear retos globales, o bien hacerlo a través de alguna
situación local o próxima, que la sociedad digital plantea y a los que la materia Digitalización
ofrece elementos de respuesta, tales como el bienestar personal y social, la ciudadanía crítica,
el aprendizaje permanente a lo largo de la vida, la creación y publicación de materiales, la
seguridad en la red, o el uso y configuración de dispositivos digitales y su accesibilidad. Los retos
deben estar próximos a situaciones reales a las que el alumnado pueda enfrentarse en algún
momento de sus vidas con la intención de que den lugar a experiencias auténticas y motivadoras.

Para continuar, habida cuenta del carácter eminentemente práctico de la materia y de
acuerdo con los principios del diseño universal de aprendizaje, las situaciones han de
concretarse ubicando el reto en el ámbito personal, social, laboral, ecológico o educativo. Se
hará hincapié en que se planteen soluciones consensuadas dentro del grupo clase o del equipo
de trabajo, respetando en todo momento las opiniones aportadas y razonando su adopción o no
y los motivos de tal decisión. Siempre se documentará la búsqueda de información que se ha
llevado a cabo para conseguir la solución final, contrastando diferentes fuentes y cuidando el
respeto por los derechos de autoría. Tanto en el aula como fuera de ella se promoverá siempre
el bienestar general y se tendrán en cuenta las medidas de sostenibilidad.

El diseño de las situaciones de aprendizaje debe ayudar a interconectar las
competencias y los saberes básicos, favoreciendo la adquisición de nuevos aprendizajes y
planteando nuevas perspectivas. Es, por último, aconsejable que promuevan diversos modos de
expresarse y representar el conocimiento, valoren y reconozcan lo que se aprende fuera del aula,
y que se incluyan instrucciones claras y precisas de las actividades y tareas que tienen que llevar
a cabo los participantes.

6. Criterios de evaluación

6.1. Competencia específica 1. Criterios de evaluación.

CE1. Diseñar equipos y redes de comunicación de uso personal y doméstico, y
administrarlos y utilizarlos de manera segura y sostenible.

4º ESO

1.1. Diseñar ordenadores personales tomando decisiones razonadas, en base a sus
requerimientos, así como la sostenibilidad y el consumo responsable.

1.2.  Diseñar redes domésticas aplicando los conocimientos y procesos asociados a sistemas de
comunicaciones cableados e inalámbricos.

1.3. Conectar componentes de sistemas informáticos y redes domésticas, utilizando dispositivos
físicos o simuladores.

1.4. Instalar, utilizar y mantener sistemas operativos y aplicaciones configurando sus características
en función de sus necesidades personales.

1.5. Administrar dispositivos móviles y redes domésticas de manera segura y sostenible, según el
uso para el que están destinados.

1.6. Participar en equipos de trabajo para diseñar, administrar y utilizar equipos y redes de
comunicación, respetando los roles asignados y las aportaciones del resto de integrantes del grupo.

6.2. Competencia específica 2. Criterios de evaluación.

CE2. Buscar, seleccionar y organizar la información en el entorno personal de
aprendizaje, y utilizarla para la creación, edición, publicación y difusión de contenidos digitales.

4º ESO

2.1. Buscar y seleccionar información en función de sus necesidades a partir de diversas fuentes
con sentido crítico, contrastando su veracidad, haciendo uso de las herramientas del entorno
personal de aprendizaje y siguiendo las normas básicas de seguridad en la red.

2.2. Organizar y gestionar el entorno personal de aprendizaje mediante la integración de recursos
digitales de manera autónoma.

2.3. Crear, integrar y editar contenidos digitales con sentido estético de forma individual o colectiva,
seleccionando las herramientas más apropiadas para generar nuevo conocimiento y contenidos
digitales de manera creativa, y respetando los derechos de autoría.

2.4 Programar aplicaciones sencillas multiplataforma de manera creativa, de forma individual o
colectiva, respetando los derechos de autoría y licencias de uso.

2.5. Compartir y publicar información y datos interactuando en espacios virtuales de comunicación y
plataformas de aprendizaje colaborativo, adaptándose a diferentes audiencias con una actitud
participativa y respetuosa.

2.6. Participar en equipos de trabajo para favorecer el aprendizaje permanente mediante entornos
digitales.

6.3. Competencia específica 3. Criterios de evaluación.

CE3. Mostrar hábitos que fomenten el bienestar en entornos digitales aplicando
medidas preventivas y correctivas para proteger dispositivos, datos personales y la propia
salud.

4º ESO

3.1. Diseñar, utilizar y mantener estrategias básicas de seguridad en dispositivos digitales y redes
de comunicación, salvaguardando los equipos y la información que contienen.

3.2. Proteger los datos personales y la identidad digital, configurando adecuadamente las
condiciones de privacidad de las redes sociales y espacios virtuales de trabajo.

3.3. Adoptar conductas proactivas que protejan a las personas y fomenten relaciones personales
respetuosas y enriquecedoras.

3.4. Identificar y saber reaccionar ante situaciones que representen amenazas a través de
dispositivos digitales, escogiendo la mejor solución entre diversas opciones y valorando el bienestar
personal y colectivo.

3.5. Tomar medidas de prevención ante los riesgos derivados del uso continuado de dispositivos

digitales

3.6. Mostrar empatía hacia los miembros del grupo reconociendo sus aportaciones y estableciendo
un diálogo igualitario para resolver conflictos y discrepancias.

6.4. Competencia específica 4. Criterios de evaluación.

CE4. Ejercer una ciudadanía digital crítica mediante un uso activo, responsable y ético
de los medios digitales, el comercio electrónico y la administración digital en la sociedad de la
información.

4º ESO

4.1. Hacer un uso ético de los datos y las herramientas digitales, aplicando la etiqueta digital,
colaborando y participando activamente en la red.

4.2. Reconocer las aportaciones de las plataformas digitales en las gestiones administrativas y el
comercio electrónico, siendo consciente de la brecha de acceso, uso y aprovechamiento para
diversos colectivos.

4.3. Valorar la importancia de la oportunidad, facilidad y libertad de expresión que suponen los
medios digitales y comunidades virtuales para poder ejercer un activismo ético y responsable.

4.4. Analizar de forma crítica el mensaje transmitido en medios digitales, teniendo en cuenta su
objetividad, ideología, intencionalidad, sesgos y caducidad.

4.5. Analizar la necesidad y los beneficios globales de un uso y desarrollo ecosocialmente
responsable de las tecnologías digitales, teniendo en cuenta criterios de accesibilidad,
sostenibilidad e impacto.

6.5. Competencia específica 5. Criterios de evaluación.

CE5. Afrontar los desafíos informáticos y digitales que la sociedad de la información
plantea en los ámbitos personal, doméstico y educativo, y formular posibles soluciones.

4º ESO

5.1 Gestionar situaciones de incertidumbre en entornos digitales con una actitud positiva, y
afrontarlas utilizando el conocimiento adquirido y sintiéndose competente.

5.2. Desarrollar proyectos de digitalización en el entorno cotidiano con iniciativa, analizando las
situaciones desde diferentes puntos de vista y proponiendo soluciones creativas.

5.3. Asumir proactivamente responsabilidades en el marco de un grupo de trabajo para abordar
desafíos concretos propios de una sociedad digitalizada y conseguir metas conjuntas.

5.4. Resolver problemas técnicos sencillos analizando componentes y funciones de los dispositivos
digitales, evaluando las soluciones de manera crítica y reformulando el procedimiento utilizado en
caso necesario.
