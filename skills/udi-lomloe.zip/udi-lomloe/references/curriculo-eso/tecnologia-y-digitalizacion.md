# TECNOLOGÍA Y DIGITALIZACIÓN

> Fuente: Secundaria.pdf, páginas 992-1021 (versión en castellano).

TECNOLOGÍA Y DIGITALIZACIÓN

1. Presentación.

La materia de Tecnología y Digitalización contribuye al perfil de salida del alumnado de la
Educación Secundaria Obligatoria mediante aportaciones que, si bien están relacionadas con las de
otras materias, contienen especificidades propias valiosas para su formación integral.

Conviene tener en cuenta que los cambios sociales de las últimas décadas nos han llevado a
una situación en la que la población mundial está altamente relacionada con el mundo tecnológico y,
hasta cierto punto, se ha generado una dependencia global de él. En esta afirmación entendemos la
tecnología desde un punto de vista amplio ya que, como tal, el conocimiento tecnológico se remonta a
los orígenes de la especie humana, pero sin duda la dimensión que este conocimiento ha adquirido en
los últimos años excede con creces al concepto más formal de la palabra “Tecnología”. La revolución
tecnológica de finales del siglo XX se fundamenta en los avances de las Tecnologías de la Información
y Comunicación, imprimiendo en la sociedad un nuevo carácter y una nueva perspectiva en torno a lo
que un ciudadano debe saber y saber hacer.

Teniendo en cuenta estas premisas, la materia de Tecnología y Digitalización fusiona estos
dos aspectos del término, agrupando aquellos relativos al conocimiento asociado a la resolución de
problemas vinculados a la satisfacción de las necesidades humanas con aquellos más recientes,
propios de la comunicación y la globalización en la que hoy en día nos desenvolvemos y habitamos.

En algo más de cien años hemos pasado de una situación en la que la población en general
estaba familiarizada con tecnologías casi ancestrales (en la construcción, la agricultura o la vida
doméstica) y con algunas, concretas, más “modernas” en aquellas personas formadas e implicadas en
las diferentes industrias productivas, a una situación en la que cualquier adolescente tiene en su bolsillo
el acceso a casi todo el conocimiento humano y la posibilidad de ver y hablar en cualquier momento
con cualquier persona de cualquier punto del planeta. Semejante salto tecnológico requiere, sin duda,
de una “acomodación” del sistema educativo que permita al alumnado afrontar con garantías el
desarrollo de las habilidades necesarias para poder entender e interactuar de manera competente,
ética y responsable con este “entorno ultratecnológico” propio del siglo XXI.

La materia contribuye especialmente en el perfil de salida del alumnado a la adquisición de las
competencias clave STEM que forman parte del perfil de salida del alumnado. Entendiendo la
competencia de tecnología como la aplicación de dichos conocimientos para responder a lo que se
percibe como necesidades o deseos humanos, y que se describe en torno al planteamiento y desarrollo
de proyectos, la comunicación relacionada en diferentes formatos utilizando lenguaje técnico y
matemático. Todo ello siguiendo principios éticos y de sostenibilidad. La otra competencia clave a cuyo
desarrollo esta materia contribuye es la Digital. La alfabetización informacional, la gestión de su propio
entorno personal de aprendizaje, la participación activa en plataformas de comunicación, el desarrollo
de programas informáticos, la seguridad de los dispositivos y datos personales, así como el bienestar
de quienes los utilizan, permitirá al alumnado resolver problemas informáticos sencillos. De forma más
transversal, contribuye al desarrollo de las competencias lingüística, personal, social y de aprender a
aprender. En el caso de esta última, fundamentalmente por el desarrollo de proyectos en grupo, en los
que la reflexión, la comprensión proactiva de las diferentes perspectivas y la asunción de
responsabilidades dentro del mismo permitirán al alumnado afrontar constructivamente los nuevos
retos que se les planteen. Finalmente, la competencia emprendedora está también conectada con la
materia de Tecnología y Digitalización, en la que frecuentemente la imaginación, la creatividad y el
pensamiento estratégico intervienen de forma decisiva en los procesos de toma de decisiones con la

finalidad de encontrar soluciones y disfrutar del éxito, pero sin olvidar todas las oportunidades de
aprender en el fracaso.

Conviene destacar el carácter fundamentalmente práctico de esta materia, en la que es
habitual la resolución de problemas basada en el desarrollo de proyectos, el análisis de objetos, la
implementación de diferentes tecnologías (electricidad, mecánica, electrónica, etc.), el diseño, la
simulación, la comunicación o la difusión de ideas o soluciones. Todo ello, contextualizado en torno a
situaciones de aprendizaje bien diseñadas, proporciona amplias oportunidades de desarrollar
actividades de enseñanza y aprendizaje muy significativas para el alumnado.

En la etapa de Educación Primaria el alumnado ya se ha iniciado en realizar proyectos guiados
de diseño utilizando operadores tecnológicos sencillos para dar solución a problemas concretos, que
son la base sobre la que se profundiza en la materia de Tecnología y Digitalización consolidando las
competencias que continuará desarrollando en estudios posteriores o en el desempeño de actividades
profesionales.

En el mundo actual la alfabetización científica, tecnológica y digital es un logro imprescindible;
se espera que todos los individuos sean capaces de comprender, evaluar, usar y transformar
artefactos, procesos y sistemas tecnológicos y digitales para la vida social y productiva y que son
necesarios, además, para poder insertarse en el mundo globalizado en el que estas capacidades
devienen factores de competitividad, productividad e innovación.

A continuación, se describe una propuesta de los aprendizajes esenciales en Tecnología y
Digitalización que el alumnado debería haber alcanzado al finalizar la Educación Secundaria
Obligatoria. Tomando como eje vertebrador el método de resolución de problemas basado en el
desarrollo de proyectos, se formulan las siete competencias específicas para la materia, de las que se
proporciona posteriormente una explicación más extensa en la descripción. Cada una de ellas tiene un
conjunto de conexiones con algunas de las competencias clave, con el resto de competencias
específicas de la materia y con las del resto de las materias de la etapa, que se presentan también
brevemente.

Los saberes básicos exigidos para la adquisición y desarrollo de las competencias específicas
se organizan en sietes bloques: Proceso de resolución de problemas; Digitalización del entorno
personal de aprendizaje; Pensamiento computacional, programación, control y robótica; Herramientas
y máquinas de taller; Materiales, productos y soluciones tecnológicas; Creación, expresión y
comunicación; Tecnología sostenible.

En el apartado dedicado a las situaciones de aprendizaje se presentan algunas directrices para
diseñar de la forma más adecuada ese contexto en el que, conectado en mayor o menor medida con
la realidad, se van a articular los saberes mediante tareas significativas y relevantes para resolver retos
de manera autónoma y creativa. Se pretende de esta forma promover la transferencia de lo aprendido
a situaciones cercanas a la vida real. Siempre desde procesos pedagógicos flexibles y accesibles,
ajustados a las características y diferentes ritmos de aprendizaje del alumnado siguiendo los principios
del Diseño Universal de Aprendizaje Accesible.

Por último, se establecen los criterios de evaluación en los que se especifican, para cada
competencia específica, los aspectos más representativos del nivel de desarrollo que se espera que el
alumnado alcance al finalizar la etapa.

2. Competencias específicas de “Tecnología y Digitalización”

2.1. Competencia específica 1

Identificar y resolver problemas tecnológicos sencillos aplicando el método de proyectos,
propio de la ingeniería, ejecutando, si es necesario, sus fases características y utilizando los medios
tecnológicos y digitales más adecuados al contexto.

2.1.1. Descripción

El foco de esta competencia es la identificación y la resolución de problemas tecnológicos
sencillos y cotidianos relacionados con la satisfacción de necesidades básicas tales como el transporte,
la vivienda, las comunicaciones, los alimentos… etc., siguiendo total o parcialmente y de forma
ordenada las etapas del método de proyectos (definición y análisis del problema, búsqueda de la
información, diseño, planificación, construcción, evaluación y divulgación) que sirve de guía en la
adquisición de los saberes básicos fundamentales de esta área. En este sentido, la combinación de
conocimientos y destrezas interdisciplinares, y actitudes, tales como la autonomía, la innovación, la
creatividad, la valoración crítica de resultados, el trabajo cooperativo y/o colaborativo, la resiliencia y
el emprendimiento, resultan imprescindibles para obtener resultados eficaces en la resolución de
problemas. Esta competencia específica permite conectar los diferentes conceptos implicados en la
definición del problema, aplicarlos y relacionarlos con situaciones reales y cercanas al alumnado y
saber comunicar las ideas obtenidas al resto de la comunidad utilizando los medios tecnológicos y
digitales adecuados a la situación de aprendizaje. El aprendizaje a través de la identificación y
resolución de problemas desencadena en el alumnado el desarrollo del resto de las competencias
específicas definidas en esta área.

La identificación y resolución de problemas tecnológicos, aplicando el proceso tecnológico
propio de la ingeniería, es el foco de esta competencia nuclear y requiere movilizar saberes de los
distintos bloques de contenidos: digitalización del entorno personal; pensamiento computacional;
herramientas y máquinas de taller; materiales, productos y soluciones tecnológicas (estructuras,
electricidad, electrónica); creación, expresión y comunicación; tecnología sostenible. La identificación
del problema o la necesidad, su definición y las condiciones de partida es la primera fase del método
de proyectos. A esta fase le sigue una búsqueda de información, cada vez más digitalizada, que exige
una capacidad de filtrado, de separación de lo útil y lo inútil, lo falso de lo comprobable, una reflexión
sobre la importancia y veracidad de la misma, con intercambios argumentativos razonables,
respetuosos y colaborativos; en definitiva, que exige un pensamiento crítico. Esta búsqueda así
concebida conduce, de manera justificada, hacia la solución más eficaz del problema o la satisfacción
de la necesidad. Esta solución puede ser una respuesta simple que resuelva el problema o un punto
de partida hacia la fase de diseño. En esta fase de diseño, se movilizan contenidos de expresión y
comunicación, física y/o virtual, para proponer de manera detallada la respuesta más eficaz. El
producto final físico y/o virtual creado o construido que dará la solución definitiva a la necesidad
detectada será evaluado críticamente con el fin de comprobar que cumple todos los requisitos exigidos
inicialmente. La aplicación de esta metodología de resolución de problemas tecnológicos no tiene
únicamente un carácter secuencial, sino que puede ser cíclico hasta alcanzar soluciones viables e
idóneas. El proceso termina con la comunicación, difusión y exposición del mismo en un entorno
académico y, si es posible, también social.

En las primeras situaciones de aprendizaje, correspondientes al primer nivel cursado, la
ejecución de las diferentes fases comenzará de forma casi completamente guiada hasta un desarrollo
más autónomo según se incremente el desarrollo competencial del alumnado. Al finalizar este curso,
el alumnado deberá ser capaz de realizar alguna de las fases de manera más o menos autónoma,
especialmente aquellas que requieren de menor capacidad de abstracción y, por ende, de menor grado
de madurez.

Al finalizar la etapa, el alumnado deberá ser capaz de gestionar todo el proceso de manera
prácticamente autónoma con una mínima guía por parte del profesorado. Para obtener resultados
eficaces el alumnado combinará conocimientos con destrezas y un importante componente actitudinal.

2.2. Competencia específica 2

Buscar, obtener, analizar y seleccionar información de forma fiable y segura para poder
gestionar el tiempo, los conocimientos y los recursos disponibles a la hora de abordar retos
tecnológicos, siguiendo un plan de trabajo realista.

2.2.1. Descripción

La sociedad actual, abierta y cambiante gracias a los avances tecnológicos, se caracteriza por
un acceso generalizado a la información. Cualquier persona tiene a su alcance el acceso a una parte
ingente del vasto conocimiento humano. Para ello, es necesario, en primer lugar, saber buscar la
información que se quiere obtener, lo cual implica saber buscar tanto en internet, cómo fuera de la red.
Se ha de ser también capaz de analizar dicha información con sentido crítico, reconociendo las fuentes
fiables y seguras y seleccionando los contenidos más pertinentes para el desarrollo de cualquier tarea.
El bienestar, la privacidad, la identidad digital y la protección de datos propios y ajenos deben ser muy
tenidas en cuenta en el proceso de búsqueda y gestión de la información, de manera inclusiva y
sostenible. Este punto de partida facilita el resto del proceso de resolución de problemas o retos
tecnológicos a los que hay que hacer frente en nuestra vida cotidiana. En base a ello, realizar una
gestión sostenible y adecuada del tiempo y los recursos disponibles es un punto clave. La planificación
adecuada de las tareas, siendo consciente de las limitaciones propias y del entorno, garantiza la
eficacia en la respuesta y en la ejecución. La toma de decisiones reflexiva y basada en un análisis
previo completo y coherente evita fracasos y optimiza recursos. El cambio tecnológico constante de la
sociedad del siglo XXI exige que la ciudadanía sea capaz de desenvolverse con soltura en ese inmenso
abanico de medios y herramientas diseñando su plan y su entorno personal de aprendizaje de la mejor
manera posible. En resumen, el alumnado debe ser capaz de actuar de forma crítica, reflexionando,
planificando las tareas y analizando los recursos y garantizando un uso responsable de los mismos.

En el primero de los dos cursos, se espera que el alumnado sea capaz de buscar información
de una manera intuitiva, sin un elevado formalismo en la administración de la misma, tanto en su
selección como en su custodia y organización. Sí que se espera que sea capaz de hacerlo de manera
segura, tanto para él mismo como para los equipos utilizados, identificando los riesgos relacionados
con el uso de la tecnología. Igualmente, no se espera que la organización de los tiempos sea eficaz,
pero sí estructurada, entendiendo la priorización de tareas y siendo capaz de realizar estimaciones
sencillas de temporalización del trabajo.

Al finalizar la etapa, el alumnado debe también ser más crítico y reflexivo con la información
manejada, siendo capaz de seleccionarla, almacenarla y organizarla de manera eficaz. Asimismo, esta
organización de la información debe poder trasponerse a la organización del trabajo relacionado con
la misma, buscando la eficiencia sin perder de vista los aspectos relativos a la seguridad, así como la
adopción de medidas preventivas para garantizar el bienestar digital aprendidos en el primer curso.

2.3. Competencia específica 3

Configurar, utilizar y mantener máquinas, herramientas, aplicaciones y sistemas digitales,
haciendo una selección idónea y un uso seguro y adecuado de los mismos en función de la tarea.

2.3.1. Descripción

A lo largo del proceso propio de la resolución de problemas tecnológicos, se hace
imprescindible el uso de máquinas y herramientas sencillas, de uso cotidiano, digitales o no, que
requiere de unos conocimientos específicos que garanticen la eficacia y la seguridad. A la hora de
abordar cualquier tarea, la disponibilidad de distintos instrumentos obliga a realizar una selección de
los mismos en base a un análisis adecuado de sus posibilidades y características específicas, así como
su correspondiente adecuación al caso concreto. En cualquiera de las fases de dicho proceso puede
ser necesaria la configuración, uso y mantenimiento de herramientas, maquinaria, aparataje propio de
taller, aplicaciones y sistemas digitales, que posibiliten la ejecución de la acción encaminada a resolver
los problemas tecnológicos sencillos. Adquirir las destrezas necesarias para garantizar el uso
adecuado de dichos elementos incluye conocer sus características, su naturaleza, los potenciales

riesgos derivados de su empleo y respetar sus normas básicas de uso, de manera que se garantice la
máxima seguridad e higiene. La idoneidad de la elección en cada momento atendiendo a todos estos
factores debe ser una máxima en la planificación y el desarrollo de proyectos tecnológicos.

En el primero de los cursos, se espera que el alumnado vaya progresivamente alcanzando un
conocimiento suficiente de las características de las distintas herramientas, aplicaciones, máquinas y
sistemas, de manera que al finalizarlo sea capaz de realizar una adecuada selección de los más
apropiados para cada tarea. Igualmente, se espera que haga un uso adecuado en términos de
seguridad, sostenibilidad e idoneidad de las herramientas, máquinas, aplicaciones y sistemas
seleccionados.

Al finalizar la etapa, además de estas habilidades, se espera que el alumnado sea capaz de
hacer un uso verdaderamente eficiente de los instrumentos mencionados, adaptando la selección a la
tarea requerida y optimizando su uso. Asimismo, se espera que el alumnado realice operaciones
sencillas y adecuadas de revisión, conservación y mantenimiento de los mismos, especialmente de
aquellos más sencillos y de mayor uso cotidiano. La vertiente más actitudinal de esta competencia
vendrá de la valoración de la importancia de hacer un uso seguro y adecuado de la tecnología.

2.4. Competencia específica 4

Realizar un uso responsable y sostenible de los objetos, materiales, productos y soluciones
tecnológicas y digitales existentes en su entorno, analizando críticamente sus implicaciones y
repercusiones ambientales, sociales y éticas.

2.4.1. Descripción

A nuestro alrededor, multitud de objetos y productos cotidianos son fruto del avance
tecnológico. El funcionamiento de nuestra sociedad demanda, cada día más, la generación de nuevos
objetos. Generalmente, el uso de estos se realiza de manera poco reflexiva, dejándose guiar por la
comodidad, el pragmatismo y, en ocasiones, el mero consumismo. Todas las soluciones tecnológicas
provienen de un proceso productivo, iniciado con un diseño y una propuesta basada tanto en las
necesidades de las personas usuarias como en los intereses de las personas productoras. El uso de
estos objetos, productos o soluciones implica la aceptación de las consecuencias y repercusiones
asociadas y requiere un conocimiento básico de sus características y una comprensión adecuada de
su propósito, diseño y funcionamiento. Los aspectos relacionados con las desigualdades y las
agresiones ambientales, vinculadas a la producción industrial y a la generación de residuos, deben ser
conocidos y tenidos en cuenta a la hora de adquirir o desechar un bien tecnológico. El análisis crítico,
basado en valores asociados a los principios de sostenibilidad y seguridad, garantiza que la toma de
decisiones se haga con conocimiento de causa, con respeto hacia el entorno y con atención a la salud
y el bienestar personal. Una ciudadanía responsable debe ser capaz de tener en cuenta todos estos
detalles y actuar en consecuencia en su interacción con los diferentes productos tecnológicos que le
rodearán en su vida cotidiana.

Al finalizar el primero de los dos cursos, se espera que el alumnado sea capaz de relacionar
el diseño, la producción y el uso de objetos, materiales, productos y soluciones tecnológicas con los
residuos que se generan y con las agresiones tanto ambientales como a la salud y bienestar personal.
En cuanto a la fabricación de objetos, el alumnado será capaz de aportar pruebas sobre qué procesos
generan menor cantidad de residuos o generan residuos susceptibles de ser reciclados.

Al finalizar la etapa, el alumnado será capaz de identificar y analizar, de manera global y con
conocimientos técnicos, los problemas que afectan a nuestro planeta generados por la actividad
humana de una manera directa o indirecta, sus causas y las posibles actuaciones que se puedan
emprender para mitigarlos o adaptarse a ellos. Además, el alumnado habrá adquirido conciencia de
los hábitos de consumo responsable que conllevan una reducción de la huella de carbono, un menor
consumo energético y una menor generación de residuos, siendo además un activo en la difusión de

dichas prácticas en su entorno más cercano y aportando pruebas en torno a la idoneidad de las
mismas.

2.5. Competencia específica 5

Crear, expresar, comprender y comunicar ideas, opiniones y propuestas utilizando
correctamente los lenguajes y los medios propios de la tecnología y la digitalización, tanto en el ámbito
académico como en el personal y social.

2.5.1. Descripción.

Al igual que en cualquier otra área de conocimiento, el correcto uso de los lenguajes propios
de la tecnología y la digitalización (que a su vez se construye mediante la utilización de otros como el
matemático, lingüístico y plástico-visual) es un aspecto esencial de esta competencia. Los diferentes
formatos de expresión del conocimiento, textos escritos, exposiciones orales, representaciones
gráficas, audiovisuales, etc., así como las singularidades lingüísticas propias, son las herramientas con
la que se garantiza una comunicación adecuada de ideas, conceptos y opiniones. Ese dominio del
lenguaje propio y de los instrumentos de comunicación característicos facilita la interacción y el trabajo
colaborativo. El uso adecuado de aspectos tan diversos como la etiqueta o las normas de diseño
gráfico guían y facilitan la comprensión, la circulación de la información y la participación del alumnado
en la resolución de los problemas tecnológicos. Compartir información, conocimiento y propuestas de
manera adecuada y selectiva es una condición necesaria para dar respuesta a estos problemas de
manera eficaz. Los medios para llevar a cabo dicha comunicación de manera correcta pueden incluir
soportes sencillos, tanto físicos como informáticos, adecuados al contenido y al contexto comunicativo.

En el diseño y comunicación interviene la elección razonada y con sentido estético de las
diferentes posibilidades de expresión en diferentes medios, como pueden ser los de tipo textual,
numérico, multimedia, etc. La creación de contenidos incluye el uso de herramientas digitales sencillas
que permitan la captura, maquetación, manipulación, procesamiento e integración de información para
la realización de tareas en diversos contextos. La producción y comunicación de información contempla
la utilización de lenguaje inclusivo y específico adaptado al contexto, integrando tanto contenidos
propios como ajenos, seleccionados críticamente, respetando sus licencias y derechos de autoría.

Al finalizar el primero de los cursos, se espera que el alumnado utilice lenguajes y canales de
comunicación adecuados, generando mensajes fácilmente comprensibles tanto por las personas
integrantes de su equipo como por cualquier otra ajena a la tecnología. Esto implica el dominio de
habilidades básicas comunicativas que permitan el trabajo en equipo y la coordinación para realizar
las tareas propias de la materia. Dicha comunicación requiere del conocimiento de lenguajes propios,0
como la expresión gráfica o el uso de aplicaciones digitales sencillas. Obviamente, la expresión oral y
escrita debe estar en consonancia con los requerimientos propios de las competencias lingüísticas
específicas de las diferentes lenguas y de las matemáticas. Además de la elaboración, se espera que
el alumnado sea capaz de comprender y procesar de manera adecuada mensajes sencillos que estén
codificados en alguno de los lenguajes propios.

Al final de la etapa, se espera que la competencia comunicativa se haya desarrollado a un
nivel más avanzado, utilizando los lenguajes del área para comprender y transmitir las ideas y
pensamientos propios y ajenos. La producción de elementos comunicativos con una abstracción mayor
es uno de los avances esperados. Asimismo, se debe haber alcanzado un dominio de lenguajes más
específicos, con una riqueza de vocabulario técnico, acorde a su nivel de madurez. La comprensión
de mensajes de cierta complejidad relacionados con el área y una mayor destreza argumentativa a la
hora de transmitir sus ideas, expresar sus reflexiones y transmitir su visión crítica, son cuestiones, que
al finalizar la etapa, deben formar parte del bagaje del alumnado.

2.6. Competencia específica 6

Analizar problemas sencillos y plantear su solución automatizando procesos con herramientas
de programación, sistemas de control o robótica y aplicando el pensamiento computacional.

2.6.1. Descripción

Esta competencia aborda el análisis de problemas cotidianos y sus posibles soluciones de
manera que puedan llevarse a cabo tanto por una persona como por una máquina o inteligencia
artificial.

La competencia está enfocada a la resolución de problemas, tanto de manera individual como
distribuyendo las tareas en un equipo de trabajo, mediante diferentes entornos de desarrollo que
utilicen lenguajes de programación por bloques. La adquisición de esta competencia específica implica
la representación de la realidad mediante abstracciones con modelos, simulaciones y las estructuras
de datos necesarias, así como el interés y la curiosidad por la innovación y el progreso científico-
tecnológico desde una perspectiva igualitaria, inclusiva y sostenible.

El pensamiento computacional requiere definir propuestas para conseguir su automatización
mediante algoritmos con una secuencia de pasos ordenados y bucles, los cuales se implementan en
un lenguaje de programación por bloques y se ejecutan en diferentes dispositivos. De esta forma, la
competencia está enfocada al diseño y activación de algoritmos para lograr un objetivo concreto.
Ejemplos de ello serían el desarrollo de una sencilla aplicación informática, la automatización de un
proceso o el desarrollo de un sistema de control de una máquina en la que intervengan distintas
entradas y salidas; es decir, la aplicación de la tecnología digital en el control de objetos o máquinas,
automatizando rutinas y facilitando la interactuación con los objetos, incluyendo así, los sistemas
controlados mediante la programación de una tarjeta controladora o los sistemas robóticos.

Al acabar el primer nivel, el alumnado habrá adquirido las destrezas básicas implicadas en la
programación por bloques progresando desde un nivel básico a través de la utilización de estructuras
de programación, uso de variables, bucles. Al acabar el segundo nivel, el alumnado será capaz de
realizar diseños en diferentes plataformas.

2.7. Competencia específica 7

Utilizar la tecnología poniéndola al servicio del desarrollo personal y profesional, social y
comunitario y proponiendo soluciones creativas a los grandes desafíos del mundo actual.

2.7.1. Descripción

Los cambios son inherentes a la vida de un ser humano y, por tanto, la capacidad de asimilar
dichos cambios no puede entenderse como una competencia específica de una materia en concreto,
sino que es más bien transversal a todas ellas. No obstante, los cambios en el plano tecnológico y
digital son percibidos de manera más relevante por la ciudadanía y, por ello, esta materia puede ser
una plataforma ideal para desarrollar procesos de autoaprendizaje eficaces, que posibiliten la
participación activa en los diferentes aspectos de la vida cotidiana en los que la tecnología pueda tener
repercusiones. Estas repercusiones deben ser entendidas tanto desde el punto de vista de un futuro
laboral, como de la consideración de que una sociedad que maneja adecuadamente la tecnología
puede reducir la desigualdad y favorecer un entorno más seguro y solidario a través de los valores
democráticos, culturales y sociales propios de la identidad europea y sus normativas. Por otra parte,
se debe fomentar la autoestima y la confianza en las propias posibilidades al afrontar nuevas
situaciones de aprendizaje, favoreciendo e impulsando la capacidad de innovar y la creatividad a la
hora de aportar las mejores soluciones posibles para transformar la realidad. Mediante esta
competencia se pretende, en definitiva, poner en valor el papel de la tecnología y la digitalización en el
progreso social, cultural, artístico y científico. Se trata, por tanto, de una competencia con un importante
componente actitudinal y axiológico, puesto que implica la movilización de convicciones, apreciaciones
y valores, así como de intereses y motivaciones.

Al finalizar el primer curso, el alumnado conocerá y será capaz de utilizar la tecnología a nivel
básico para un uso personal y podrá utilizar diferentes soluciones tecnológicas previamente
establecidas para desarrollar soluciones creativas. El nivel de incertidumbre que el alumnado será
capaz de gestionar en este momento será, pues, limitado.

Al finalizar el último curso, el alumnado, además de un uso básico de las distintas tecnologías,
será capaz de analizarlas y valorarlas para elegir la que mejor se adapte y ofrezca un servicio más
adecuado a lo que las nuevas necesidades demandan. Por lo tanto, podrá proponer nuevas
tecnologías para afrontar las diferentes situaciones que se le planteen, asumiendo la gestión de un
grado creciente de incertidumbre y siendo capaz de actuar con un mayor grado de libertad para afrontar
los retos. Por último, el alumnado valorará los logros del desarrollo tecnológico como motores de
transformación y de desarrollo social, cultural y científico a lo largo de la historia.

3. Conexiones de las competencias específicas entre sí, con las competencias específicas de otras
áreas / materias y con las competencias clave

3.1. Relaciones o conexiones con las otras CE del área/materia

Competencia 1 Conexiones

El hecho de considerar esta primera competencia específica como una macrocompetencia
hace que su relación con las competencias específicas propias de la materia y las competencias clave
sea una obviedad.

Las otras competencias específicas están de una manera u otra incluidas en esta, en la medida
en que sus focos respectivos refieren a aspectos esenciales de la resolución de problemas
tecnológicos sencillos: el análisis de la información y la gestión de recursos (CE 2), las destrezas
básicas en el uso responsable y crítico de elementos tecnológicos y digitales (CE 3 y CE 4), así como
los lenguajes utilizados (CE 5) en el proceso están presentes al afrontar cualquier problema del área.
La capacidad de desarrollar un aprendizaje autónomo a partir de los conocimientos adquiridos
garantizará la solvencia y facilitará el éxito en la resolución de dichas situaciones problemáticas o retos.

Competencia 2 Conexiones

Esta competencia específica está relacionada con el resto de competencias de la materia: la
búsqueda de información forma parte de una de las fases del proceso propio del diseño de la ingeniería
a la que se hace referencia en la CE 1; la necesidad de usar de manera adecuada herramientas
tecnológicas para abordar los retos tecnológicos cotidianos está vinculada a la CE 3; saber
comunicarse y exponer las ideas utilizando correctamente el lenguaje enlaza con la CE 5 y la buena
gestión del conocimiento adquirido para llegar a una solución adecuada se relaciona con la CE 7 y la
CE 4.

Competencia 3 Conexiones

Esta competencia está relacionada con el resto de las competencias específicas de la materia.
La utilización responsable y sostenible de máquinas y herramientas tecnológicas y el uso de sistemas
informáticos se relaciona con la CE 1, CE 2 y CE 4 a la hora de resolver los problemas, retos
tecnológicos sencillos y cercanos al alumnado.

Competencia 4 Conexiones

Esta competencia específica está relacionada con el resto de competencias de la materia. Las
CE 1, CE 2, CE 3 y CE 7 nos ayudan a realizar un uso responsable y sostenido de los objetos,
productos y soluciones tecnológicas y digitales a la hora de comprender su funcionamiento, diseño y
propósito, para satisfacer las necesidades de la sociedad. También se relaciona con la CE 5 por la
exigencia de analizar críticamente las implicaciones y repercusiones ambientales, sociales y éticas del
funcionamiento de estos productos utilizando correctamente los lenguajes propios de esta área de
conocimiento.

Competencia 5 Conexiones

La dimensión comunicativa y la producción y comprensión de mensajes relacionados con
aspectos tecnológicos y digitales sobre situaciones reales vincula esta competencia con el resto de
competencias específicas. Crear, expresar, comprender y comunicar ideas, opiniones y propuestas
relacionadas con aspectos tecnológicos y digitales requiere obtener, analizar y seleccionar información
de forma fiable y segura (CE 2), así como manejar de manera responsable y sostenible las máquinas
y herramientas tecnológicas y digitales (CE 3). Así mismo, para hacer un uso correcto de los objetos,
productos y soluciones tecnológicas (CE 4), es necesaria una comprensión adecuada y utilización
correcta de los lenguajes propios de este ámbito de conocimiento.

Competencia 6 Conexiones

Convertir las ideas planteadas en una solución digital requiere una planificación y gestión de
proyectos (CE 1) con un enfoque social y cultural que implica creatividad, la asunción de retos, la
gestión de éxitos y fracasos para la innovación y el progreso tecnológico (CE 7). Las implicaciones
sociales y éticas del diseño y desarrollo de aplicaciones hacen que esta competencia específica esté
relacionada con la CE 4.

Competencia 7 Conexiones

|  | puesto que en el proceso que va desde la definición de un problema hasta la elaboración |
| --- | --- |
| de un producto o solución tecnológica y disponer de los conocimientos para su uso se deberá analizar |  |
| y considerar el impacto que tiene en el medio ambiente, la vida social, etc. También se relaciona con |  |
| el resto de competencias específicas de la materia, puesto que ese aprendizaje permanente se hace |  |
| con la intención de resolver problemas (CE 1), gestionando la información que permita dicho |  |
| aprendizaje (CE 2), conlleva frecuentemente el uso de alguna herramienta o sistema informático (CE |  |
| 3) y, por supuesto, requiere el conocimiento adecuado de los lenguajes propios del área (CE 5). |  |

3.2. Relaciones o conexiones con las CE de otras áreas/materias de la etapa

La materia de Tecnología y Digitalización incorpora en sus competencias específicas y los
saberes básicos asociados una buena parte del ámbito de conocimiento y de actividad de la ciencia,
la tecnología y las matemáticas. Por esta razón, las conexiones más directas y numerosas se dan con
las áreas de Ciencias y Matemáticas.

Competencia 1 Conexiones

Así, la CE 1, relativa a la identificación y resolución de problemas tecnológicos, se vincula con
las competencias matemáticas, puesto que la resolución de esos problemas pone en juego a menudo
modelos matemáticos de la realidad (CE 3 de la materia de Matemáticas), y, si el producto tecnológico
que soluciona el problema es un programa informático, la aplicación del pensamiento computacional
(CE 4 de Matemáticas).

Competencia 2 Conexiones

La CE 2, relativa a la búsqueda y análisis de información fiable para abordar retos, se relaciona
con las competencias específicas del área de Biología y Geología (CE 2) de Física y Química (CE 3)
que ponen el acento en la utilización del conocimiento científico para distinguir la información
contrastada de los bulos y opiniones. También con la competencia de Geografía e Historia relativa al
tratamiento correcto de la información en cuanto a su organización, crítica y respeto (CE 2). Existe, así
mismo, una conexión con las competencias específicas de las materias de Lengua Castellana y
Valenciano relacionadas con la comprensión escrita (CE 3) y la lectura autónoma (CE 8). Y con las de
la materia Lengua Extranjera que abordan la comprensión oral y escrita (CE 2 y CE 3).

Competencia 3 Conexiones

La CE 3 mantiene una estrecha relación con la CE 7 de la materia de Valores Cívicos y Éticos,
ya que un uso inadecuado de las máquinas, herramientas, aplicaciones y sistemas propios de la
tecnología puede tener repercusiones, en términos de sostenibilidad, que deben abordarse de manera
crítica. Igualmente, el uso inadecuado de los elementos tecnológicos y digitales puede tener un impacto
en el bienestar físico y mental, especialmente en aspectos como la ergonomía o los potenciales
problemas psico-sociales asociados al abuso de determinados dispositivos y aplicaciones digitales, lo
que vincula esta competencia con la CE1 de Educación Física.

Competencia 4 Conexiones

La CE 4, relativa al uso responsable y sostenible de cualquier solución tecnológica y sus
repercusiones ambientales, sociales y éticas, tiene una intensa conexión con las CE 10 y CE 11 de
Biología y Geología relacionadas con la adopción de hábitos responsables con el entorno y la
búsqueda de soluciones científicas a los problemas de naturaleza ecosocial son sus elementos clave.
El desarrollo de esta competencia y de todas aquellas que la complementan necesita de una
sensibilización que debe sustentarse en datos objetivos y en la reflexión asociada a un pensamiento
crítico. Por otra parte, las implicaciones económicas, sociales y éticas que se derivan de la cultura de
la sostenibilidad la conectan con las CE 5 y CE 7 de Geografía e Historia, habida cuenta de la
necesidad de generar argumentos críticos sobre estas problemáticas relevantes siempre desde la
asunción de valores democráticos fundamentales.

Competencia 5 Conexiones

La CE 5, cuyo foco es la comunicación, expresión y comunicación de ideas tecnológicas, se
relaciona lógicamente con las competencias sobre los distintos lenguajes que es necesario emplear
en tecnología: plástico y visual, matemático y lingüístico. Este hecho la conecta con las competencias
CE 4, CE 5 y CE 6 de lengua extranjera, las CE 4, CE 5 y CE 6 de Lengua castellana y literatura y
Valenciano: lengua y literatura, ya que para comunicar ideas, opiniones y propuestas se hace uso tanto
de la expresión oral como escrita estableciendo una interacción y mediación también oral y escrita.
Asimismo, mantiene una estrecha relación con la competencia matemática CE 3, centrada en
interpretar, analizar y valorar problemas relevantes mediante modelos matemáticos, y la CE 5, con el
foco puesto en el manejo del simbolismo matemático. Por último, también las competencias CE 4 y CE
5 de Educación Plástica y Visual conectan directamente con las necesidades comunicativas de la
actividad tecnológica y digital.

Competencia 6 Conexiones

La CE 6, relativa al pensamiento computacional, tiene relación directa con la CE 3 y las CE 4
de la materia de Matemáticas que versan, respectivamente, sobre la modelización matemática y la
implementación de algoritmos computacionales organizando datos, descomponiendo un problema en
partes, reconociendo patrones y empleando lenguajes de programación y otras herramientas TIC.

Competencia 7 Conexiones

Esta competencia, centrada en el uso de la tecnología al servicio del desarrollo personal,
profesional, social y comunitario, mantiene una relación estrecha con la CE 3 de Geografía e Historia
que, a través de las nociones básicas de cambio y continuidad en la historia y adoptando una
perspectiva causal y contextualizada, busca en el pasado el origen y la evolución de las cuestiones
más relevantes del mundo actual al tiempo que promueve la  formación de juicios y opiniones sobre el
presente y el futuro. Y también con la CE 8, de esta misma materia, orientada a promover y participar
en proyectos cooperativos de convivencia que favorezcan un entorno más justo y solidario mediante
la aplicación de valores y procedimientos democráticos. Finalmente, cabe mencionar las relaciones
con las CE 6 y CE 7 de la materia de Valores Cívicos y Éticos relativas, respectivamente, a la lucha
contra la desigualdad y las injusticias, y a los desafíos ecológicos y el desarrollo sostenible. En ambos
casos el uso adecuado de la tecnología puede ser una fuente importante de soluciones.

3.3. Relaciones o conexiones con las competencias clave.

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE 1 |  |  | X | X |  |  | X |  |
| CE 2 | X | X | X |  |  |  |  |  |
| CE 3 |  |  | X | X | X | X |  |  |
| CE 4 | X |  | X | X |  | X |  | X |
| CE 5 | X | X | X | X |  |  |  | X |
| CE 6 | X | X | X | X | X |  | X |  |
| CE 7 |  | X | X | X | X |  |  |  |

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

CCL: competencia en comunicación lingüística

CP: competencia plurilingüe

CMCT: competencia matemática, ciencia y tecnológica

CD: competencia digital

CPSAA: competencia personal, social y de aprender a aprender

CC: competencia ciudadana

CE: competencia emprendedora

CCEC: competencia en conciencia y expresión cultural

CE 1

Tanto en el proceso de búsqueda de información como en la fase de diseño y en la
comunicación y difusión del resultado final se ponen en juego la competencia clave en comunicación
lingüística y, en su caso, la plurilingüe. Igualmente, la competencia digital impregna estas mismas fases
o se aplica de pleno en el caso de que el objeto construido sea un producto digital. El trabajo
colaborativo y/o cooperativo propio del método de diseño de la ingeniería apela tanto a la competencia
ciudadana y a la de conciencia y expresión cultural, como a la personal, social y de aprender a
aprender, al tener que asumir responsabilidades valorando y respetando el saber y las opiniones de
todo el equipo. Del mismo modo, la iniciativa en la búsqueda y propuesta de soluciones hace uso de
un conocimiento STEM y recurre a un carácter y una actitud propios, respectivamente, de las
competencias clave en matemáticas, en ciencia, tecnología e ingeniería y emprendedora.

CE 2

Sin duda la competencia clave en comunicación lingüística y por extensión la plurilingüe son,
por motivos obvios, las que presentan una relación más directa con esta competencia. Así mismo, la

condición participativa implica también la puesta en juego de la competencia ciudadana. La
comunicación orientada a un propósito concreto y el trabajo colaborativo facilitan aprendizajes
dialógicos y de resolución de conflictos. La aceptación de la diversidad y la interacción empática y
respetuosa son aspectos de esta competencia que entroncan directamente con la competencia clave
en conciencia y expresión culturales al respetar la forma en que las ideas pueden ser expresadas y
comunicadas. Lógicamente, y como en el resto de las competencias específicas de nuestra área, la
conexión con la competencia matemática y en ciencia y tecnología y la competencia digital son
inherentes al planteamiento de la competencia en comunicación tecnológica y digital. La competencia
personal, social y de aprender a aprender y la competencia emprendedora están, así mismo,
directamente implicadas en lo que concierne a la gestión del aprendizaje y al desarrollo de un enfoque
dirigido a utilizar los conocimientos necesarios para generar resultados que hagan frente a los retos.

CE 3

Como sucede con las otras competencias específicas de la materia, las competencias clave
matemática y en ciencia y tecnología y digital son consustanciales a esta competencia. Entre el resto
de competencias clave, conviene resaltar la conexión con las competencias en comunicación
lingüística y plurilingüe en lo que concierne al análisis de las descripciones de las diferentes técnicas
y herramientas. El uso de las mismas requiere a menudo la interpretación de textos instructivos y del
dominio del lenguaje propio del área. Igualmente, la competencia ciudadana se materializa en el
análisis crítico de elementos involucrados en el desarrollo de esta competencia específica. Las
decisiones sobre los materiales, los objetos o los procesos utilizados requieren de las consideraciones
relacionadas con el desarrollo sostenible y los Objetivos del Desarrollo Sostenible asociados. La
competencia personal, social y de aprender a aprender está también directa y estrechamente
relacionada con esta competencia específica, en lo que atañe al conocimiento de los riesgos para la
salud, propia y colectiva.

CE 4

Junto a las competencias clave matemática y en ciencia y tecnología y digital, obviamente
vinculadas a la materia como sucede en las competencias específicas precedentes, la necesidad de
comprender e interpretar de manera crítica y responsable la información disponible sobre los productos
tecnológicos hace que la competencia clave en comunicación lingüística sea esencial para la
adquisición de esta competencia específica. De manera similar, la competencia plurilingüe permite
tener mayor sentido crítico, al poder contrastar opiniones y datos sobre innovaciones tecnológicas
expresados en otras lenguas. La competencia emprendedora juega igualmente un papel importante
en la adquisición de nuevos conocimientos que nos ayuden a avanzar en una reflexión ética sobre el
funcionamiento y utilización de los nuevos productos tecnológicos cotidianos que van surgiendo en la
sociedad como consecuencia del avance tecnológico. Del mismo modo, el impacto de los productos
tecnológicos confiere especial importancia a la competencia ciudadana. La tecnología del siglo XXI
plantea constantemente nuevos dilemas éticos, cuya respuesta puede tener consecuencias en el estilo
de vida del alumnado y, en última instancia, de su entorno social. Una vez más, la sostenibilidad
emerge como término vertebrador del desarrollo de esta conexión competencial. En esta línea, el
respeto por la riqueza cultural, anteponiendo los intereses de su preservación frente a potenciales
amenazas basadas en aspectos tecnológicos, requiere de una correcta integración de la competencia
en conciencia y expresión cultural a la hora de ejercer el uso responsable y el análisis crítico de los
productos tecnológicos.

CE 5

Sin duda, las competencias clave en comunicación lingüística, y por extensión la plurilingüe,
son, por motivos obvios, las que presentan una relación más directa con esta competencia específica.
La integración del discurso sobre una situación para justificar argumentos es un instrumento poderoso
de pensamiento crítico y de confianza en sí mismo, lo cual la relaciona con las competencias clave
ciudadana, emprendedora y social, personal y en aprender a aprender. La comunicación orientada a

un propósito concreto y el trabajo colaborativo facilitan aprendizajes dialógicos y de resolución de
conflictos. La aceptación de la diversidad y la interacción empática y respetuosa son aspectos de la
competencia clave referida a la conciencia y expresión cultural que entroncan directamente con esta
competencia específica. Lógicamente, y como en el resto de las competencias específicas expuestas,
las conexiones con la competencia matemática y en ciencia y tecnología y la competencia digital son
inherentes al planteamiento de la competencia en comunicación tecnológica y digital.

CE 6

Esta competencia específica es la que mayor conexión tiene con la competencia clave
matemática y en ciencia y tecnología y, por supuesto, con la competencia digital. En el desarrollo de
esta competencia se utilizan métodos inductivos, deductivos y lógicos para plantear modelos y
transmitir los razonamientos utilizando lenguaje formal con rigor y precisión científica. Tanto la
búsqueda de información fiable, como la organización del entorno de desarrollo, la gestión colaborativa
de proyectos, la seguridad y sostenibilidad en el trabajo y soluciones, así como el desarrollo
aplicaciones informáticas, son aspectos que abarca esta competencia específica.

En el proceso de desarrollo de software es imprescindible la comprensión, selección de
información y expresión a través de lenguas oficiales y extranjeras, lo que vincula esta competencia
específica con las competencias clave en comunicación lingüística y plurilingüe. La autonomía personal
que favorece esta competencia específica está relacionada con la competencia personal, social y de
aprender a aprender ya que se han de gestionar los retos que plantea la programación, aumentando
su motivación para aprender, generar hábitos de trabajo saludables física y mentalmente, colaborar
activamente con el grupo de trabajo, usar fuentes fiables para validar los aprendizajes y plantear
mecanismos para aprender de los errores a medio plazo.

CE 7

La principal competencia clave relacionada con esta competencia específica es la personal,
social y de aprender a aprender, en la que la gestión del aprendizaje a lo largo de la vida como forma
de afrontar la incertidumbre y complejidad de los escenarios futuros, se presenta como algo esencial
para todas las personas. La exposición recurrente a la necesidad de establecer procesos de
autoaprendizaje llevará a desarrollar estrategias cada vez más efectivas para lograr realizar los
procesos que se le demandan. Conecta, así mismo, con la competencia emprendedora en lo que
concierne al enfoque vital con que se actúa frente a las oportunidades, que serán siempre entendidas
como oportunidades para aprender. Lo hace también con la competencia ciudadana, en tanto que el
desarrollo de esta competencia tiene como trasfondo la participación plena en la vida social y cívica
con valores democráticos. De la misma manera, la competencia digital está implicada de forma directa,
puesto que es el entorno digital el que mayor volumen de tecnologías presenta y en el que las
consideraciones sobre la identificación de riesgos y la adopción de medidas para proteger los
dispositivos, los datos personales y la legalidad que van ligadas a estas tecnologías son de mayor
utilidad para establecer una reflexión crítica de las mismas. La competencia matemática y en ciencia y
tecnología está estrechamente relacionada con todas las competencias específicas de esta materia.
Por último, hay también una conexión con la competencia plurilingüe en lo que concierne a las
posibilidades de emplear diferentes lenguas en los recursos para desarrollar el aprendizaje.

4. Saberes básicos

4.1. Introducción.

Los saberes o contenidos básicos son los que se consideran necesarios para la adquisición y
el desarrollo de las competencias específicas, siendo por tanto estas competencias el criterio utilizado
para su selección.

Los saberes se han agrupado en siete bloques de contenidos que abarcan toda la materia.
Mediante el aprendizaje, articulación y movilización de los saberes incluidos en estos bloques se

asegura que el alumnado sea capaz de comprender, reflexionar y actuar frente a los profundos cambios
que el desarrollo tecnológico y la digitalización están imprimiendo en la sociedad, de acuerdo con lo
establecido en las competencias específicas.

Los contenidos incluidos en estos bloques son necesarios para utilizar el conocimiento
científico y tecnológico aplicando metodologías de trabajo creativo, y para desarrollar ideas y
soluciones innovadoras y sostenibles con una actitud creativa y emprendedora. Asimismo, son
necesarios para hacer un uso responsable y ético de las tecnologías digitales, aprender a lo largo de
su vida, reflexionar de forma consciente, informada, crítica y responsable sobre la sociedad digital en
la que vivimos, y para afrontar situaciones y problemas habituales con éxito.

La organización de los contenidos en bloques tiene como finalidad facilitar su comprensión y
no debe interpretarse en ningún caso como una propuesta para abordarlos y trabajarlos por separado.
Su tratamiento será integral y no deben entenderse de forma aislada. Su adquisición y movilización
mediante situaciones de aprendizaje adecuadas permitirá el desarrollo de las competencias
específicas y, con ello, el de las competencias clave incluidas en el perfil de salida del alumnado.

El bloque referido al Proceso de resolución de problemas es el eje vertebrador de todos los
saberes básicos. Se aborda el desarrollo de estrategias y métodos para, partiendo de la identificación
de un problema o necesidad, llegar al desarrollo de una solución, pasando por las distintas fases
intermedias de forma planificada.

En el bloque de Digitalización del entorno personal de aprendizaje se introducen elementos
propios del espacio digital, como el ajuste y mantenimiento de equipos y aplicaciones, que forma parte
de la vida cotidiana de la ciudadanía de manera cada vez más relevante y cuyo dominio, por lo tanto,
deviene una destreza esencial en la sociedad del siglo XXI.

El bloque de Pensamiento computacional, programación, control y robótica incluye los
fundamentos del planteamiento y solución de problemas, a través de la abstracción, secuenciación,
algorítmica y reconocimiento de patrones, aplicada al diseño de programas sencillos y a la
automatización de los procesos, propia de los robots y los sistemas de control, elementos muy
presentes en la cotidianidad del alumnado

En el bloque de Herramientas y máquinas de taller se presenta el conjunto de saberes
relacionados con los elementos físicos propios del taller, su idoneidad y su uso seguro, como
facilitadores de los procesos constructivos.

El bloque de Materiales, productos y soluciones tecnológicas está subdividido en: Materiales
(madera, materiales de construcción, metales y plásticos), Estructuras y esfuerzos mecánicos,
Máquinas simples y mecanismos, Electricidad y electrónica.

El bloque de Creación, expresión y comunicación agrupa el conjunto de saberes asociados a
los sistemas de expresión propios del área, incluyendo el dibujo técnico y todo lo necesario para una
transmisión de los elementos más relevantes de sus resultados, proyectos y demostraciones de la
forma más clara y precisa posible, empleando terminología y herramientas digitales adecuadas.

El bloque de Tecnología sostenible considera todos los aspectos de carácter más transversal
que en este sentido se están ofreciendo desde las diferentes respuestas tecnológicas, así como un
elemento fundamental de reflexión sobre las propias medidas, soluciones y diseños que el alumnado
desarrolla en el aprendizaje de la materia.

4.2. Proceso de resolución de problemas

| CONTENIDOS | 1er curso | 3er curso |
| --- | --- | --- |

| Estrategias de búsqueda y filtrado de información | x | x |
| --- | --- | --- |
| Introducción a la Inteligencia Artificial |  | x |
| Estrategias, técnicas y marcos de resolución de problemas y sus fases | x |  |
| Procesos de diseño de prototipos | x | x |
| Estrategias de planificación de la construcción de un prototipo | x | x |
| Recursos materiales y organizativos con criterios de economía, seguridad y sostenibilidad | x | x |
| Herramientas y técnicas para la construcción de prototipos | x | x |
| Introducción a la fabricación digital |  | x |
| Métodos de evaluación de prototipos construidos | x | x |
| Emprendimiento, resiliencia, perseverancia y creatividad para abordar problemas desde una perspectiva interdisciplinar | x | x |

4.3. Digitalización del entorno personal de aprendizaje

| CONTENIDOS | 1er curso | 3er curso |
| --- | --- | --- |
| Arquitectura básica de los equipos informáticos: microprocesador, memoria, buses y periféricos | x |  |
| Sistemas operativos comunes: instalación, configuración, actualización y desinstalación de aplicaciones |  | x |
| Redes de ordenadores cableadas e inalámbricas |  | x |

| Identificación y resolución de problemas informáticos sencillos en el entorno personal |  | x |
| --- | --- | --- |
| Herramientas y plataformas de aprendizaje. Configuración, mantenimiento y uso crítico | x |  |
| Protección de dispositivos y datos personales. Técnicas de tratamiento, organización y almacenamiento seguro de la información. Copias de seguridad | x | x |
| Seguridad. Medidas de protección de datos y de información. Antivirus | x | x |
| Identidad digital y bienestar digital | x |  |
| Prácticas seguras y riesgos. Ciberconvivencia | x | x |
| Licencias de software. El software libre y el software propietario |  | x |
| Comunidades virtuales y entornos virtuales de aprendizaje | x | x |

4.4. Pensamiento computacional, programación, control y robótica

| CONTENIDOS | 1er curso | 3er curso |
| --- | --- | --- |
| Representación de problemas mediante el modelado | x | x |
| Abstracción, secuenciación, algorítmica y su representación con lenguaje natural y diagramas de flujo |  | x |
| Sostenibilidad e inclusión como requisitos del diseño del software | x |  |
| Introducción a la programación por bloques: composición de las estructuras básicas y encaje de bloques | x |  |
| Estructuras de control del flujo del programa. Bucles | x | x |

| Variables, constantes, condiciones y operadores | x | x |
| --- | --- | --- |
| Elaboración de programas informáticos sencillos | x |  |
| Elaboración de programas informáticos sencillos para dispositivos móviles |  | x |
| Análisis de sistemas automáticos: funcionamiento, tipos y componentes de control |  | x |
| Montaje de robots: tipos, grados de libertad y características técnicas. |  | x |
| Control de sistemas automatizados y robotizados |  | x |
| Programación y aplicación de tarjetas controladoras en la experimentación con prototipos diseñados |  | x |
| Programas de simulación de programación de tarjetas controladoras |  | x |
| Implicaciones sociales de la robótica, la inteligencia artificial y el internet de las cosas | x | x |
| Autoconfianza e iniciativa. El error, la reevaluación y la depuración como parte del proceso de aprendizaje | x | x |

4.5. Herramientas y máquinas de taller

| CONTENIDOS | 1er curso | 3er curso |
| --- | --- | --- |
| Herramientas del taller de Tecnología | x |  |
| Máquinas del taller de Tecnología | x | x |
| Normas de seguridad e higiene del aula-taller | x | x |

| Riesgos derivados del manejo de herramientas, máquinas y materiales | x | x |
| --- | --- | --- |
| Elementos y medidas de protección en el taller | x | x |
| Criterios de reducción de riesgos en el taller | x | x |
| Criterios de actuación y primeros auxilios en caso de accidente | x | x |
| Manejo de máquinas y herramientas para trabajar la madera, metales | x |  |
| Manejo de máquinas y herramientas para trabajar los plásticos |  | x |
| Mantenimiento de las máquinas y herramientas | x | x |

4.6. Materiales, productos y soluciones tecnológicas

| CONTENIDOS | 1er curso | 3er curso |
| --- | --- | --- |
| Estrategias para el análisis morfológico, funcional y propuestas de mejora de productos y sistemas tecnológicos | x | x |

4.6.1 Materiales: la madera, los materiales de construcción, metales y plásticos

| CONTENIDOS | 1er curso | 3er curso |
| --- | --- | --- |
| Obtención y clasificación | x |  |
| Relación entre sus propiedades y su estructura interna | x |  |
| Técnicas de manipulación y mecanizado. Acabados | x |  |
| Generación y gestión de residuos asociados a la producción de materiales | x |  |

| Obtención y clasificación de plásticos |  | x |
| --- | --- | --- |
| Relación entre las propiedades y la estructura interna de los plásticos |  | x |
| Técnicas de manipulación y mecanizado de plásticos |  | x |

4.6.2. Estructuras y esfuerzos mecánicos

| CONTENIDOS | 1er curso | 3er curso |
| --- | --- | --- |
| Tipos de estructuras y sus elementos. | x |  |
| Triangulación. Esfuerzos mecánicos | x |  |
| Reacciones y tipos de apoyo |  | x |
| Cálculo de esfuerzos en piezas simples |  | x |

4.6.3. Máquinas simples y mecanismos

| CONTENIDOS | 1er curso | 3er curso |
| --- | --- | --- |
| Palancas | x |  |
| Tipos y aplicaciones de mecanismos | x |  |
| Transmisión y transformación del movimiento | x |  |
| Relación de transmisión | x | x |
| Mecanismos de retención, acoplamiento y lubricación de ejes |  | x |
| Programas de simulación de mecanismos |  | x |

4.6.4. Electricidad y electrónica

| CONTENIDOS | 1er curso | 3er curso |
| --- | --- | --- |
| Magnitudes eléctricas: definición y elementos de medida |  | x |
| Circuitos eléctricos: interpretación, diseño y aplicación en proyectos | x | x |
| Ley de Ohm: análisis de circuitos eléctricos de corriente continua |  | x |
| Simbología y diseño de circuitos eléctricos de corriente continua | x | x |
| Asociaciones básicas de generadores y receptores eléctricos en corriente continua |  | x |
| Programas informáticos de simulación de circuitos eléctricos | x | x |
| Electrónica analógica: componentes básicos y simbología |  | x |
| Análisis y montaje de circuitos electrónicos elementales |  | x |
| Simuladores para analizar el comportamiento de los circuitos electrónicos |  | x |

4.7. Creación, expresión y comunicación

4.7.1. Comunicación técnica

| CONTENIDOS | 1er curso | 3er curso |
| --- | --- | --- |
| Documentación técnica: formatos, vocabulario apropiado | x | x |
| Herramientas digitales para la elaboración, publicación y difusión de documentación técnica sobre proyectos desarrollados | x | x |

| Propiedades textuales en situaciones comunicativas relativas a la tecnología y la digitalización: adecuación, coherencia y cohesión | x | x |
| --- | --- | --- |
| Técnicas para la exposición pública de proyectos desarrollados | x | x |
| Respeto en el uso del lenguaje: uso de lenguaje inclusivo y no discriminatorio | x | x |
| Colaboración digital |  | x |
| Pautas de conducta apropiadas del entorno virtual | x | x |
| Participación ciudadana en línea | x | x |
| Propiedad intelectual y licencias. Tipos de derechos, duración, límites a los derechos de autoría y licencias de distribución y explotación | x | x |
| Sistemas de intercambio, colaboración y publicación de información: seguridad y uso responsable | x | x |

4.7.2. Elaboración de documentación técnica e información de proyectos.

| CONTENIDOS | 1er curso | 3er curso |
| --- | --- | --- |
| Herramientas de creación y edición digital en línea. Instalación, configuración y uso responsable | x | x |
| Elaboración y formateado de contenidos en un documento de texto. Inserción de gráficos. Impresión de documentos | x |  |
| Uso de estilos, tablas e índices en documentos de texto |  | x |
| Inserción de datos, formateado de las celdas y manejo de hojas de cálculo | x |  |

| Fórmulas y funciones sencillas en hojas de cálculo. Creación de gráficos | x | x |
| --- | --- | --- |
| Planificación, individual o de forma cooperativa, en la elaboración de exposiciones orales con presentaciones digitales | x |  |
| Elaboración, formateado, diseño de diapositivas en una presentación digital | x |  |
| Otros formatos de documentación técnica: infografías, líneas de tiempo, animaciones, cómics, libros electrónicos, mapas mentales |  | x |
| Producción y edición sencilla de audio y vídeo |  | x |

4.7.3. Sistemas de representación

| CONTENIDOS | 1er curso | 3er curso |
| --- | --- | --- |
| Materiales de dibujo y diseño | x |  |
| Sistemas de representación: diédrico, perspectiva | x |  |
| Croquis y bocetos como elementos de información de objetos cotidianos e industriales | x | x |
| Normalización y simbología en dibujo técnico: criterios de normalización, escalas y acotación |  | x |
| Dibujo asistido por ordenador en 2D y 3D para representar esquemas, circuitos y objetos |  | x |

4.8. Tecnología sostenible

4.8.1. Implicaciones de la Tecnología en la sociedad y medio ambiente

| CONTENIDOS | 1er curso | 3er curso |
| --- | --- | --- |

| Desarrollo tecnológico: creatividad, innovación, investigación, obsolescencia | x | x |
| --- | --- | --- |
| Breve historia del desarrollo tecnológico | x | x |
| Logros del desarrollo científico y técnico |  | x |
| Aprovechamiento sostenible de materias primas y recursos naturales |  | x |
| Hábitos que potencien el desarrollo sostenible | x | x |
| Implicaciones de la tecnología en el desarrollo social | x | x |
| Contribución a la consecución de los Objetivos de Desarrollo Sostenible. Valoración crítica |  | x |
| El desarrollo del transporte, las comunicaciones, el tratamiento y la transmisión de la información |  | x |
| Consumo responsable de equipamiento informático |  | x |
| Impacto ambiental de la actividad tecnológica y la explotación de recursos | x | x |
| Técnicas de tratamiento y reciclaje de residuos | x | x |
| Selección de recursos materiales y organizativos con criterios de economía, seguridad y sostenibilidad para la resolución de problemas tecnológicos | x | x |

4.8.2. La energía: tipos, producción, transporte y consumo

| CONTENIDOS | 1er curso | 3er curso |
| --- | --- | --- |
| Producción de las distintas formas de energía |  | x |

| Impacto sobre el medio ambiente |  | x |
| --- | --- | --- |
| Transporte de la energía eléctrica, carbón, petróleo, gas natural |  | x |
| Técnicas de ahorro energético | x | x |
| Energías alternativas | x | x |

5.- Situaciones de aprendizaje

Las situaciones de aprendizaje integran todos los elementos que constituyen el proceso de
enseñanza y aprendizaje competencial, pues, encaminadas al logro de los objetivos, plantean tareas
complejas en las que el alumnado moviliza un conjunto de recursos y saberes para afrontar dichas
situaciones. Con el fin de diseñar situaciones de aprendizaje que sean relevantes se propone combinar
una serie de elementos que se enumeran a continuación de forma que finalmente se obtenga el
bosquejo de una situación de aprendizaje ideal. Para comenzar, se propone partir de alguno de los
complejos retos globales a los que nos enfrentamos como sociedades más directamente relacionadas
con la Tecnología y Digitalización, entre los cuales cabe mencionar, a título de ejemplos, la inteligencia
artificial, la robótica, la sociedad digital, la energía (limpia y segura), el cambio climático, la
sostenibilidad, la salud (medicina personalizada, bionanotecnología, edición genética) o el cambio
demográfico. Una vez seleccionado el reto, conviene adoptar un posicionamiento al respecto: consumo
responsable, respeto al medio ambiente, vida saludable, resolución pacífica de conflictos, aceptación
y manejo de la incertidumbre, compromiso ante las situaciones de inequidad y exclusión, valoración
de la diversidad personal y cultural, compromiso ciudadano en el ámbito local y global, confianza en el
conocimiento como motor del desarrollo, aprovechamiento crítico, ético y responsable de la cultura
digital.

Alcanzado este punto, es el momento de considerar la esfera contextual en torno a la cual dar
sentido a los aprendizajes y estimularlos. Así, se pueden plantear desde la esfera personal, social,
escolar o profesional. En función de la propuesta planteada, es posible reflexionar sobre el grado de
conexión de la situación con el mundo real, que puede variar desde una que solamente tiene sentido
dentro del aula hasta una auténticamente real con actuaciones y soluciones con influencia y utilidad
reales. Así mismo, el papel del alumnado dentro de la situación de aprendizaje puede ir desde resultar
creíble pero no interactuar realmente con el mundo, hasta hacer que la interacción sea real. También
se puede valorar si los saberes movilizados en la situación de aprendizaje son esenciales para su
resolución y se encuentran en el centro del reto, desafío o problema que se propone. Es recomendable,
además, que el conjunto de la información, datos y soluciones generadas mediante la construcción de
prototipos, el análisis de objetos o el diseño de experimentos permitan la argumentación y fundamentar
la toma de decisiones. Otra de las claves para definir una situación óptima de aprendizaje es el ajuste
del nivel de autonomía del alumnado, que comenzará con el desarrollo de propuestas casi
completamente guiadas hasta una actuación totalmente autónoma a medida que se alcancen mayores
niveles de desarrollo competencial. El nivel más avanzado supone que el alumnado decide qué
tecnología, productos y herramientas, incluidas las digitales, utiliza para lograr los objetivos.

Mediante esta búsqueda de oportunidades para conectar los aprendizajes realizados y
desarrollar nuevos aprendizajes en diferentes situaciones bien contextualizadas, se pretende que la
adquisición de las competencias específicas de la materia sea lo más efectiva posible. Para que los

aprendizajes sean accesibles y se adapten a las necesidades, características y diferentes ritmos de
aprendizaje del alumnado, hay que alinear su diseño con los principios del Diseño Universal de
Aprendizaje Accesible. Desde la perspectiva de la accesibilidad, hay que tener en cuenta:  la
accesibilidad física, según la cual cualquier persona ha de poder desplazarse, llegar y permanecer en
los diferentes lugares en los que se desarrollan las actividades y participar en ellas de manera cómoda,
así como coger y manipular los objetos confortablemente; la accesibilidad cognitiva, que permite la
comprensión los entornos, las actividades y el uso de objetos porque están adaptados al nivel de
comprensión del alumnado y son predecibles; la accesibilidad emocional, que promueve que las
personas se sientan competentes, seguras y acogidas, sin conflictos como consecuencia de las
diferencias culturales del alumnado; y, por último, la accesibilidad sensorial, que debe garantizar el
acceso a través de los sentidos a la información necesaria para realizar las diferentes actividades,
manipular objetos y desplazarse por los entornos.

El diseño de las situaciones debe ofrecer oportunidades para la generalización de los
aprendizajes y la adquisición de otros nuevos mediante la realización de tareas complejas que
movilizan de forma coherente y eficaz los conocimientos, destrezas y actitudes implicados en las
competencias específicas. Por último, cabe señalar que, con el fin de favorecer la movilización de las
competencias específicas en situaciones y condiciones nuevas o relativamente nuevas respecto a las
situaciones en las que se han aprendido, conviene incluir reflexiones en torno a lo que sucedería en el
reto o problema si se modifican algunas de las variables que lo definen, presentar nuevas y más
amplias perspectivas para afrontarlo, o sencillamente plantear nuevas situaciones o actividades
susceptibles de ser abordadas a partir de las competencias aprendidas.

6.- Criterios de evaluación

Competencia específica 1. Criterios de evaluación

CE 1. Identificar y resolver problemas tecnológicos sencillos y cercanos aplicando el método
de proyectos, propio de la ingeniería, ejecutando, si es necesario, sus fases características y utilizando
los medios tecnológicos y digitales más adecuados al contexto.

| 1er curso | 3er curso |
| --- | --- |
| 1.1. Identificar problemas tecnológicos actuales, sencillos y cercanos, utilizando los saberes básicos fundamentales de esta área para entender la necesidad o problema detectado. | 1.1. Identificar problemas tecnológicos actuales, sencillos y cercanos, utilizando los saberes básicos fundamentales de esta área y el pensamiento crítico para afrontar y dar solución a la necesidad o problema detectado. |
| 1.2. Resolver de manera guiada problemas y desafíos tecnológicos cotidianos siguiendo las fases del método de proyectos para generar y/o utilizar productos que den solución a la necesidad o problema identificado. | 1.2. Resolver problemas y desafíos tecnológicos cotidianos siguiendo las fases del método de proyectos para generar y/o utilizar productos que den solución a la necesidad o problema identificado. |
| 1.3. Utilizar los medios tecnológicos y digitales, herramientas y materiales disponibles en la resolución de los problemas o el abordaje de retos tecnológicos planteados en la vida cotidiana, gestionando de forma guiada su uso de manera adecuada y sostenible. | 1.3. Utilizar los medios tecnológicos y digitales, herramientas y materiales disponibles en la resolución de los problemas o el abordaje de retos tecnológicos planteados en la vida cotidiana, gestionando autónomamente su uso de manera eficaz, innovadora y sostenible. |

| 1.4. Fabricar objetos, prototipos o modelos sencillos mediante la manipulación y conformación de materiales, empleando las herramientas y máquinas adecuadas, aplicando los fundamentos de estructuras, mecanismos y electricidad, respetando las normas de seguridad y salud básicas correspondientes. | 1.4. Fabricar objetos, prototipos o modelos mediante la manipulación y conformación de materiales, seleccionando y empleando herramientas y máquinas adecuadas, aplicando los fundamentos de estructuras, mecanismos, electricidad y electrónica, y respetando las normas de seguridad y salud correspondientes. |
| --- | --- |

Competencia específica 2. Criterios de evaluación

CE 2. Buscar, obtener, analizar y seleccionar información de forma fiable y segura para poder
gestionar, el tiempo, los conocimientos y los recursos disponibles a la hora de abordar retos
tecnológicos siguiendo un plan de trabajo realista.

| 1er curso | 3er curso |
| --- | --- |
| 2.1. Realizar búsquedas básicas en internet atendiendo a criterios de calidad, actualidad y fiabilidad de las fuentes, como punto de partida en cualquiera de las fases del proceso de resolución de problemas tecnológicos. | 2.1. Realizar búsquedas avanzadas en internet atendiendo a criterios de validez, calidad, actualidad y fiabilidad de las fuentes y considerando los riesgos asociados a las mismas, como punto de partida en cualquiera de las fases del proceso de resolución de problemas tecnológicos. |
| 2.2. Analizar y seleccionar la información científico-técnica obtenida, eligiendo la más adecuada en función de la tarea y de su necesidad en cada ocasión. | 2.2. Comparar y valorar la información científico-técnica obtenida de manera crítica, eligiendo la más adecuada en función de la tarea y de su necesidad en cada ocasión. |
| 2.3. Utilizar de manera segura la información científico-técnica seleccionada para la superación de los retos tecnológicos planteados. | 2.3. Utilizar la información científico- técnica seleccionada de manera segura, optimizando sus posibilidades para asegurar la eficacia en la superación de los retos tecnológicos planteados. |
| 2.4. Seguir y ejecutar, con la información obtenida, un plan de trabajo individual o en grupo cooperativo coherente con las características de la tarea. | 2.4. Diseñar y ejecutar, con la información obtenida, un plan de trabajo individual o en grupo cooperativo coherente con las características de la tarea, adecuando el tiempo de trabajo y los conocimientos para actuar con la mayor eficacia y eficiencia posibles. |
| 2.5. Organizar la información aplicando técnicas de almacenamiento seguro. | 2.5. Organizar la información de manera estructurada, aplicando técnicas de almacenamiento seguro. |

| 2.6. Identificar problemas y riesgos relacionados con el uso de la tecnología y analizarlos de manera ética y crítica. | 2.6. Adoptar medidas preventivas para la protección de los dispositivos, los datos y la salud personal. |
| --- | --- |

Competencia específica 3. Criterios de evaluación

CE 3. Configurar, utilizar y mantener máquinas, herramientas, aplicaciones y sistemas
digitales, haciendo una selección idónea y un uso seguro y adecuado de los mismos en función de la
tarea.

| 1er curso | 3er curso |
| --- | --- |
| 3.1. Emplear correctamente la herramienta de trabajo adecuada para la tarea a realizar. | 3.1. Elegir, en cada momento, las herramientas de trabajo más adecuadas, valorando sus características, su potencial y su adecuación a la tarea a realizar. |
| 3.2. Utilizar y adaptar las herramientas digitales y aplicaciones del entorno de aprendizaje a las propias necesidades. | 3.2. Configurar las herramientas digitales y aplicaciones del entorno de aprendizaje ajustándolas a las propias necesidades. |
| 3.3. Utilizar los instrumentos tecnológicos y digitales de forma ajustada al propósito, respetando en todo momento sus normas de uso y conservación. | 3.3. Utilizar y realizar un mantenimiento de los instrumentos tecnológicos y digitales accesibles de manera adecuada al propósito de cada acción, identificando los riesgos implícitos en su utilización y respetando en todo momento sus normas de uso y conservación. |
| 3.4. Respetar las normas de seguridad e higiene en el uso y manipulación de materiales, máquinas, herramientas, sistemas digitales, etc. | 3.4. Respetar y valorar las normas de seguridad e higiene en el uso y manipulación de materiales, máquinas, herramientas, sistemas digitales, etc.. |

Competencia específica 4. Criterios de evaluación

CE 4. Realizar un uso responsable y sostenible de los objetos, materiales, productos y
soluciones tecnológicas y digitales existentes en el entorno ordinario, analizando críticamente sus
implicaciones y repercusiones ambientales, sociales y éticas.

| 1er curso | 3er curso |
| --- | --- |
| 4.1. Analizar los objetos, productos y soluciones tecnológicas de forma básica, atendiendo a sus características funcionales, estructura y aplicación. | 4.1. Analizar críticamente los objetos, productos y soluciones tecnológicas, atendiendo a sus características funcionales y considerando su naturaleza, estructura y aplicación, utilizando |

|  | métodos inductivos, deductivos y lógicos propios del razonamiento tecnológico. |
| --- | --- |
| 4.2. Considerar las implicaciones para el medio y el entorno derivadas de utilizar elementos tecnológicos, tanto actuales como a medio y largo plazo. | 4.2. Emplear los elementos tecnológicos accesibles considerando las implicaciones derivadas de su uso, tanto actuales como a medio y largo plazo, y siendo lo más respetuoso posible con el medio y el entorno. |
| 4.3. Comparar y valorar los productos digitales utilizados para hacer frente a los desafíos tecnológicos susceptibles de mejorar la calidad de vida personal y colectiva tanto en el ámbito académico como en el personal. | 4.3. Evaluar y opinar críticamente sobre los procesos productivos asociados a la explotación y transformación de los diferentes recursos naturales usados en la producción de bienes tecnológicos cotidianos. |
|  | 4.4. Analizar crítica y éticamente los productos digitales utilizados para hacer frente a los desafíos tecnológicos susceptibles de mejorar la calidad de vida personal y colectiva tanto en el ámbito académico como en el personal. |

Competencia específica 5. Criterios de evaluación

CE 5. Crear, expresar, comprender y comunicar ideas, opiniones y propuestas utilizando
correctamente los lenguajes y los medios propios de la tecnología y la digitalización, tanto en el ámbito
académico como en el personal y social.

| 1er curso | 3er curso |
| --- | --- |
| 5.1. Crear y editar contenidos tecnológicos y digitales utilizando diferentes formatos, tanto presencialmente como en remoto, para facilitar la comunicación de ideas, opiniones y propuestas tecnológicas. | 5.1. Crear y editar contenidos tecnológicos y digitales de manera colaborativa utilizando diferentes formatos, tanto presencialmente como en remoto, para facilitar la comunicación de ideas, opiniones y propuestas tecnológicas. |
| 5.2. Respetar las licencias y derechos de autoría en la creación y comunicación de ideas | 5.2. Utilizar y respetar las licencias y derechos de autoría en la creación y comunicación de ideas |
| 5.3. Comunicar contenidos, ideas, opiniones y puntos de vista sobre cuestiones tecnológicas en diferentes formatos, utilizando de forma correcta y coherente la terminología y la simbología adecuadas. | 5.3. Explicar y argumentar ideas, opiniones y puntos de vista sobre cuestiones tecnológicas en diferentes formatos, utilizando de forma correcta y coherente la terminología y la simbología adecuadas. |
| 5.4. Comunicar en una o más lenguas en el ámbito tecnológico y digital, de manera apropiada, utilizando expresiones no discriminatorias e inclusivas | 5.4. Participar responsablemente en las comunicaciones interpersonales en el ámbito personal, académico o social con actitud cooperativa y respetuosa, tanto para intercambiar información vinculada con la tecnología y la |

|  | digitalización, como para construir vínculos personales en torno a dicho campo de conocimiento. |
| --- | --- |
| . | 5.5. Usar eficazmente una o más lenguas para satisfacer las necesidades comunicativas en el ámbito tecnológico, utilizando un lenguaje técnico adecuado y expresiones no discriminatorias e inclusivas. |

Competencia específica 6. Criterios de evaluación

CE6. Analizar problemas sencillos y plantear su solución automatizando procesos con
herramientas de programación, sistemas de control o robótica y aplicando el pensamiento
computacional.

| 1er curso | 3er curso |
| --- | --- |
| 6.1. Analizar problemas sencillos mediante la abstracción y modelización de la realidad. | 6.1. Analizar problemas sencillos mediante el uso de las estructuras de control más adecuadas. |
| 6.2. Resolver problemas de manera individual, utilizando los algoritmos y las estructuras de datos necesarias. | 6.2. Planificar la solución de problemas de manera individual y cooperativa, utilizando los algoritmos y las estructuras de datos necesarias. |
| 6.3. Programar aplicaciones sencillas usando un entorno para el aprendizaje de programación basado en bloques. | 6.3. Programar aplicaciones sencillas usando un entorno para el aprendizaje de programación basado en bloques en dispositivos móviles añadiendo módulos de inteligencia artificial. |
|  | 6.4. Automatizar procesos, máquinas y objetos, con conexión a internet, mediante el análisis, construcción y programación de robots o sistemas de control. |

Competencia específica 7. Criterios de evaluación

CE7. Utilizar la tecnología poniéndola al servicio del desarrollo personal y profesional, social y
comunitario y proponiendo soluciones creativas a los grandes desafíos del mundo actual.

| 1er curso | 3er curso |
| --- | --- |
| 7.1. Diseñar soluciones creativas sencillas en situaciones abiertas e inciertas que surgen en el entorno. | 7.1. Desarrollar soluciones que utilicen la tecnología más adecuada, analizando el problema |

|  | desde diferentes puntos de vista, para obtener soluciones creativas. |
| --- | --- |
| 7.2. Afrontar pequeñas situaciones de incertidumbre con una actitud positiva, utilizando el conocimiento adquirido. | 7.2. Gestionar situaciones de incertidumbre en una realidad tecnológica cambiante con una actitud positiva, y afrontarlas utilizando el conocimiento adquirido y sintiéndose competente. |
| 7.3. Reconocer la importancia del desarrollo de la tecnología como herramienta para el avance social y cultural de la humanidad. | 7.3. Valorar el desarrollo de la tecnología como herramienta para el avance social y cultural de la humanidad. |

|  | pequeñas situaciones de |
| --- | --- |
| incertidumbre con una actitud positiva, |  |
| utilizando el conocimiento adquirido. |  |

|  | Gestionar situaciones de |
| --- | --- |
| incertidumbre en una realidad tecnológica |  |
| cambiante con una actitud positiva, y afrontarlas |  |
| utilizando el conocimiento adquirido y sintiéndose |  |
| competente. |  |

|  | 7.3. Reconocer la importancia del |
| --- | --- |
| desarrollo de la tecnología como herramienta |  |
| para el avance social y cultural de la |  |
| humanidad. |  |

|  | 7.3. Valorar el desarrollo de la tecnología |
| --- | --- |
| como herramienta para el avance social y cultural |  |
| de la humanidad. |  |
