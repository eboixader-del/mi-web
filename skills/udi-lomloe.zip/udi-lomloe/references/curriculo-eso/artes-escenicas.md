# ARTES ESCÉNICAS

> Fuente: Secundaria.pdf, páginas 1056-1072 (versión en castellano).

ARTES ESCÉNICAS

1. Presentación

La finalidad de la asignatura Artes Escénicas es permitir al alumnado lograr las competencias
necesarias para transmitir sus representaciones de la realidad y su visión del mundo, mediante lenguajes
artísticos simbólicos en situaciones diversas de creación, interpretación y valoración.

Las competencias específicas de esta materia y todo el trabajo al aula para lograrlas que se deriva
tienen que contribuir con el resto de las artes a la educación integral de la percepción y la imaginación, del
cultivo del sentido estético y artístico, sobre los cuales se asienta la naturaleza individual y social de las
personas, sin olvidar que los lenguajes artísticos forman parte de la historia de las sociedades, reflejan sus
valores estéticos y culturales y son uno de los rasgos fundamentales.

La práctica de las Artes Escénicas pretende influir positivamente en el desarrollo integral y la
formación de las personas al invocar diferentes formas de inteligencia y permitir confrontar, comprender e
interpretar la realidad para trasladarla al lenguaje simbólico.

Como vehículo para el desarrollo de la personalidad a través de la expresión propia y colectiva, las
Artes Escénicas son un buen marco para mejorar los procesos de aprendizaje, potenciar la creatividad y la
sensibilidad, pero también las funciones cognitivas, la toma de conciencia del grupo y el compromiso que
comporta la pertenencia y los valores ciudadanos.

El alcance de esta materia llamada Artes Escénicas como término inclusivo, comprende saberes de
diferentes lenguajes artísticos tales como el drama y el teatro, la danza y las artes de acción o performativas.
Por lo tanto, habrá que conocer y utilizar los elementos propios del lenguaje distintivo de cada arte para
representar ideas, vivencias y sentimientos. A pesar de que cada una de las disciplinas permite un amplio
despliegue de contenidos teóricos, las competencias específicas propuestas abocan a trabajar, sobre todo,
la experimentación en la práctica de unos lenguajes universales que conectan las personas con ellas mismas
y con su entorno, aprovechando la intuición, la imaginación, el juego y la analogía.

En el contexto de la materia está la formación humanística, artística y cultural. Pero en este caso no
se tiene que adquirir de un modo pasivo y unidireccional. El planteamiento de la asignatura propone que el
alumnado llegue a ser a la vez artista, creador, intérprete, espectador y consumidor crítico, y sea la práctica
activa la manera de adquirir unos hábitos para poder apreciar las diferentes obras artísticas dentro del
contexto en que se han creado y construir su formación personal.

Así, el drama o dramatización, más orientado al proceso, a las formas libres de improvisación y juego
simbólico de los participantes, y el teatro, orientado a un producto artístico de comunicación escénica entre
actores y espectadores, proponen la creación y representación de acciones o narración de historias con
personajes interpretados por el alumnado utilizando cuerpo, gestos y voz, a partir de diferentes estímulos
creativos, como pueden ser textos procedentes de la literatura dramática y general o de creación propia.

El proceso de la dramatización y el teatro permiten abordar cuestiones personales, sociales y
universales salidas del mundo real, del imaginario o de la recepción de producciones artísticas y mediáticas
del entorno cultural inmediato, adaptadas a la edad e intereses de los jóvenes, de una manera concreta,
sensible, expresiva y simbólica y facilitan el acceso al patrimonio cultural próximo y de todo el mundo.

El arte escénico de la danza utiliza y organiza el cuerpo humano en movimiento como materia prima,
instrumento y medio para expresar, crear y comunicar de una forma individual o grupal, a través de la
interacción entre el espacio, el tiempo y la energía. Estrechamente vinculada a la música y al ritmo, la danza,
con funciones y formas diversas a lo largo de los siglos, ha superado la mera autoexpresión para estructurarse
y ponerse en escena y crear significado mediante la coreografía. Con el trabajo psicomotriz que implica la
danza, el alumnado se encuentra en situaciones que les permiten explorar la interrelación entre su cuerpo,
en cambio constante, sus emociones y el pensamiento y aprender a controlar gestos, movimientos para
mejorar la expresión y la comunicación.

La danza, el teatro y las artes de acción o performativas tienen su propio lenguaje, reglas y
convenciones, habilidades, conceptos, principios y herramientas particulares, pero todas ellas puestas en
relación constituyen un medio ideal de autodescubrimiento y de expresión para los y las jóvenes adolescentes,
que tienen una necesidad creciente de afirmar su identidad y sus valores. Los ayudan a definirse de una
manera creativa en relación a cuestiones personales, sociales y universales, a explorar la realidad a través
de sus sentidos y les ofrece la oportunidad de expresar sus emociones, ideas, aspiraciones, sueños.

En cuanto al desarrollo cognitivo, el alumnado de Artes Escénicas lleva a cabo todo un conjunto de
operaciones mentales como la observación, la memorización, la comprensión y el análisis o la síntesis,
necesarias para aplicar sus competencias, tanto a textos dramáticos como situaciones de la vida cotidiana, la
expresión del cuerpo y el movimiento. También requiere que los estudiantes ejerzan un pensamiento creativo
y un juicio crítico. Además, las oportunidades para interactuar con sus compañeros a través de la
confrontación de ideas, la asistencia mutua, la negociación o el debate, contribuye a definirse como seres
sociales.

Formar personas competentes en el entorno cultural que les ha tocado vivir pide la formación del
sentido estético, es decir, desarrollar el gusto por las manifestaciones artísticas.

Así, esta materia tiene que enmarcarse en los contextos social, cultural y educativo que ofrezcan
oportunidades para practicar las artes escénicas, desde el punto de vista de la creación y la expresión, pero
también para focalizar la mirada en la asistencia y el visionado de espectáculos, adquirir un conocimiento de
un repertorio básico de visualización de teatro, danza y otras artes escénicas de diferentes estilos, épocas y
autores, para acceder así a una recepción lúdica, reflexiva y crítica, para conocer el lenguaje de cada arte en
particular y para eliminar las barreras de acceso a los productos culturales ante la discapacidad física,
intelectual o el nivel social o económico.

Al ser más conscientes de los efectos de la práctica artística en su vida, los estudiantes desarrollan
una conexión directa con el arte y la cultura, amplían sus horizontes culturales mediante la exposición a obras
de artistas de diferentes épocas y orígenes, incluidas las que pertenecen al patrimonio escénico valenciano y
a otras culturas.

La materia Artes Escénicas contribuye de una manera inequívoca al perfil competencial del alumnado
al finalizar la educación secundaria especialmente en cuanto al logro de la competencia en conciencia y
expresión culturales en cuanto que supone valorar y respetar la manera como las ideas propias y ajenas y
sus significados son expresados y comunicados de manera creativa a las diferentes sociedades. Las artes
escénicas ayudan al alumnado adolescente a comprender la identidad propia en desarrollo continuo, el
patrimonio en un contexto de diversidad cultural y la forma como el arte y otras manifestaciones culturales
son una manera de ver el mundo y de transformarlo. La competencia clave personal, social y de aprender a
aprender implica la capacidad de reflexionar sobre uno mismo para autoconocerse, aceptarse y promover un
crecimiento personal constante.

La contribución de las artes escénicas resulta relevante en cuanto a la competencia en comunicación
lingüística y la competencia plurilingüe, por lo que conlleva en la interactuación oral y escrita adecuada en

ámbitos, contextos y con varios propósitos comunicativos. De hecho, en el teatro, por ejemplo, la palabra, el
lenguaje verbal sucede junto al cuerpo y el movimiento, el espacio y el tiempo y forma parte inseparable de
muchas de sus propuestas. Además, las dimensiones históricas e interculturales propias de las artes
escénicas permiten conocer, valorar y respetar la diversidad lingüística y cultural de la sociedad.

Igualmente podemos mencionar la competencia clave ciudadana, que contribuye a que el alumnado
participe plenamente en la vida social y cívica, la adopción consciente de los valores propios de una cultura
democrática fundamentada en el respeto a los derechos humanos o la reflexión crítica sobre los grandes
problemas éticos de nuestro tiempo y el desarrollo de un estilo de vida sostenible; temáticas que la práctica
escénica permite trabajar desde muchos ángulos.

El uso de herramientas tecnológicas multimedia y la creación de contenidos digitales en las diferentes
partes de los procesos de creación de proyectos artísticos escénicos, tanto en la planificación como en la
realización y la posterior difusión, contribuyen al logro de la competencia digital.

A pesar de que no hay ninguna materia obligatoria en los cursos anteriores de la secundaria que
permita plantear la materia en términos estrictos de una continuidad en progresión, hay que decir que se parte
de competencias específicas, criterios y saberes de otras materias como por ejemplo Música, Lengua y
Literatura, Educación Física y Educación Plástica, Visual y Audiovisual que se vinculan con las Artes
Escénicas.

Las líneas que ordena esta propuesta curricular de la materia se dirigen, por lo tanto, a dotar al
alumnado de unas competencias específicas a través de saberes con los lenguajes y procedimientos básicos
del mundo de las artes escénicas.

Las competencias propias de la práctica de las Artes Escénicas implican, para el alumnado, crear,
interpretar, valorar y apreciar obras, del patrimonio cultural del entorno más próximo al más global, y también
las producciones propias y de sus compañeros y compañeras.

En primer lugar, se presentan las cuatro competencias específicas de la materia de Artes Escénicas
que definen los aprendizajes que el alumnado tiene que adquirir. Estas cinco competencias están
relacionadas con cada uno de los bloques de saberes, que seleccionan a su vez los contenidos básicos sin
los cuales no sería posible su logro.

Estas competencias se desarrollan de manera interactiva y enriquecedora mutuamente. La
presentación no implica ninguna jerarquía ni ordenación cronológica, y el lugar que se concederá al desarrollo
de cada competencia dependerá de la naturaleza particular de cada situación de aprendizaje. Por ejemplo, la
creación y la representación de obras dramáticas o coreográficas requiere un tiempo suficiente para las
exigencias de adquisición del lenguaje, el dominio de las técnicas, las convenciones y las prácticas de la
dramaturgia o la expresión del cuerpo, así como la adquisición de psicomotricidades complejas.

El apartado siguiente, los saberes básicos, son el grupo de conocimientos necesarios para lograr el
conjunto de las competencias de la materia. Se ha estructurado el área en tres bloques interrelacionados, que
tienen que ser trabajados de forma integrada con los subbloques correspondientes. El primero, Percepción y
análisis, tiene un primer subbloque de Percepción que busca profundizar en los contextos históricos y
culturales del repertorio escénico, así como en los de la recepción escénica. Un segundo subbloque, de
Análisis, aborda el conjunto de elementos que configuran el arte dramático y la danza, además de un grupo
de elementos comunes a todas las disciplinas escénicas.

El segundo bloque, Creación, presenta saberes relacionados con la creación y la puesta en escena
y la difusión de las producciones artísticas. El tercer bloque son los saberes en su vertiente más vivencial,
mediante la interpretación y la expresión corporal y vocal.

En las situaciones de aprendizaje se presentan un conjunto de principios que orientan sobre cómo
organizar actividades articuladas para que el alumnado pueda lograr ciertos fines o propósitos educativos en
la materia.

Finalmente, el apartado referente a los criterios de evaluación establece el grado de aprendizaje que
se espera que haya conseguido el alumnado con las diferentes competencias específicas. Cada competencia
lleva asociados diferentes criterios de evaluación.

2. Competencias específicas de la materia de Artes Escénicas
2.1. Competencia específica 1
Apreciar y argumentar la aportación de las manifestaciones escénicas al patrimonio cultural,
participando activamente en la recepción a través de diferentes canales y valorando la diversidad de
tradiciones, géneros y estilos estéticos.

2.1.1. Descripción de la competencia

Apreciar una obra dramática o una danza implica examinarla desde un punto de vista sensible, crítico
y estético, e intentar entenderla explorando los diversos significados.

El contacto con piezas escénicas de un repertorio diverso, incluido el patrimonio valenciano y de otras
culturas, pero también las creaciones de los compañeros y compañeras, permite a los y las estudiantes
desarrollar la conciencia artística y la sensibilidad hacia las cualidades expresivas, simbólicas, técnicas y
estéticas de una obra dramática, una pieza de danza o una acción performativa. También les permite cultivar
el conocimiento y disfrutar de las propuestas artísticas en los espacios culturales.

Este conocimiento tendrá que basarse en una selección representativa de manifestaciones escénicas
atendiendo el valor de sus contenidos, significados artísticos y éticos. Una selección respetuosa con la
diversidad de tradiciones culturales, prestando especial atención a la contemporaneidad.

La participación activa en la recepción y la promoción de las artes escénicas a través de todos los
canales y los contextos posibles (asistencia a representaciones en directo, visitas a teatros y encuentros con
artistas, lectura de textos, medios audiovisuales, redes sociales) será una de las claves para conseguir la
alfabetización propia de cada lenguaje artístico.

Apreciar y argumentar mediante una recepción activa implica recibir la propuesta artística tomando
como punto de partida la propia experiencia, sensibilidad estética y los conocimientos artísticos que se están
adquiriendo.

Argumentar durante todo el proceso de apreciación supone para el estudiante mostrar respeto por el
trabajo, pero también por las diferentes visiones, al comparar su percepción con la de los otros,
perfeccionando su juicio. Se pide al alumnado que participe en un proceso en el cual tienen que formular
argumentos constructivos para expresar y justificar su opinión.

La implicación del alumnado como público les permitirá entrar en contacto con los elementos que
influyen en la percepción de los espectadores: la puesta en escena, la escenografía y la organización de la
relación escenario-público. A través de géneros y estilos estéticos diferentes, la materia de trabajo del teatro,
la danza, las artes de acción o performativas, son las personas, sus ideas, las emociones, los sentimientos,
sus conflictos. Por lo tanto, apreciar las artes escénicas es un vehículo para la comprensión de las relaciones
humanas en toda su complejidad.

2.2.  Competencia específica 2

Analizar propuestas escénicas desde un punto de vista estético, con actitud crítica, explorando
componentes, la escritura, la finalidad comunicativa y las relaciones con el entorno sociocultural.

2.2.1. Descripción de la competencia

Acercarse a una obra o pieza escénica pide sumergirse y centrarse en sus reacciones emocionales
y estéticas, pero también analizarla, teniendo en cuenta su contexto sociocultural, incluyendo los aspectos
históricos.

A la hora de analizar una producción artística escénica, obra, pieza o fragmento, haciendo referencia
a una experiencia cultural adecuada a la edad, el alumnado examina todos o algunos de los contenidos que
han observado, teniendo en cuenta criterios de valoración determinados por sus compañeros y compañeras
o propuestos por el profesorado.

Analizar implica un trabajo de apreciación individual y personal pero también se enfoca pidiendo a los
y las estudiantes que valoren una propuesta escénica comparando sus observaciones y compartiendo su
percepción con la de los otros y otras.

En el proceso de análisis, aprender a identificar los elementos y características de los lenguajes
escénicos observados, la estructura dramática o coreográfica, indagar la función comunicativa y establecer
conexiones entre los elementos significativos y los efectos producidos, o las comparaciones con otras obras,
en relación a un determinado contexto sociocultural e histórico, contribuye a refinar las opiniones formadas.

Las características básicas de esta competencia de analizar forman parte de un movimiento dinámico
a lo largo del curso, y pueden ocurrir en el mismo punto o en diferentes momentos de la experiencia de
apreciación y valoración.

Consecuencia del trabajo para lograr esta competencia es la búsqueda de información adicional y la
necesidad de compartir el análisis a través de la comunicación oral, escrita y multimodal, con fluidez,
coherencia, corrección y adecuación en la cual el alumnado pone en práctica sus competencias lingüísticas
mientras integra el vocabulario específico de la materia.

2.3. Competencia específica 3

Planificar y crear producciones escénicas individuales y colectivas mediante el uso de elementos,
técnicas y procesos de los diferentes lenguajes artísticos a partir de estímulos diversos, dando  expresión
concreta a ideas, sentimientos o emociones, y valorando  tanto el proceso como el resultado final.

2.3.1. Descripción de la competencia

Para los y las estudiantes de Artes Escénicas crear una producción escénica consiste en participar
en una dinámica creativa en la cual movilizan simultáneamente la imaginación y el pensamiento divergente y
convergente, dando expresión concreta y deliberada a ideas, sensaciones, sentimientos o emociones, y
poniéndolas en acción a través de la invención o recreación de personajes y el cuerpo en movimiento.

También implica movilizar los recursos personales y culturales para descubrir el potencial de la
creación y la acción.

La competencia pide familiarizarse con los principios subyacentes a la creación dramática o
coreográfica y aprender a utilizar y planificar los elementos del lenguaje del teatro, de la danza, y otros
enfoques artísticos contemporáneos, sus técnicas, herramientas y procesos tanto comunes como diversos
para ponerlos al servicio de creaciones auténticas, expresivas y originales, entendido en el sentido de
demostrar un esfuerzo de implicación personal por parte del alumnado para ir más allá de los tópicos y
estereotipos.

En función del mensaje que quieren comunicar e inspirados tanto por su realidad como por la
imaginación, tienen que practicar durante el proceso de creación, que incluye planificación, una toma de
decisiones estéticas que reflejen su personalidad, experiencias, referentes culturales, valores, aspiraciones
artísticas y visión del mundo.

El proceso creativo requerirá aprender a utilizar varios recursos materiales, visuales, textuales,
gestuales, sonoros, así como elementos cinéticos, cuerpo, tiempo, espacio y energía, para experimentar con
su potencial simbólico.

Crear implica estar abierto a los estímulos para la creación y aplicar ideas, imágenes, emociones,
sensaciones o sentimientos evocados por el estímulo.

Los estímulos de creación varios puestos  a disposición del alumnado se basan en temas adecuados
a la edad, y tienen en cuenta sus aspiraciones artísticas y la experiencia previa. Pueden implicar un contexto
sociocultural concreto, incluidos sus aspectos históricos, y permitir establecer vínculos con las amplias áreas
de aprendizaje.

La competencia crear producciones escénicas puede implicar la realización de varias tareas
complejas: improvisar, componer, adaptar para más adelante, si procede, poner en escena y producir un
espectáculo.

Además, abre expectativas y plantea la utilización, de nuevas y diferentes tecnologías, así como
soportes aplicados a la creatividad artística, como el diseño, el audiovisual, la animación, la fotografía o la
imagen digital, y se vincula necesariamente a las otras disciplinas artístico-expresivas como, por ejemplo, la
literatura, la música, las artes plásticas, visuales y audiovisuales, o la educación física.

Cuando los y las estudiantes crean y planifican una pieza escénica se pide un compromiso a seguir
las convenciones establecidas y a mantenerse atentos los unos a los otros, desde la igualdad y respeto a la
diversidad, interaccionando y cooperando, ajustando las acciones en consecuencia por el beneficio de un
producto final colectivo.

Resulta fundamental al desarrollar la competencia de creación participar de manera desinhibida en
dinámicas de grupo creativas mostrando un comportamiento responsable y tolerante, así como explicar y
compartir las elecciones y decisiones tomadas durante el proceso.

Describir y comentar su experiencia de creación y planificación e identificar lo que han aprendido, así
como las estrategias y métodos que han utilizado para transferir el aprendizaje a diferentes contextos suponen
poner en valor el proceso frente al resultado final.

2.4. Competencia específica 4

Interpretar obras o piezas escénicas de creación propia o ajena mediante los instrumentos expresivos
y comunicativos del cuerpo, la voz, el movimiento, el tiempo y el espacio, haciendo uso de la memoria
sensorial y afectiva personal y del grupo.

2.4.1. Descripción de la competencia

Interpretar obras o piezas escénicas implica recrear en un espacio escénico un mundo ficticio con la
intención de comunicarlo a los otros.

Los y las intérpretes son el vehículo necesario para la expresión escénica. En el caso del teatro, sólo
a través de la interpretación toman forma palabras, personajes e historias. En el caso de la danza y otras
artes performativas, por su naturaleza más abstracta y efímera sólo se revela su significado a través del y de
la intérprete. Y es a través de la interpretación, cuando el uso del cuerpo, la voz, el movimiento, el tiempo y
el espacio se convierten en instrumentos expresivos y comunicativos, con los cuales el alumnado puede
explorar los posibles significados de una obra o pieza escénica de una manera más íntima y personal.

Al practicar la interpretación como actores, actrices o bailarines, bailarinas; los y las estudiantes
adoptan una manera de ser y de pensar que no es necesariamente propia. Para conseguirlo, tienen que estar
abiertos y abiertas a la diversidad de las personas, entender bien las motivaciones que dan lugar a diferentes
comportamientos humanos y hacerlos suyos. Mediante la memoria sensorial y afectiva, rebuscan en ellos
mismos y ellas mismas sensaciones, emociones y sentimientos inspirados por su personaje en una obra
dramática o sus habilidades físicas para traducir y comunicar sensaciones, ideas y sentimientos a través de
una coreografía.

A través de la expresión se busca que el alumnado utilice las habilidades, conocimientos, o técnicas
propias de cada disciplina para dar forma a obras dramáticas, danzas contemporáneas o creaciones de un
repertorio de diferentes periodos históricos y culturas, formas estéticas y simbólicas, del patrimonio artístico
mundial. Pero también pueden partir de textos dramáticos escritos por compañeros o compañeras, o ser
fragmentos de obras de teatro o montajes de piezas existentes, adaptaciones u otros tipos de textos o basarse
en trabajos de improvisación en el aula.

Una de las características importantes de esta competencia radica en la asimilación del contenido
dramático de una obra, el carácter expresivo y el lenguaje dramático específico o la incursión en el mundo del
coreógrafo o coreógrafa que permite explorar diferentes maneras de expresarse, explicar una historia o
representar la realidad, así como las actitudes y estrategias para transmitir su significado.

Interpretar requiere el uso adecuado de los instrumentos expresivos y comunicativos, es decir, un
trabajo de organización estructural del cuerpo y de la voz, reconocer las características anatómicas
relacionadas con el arte dramático y la danza, mostrando una correcta alineación del esquema corporal, así
como desarrollar actitudes corporales saludables en el ámbito de la interpretación y el movimiento.

Pero interpretar consiste también en adaptar estos elementos a la intención del creador o creadora y
a la representación poniendo en práctica las convenciones establecidas, ajustando su rendimiento a los otros
u otras en un trabajo de escucha activa, colaboración y respeto.

La competencia específica interpretar obras o piezas escénicas contribuye al perfil del final de etapa
al ayudar a consolidar una madurez personal y social con el respeto, la responsabilidad, la autonomía y la
cooperación como valores y a reafirmar los hábitos de actividad corporal para favorecer el bienestar físico y
mental.

2.5.  Competencia específica 5

Poner en escena proyectos artísticos de un repertorio diverso, cooperando en la organización de los
elementos artísticos y fases de producción, asumiendo con responsabilidad los diferentes roles.

2.5.1. Descripción de la competencia

Esta competencia específica complementa la de creación e interpretación en cuanto a la consecución
de un producto final en forma de espectáculo, presentación o representación que culmina un proyecto artístico
de carácter escénico. Frente al enfoque procesual de las anteriores competencias, esta pretende poner en
valor la consecución de un producto cultural con la mejor calidad posible.

La puesta en escena permite a los y las estudiantes experimentar el reto de poner en práctica de
manera conjunta toda la experiencia escénica trabajada al lograr las otras competencias, puesto que tienen
la oportunidad de conjugar de manera colectiva todos los elementos artísticos seleccionados previamente de
creación, dramaturgia o coreografía, con la interpretación, al servicio de la expresión final de las ideas, la
visión propia del mundo, valores o intereses.

Poner en escena implica seleccionar elementos dramáticos, expresivos y plásticos específicos de las
artes escénicas y de las otras artes e integrarlos con creatividad y de manera colaborativa, para diseñar un
proyecto que responda a una finalidad determinada.

Plantear poner en escena proyectos artísticos de un repertorio diverso significa explorar
manifestaciones escénicas de culturas y periodos históricos varios para conocer el concepto y características
de un espectáculo y sus tipologías básicas.

También permite abordar la organización de las diferentes fases de una producción, la secuenciación
de la escenificación, las áreas de trabajo, técnica, estética, creativa y de producción, el reparto de tareas y la
asunción de roles para el diseño de un montaje escénico. Entre estas, aproximarse a las funciones de la
dirección escénica.

La puesta en escena además invoca la relación con otras materias artísticas y a entender los vínculos
entre sus respectivos lenguajes simbólicos. La escenificación abre la posibilidad de plantear y diseñar el
espacio escénico en sus vertientes visual y sonoro y la interacción con elementos tecnológicos multimedia.

El conocimiento derivado de los diferentes elementos que intervienen en una producción escénica a
partir de la creación como sueño la interpretación y la dirección, pero también la escenografía, el vestuario, el
diseño sonoro o la iluminación, ayudará al alumnado en el conocimiento de posibles caminos académicos y
profesionales en un futuro posterior a la etapa educativa de secundaria.

Finalmente, a los puntos de vista principales de la puesta en escena: dramaturgia o coreografía,
interpretación, dirección y producción escénica hay que añadir la recepción del público. Culminar la puesta
en escena con la representación ante el público, permite compartir sus experiencias de actuación con otras,
establecer vínculos con sus aprendizajes anteriores y confrontar sus opciones artísticas con las personas del
grupo.

La competencia poner en escena proyectos artísticos contribuye al perfil del final de etapa al ayudar
al alumnado a adaptar y organizar sus conocimientos, destrezas y actitudes para responder con creatividad
y eficacia a un ejercicio de producción cultural o artística, valorando el producto final.

3. Conexiones de las competencias específicas entre sí, con las competencias de otras materias
3.1. Relaciones o conexiones con las otras CE de la materia

En este apartado presentamos las conexiones más significativas entre las competencias específicas
(CE) de la materia de Artes Escénicas.

El proceso de enseñanza y aprendizaje de esta materia exige el desarrollo y la integración de las
diferentes competencias específicas de manera simultánea.

De hecho la CE1 está vinculada estrechamente con la CE2, puesto que los procesos de apreciar y
analizar están íntimamente relacionados en cuanto que la apreciación de obras y piezas escénicas y su
análisis implican conocimientos simultáneos.

La CE3 está directamente conectada con la CE4 en cuanto que la creación y la interpretación en un
proceso de experimentación son simultáneas o consecutivas.

La CE5 supone la culminación de las otras.

3.2. Relaciones o conexiones con las CE de otras materias de la etapa

La materia de Artes Escénicas de 4.º de ESO permite establecer conexiones diferentes con otras
materias de la etapa. Teniendo en cuenta las competencias específicas, los saberes y los criterios de
evaluación, se enumeran y se relacionan las conexiones más relevantes.

Las materias lingüísticas, especialmente en la vertiente creativa del lenguaje, las diferentes literaturas
en cuanto que son un vehículo necesario de comunicación, estímulo para la creación y comparten estructuras
narrativas con el teatro. Con las lenguas se generan espacios de producción creativa contemporánea,
mediante la improvisación y experimentación a partir de la palabra unida al gesto, desde un enfoque que
aborda con apertura el terreno del que es efímero e imprevisible pero también la relación con el repertorio de
la literatura dramática.

La metodología en la elaboración de proyectos, común a tantas áreas.

La materia de Tecnología y Digitalización comparte el uso de recursos digitales para el registro, la
edición y la difusión de productos parciales o finales de Artes Escénicas.

En cuanto a la relación con la materia de Expresión Artística de 4.º de ESO hay que destacar la
producción y la utilización de diseños que pueden servir tanto de apoyo escénico visual o punto de partida
creativo para la experimentación en teatro, la danza u otras artes de acción.

Supone una oportunidad para establecer conexiones y trabajar conjuntamente con la materia de
Música, puesto que se comparte saberes destacados en relación sobre todo a la danza, pero también con la
utilización de la música como estímulo para piezas teatrales o creación de espacios sonoros. Además, hay
una clara intención expresiva en la producción de propuestas artísticas interdisciplinarias basadas en el uso
de lenguajes plásticos, gráficos, musicales, escénicos y audiovisuales. Finalmente, toman importancia los
saberes relacionados referidos a las vanguardias artísticas del siglo XX y XXI y todo el arte contemporáneo.

En cuanto a los contenidos, todas las áreas curriculares pueden tener cabida en cuanto que fuente
de información y estímulos para la creación.

Por supuesto la conexión con la materia de Educación Física es evidente en cuanto que comparte
competencias y saberes con la parte artístico-expresiva de la materia, con la expresión corporal como pilar
de los procesos de creación interdisciplinaria.

Finalmente, no podemos olvidar la oportunidad que se plantea en relación con la producción de
proyectos escenográficos interdisciplinarios que con materias optativas de cursos anteriores como Laboratorio
de Artes Escénicas de 1.º de ESO, Creatividad Musical de 3.º de ESO y Expresión Artística de 4.º de ESO.

3.3. Relaciones o conexiones con las competencias clave

Conexiones de las competencias específicas de la materia con las competencias clave del perfil de
salida del alumnado al final de la educación básica.

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 | X |  |  |  | X | X |  | X |
| CE2 | X | X |  | X | X | X |  | X |
| CE3 | X |  |  |  | X |  | X | X |
| CE4 | X | X |  |  | X |  |  | X |
| CE5 |  |  |  |  | X |  |  | X |

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

•
CCL Competencia en comunicación lingüística
•
CP Competencia plurilingüe
•
CMCT Competencia matemática y competencia en ciencia y tecnología
•
CD Competencia digital
•
CPSAA Competencia personal, social y de aprender a aprender
•
CC Competencia ciudadana
•
CE Competencia emprendedora
•
CCEC Competencia en conciencia y expresión culturales

El cuadro adjunto anterior muestra la existencia de una relación especialmente significativa y
relevante entre las cinco competencias específicas de esta materia y algunas competencias clave incluidas
en el perfil de salida del alumnado al finalizar la educación básica.

En todos los casos, esta relación opera en  las dos direcciones. Por un lado, la adquisición y el
desarrollo de las competencias específicas señaladas contribuye a la adquisición y el desarrollo de las
competencias clave con que aparecen estrechamente vinculadas; por otro lado, estas competencias clave
juegan un papel importante en la adquisición y el desarrollo de las competencias específicas señaladas.

CE1: Esta competencia específica de apreciación contribuye al logro fundamental de la CCEC, en
cuanto que supone valorar de forma argumentada las manifestaciones artísticas como vehículo de expresión
libre, comunicación creativa de ideas y fuente de conocimiento, creación y comprensión de la propia identidad
personal y cultural en todas las sociedades de un mundo diverso.

No es ajena, sin embargo, a otras competencias clave como la CCL, necesaria para argumentar, o
una competencia como la personal, social y aprender a aprender, que implica reflexionar sobre uno o una
mismo y su entorno para autoconocerse, aceptarse y promover un crecimiento personal constante, entre otras
capacidades.

Atiende la CC, en cuanto a la participación plena en la vida social y cívica, en la adopción consciente
de los valores propios de una cultura democrática fundamentada en el respeto a los derechos humanos, como
por ejemplo la libertad de expresión inherente a las manifestaciones escénicas o la reflexión crítica sobre los
grandes problemas éticos y los desafíos de nuestro tiempo que se pueden dar.

Retos como por ejemplo la adquisición de un compromiso ciudadano en el ámbito local y global ante
las situaciones de desigualdad o exclusión se podrán lograr mejor desde la valoración de la diversidad
personal y cultural que proporciona el conocimiento de las artes escénicas a través de la participación activa
en su recepción y promoción.

CE2: Serán condiciones necesarias reafirmar los hábitos de lectura, estudio y dominio de las lenguas
de aprendizaje del alumnado para participar en interacciones comunicativas con actitud rigurosa, cooperativa
y respetuosa o argumentar las opiniones, capacidades propias de la competencia clave en CCL y CP.

La CD se relaciona con esta específica en cuanto que requiere capacidades para la búsqueda
avanzada y con criterio de información en redes, así como la creación, integración y reelaboración de
contenidos digitales de manera individual o colectiva con el uso imprescindible de las herramientas
tecnológicas.

Analizar ideas relativas a la dimensión social, histórica, cívica y moral a través de las artes escénicas
y adoptar juicios propios y argumentados ante problemas éticos y filosóficos fundamentales y de actualidad
remiten a la CC.

Además, en el entorno de la CPSAA, esta específica requiere comparar, analizar, evaluar y sintetizar
datos, información e ideas de los medios de comunicación con espíritu crítico, para obtener conclusiones
lógicas de manera autónoma y mostrar sensibilidad hacia las emociones y las experiencias de los otros y las
otras.

Esta competencia específica, no obstante, contribuye especialmente al logro fundamental de la
CCEC, por el que supone de implicación de varias maneras y en varios contextos, en la comprensión, el
desarrollo y la expresión de las ideas propias y del sentido del papel que desarrollamos en la sociedad.

En definitiva, apreciar el hecho cultural y artístico conlleva disponer de los conocimientos,
procedimientos y actitudes que permiten acceder a las diferentes manifestaciones, así como disponer de
capacidades cognitivas, perceptivas y comunicativas, sensibilidad y sentido estético para poder
comprenderlas, valorarlas, emocionarse y disfrutar. A todo esto contribuye una competencia específica de
análisis.

CE3: Esta competencia específica contribuye al logro fundamental de la CCEC en cuanto que supone
seleccionar e integrar con creatividad varios medios, soportes y técnicas para diseñar y planificar proyectos
artísticos.

Adaptando y organizando sus conocimientos, destrezas y actitudes para responder con creatividad y
eficacia a la producción cultural o artística, utilizando lenguajes, técnicas, herramientas y recursos diversos y
valorando tanto el proceso como el producto final.

Además, el hecho de llevar a cabo un proceso de creación y tomar decisiones, con sentido crítico y
ético, para, en consecuencia, aplicar conocimientos técnicos específicos y estrategias ágiles de planificación
y gestión de proyectos, reflexionando sobre el proceso realizado y el resultado obtenido como una oportunidad
para aprender, permite situar esta competencia específica en relación a la CE.

La distribución en un grupo de tareas, recursos y responsabilidades de manera ecuánime, según los
objetivos inherentes con una buena planificación de un proyecto, en este caso escénico, forman parte de las
capacidades que requiere la CPSAA.

Así mismo, la creación, la integración y la reelaboración de contenidos digitales de manera individual
o colectiva, aplicando medidas de seguridad y respetando los derechos de autoría para ampliar los recursos
y generar nuevo conocimiento, lo serán de la competencia digital.

Independientemente de que la CCL constituye la base para el pensamiento propio y para la
construcción del conocimiento en todos los ámbitos del saber, está especialmente vinculada a una
competencia específica de creación escénica, teniendo en cuenta la especial relación del lenguaje dramático
con los usos de la oralidad, la escritura de textos, la dimensión estética del lenguaje y la cultura literaria
dramática y general que habrá que activar en la consecución de esta competencia específica.

CE4: La competencia específica interpretar obras o piezas escénicas contribuye a la consecución de
la CCEC, puesto que permite descubrir la autoexpresión como experiencia vital, a través de la interacción
corporal, de las diferentes herramientas y lenguajes artísticos, enfrentándose a situaciones que fomentan el
conocimiento y la aceptación propia y de los otros y otras, apreciando los valores de la empatía y la
colaboración.

La expresión oral y las interacciones comunicativas forman parte de la CCL que en determinadas
manifestaciones escénicas asumen un papel predominante. Así como la CP, puesto que la diversidad
lingüística es una característica de las manifestaciones escénicas universales.

La CPSAA hace referencia a mostrar sensibilidad hacia las emociones y las experiencias de los otros
y las otras, siendo consciente de la influencia que ejerce el grupo en las personas, para consolidar una
personalidad empática e independiente y desarrollar la inteligencia. La contribución de una competencia
específica de interpretación fomenta esta capacidad.

CE5: Respecto a la CCEC, al poner en escena, se ponen en valor las diferentes herramientas y
lenguajes artísticos para producir proyectos artísticos y culturales sostenibles ejemplo de nuevos retos
personales y profesionales vinculados con la diversidad cultural y artística.

La CPSAA hace referencia a mostrar sensibilidad hacia las emociones y las experiencias de los otros
y las otras, siendo consciente de la influencia que ejerce el grupo en las personas, para consolidar una
personalidad empática e independiente y desarrollar la inteligencia. La contribución de una competencia
específica donde la colaboración responsable y respetuosa es imprescindible y fomenta esta capacidad.

4. Saberes básicos
4.1.
Introducción

Los saberes básicos son el conjunto de conocimientos, procedimientos y actitudes que se trabajarán
en el proceso enseñanza-aprendizaje que llevará al alumnado a lograr las competencias enunciadas.

El enunciado poco específico de los saberes implica tanto su concepción básica como la posibilidad
de ser ampliados y adaptados por el profesorado en el propio contexto escolar.

Estos saberes básicos se distribuyen en tres bloques que a su vez se dividen en subbloques (SB) y
grupos según el caso.

Los saberes del primer bloque Percepción y análisis están especialmente vinculados a C1 y C2. El
segundo bloque, Creación e interpretación tiene un subbloque 2.1 más vinculado a la competencia específica
C3 y el subbloque 2.2 a la C4. Por último el tercer bloque Puesta en escena se vincula especialmente a la
competencia específica C5.

A pesar de esto, en general, los saberes propuestos son transversales a todas las competencias
puesto que no tienen una ordenación ni desde el punto de vista de la temporización a la hora de ser
introducidos en el diseño de las diferentes situaciones de aprendizaje ni desde una consideración jerárquica
en cuanto a grado de importancia.

4.2.
Bloque 1. Percepción y análisis CE1 I CE2

4.2.1. Subbloque 1.1 Percepción

•
Origen, evolución, características y tipologías de las Artes Escénicas. Tendencias contemporáneas.
•
Elementos comunes y convenciones: ritualidad, dramaticidad, teatralidad, performatividad.
•
Literatura dramática y otras tipologías de textos.
•
Patrimonio escénico valenciano y universal.
•
Elementos en la recepción de un espectáculo escénico. Espacios escénicos y público.
•
Valores estéticos y actitudes éticas de creador y receptor.

4.2.2. Subbloque 1.2 Análisis

•
Dramaturgia: trama, personajes, detonante, acción, conflicto, espacio, tiempo.
•
El instrumento del cuerpo. Técnica de expresión: gestos y movimientos.
•
Elementos expresivos y simbólicos: personaje, cuerpo, gesto, voz, texto, caracterización. Acción
dramática, danzada, o performativa: tiempo, espacio, energía, interrelación, expresión.
•
Elementos visuales y sonoros: escenografía, iluminación, ambiente sonoro, vestuario.
•
Música para las artes escénicas.
•
Elementos de otros lenguajes y prácticas artísticas contemporáneas.

4.3.
Bloque 2. Creación e interpretación. CE3 i CE4

4.3.1. Subbloque 2.1 Creación

•
Formas contemporáneas de presentación escénica: estímulos creativos, tipologías básicas.
•
Conciencia de grupo: sensibilidad y socialización. Escucha activa y respeto.
•
Terminología de las artes escénicas.
•
Métodos básicos de escritura teatral. Esquema dramático: tema, personaje, conflicto, tiempo, trama.
•
Composición y estructura coreográfica. El cuerpo como materia prima: gestos y movimientos.
•
Cultura musical para la danza.

4.3.2. Subbloque 2.1 Interpretación

•
Entrenamiento corporal: conciencia de esquema corporal, movilidad, técnica del gesto y el
movimiento, individual y grupal. Actitudes saludables hacia el cuerpo y la voz.
•
Elementos y técnicas interpretativas actuales. Dramáticas, cinestésicas y performativas.
•
Pautas de atención, percepción, escucha activa, concentración, conciencia corporal y memoria.
Solidaridad y respeto.
•
Trabajo: textual, musical y audiovisual.
•
Voz expresiva: respiración, dicción, vocalización, articulación, prosodia, proyección.
•
Control de las emociones y sentimientos en la expresión.

4.4.
Bloque 3. Puesta en escena CE5

•
Diseño de un espectáculo: equipos, fases y áreas de trabajo.
•
Dramaturgia y coreografía. Dirección escénica. Ensayos: tipología, finalidad, fases y organización.
•
Espacio visual y sonoro: escenografía física y virtual, recursos plásticos, diseño de iluminación,
vestuario, caracterización. Música, recursos sonoros. Herramientas digitales multimedia.
•
Planteamientos éticos y responsables. Implicación en los proyectos colectivos. Respeto al grupo, la
salud y la seguridad.
•
Valoración de procesos y resultados.
•
La experiencia ante el público.
•
Interacción en redes sociales.

5. Situaciones de aprendizaje para el conjunto de las competencias de la materia

Para que todas las dimensiones de la práctica de las Artes Escénicas se puedan implementar
plenamente en el aula, es importante prestar atención al entorno pedagógico en que se desarrolla el
alumnado.

La materia Artes Escénicas tiene que permitir la construcción de conocimientos integradores basados
en un aprendizaje esencialmente procedimental, sin obviar, no obstante, la teoría y la conceptualización, y
prestando especial atención a las actitudes y valores que estos aprendizajes necesariamente comportan.

El aula de Artes Escénicas debería ser un lugar donde se producen numerosas acciones e
intercambios en un clima de confianza y respeto. Que proporcione a los y las estudiantes un entorno de apoyo
donde se sienten libres de asumir riesgos, mostrar iniciativa y ser creativos y autónomos, entendiendo la
creación desde un enfoque y un proceso que implica un diálogo permanente entre teoría y práctica, acción y
reflexión, experiencia y enriquecimiento cultural.

Así se deberían establecer espacios de aprendizaje adaptados a los requisitos de creación,
representación y valoración de obras escénicas, y ofrecer un entorno rico en recursos documentales y
artísticos de calidad. Se debería poner a disposición herramientas y apoyos tecnológicos, libros y material
audiovisual sobre teatro, danza y otras artes performativas para estimular la creatividad de los y las
estudiantes, proporcionar elementos para la reflexión y enriquecer su conocimiento del mundo artístico
escénico.

Las situaciones de aprendizaje se tendrían que ampliar, en la medida de las posibilidades, fuera del
aula. La interacción entre el o la intérprete y el espectador o la espectadora hace que cada actuación de
teatro, danza o artes performativas sea un acontecimiento único, independientemente del alcance, y los y las
estudiantes deben tener la oportunidad de vivir acontecimientos escenificados.

Si se potencia además con visitas a lugares culturales, encuentros con artistas y participación activa
en la vida artística de la escuela y de la comunidad, los y las estudiantes serán estimulados para desarrollar
sus facultades críticas y estéticas.

El profesorado tiene un papel determinante para ayudar a los y las estudiantes a implicarse a nivel
personal en el proceso de creación, interpretación o recepción y análisis, a hacerlos y hacerlas conscientes
de la importancia de ser receptivos y receptivas  a las propias sensaciones, impresiones, emociones y
sentimientos, a integrar sus experiencias y desarrollar sus necesidades físicas, cognitivas y sociales
particulares.

Los docentes y las docentes de Artes Escénicas tendrían que hacer el papel de “mediador o
mediadora cultural”, capaz de comunicar la pasión por ellas y establecer vínculos entre el pasado y el presente
o entre las diferentes formas del arte, mantenerse en el día de la evolución del mundo escénico y compartir
este conocimiento con el alumnado y animarlo a interesarse por las obras artísticas y sus contextos históricos,
y a abordar los estímulos para la creación, la interpretación y la valoración con una mente abierta.

Las situaciones de aprendizaje tienen que ser variadas, que planteen retos adecuados y ayuden al
alumnado a desarrollar, consolidar y dominar sus capacidades.

Deberían atender a la importancia de la transferencia de los aprendizajes, incluyendo actividades que
permitan al alumnado contextualizar sus conocimientos y habilidades. De este modo, el alumnado podrá
adquirir nuevos aprendizajes, establecer relaciones con sus aprendizajes anteriores y descubrir la importancia
en la vida cotidiana.

Para diseñar situaciones significativas de aprendizaje habría que inspirarse en los intereses, los
referentes culturales y otras materias de los y las estudiantes y permitir establecer vínculos con las amplias
áreas de aprendizaje.

Deben ser adecuadas para una instrucción diferenciada y permitir a los y las estudiantes explorar una
gama tan amplia como sea posible de experiencias sensoriales, relacionadas con el juego dramático, la
expresión corporal y las estéticas.

Se debe poner énfasis en la autenticidad, entendida como demostración de un esfuerzo de
implicación personal por parte del alumnado que intenta ir más allá de los tópicos y los estereotipos para
buscar soluciones nuevas. También en la expresividad y la investigación de la originalidad en la creación, la
interpretación y la valoración de las obras escénicas.

Se deben incluir tareas que reflejen las capacidades del alumnado, que involucran todos los aspectos
de las competencias y movilizan recursos diversos, que los dejan margen para determinar los pasos de su
propia progresión artística y permiten seleccionar las estrategias adecuadas.

Las situaciones de aprendizaje tendrán sentido cuando despierten el interés y el compromiso del
alumnado, estimulen su pensamiento, lo animen a tomar iniciativas en función de sus preferencias y
capacidades y lo inviten a implicarse en el desarrollo concreto de proyectos o actividades artísticas ricas y
estimulantes.

Ya sea en situaciones de creación, interpretación o apreciando obras escénicas, los y las estudiantes
deben experimentar las ventajas, los retos y la sinergia del trabajo en equipo. En el teatro, la danza y las otras
artes performativas, la comunicación se valida a ojos de los compañeros y compañeras y del público. Esta
interacción influye tanto en el proceso de creación o actuación como en su resultado. El alumnado lo tiene
que tener en cuenta en el uso de los diferentes elementos escénicos. Actúan para las personas de su grupo
para poner a prueba sus opciones artísticas.

El grupo como primer público, tendría que usar su juicio crítico y estético para ayudarlos y ayudarlas
a progresar en su trabajo creativo y de rendimiento. Su contacto con una visión externa a la suya y su incursión
en el universo creativo de otra persona los y las ayuda a explorar otras maneras de representar situaciones,
de dar vida a los personajes al escenario o expresión concreta del movimiento. Se anima al alumnado a tomar
una posición respecto a diferentes modas de expresión a la vez que desarrollan sus conocimientos de técnica,
comunicación verbal y no verbal y cultura.

Las situaciones de aprendizaje de las Artes Escénicas tiene que permitir vincularse especialmente
con las otras asignaturas de artes y expresión, la Música, la Literatura, la Educación Física y las Artes
Plásticas, Visuales y Audiovisuales, especialmente vinculadas en todos los momentos y aspectos de la
creación y la representación, pero también con todas las otros áreas temáticas y generar uno o más estímulos
de creación, actuación o valoración.

Deben recurrir a una o más competencias específicas de la asignatura, incluyendo una serie de tareas
complejas, conducir a diferentes tipos de producción y dar valor tanto al proceso como al producto.

Deben apoyar la adquisición de actitudes esenciales para el desarrollo artístico, inducir el uso de los
recursos presentados como contenidos del programa, implicar referentes culturales y fomentar el uso de
herramientas de reflexión.

Con el objetivo de atender a la diversidad de intereses y necesidades del alumnado, se incorporarán
los principios del diseño universal, asegurándonos de que no hay barreras que impidan la accesibilidad física,
cognitiva, sensorial y emocional para garantizar su participación y el aprendizaje.

Todas las actividades generadas en las situaciones de aprendizaje tienen que garantizar la
convivencia y los valores democráticos. Además, promocionar la participación activa en el centro y fuera de
él, dando a conocer el trabajo de aula desde una perspectiva sostenible y contribuyendo a la consecución de
los retos y desafíos del s. XXI.

Finalmente, tienen que permitir al profesorado observar el desarrollo de las competencias del
alumnado mediante los criterios de evaluación.

6. Criterios de evaluación
6.1.
CE1

Apreciar y argumentar la aportación de las manifestaciones escénicas al patrimonio cultural,
participando activamente en la recepción a través de diferentes canales, y valorando la diversidad de
tradiciones, géneros y estilos estéticos.

6.1.1. Recibir propuestas escénicas diversas interpretando los diversos significados y
examinándolas desde un punto de vista crítico y estético.
6.1.2. Promover el conocimiento y difusión de producciones escénicas diversas
argumentando su importancia como parte fundamental del patrimonio cultural y vehículo del
derecho a la libertad de expresión.

6.2.
CE2

Analizar propuestas escénicas desde un punto de vista estético, con actitud crítica, explorando
componentes, la escritura, la finalidad comunicativa y las relaciones con el entorno sociocultural.

6.2.1. Analizar de manera crítica una obra escénica o un fragmento identificando los
elementos significativos, a partir de varios criterios de apreciación.
6.2.2. Comentar los posibles significados de una pieza escénica para proponer una
interpretación personal empleando la terminología adecuada, mostrando respeto y rigor,
teniendo en cuenta el valor artístico y el contexto.

6.3.
CE3

Crear producciones escénicas individuales y colectivas mediante el uso de elementos, técnicas y
procesos de los diferentes lenguajes artísticos a partir de estímulos diversos, dando expresión concreta a
ideas, sentimientos o emociones, valorando tanto el proceso como el resultado final.

6.3.1. Aplicar ideas para la creación de una pieza escénica a partir de diferentes estímulos
utilizando elementos del teatro, la danza y otros lenguajes artísticos.
6.3.2. Desarrollar un proyecto escénico, partiendo de una propuesta previa, mediante un
trabajo colaborativo, adaptando los recursos disponibles a la intencionalidad creativa.
6.3.3. Compartir la experiencia creativa de selección y toma de decisiones en función del
mensaje que se quiere comunicar.

6.4.
CE4

Interpretar obras o piezas escénicas de creación propia o ajena mediante los instrumentos expresivos
y comunicativos del cuerpo, la voz, el movimiento, el tiempo y el espacio, y hacer uso de la memoria sensorial
y afectiva personal y del grupo.

6.4.1. Construir, de forma creativa, un personaje dramático desde la expresión física del
cuerpo y la técnica vocal aplicando la memoria sensorial y afectiva personal.
6.4.2. Incorporar calidades expresivas en secuencias de movimientos ligadas a través del
aprendizaje de coreografías, interactuando con coordinación y cooperando con los otros y
las otras.
6.4.3. Hacer uso correcto de contenidos dramáticos y coreográficos, elementos de la
técnica y estilos escénicos respondiendo a nivel cognitivo y emocional a las características
de la pieza.
6.4.4. Describir los elementos relevantes de la experiencia interpretativa compartiéndola
con los otros y las otras con respeto.

6.5.
CE5
Poner en escena proyectos artísticos de un repertorio diverso, cooperando en la organización de los
elementos artísticos y fases de producción, asumiendo con responsabilidad los diferentes roles.

6.5.1. Tomar parte activamente en diferentes fases de una producción escénica, desarrollar
diferentes roles y contribuir a conseguir un proceso creativo eficiente, colaborativo e
integrador.
6.5.2. Representar públicamente un proyecto escénico, involucrando a todos y todas los y
las participantes y manteniendo una comunicación cohesionadora e inclusiva.
