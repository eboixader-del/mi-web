# LABORATORIO DE CREACIÓN AUDIOVISUAL

> Fuente: Secundaria.pdf, páginas 1154-1165 (versión en castellano).

LABORATORIO DE CREACIÓN AUDIOVISUAL

1. Presentación

Vivimos en una sociedad en la que las imágenes tienen un protagonismo sin precedentes: en

los productos que consumimos, en la publicidad, en la televisión, en las redes sociales. Tanto el

consumo como la producción de contenidos audiovisuales se han multiplicado, recibiendo miles de

impactos visuales diarios que configuran nuestro imaginario, nuestros deseos y nuestra identidad.

Teniendo en cuenta esta realidad, desde la educación formal es necesaria una alfabetización visual y

audiovisual para construir discursos y relatos alternativos que permitan al alumnado leer y comprender

las imágenes que nos rodean y, también crear las suyas propias teniendo en cuenta los códigos y las

posibilidades expresivas del lenguaje audiovisual. De esta manera se está garantizando el derecho

fundamental de la participación en la vida cultural, democratizando los contenidos culturales y

fomentando el acceso a los mismos.

La materia Laboratorio de Creación Audiovisual pretende iniciar al alumnado en los contenidos

relativos al lenguaje y a la producción audiovisual desde una perspectiva predominantemente

procedimental, que se ampliarán en la materia de Educación Plástica, Visual y Audiovisual de 2.º de

ESO. El alumnado configurará su imaginario analizando obras diversas y explorando el patrimonio

audiovisual, pero también creando sus propias propuestas innovadoras, tanto individualmente como

en equipos de trabajo coordinados y con diferentes roles y funciones.

Los lenguajes de creación contemporánea se nutren de multiplicidad de formatos y de

experiencias que trascienden los límites disciplinares. Así, el lenguaje audiovisual, a través de

diferentes canales (cine, televisión, series, publicidad, arte contemporáneo) forma parte del tejido

artístico y cultural contemporáneo y, como tal, requiere de espectadores y profesionales conocedores

de sus códigos y de sus posibilidades expresivas y comunicativas.

Teniendo en cuenta que gran parte del alumnado de 1.º de ESO que cursa la materia

Laboratorio de Creación Audiovisual ya es usuario y consumidor de redes sociales con contenidos

visuales y audiovisuales, uno de los objetivos fundamentales de la materia es promover el uso

adecuado y responsable de estas herramientas, así como de las técnicas, recursos y soportes de

creación audiovisual.

De esta manera, se posibilita la introducción de la competencia digital para el aprendizaje y el

desarrollo de conocimientos sobre procesos audiovisuales y artísticos, contemplando los soportes

digitales como herramientas de trabajo y expresión, y también como una oportunidad para acercar esta

disciplina al alumnado.

Con todo, se promoverá la utilización de las TIC en el desarrollo de los diversos procesos

creativos, favoreciendo el empleo de medios digitales en las distintas fases de desarrollo, así como en

la evaluación y la exposición. Asimismo, se fomentará el conocimiento de la normativa reguladora de

protección de datos de carácter personal, a fin de evitar situaciones de riesgo y vulnerabilidad del

alumnado y del profesorado, protegiendo sus derechos y libertades fundamentales.

La materia Laboratorio de Creación Audiovisual contribuye de manera directa a la adquisición

de las competencias clave, por su carácter favorecedor de metodologías activas y cooperativas que

transforman el aprendizaje en una experiencia significativa y promueven el desarrollo de la creatividad,

facilitando de esta forma la consecución de los objetivos de la etapa de Educación Secundaria

Obligatoria.

El orden de presentación de las competencias específicas no debe entenderse como una

secuencia ordenada, sino más bien como una secuencia formativa que necesita de momentos de

observación, análisis, creación y evaluación a lo largo de todo el proceso.

Los saberes básicos seleccionados son aquellos que se consideran necesarios para la

adquisición de las competencias específicas y se dividen en tres bloques fundamentales y en sub-

bloques dedicados, por una parte, al estudio de los códigos básicos del lenguaje audiovisual y, por

otra, a la creación y puesta en práctica de un proceso de producción audiovisual.

Finalmente se presentan los criterios de evaluación, orientados a conocer el grado de

adquisición de cada una de las competencias específicas de la materia.

2. Competencias específicas

2.1. CE1

Explorar propuestas audiovisuales desde una perspectiva inclusiva y abierta, analizando sus

elementos formales y comunicativos básicos, y valorando la importancia de la diversidad cultural.

2.1.1. Descripción de la competencia

En los procesos creativos es fundamental partir de referentes significativos que enriquezcan

el imaginario del alumnado y amplíen su repertorio de recursos expresivos, aportando ejemplos de

resolución creativa a diferentes desafíos y posibilitando la conexión de intenciones, temáticas,

resoluciones técnicas y estéticas. Por ello, es importante el conocimiento de referencias audiovisuales,

así como su potencial comunicativo y expresivo en la actualidad.

La exploración y el análisis son necesarios para poder interpretar los códigos de las imágenes,

la influencia que ejercen sobre nosotros, y poder dilucidar el poder de los medios de comunicación en

la sociedad, comprendiendo la afectación que supone en las pautas de conducta, así como los valores

y contravalores que promueven, incluso en la generación de ideologías.

Los ejemplos explorados deberían ser diversos y favorecer un análisis de la cultura visual y

audiovisual desde una perspectiva inclusiva, tolerante, que cuestione los estereotipos y

discriminaciones existentes en las imágenes, y su poder de fascinación, de manera que el alumnado

pueda tomar decisiones informadas en sus creaciones futuras. Practicar el análisis de creaciones

fotográficas, fílmicas, vídeos publicitarios, piezas radiofónicas o cualquier otro tipo de producción

audiovisual implica convertir al alumnado en usuario consciente, ya que la representación subjetiva de

la realidad nunca es la realidad misma.

Por tanto, reconocer las características formales y comunicativas de dichos referentes

audiovisuales o artísticos, ayudaría a distinguir los aspectos sociales que atraviesan dichas obras y

valorar cuál es su impacto social, especialmente en la construcción de la identidad.

Es por ello que, mediante esta competencia, el alumnado debería enriquecer su bagaje

cultural, reconociendo la comunicación audiovisual como una fuente de expresión y de generación de

ideas, sentimientos y emociones de otras autorías, que se promueve y difunde a través de los medios

y canales de comunicación, incluidas las redes sociales, reconociendo también su presencia y su

impacto en la sociedad y ayudando a la construcción de una identidad digital más respetuosa y

consciente.

2.2. CE2

Elaborar propuestas audiovisuales experimentando con diferentes recursos, técnicas y

herramientas y aplicando los códigos básicos del lenguaje visual y audiovisual en la transmisión de

ideas, sentimientos y emociones.

2.2.1. Descripción de la competencia

A través de esta competencia el alumnado conoce diferentes elementos, formatos, procesos,

técnicas y soportes para la elaboración de creaciones audiovisuales, explorando tanto posibilidades

analógicas como digitales y experimentales.

La creación requiere planificación y la capacidad de reconducir la secuencia creativa en base

a una evaluación continua del proceso. El alumnado debería intentar transmitir intereses afectivos,

cognitivos, sociales y culturales, así como la propia percepción de la realidad.

Para ello, se partirá del propio autoconocimiento y de los referentes audiovisuales analizados

con anterioridad, para experimentar con sus propiedades como estímulo para el proceso de creación

de las obras propias y, de esta manera, poder aplicar los diferentes códigos del lenguaje audiovisual,

en función de las intenciones comunicativas en las piezas.

Esta competencia pone el énfasis en los fundamentos de la sintaxis visual y audiovisual, de

manera que posibilite al alumnado ampliar su repertorio de recursos técnicos y expresivos, así como

su bagaje cultural y artístico.

2.3. CE3

Participar de todas las fases del proceso de producción audiovisual colectivo, asumiendo

diferentes roles con autoexigencia y compromiso, proporcionando soluciones a los distintos retos y

respetando las aportaciones del resto de participantes.

2.3.1. Descripción de las competencias

Esta competencia alude a la importancia no solo de la calidad del producto final sino también

del proceso de trabajo en los proyectos de creación audiovisual (preproducción, producción y

postproducción), así como a la ejecución de la planificación como estrategia fundamental para

elaborarlo. Asimismo, es importante destacar que participar en un proceso de trabajo colectivo implica

siempre asumir diferentes roles y funciones con responsabilidad y compromiso en aras de un objetivo

común.

A través de esta competencia, al finalizar el curso, el alumnado debería ser capaz de

argumentar las decisiones tomadas en cualquier proyecto, interpretando, además, que la creación

artística es consecuencia de un método ordenado de trabajo en el que las fases de ideación,

experimentación y desarrollo son objetivables y definen el resultado final de la obra.

Además, esta competencia requiere de una actitud abierta en la evaluación contínua del

proyecto, de manera que puedan detectarse posibles mejoras y reconducir, cuando sea necesario, el

proceso de trabajo.

Con esta competencia debería propiciarse en el alumnado la habilidad para argumentar las

ideas propuestas, reflexionar y analizar durante todo el proceso, así como la actitud abierta,

participativa y democrática.

2.4. CE4

Compartir las propuestas audiovisuales individuales y colectivas a través de diferentes canales

y medios, empleando la terminología propia del área y promoviendo la participación en la vida cultural

del centro educativo.

2.4.1. Descripción de la competencia

La exposición de las propuestas audiovisuales, dentro y fuera del centro educativo permite al

alumnado la interacción y retroalimentación con el espectador, el promotor del proyecto o la comunidad

educativa, dotando de sentido y finalidad a la obra, y creando un impacto social que contribuye a su

capacidad de transformación.

A través de esta competencia específica, se fomentará también el respeto y la escucha activa

de las propuestas de los demás, así como la gestión de las críticas constructivas. Para poder defender

las propias ideas de manera asertiva también se facilitarán momentos de comunicación en el aula que

requieran el empleo de la terminología específica de la materia, así como un uso correcto e inclusivo

del lenguaje.

Esta competencia alude a la importancia de la visibilización de los proyectos escolares en la

comunidad educativa y en la sociedad. La participación ciudadana y la relación del contexto educativo

con otras instituciones deberían potenciar la aplicación directa de los conocimientos del alumnado, su

función social, y favorecer su motivación para la conservación del entorno y la relevancia del trabajo

realizado.

La importancia de la divulgación de los proyectos dentro y fuera de la comunidad educativa es

un punto crucial en el desarrollo de proyectos en cualquier ámbito, que ayuda a formar al alumnado en

la gestión de recursos físicos y digitales como medios de difusión, aplicando y respetando la normativa

vigente en relación a derechos de autoría y usos lícitos de los recursos, y teniendo en cuenta las

posibilidades del contexto educativo.

3. Conexiones de las competencias específicas entre sí, con las de otras materias y con las
competencias clave

3.1. Relación entre las CE

Todas las competencias específicas del área están relacionadas entre sí y describen diferentes

momentos por los que transita el aprendizaje en el aula. Aunque su vinculación tiene una lógica

secuencial, debe entenderse que las diferentes competencias atraviesan todos los momentos del

proceso creativo, especialmente en lo relativo al análisis, la experimentación y la participación, que

permitirán evaluar y reconducir, si es necesario, la hoja de ruta de la producción audiovisual.

Se hace alusión a la experiencia de apreciación de referentes audiovisuales (CE1) a partir de

la contemplación y el análisis que permiten extraer conocimientos y referentes que amplían el repertorio

de recursos del alumnado. Como consecuencia del análisis se extraerán conclusiones con las que

poder experimentar (CE2) para la producción de sus propios productos audiovisuales, tanto

individuales como colectivos. En este sentido, será imprescindible una participación (CE3) activa,

democrática, respetuosa y comprometida. Por último, el momento de difundir (CE4) y compartir las

conclusiones y resultados de los procesos creativos implica un conocimiento de diferentes medios

físicos, digitales e informáticos que están presentes tanto en los momentos de investigación y análisis

(CE1), como en los de creación y experimentación (CE2 i CE3).

3.2. Relación de las CE con otras materias

Las conexiones que se establecen entre las competencias específicas de Laboratorio de

Creación Audiovisual con las de la materia de Música, muestran una relación global, puesto que en

ambas se trata la exploración y el acercamiento a diferentes propuestas artísticas, para reconocer los

diferentes elementos y características que las conforman. Además, la importancia del sonido y la

música en las producciones audiovisuales es evidente, posibilitando la hibridación de los saberes

específicos de ambas materias.

En cuanto a la exploración, el reconocimiento, la experimentación y la descripción con el uso

de una terminología adecuada, que implica todo proceso de análisis, apreciación, creación y difusión,

se requieren competencias propias de las materias lingüísticas, ya que el vocabulario y las expresiones

utilizadas facilitan la comunicación entre todos los agentes implicados en la producción.

En cuanto al resto de áreas, la vinculación con Laboratorio de Creación Audiovisual puede

establecerse desde la perspectiva de integrar saberes, puesto que la producción artística actual hibrida

conocimientos y utiliza recursos de experimentación científica o documentación, siendo habitual que

las y los creadores trabajen junto con personal profesional de sectores diversos, representado en las

diferentes áreas de conocimiento.

3.3. Relación de las CE con las CC

La competencia clave en comunicación lingüística se relaciona con todas las competencias

específicas dado que el uso del lenguaje oral y escrito es necesario en cada momento de la práctica

docente de la materia, tanto en la experiencia de percepción de propuestas audiovisuales, como en la

de experimentación y creación de las propias producciones.

La competencia plurilingüe, que implica trabajar con referentes audiovisuales de zonas

geográficas diversas y acceder a propuestas e información en lenguas diferentes, se desarrollará tanto

en los momentos de análisis como en la creación y difusión, permitiendo una mayor apertura y

contribuyendo a la accesibilidad de los productos en la difusión final.

La competencia matemática y competencia en ciencia, tecnología e ingeniería (STEM), se

relaciona con la cultura visual y con la producción audiovisual en cuanto que los medios y procesos

tecnológicos son necesarios para el desarrollo de proyectos en esta materia, tanto en la apreciación

como en la experimentación y difusión de propuestas, y suponen un vínculo con la tecnología, la ética

y la seguridad. Asimismo, se necesita comprender la evolución tecnológica que han sufrido los medios

informáticos y audiovisuales hasta llegar a las tecnologías de hoy.

La competencia digital se vincula claramente con la CE2 y la CE4, pero se relaciona también

con el resto en el acercamiento a las obras que conforman la cultura visual y audiovisual (CE1), que

puede darse por medios digitales y tecnológicos mediante el uso de entornos virtuales de aprendizaje.

En el trabajo de comprensión de los referentes, el tratamiento de la información recibida deberá ser

analizada (CE1) y asegurar su veracidad, haciendo un buen uso y respetando las leyes de propiedad

intelectual y autoría, y construyendo una identidad digital consciente, sostenible, crítica y responsable.

La competencia de conciencia y expresión culturales se relaciona con el hecho de entender la

relevancia del entorno cultural y artístico como elemento inherente a la construcción de la identidad y

del compromiso social. Así, con la comprensión (CE1) de los hechos históricos y sociales más

relevantes del contexto, el alumnado debería poder establecer vínculos con sus propias producciones

(CE2).

4. Saberes básicos

Bloque 1. Fundamentos del lenguaje audiovisual (CE1, CE2, CE4)

Subbloque 1.1 Imagen fija e imagen en movimiento

-
Los elementos de la comunicación visual. La imagen en el mundo actual: funciones.

Canales de difusión de contenidos audiovisuales. Redes sociales: imagen e identidad. Publicidad.

-
Los orígenes de la fotografía. Fotografía analógica y fotografía digital. Géneros

fotográficos. La fotografía en las manifestaciones artísticas contemporáneas: proceso y producto.

Fotomontaje. Elementos de análisis de referentes fotográficos desde una perspectiva inclusiva.

-
Fundamentos históricos de las tecnologías del cine y de las artes audiovisuales.

Géneros cinematográficos: evolución y características. El audiovisual en las manifestaciones artísticas

contemporáneas: videoarte, videoinstalación. Stop motion y cine de animación.

-
Propuestas interdisciplinares: música, imagen, movimiento.

-
Perspectiva de género y multicultural en la producción audiovisual.

Subbloque 1.2. Lenguaje audiovisual básico

-
Elementos formales de la imagen: códigos temporales, espaciales y sonoros. Luz,

color, planificación, encuadre, composición, tiempo, sonido y texto.

-
Formatos audiovisuales.

-
Patrimonio audiovisual valenciano y patrimonio audiovisual universal.

Bloque 2. Producción audiovisual (CE2, CE3, CE4)

Subbloque 2.1 Planificación

-
Fases del proyecto audiovisual: preproducción, grabación/captura de imágenes,

postproducción.

-
Estrategias de pensamiento creativo para idear proyectos.

-
Distribución inclusiva de roles en la producción audiovisual.

-
Pautas de atención, escucha activa y responsabilidad.

Subbloque 2.2. Preproducción, producción y postproducción

-
El guion literario: idea, argumento, escaleta. Narrativa audiovisual. Personajes,

diálogos, secuencia, conflicto.

-
El guion técnico: plano, escena y secuencia.

-
Guion gráfico. Storyboard.

-
Puesta en escena. El espacio: localizaciones y escenografía.

-
Medios técnicos para la realización: elementos de grabación de imagen y sonido,

iluminación y herramientas digitales para el diseño y la manipulación de imágenes. Montaje

audiovisual.

-
Valoración y evaluación de procesos y resultados.

Subbloque 2.3 Difusión

-
Recursos digitales aplicados a la difusión de proyectos audiovisuales.

-
El diseño de elementos gráficos comunicativos. Principios de composición y teoría del

color. Uso de la tipografía y el texto como base de información y elemento compositivo.

-
Teaser y vídeo promocional.

-
Normativa vigente en relación con las licencias de uso.

-
Ámbitos de aplicación y perfiles profesionales del sector audiovisual.

5. Situaciones de aprendizaje

El entorno pedagógico en el que se desarrolla el alumnado es muy importante para poder

implementar todas las dimensiones de la práctica en el Laboratorio de Creación Audiovisual.

La materia tiene que permitir la construcción de conocimientos integradores basados en un

aprendizaje esencialmente procedimental, fundamentado en la investigación y experimentación

personal y prestando especial atención a las actitudes y valores que comportan estos aprendizajes,

con la introducción necesaria de contenidos teóricos.

El Laboratorio de Creación Audiovisual tiene que ser un aula abierta a acciones e intercambios

diversos en un clima de respeto y confianza. Debería proporcionar a los estudiantes un entorno en el

que se puedan sentir libres de mostrar iniciativas, asumir riesgos y ser creativos, hablar, debatir y

reflexionar sobre temáticas diversas y sobre los propios medios, contribuyendo así a una alfabetización

mediática.

La creación tiene que ser entendida como un diálogo entre la práctica, la acción, la reflexión,

la experiencia, la teoría y el enriquecimiento cultural que el conocimiento del lenguaje y la comunicación

audiovisual comportan.

Se deberían establecer espacios de aprendizaje adaptados a los requisitos de exploración

para el análisis, creación y difusión de producciones audiovisuales, con recursos técnicos,

documentales y artísticos de calidad para estimular la creatividad de los i las estudiantes, proporcionar

elementos para la reflexión y enriquecer su conocimiento del mundo audiovisual.

Para la práctica en el laboratorio habrá que usar una variedad de estímulos para la creación

adecuados a la edad, así como una diversidad de recursos para la realización práctica de aquello

diseñado.

Las situaciones de aprendizaje se tendrían que ampliar, en la medida de las posibilidades,

fuera del aula. Hay que atender no solo las posibilidades que el propio centro aporta a la

experimentación audiovisual, sino todas aquellas oportunidades de vivir acontecimientos relacionados

con las artes audiovisuales del entorno más o menos próximo que enriquezcan sus investigaciones al

aula. Si se potencia, además, con visitas a lugares culturales, encuentros con artistas y participación

activa en la vida cultural de la escuela y de la comunidad, el alumnado será estimulado para desarrollar

sus facultades críticas y estéticas.

El profesorado tiene un papel determinante para ayudar al alumnado a implicarse a nivel

personal en el proceso de creación audiovisual, a hacerlo consciente de la importancia de ser receptivo

a las propias sensaciones, impresiones, emociones y sentimientos, a integrar sus experiencias y

desarrollar sus necesidades físicas, cognitivas y sociales particulares. El profesorado deberá asumir,

cuando sea necesario, la función de facilitador en el fomento de la reflexión y el intercambio de ideas.

El diseño de situaciones de aprendizaje incluye una buena selección de piezas y fragmentos

audiovisuales por parte del docente. Este es un elemento fundamental del cual depende la posibilidad

no solo de trabajar con rigor y precisión sobre un objetivo limitado y manejable, sino de hacer fácilmente

accesible la lectura propuesta y contribuir así a la alfabetización mediática, es decir, al conocimiento

del lenguaje audiovisual tanto en lo referente a la comprensión como a la expresión.

El profesorado del Laboratorio de Creación Audiovisual tendría que hacer el papel de

“mediador cultural”, capaz de comunicar la pasión por las artes y de establecer vínculos entre el pasado

y el presente o entre las diferentes formas artísticas, mantenerse al día y compartir este conocimiento

con el alumnado y animarlos a interesarse por las obras artísticas y sus contextos históricos, y a

abordar los estímulos para la creación y la valoración con una mentalidad abierta.

Para diseñar situaciones significativas de aprendizaje habría que inspirarse en los intereses,

referentes culturales y otras materias del interés de los y las estudiantes y permitir establecer vínculos

con las amplias áreas de aprendizaje.

Las situaciones de aprendizaje tienen que ser adecuadas para una instrucción diferenciada y

permitir explorar una gama de experiencias tan amplia como sea posible.

Se tienen que incluir tareas que reflejen las capacidades del alumnado, que involucren todos

los aspectos de las competencias y movilicen recursos diversos, que dejen margen para determinar

los pasos de su propia progresión artística y que permitan seleccionar las estrategias adecuadas.

Las situaciones de aprendizaje tendrán sentido cuando despierten el interés y el compromiso

del alumnado, estimulen su pensamiento, le animen a tomar iniciativas en función de sus preferencias

y capacidades y le inviten a implicarse en el desarrollo concreto de proyectos o actividades artísticas

ricas y estimulantes.

Ya sea en situaciones de creación, interpretación o de apreciación, las y los estudiantes tienen

que experimentar las ventajas del trabajo en equipo. Considerar el grupo como primer público, además,

tendría que ayudarles a progresar en su trabajo creativo y su rendimiento. Su contacto con una visión

externa a la suya y su incursión en el universo creativo de otra persona les ayuda a explorar otras

maneras de expresarse mediante el audiovisual.

Las situaciones de aprendizaje de esta materia tienen que permitir vincularse especialmente a

las otras asignaturas de artes y expresión, fundamentalmente a la Educación Plástica, Visual y

Audiovisual, pero también a la Literatura, a la Música o a la Educación Física, especialmente vinculadas

en todos los momentos y aspectos de la creación y de la realización, y a todas las otras áreas

temáticas.

Tienen que fomentar la adquisición de actitudes esenciales para el desarrollo artístico, inducir

al uso de los recursos presentados como contenidos del programa, implicar referentes culturales y

fomentar las herramientas de reflexión.

Con el objetivo de atender la diversidad y las necesidades del alumnado, se incorporarán los

principios del diseño universal de aprendizaje, asegurándonos de que no hay barreras que impidan la

accesibilidad física, cognitiva, sensorial y emocional, para garantizar la participación y el aprendizaje.

Todas las actividades generadas en las situaciones de aprendizaje tienen que garantizar la

convivencia y los valores democráticos. Además, tienen que promocionar la participación activa en el

centro y fuera de él, dando a conocer el trabajo de aula desde una perspectiva sostenible y

contribuyendo a la consecución de los retos y desafíos del siglo XXI.

Finalmente, tienen que permitir al profesorado observar el desarrollo de las competencias del

alumnado mediante los criterios de evaluación.

6. Criterios de evaluación

6.1. CE1

Explorar propuestas audiovisuales diversas desde una perspectiva inclusiva y abierta,

analizando sus elementos formales y comunicativos básicos, y valorando la importancia de la

diversidad cultural.

CrEv1.1

Reconocer la función del lenguaje audiovisual como medio de expresión y comunicación

contemporáneo, observándolo en diferentes manifestaciones culturales y artísticas.

CrEv1.2

Analizar diferentes propuestas audiovisuales reconociendo sus características formales y

comunicativas a través de los códigos y formatos propios del lenguaje audiovisual.

CrEv1.3

Distinguir los aspectos éticos de las diferentes producciones audiovisuales apreciando

aquellas prácticas culturales que contemplan la diversidad y la inclusividad como valores

fundamentales.

CrEv1.4

Valorar la comunicación audiovisual como forma expresiva y estética y como referente cultural

e identitario reconociendo, a través de diferentes canales y medios, su presencia y su impacto social.

6.2. CE2

Elaborar propuestas audiovisuales experimentando con diferentes recursos, técnicas y

herramientas y aplicando los códigos básicos del lenguaje audiovisual en la transmisión de ideas,

sentimientos y emociones.

CrEv2.1

Utilizar los referentes audiovisuales percibidos como estímulo para las propias producciones,

incorporando sus características formales y comunicativas al propio repertorio de recursos expresivos.

CrEv2.2

Explorar formatos, técnicas y herramientas diversas de creación audiovisual desde el punto de

vista de la sostenibilidad y explicando la intencionalidad comunicativa de las diferentes propuestas.

CrEv2.3

Emplear recursos digitales básicos de producción audiovisual, adecuándose a los objetivos de

las diferentes propuestas y respetando la normativa vigente.

CrEv2.4

Crear propuestas audiovisuales sencillas transmitiendo diferentes ideas, sentimientos y

emociones, teniendo en cuenta el respeto a la diversidad y desde un punto de vista inclusivo e

innovador.

6.3. CE3

Participar de todas las fases del proceso de producción audiovisual colectivo, asumiendo

diferentes roles con autoexigencia y compromiso, aportando soluciones argumentadas a los distintos

retos y respetando e integrando las aportaciones del resto de participantes.

CrEv3.1

Planificar las fases de preproducción, producción y postproducción de propuestas

audiovisuales sencillas, individuales o colectivas, distribuyendo los roles de manera inclusiva.

CrEv3.2

Asumir diferentes roles de manera responsable, activa y participativa, de acuerdo con los

objetivos de las distintas funciones a desempeñar.

CrEv3.3

Evaluar el proceso de creación, expresando opiniones y aportando propuestas de mejora de

manera asertiva y constructiva.

6.4. CE4

Compartir las propuestas audiovisuales individuales y colectivas a través de diferentes canales

y medios, empleando la terminología propia del área y promoviendo la participación en la vida cultural

del centro educativo.

CrEv4.1

Difundir las producciones audiovisuales realizadas desde una perspectiva inclusiva y explorar

los diferentes medios y canales para adaptarlos a las características del proyecto y del usuario final.

CrEv4.2

Conocer la normativa vigente relativa a licencias de uso y a protección de la propiedad

intelectual aplicándola en la difusión de proyectos creativos propios.

CrEv4.3

Promover la creación de propuestas audiovisuales que afecten positivamente al contexto

educativo y fomentar la participación del alumnado en la vida cultural del centro.

CrEv4.4

Emplear adecuadamente la terminología específica del lenguaje audiovisual, tanto en la

apreciación de referentes como en el proceso de creación propio, utilizando un lenguaje inclusivo y

una actitud respetuosa y proactiva.
