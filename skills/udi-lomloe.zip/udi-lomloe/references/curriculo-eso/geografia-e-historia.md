# GEOGRAFÍA E HISTORIA

> Fuente: Secundaria.pdf, páginas 853-882 (versión en castellano).

GEOGRAFÍA E HISTORIA

1. Presentación

La vida en sociedad, la percepción y análisis crítico del mundo actual, complejo, plural y
cambiante, como consecuencia de la acción humana, social o individual, a través del tiempo y del
espacio, constituyen el objeto principal de los aprendizajes de Geografía e Historia. Esta materia,
basada en dos disciplinas de gran raigambre académica, continúa el desarrollo competencial de
Conocimiento del Medio Natural, Social y Cultural de Educación Primaria e implica, en esta etapa
educativa en la que el alumnado alcanza la adolescencia, una mayor participación progresiva en esa
sociedad, la conformación de su identidad individual y social, así como la preparación para el ejercicio
de la ciudadanía y la adquisición de los compromisos éticos que conlleva. Nuestro presente afronta
retos como garantizar la sostenibilidad del planeta, la globalización y el incremento de las
desigualdades, sobre los que los futuros ciudadanos han de ser conscientes para tomar decisiones
basadas en los conocimientos históricos y geográficos y el espíritu crítico.

El carácter integrador y comprensivo de la geografía y la historia, tanto entre ellas como
respecto a las demás ciencias sociales, les confiere la capacidad necesaria para contribuir a alcanzar
los objetivos y competencias establecidos en el perfil de salida del alumnado de la educación
obligatoria.

La integración de la geografía y la historia supone además la combinación de sus métodos,
instrumentos y estrategias de estudio en aras del desarrollo competencial, al movilizar destrezas como
la localización e identificación de información y de fuentes utilizando herramientas y recursos de índole
diversa, desde los digitales a los más tradicionales, el pensamiento crítico, la comparación y la
interrelación de hechos.

Ambas disciplinas resultan indispensables para poder afrontar los retos que las sociedades
actuales plantean respecto a la información. La sociedad de la hiperinformación somete al alumnado
a dos desafíos importantes: saber discernir qué información es esencial y cuál es anecdótica, y
encontrar información veraz frente a falsedades y tergiversaciones a las que cada vez está más
expuesto. La geografía y la historia aportan las herramientas necesarias para poder formar en
competencia informacional y asumir el reto con garantías de superación. Además, tanto la geografía
como la historia se interrelacionan intensamente con el resto de ciencias sociales y humanidades,
cuyos contenidos promueven a través de su presencia implícita en el currículo de Geografía e Historia,
como es el caso de la economía y la historia del arte.

La geografía, por su parte, aporta habilidades para el análisis y entendimiento del espacio y la
interacción que las sociedades humanas mantienen con el medio natural en el espacio físico mediante
el concepto de espacio geográfico. Contribuye, por tanto, a explicar las transformaciones desde un
punto de vista procesual, el de la interacción ser humano-medio natural, desde una perspectiva crítica
y de compromiso social enfocada hacia la detección de los desequilibrios territoriales y principales
problemas del mundo actual, buscando soluciones sostenibles, solidarias y justas.

La historia permite la comprensión de la evolución temporal de los grupos e individuos
humanos mediante la construcción de explicaciones causa-efecto, contribuyendo al entendimiento de
la diversidad y complejidad de la experiencia humana, forjada a través de procesos de cambio y de
continuidad.

En consecuencia, tanto la geografía como la historia hacen el presente más inteligible para el
alumnado, pues promueven su capacidad de empatizar con respecto a otras culturas, fomentando la
tolerancia hacia las diferencias y las actitudes de interés y respeto hacia otras identidades y

cosmovisiones. En definitiva, favorecen el enriquecimiento personal del alumnado a la vez que facilitan
su integración y participación social.

Por otro lado, ambas disciplinas, geografía e historia, han ido ligadas históricamente a unos
valores humanísticos que ahora cobran una mayor presencia específica tanto en el perfil de salida
como en las competencias específicas y en los contenidos básicos. Estos valores están relacionados
directamente con los desafíos y retos que afronta el mundo actual, plasmados en los Objetivos de
Desarrollo Sostenible: la cultura de la paz, la igualdad de derechos entre hombres y mujeres, la crítica
hacia las situaciones inicuas, la sostenibilidad medioambiental, la ciudadanía y convivencia
democrática y la valoración y preservación del patrimonio natural y cultural.

En síntesis, esta materia trata de cumplir una importante función cívica al armonizar las señas
de identidad del colectivo al que pertenece cada individuo con el entramado de culturas en el que se
ve inmerso el habitante de la aldea global. Por ello, en la medida en que muestra y permite entender
que ninguna identidad es eterna o impenetrable y que las construcciones humanas son perecederas,
su presencia en la formación del alumnado del siglo XXI es fundamental. Solamente así podrá entender
que el cambio, y no la inmutabilidad, es la esencia del devenir de la humanidad.

La materia de Geografía e Historia se estructura en los siguientes elementos curriculares:
nueve competencias específicas, con su descripción correspondiente; las conexiones principales de
estas competencias específicas entre sí, con las de otras materias de la etapa y con las competencias
clave; los saberes básicos, graduados en dos niveles correspondientes al final del segundo curso y del
cuarto curso de la etapa; las situaciones de aprendizaje; y, por último, los criterios de evaluación,
igualmente graduados en dos niveles.

2.
Competencias específicas Geografía e Historia

2.1. Competencia específica 1

CE 1. Describir y contextualizar en el tiempo y el espacio los acontecimientos y procesos más
relevantes de la historia propia y universal, identificando referentes de la evolución hacia la sociedad
actual y valorando su diversidad

2.1.1
Descripción competencia 1

Describir los hechos y procesos históricos más relevantes de forma razonada, ordenada y
coherente implica identificar, caracterizar y relatar los acontecimientos y procesos del pasado que, de
acuerdo con el consenso historiográfico, han tenido una mayor repercusión en el complejo y largo
acontecer hacia la conformación histórica de las sociedades, culturas, estructuras económicas y
sistemas políticos del presente, en una escala espacial que, en la Educación Secundaria Obligatoria,
se ampliará desde la local y regional hasta incluir también la estatal y mundial.

En su concreción más avanzada, estas construcciones textuales demandarán una
aproximación a las principales interpretaciones historiográficas actuales, así como el uso de
vocabulario y conceptos específicos de las ciencias sociales. El alumnado tendrá que conocer y ser
capaz de emplear los conceptos más básicos y fundamentales para la construcción de su propio relato
sobre los hechos y procesos históricos del pasado, siempre a partir de contenidos relativos a las
propuestas aportadas por los historiadores.

Así mismo, la comprensión significativa de los acontecimientos y cambios históricos requiere
de su correcta adscripción cronológica, tanto absoluta como relativa, respecto de otros hechos y
procesos históricos, y, también, de su ubicación en un determinado espacio geográfico para reconocer
su particularidad e integrarlos en un contexto concreto. Para esto, habrá que partir de la comprensión
del eje temporal de la historia universal y de la incorporación al mismo de los acontecimientos y

procesos más significativos, así como del reconocimiento de la vinculación de los diferentes procesos
históricos con un espacio geográfico determinado.

Paralelamente, la adquisición de referentes históricos factuales comportará la detección de la
distinta importancia otorgada a unos hechos sobre otros por parte de la historiografía en diferentes
momentos históricos, de acuerdo con los intereses de los actores sociales del pasado y del presente,
en el marco del proceso de construcción de un relato histórico particular que se deriva de una escala
de valores concreta.

Al final del segundo curso de la etapa, el alumnado reconocerá y asumirá que el conjunto de
los relatos históricos disponibles es el fruto de una selección de determinados hechos y de una
interpretación personal de quien escribe la historia a partir de las fuentes o restos del pasado.
Paralelamente, se familiarizará con los conceptos y vocabulario más básicos de la materia.

Al final del cuarto curso, el alumnado será capaz de desarrollar una visión crítica sobre el
diferente grado de relevancia que se ha otorgado en cada época a determinados hechos frente a otros
y se adquirirán nociones básicas de las interpretaciones historiográficas actuales de los principales
hechos y procesos históricos. Igualmente, el alumnado será capaz de emplear los conceptos y
vocabulario específicos de la materia en la redacción de sus propios textos sobre historia.

Esta competencia habilita al alumnado para la comprensión del origen y las características de
su contexto social y cultural, para el reconocimiento crítico de la propia identidad y para la valoración
de la diversidad y pluralidad social, cultural, económica y política de su entorno vital, en una sociedad
globalizada y compleja que ya no atiende a fronteras y que requiere de una base de saberes sociales
y culturales amplia, así como de actitudes abiertas y respetuosas con la diferencia.

2.2. Competencia específica 2

CE 2. Buscar, identificar y seleccionar la información referente a hechos históricos, geográficos
y artísticos a partir de diferentes fuentes documentales, realizando un tratamiento correcto en cuanto
a investigación, clasificación, recogida, organización, crítica y respeto

2.2.1.
Descripción competencia 2

Las ciencias sociales se nutren de una gran cantidad de fuentes documentales que aseguran
que sus conclusiones son producto de una investigación científica. Geógrafos e historiadores basan
sus aportaciones en el estudio de estos materiales. El alumnado debe conocer estas fuentes para
poder comprender que el trabajo de los investigadores sociales es fruto del método científico y que sus
conclusiones buscan siempre la veracidad. Desarrollar esta competencia es fundamental para
enfrentar un reto muy importante del siglo XXI: formar una ciudadanía interesada por la información y
crítica con las fuentes que la contienen. Conocer, usar e interpretar la información contribuirá a
acrecentar el sentido crítico del alumnado, imprescindible ante el avance extraordinario al que ha
llegado el mundo digital y las nuevas tecnologías. Este mundo permite el acceso inmediato a múltiples
fuentes de información, pero también exige el desarrollo de una competencia que facilite este acceso.

El alumnado será capaz de identificar recursos informativos y encontrará el camino para
acceder a ellos. Sabrá buscar y seleccionar fuentes de información, tanto digitales como no digitales,
entendiendo éstas con una mirada amplia que comprende desde las gráficas y los mapas de geografía,
hasta el texto histórico o filosófico, pasando por obras de arte, tanto de arquitectura como de pintura,
escultura, fotografía, cine o cómic. También incluye cualesquiera otros tipos de documentos que
puedan ofrecer información valiosa para las ciencias sociales como, por ejemplo, estadísticas, líneas
de tiempo, caricaturas, mapas conceptuales, presentaciones, infografías, canciones o novelas.

En definitiva, la identificación y distinción de estas fuentes ayudará al alumnado a diferenciarlas
entre primarias y secundarias, a obtener y evaluar la información necesaria para ampliar sus saberes

y fomentará la consulta de documentos sobre cuestiones históricas, geográficas y artísticas con una
postura crítica sobre la veracidad de sus informaciones.

Al final del segundo curso, el alumnado será capaz de identificar fuentes veraces, clasificarlas
según su tipo y extraer la información básica necesaria para poder elaborar sus trabajos de aula.

Al final del cuarto curso, el alumnado llevará a cabo un trabajo más complejo con las fuentes:
la crítica respecto a su origen, el contraste de la información que contienen y el respeto a su tratamiento
en cuanto a cuestiones de autoría; trabajo que le permitirá empezar a construir sus propias
conclusiones. Se espera que sea capaz de elaborar documentos que contengan las mismas y que
puedan ser expuestos ante el docente y los compañeros y compañeras de clase.

2.3. Competencia específica 3

CE 3- Explicar las nociones básicas de cambio y continuidad en la historia empleando una
perspectiva causal y contextualizada, reconociendo en el pasado el origen y evolución de las
cuestiones más relevantes del mundo actual y expresando juicios y opiniones sobre el presente y el
futuro

2.3.1.
Descripción competencia 3

La explicación lógica, racional y coherente de los procesos de cambio y continuidad ocurridos
en el pasado y en el presente exige el desarrollo de destrezas básicas del pensamiento histórico. En
primer lugar y como primera aproximación, es necesario que el alumnado desarrolle habilidades
cognitivas de explicación causal. Para esto, habrá que iniciarlo en el significado y diferenciación de los
conceptos históricos de causa y efecto, siempre atendiendo a la correlación cronológica y las
relaciones de prelación entre estos como forma de asegurar la correcta adscripción de los hechos
históricos a una de las dos categorías. Se continuará con la identificación de determinados hechos y
procesos relevantes del pasado como causas o efectos de otros con los cuales se relacionan, de forma
que el estudio de estas interacciones concretas permita la comprensión de la causalidad sobre el
proceso de la evolución histórica de las sociedades. Además, será fundamental la clasificación de
causas según su ámbito de acción (natural, social, político, económico, cultural), función (condiciones
necesarias, impulsos o desencadenantes), duración (en el corto, medio o largo plazo) e importancia
relativa sobre un mismo efecto.

En segundo lugar, para que el alumnado adquiera competencia en la correcta comprensión y
evaluación de las decisiones de los individuos y colectivos humanos del pasado y del presente, se
requiere adoptar una perspectiva contextualizada que tenga en cuenta que las personas actuaron en
entornos culturales y sociales muy diferentes y alejados en el tiempo y el espacio del nuestro, y
condicionadas por intereses, expectativas, creencias y prácticas sociales que actualmente nos resultan
ajenas. El reconocimiento y aceptación de las diferencias en las mentalidades y las circunstancias de
las personas favorecerán, en un principio, el desarrollo de actitudes de respeto e interés hacia la
diversidad cultural e ideológica de los grupos humanos y, posteriormente, una mejor comprensión de
la dinámica histórica.

En tercer lugar, resulta esencial detectar los cambios y las continuidades en las sociedades
del pasado. Para ello será necesario distinguir entre cambio y permanencia, así como reconocer la
posible coexistencia entre ritmo rápido y lento en el acontecer histórico. Además, esta competencia
podrá ser aplicada también a la dinámica del presente que el alumnado experimenta en su propia vida.

Al final del segundo curso de la etapa, esta competencia requerirá del alumnado la
diferenciación de los conceptos de causa y consecuencia, aplicados a hechos históricos de gran
relevancia y cronología bien definida a través de los cuales puedan apreciarse fácilmente las
interacciones de causalidad, así como la habilidad para reconocer diferentes tipos de causas según su
ámbito, función y relevancia. Igualmente, será capaz de comprender que las personas de otros tiempos

o lugares pueden haber actuado o actúan de acuerdo con motivaciones y patrones de conducta muy
distintos a los del contexto histórico y social propio, y habrá desarrollado actitudes de respeto y
tolerancia hacia otras culturas y cosmovisiones.

Al final de la etapa, el alumnado habrá logrado comprender y explicar que determinados
hechos históricos pueden ser al mismo tiempo causa y efecto de otros, en conexiones más complejas
que afectan a múltiples ámbitos de acción. Al mismo tiempo, será capaz de debatir sobre las causas y
contextos que motivaron las acciones humanas del pasado o de contextos alejados, así como de
formular juicios de valor sobre hechos del pasado y del presente desde el respeto y la tolerancia hacia
las diferencias culturales, y manifestar interés por conocerlas.

En resumen, esta competencia contribuye a la comprensión de las causas y estado actual de
las cuestiones del mundo contemporáneo y permite la identificación de la multiplicidad de factores que
explican las dinámicas de cambio social o el mantenimiento de las estructuras existentes, en varios
contextos del pasado y del presente. Habilita al alumnado para formar y debatir opiniones y juicios de
valor sobre problemas sociales y políticos, y lo capacita para intervenir responsablemente en su
entorno y para la comunicación, tolerancia y valoración mutua entre culturas distintas en el contexto
de una sociedad globalizada.

2.4. Competencia específica 4

CE 4. Contrastar las identidades individuales con las colectivas, identificando las aportaciones
decisivas en su construcción, reconociendo y valorando las actuaciones de tolerancia y respeto

2.4.1.
Descripción competencia 4

Esta competencia se vincula con el reto de promover la diversidad desde la comprensión de
la idiosincrasia del individuo y de los procesos de construcción de identidades colectivas.

El conocimiento de la diversidad personal y cultural implica, inicialmente, la capacidad de
reconocer los elementos constitutivos de la identidad cultural e histórica propia, así como de las que
están presentes en el entorno. A partir de ello, el alumnado desarrollará una perspectiva crítica y
comparada entre las identidades y sus procesos de construcción histórica, desde el entorno personal
y local hasta el más global. Para adquirir estas habilidades habrá que analizar diferentes ejemplos de
experiencias colectivas pasadas y presentes, y los procesos que han producido cambios identitarios,
tanto individuales como colectivos, a lo largo de la historia. Paralelamente, el alumnado aprenderá a
detectar los procesos identitarios construidos desde la tolerancia y a distinguirlos de los que se han
desarrollado desde la exclusión del otro para, en consecuencia, valorar, aceptar y defender las
actitudes personales y sociales implicadas en los primeros y, al mismo tiempo, rechazar las vinculadas
a los segundos.

Igualmente, esta competencia implica aprender a respetar, cooperar y convivir en sociedades
abiertas y cambiantes como son las actuales. Comporta, así mismo, el interés por conocer diferentes
culturas y aprender su lengua y sus costumbres para poder interactuar con sus miembros. Para ello,
se abordarán los principios fundamentales que permitan consolidar la convivencia, el respeto y la
solidaridad, desde una perspectiva histórica. Al mismo tiempo, habrá que propiciar que todo el
alumnado, como individuo y como miembro de una colectividad, se comprometa a ejercer la
convivencia ante situaciones de iniquidad y exclusión, y sea competente para proponer vías de
actuación justas y construir contextos de convivencia.

Al final del segundo curso, el alumnado será capaz de identificar y asociar los elementos
fundamentales de distintas identidades presentes en su entorno más inmediato y de desarrollar
actitudes de tolerancia. Al final del cuarto curso, desplegará capacidades críticas con respecto a la
construcción histórica de las identidades colectivas y a los distintos contextos de tolerancia o de

intolerancia asociados a cada proceso. Además, se espera que formule propuestas prácticas para
favorecer la convivencia en su propio entorno.

2.5. Competencia específica 5

CE 5. Explicar las interrelaciones económicas fundamentales entre los elementos del espacio
físico y las actividades de las sociedades humanas, así como su repercusión en la sostenibilidad

2.5.1.
Descripción competencia 5

El conocimiento del espacio geográfico, entendido como la porción del espacio físico donde se
desarrolla la vida y la actividad humana, se relaciona con la compleja interacción entre los grupos
humanos y el medioambiente. Esta competencia, por un lado, implica analizar la localización y
distribución de las actividades humanas, especialmente las económicas, y relacionarlas con la
sostenibilidad. En este sentido, los espacios global y local se han de considerar integrados para
comprender la degradación que sufre el planeta y el agotamiento de los recursos naturales, así como
adquirir conciencia de las causas que lo provocan. Por otro lado, esta competencia permite profundizar
en cómo las distintas sociedades y grupos humanos responden a los condicionantes que suponen los
diferentes factores físicos.

Al final del segundo curso, el alumnado ubicará las actividades económicas más relevantes en
el espacio geográfico, detectando los problemas territoriales y medioambientales más importantes
tanto a escala global como local. Además, se iniciará en la propuesta de soluciones a los problemas
locales detectados que afecten a su entorno más cercano.

Al terminar el cuarto curso, el alumnado será capaz de explicar las interrelaciones entre los
grupos y sociedades humanas y el medioambiente, asumiendo la irreversibilidad de la mayoría de los
cambios en el medio físico, los límites del crecimiento y del consumo en un planeta finito, así como la
relación entre el acceso a los recursos naturales y los conflictos. Asimismo, hará propuestas
argumentadas para afrontar los problemas anteriormente detectados con criterios de sostenibilidad.

En definitiva, esta competencia pretende entender la vida de los grupos humanos sobre la
superficie terrestre y sus principales condicionantes medioambientales. Se espera que el alumnado
conozca el espacio donde se desarrollan las sociedades, los recursos naturales disponibles y el uso
que se les ha dado, ya que esto aporta datos sobre el pasado y permite distinguir las causas de algunos
de los problemas actuales, superando visiones etnocéntricas.

2.6. Competencia específica 6

CE 6. Contrastar los principales modelos de ocupación territorial y de organización política y
económica que explican la desigualdad entre los seres humanos, tanto a escala local como global

2.6.1.
Descripción competencia 6

Esta competencia afronta los desafíos del siglo XXI y la consecución de los Objetivos de
Desarrollo Sostenible, específicamente los relacionados con los distintos modelos de ocupación
territorial y de organización política y económica. La forma en que los grupos y las sociedades humanas
ocupan y se asientan sobre el espacio geográfico tiene una relación muy estrecha con sus formas de
organización política y económica, las cuales, a su vez, condicionan al territorio. Estas formas de
ocupación pueden agruparse en una serie de modelos que facilitan su estudio y comparación. Estos
modelos territoriales, políticos y económicos comportan también enormes desigualdades
socioculturales, colocando al alumnado frente a realidades muy diferentes y, en ocasiones, similares a
la propia.

Algunos valores que interiorizará el alumnado con esta competencia son el respeto, la
cooperación y la convivencia con múltiples culturas en una sociedad abierta y cambiante. La

comparación de modelos de sociedades diferentes, muestra al alumnado que las desigualdades entre
los seres humanos son consecuencia de las propias acciones humanas, lo cual se refleja además en
una historia reciente dispar y en muchos casos conflictiva. Estas desigualdades, conflictos y tensiones
que se manifiestan en el territorio generan un acceso diferencial a los recursos.

El alumnado entenderá cómo han influido los cambios históricos en el devenir de la sociedad,
dando lugar a desigualdades de poder y jerarquías. En este sentido, se prestará atención a las
sociedades y colectivos más desfavorecidos por las entidades políticas y económicas hegemónicas.
Especialmente se atenderá el caso de las mujeres, silenciadas en contextos donde predomina la
presencia masculina. Esta competencia movilizará la capacidad crítica para profundizar en elementos
como la desigualdad de poder y las jerarquías, los roles femenino y masculino, fundamentales no solo
para entender un mundo pasado, sino para entender y gestionar el mundo actual. Se pretende lograr
un espíritu y una visión crítica sobre parámetros y relaciones socioeconómicas preestablecidas, con
implicaciones trascendentales en la historia pasada y actual.

Al final del segundo curso, el alumnado identificará y localizará los principales modelos de
organización política, económica y territorial. Además, explicará cómo inciden las distintas entidades
políticas y formas de organización económica en la vida cotidiana de las personas. También señalará
algunos de los principales problemas económicos y políticos, así como los agentes sociales que
intervienen a escala local, regional, estatal y supraestatal.

Al final del cuarto curso, el alumnado expondrá las desigualdades a diferente escala y explicará
de forma crítica cómo inciden las políticas de las diversas administraciones territoriales en relación a
las dinámicas de la globalización en la vida cotidiana de las personas, asumiendo derechos y
responsabilidades propios de la ciudadanía.

2.7. Competencia específica 7

CE 7. Dar argumentos desde una perspectiva crítica, fundamentada en conocimientos
históricos y geográficos acerca de problemas sociales relevantes, asumiendo valores democráticos y
pronunciándose en su defensa

2.7.1.
Descripción competencia 7

A través de esta competencia, se pretende que desde la perspectiva crítica que proporcionan
la geografía y la historia, el alumnado identifique y aborde los principales problemas sociales a los que
nos enfrentamos en la actualidad, y que valore así la oportunidad de intervenir en su resolución. Esta
competencia hará posible que el alumnado reconozca y denuncie problemas sociales que lo rodean
para tomar partido en su resolución. Contenidos concretos de la materia como, por ejemplo, la situación
de las mujeres en la historia y en las sociedades actuales, el funcionamiento del sistema democrático,
la situación de los derechos humanos, las desigualdades e injusticias o los focos de conflicto en el
mundo actual, pueden hacer al alumnado más consciente de la necesidad de comprometerse con la
sociedad. Además, le ayudarán a participar activamente en actividades colectivas tanto en el ámbito
escolar como en el social y desarrollará su pensamiento crítico.

Con esta competencia se espera que el alumnado logre cuatro objetivos: la identificación de
los problemas, la argumentación propia basada en saberes geográficos e históricos, interesarse por
su solución y proponer acciones concretas para conseguirlo.

Al final del segundo curso, el alumnado será capaz de identificar los problemas sociales más
relevantes de la actualidad. Problemas que constituyen los retos más importantes a los que nos
enfrentamos a comienzos del milenio: medioambiente, consumo, vida saludable, desigualdad y
conflictos. Tienen que ser capaces de establecer relaciones entre las acciones humanas y la aparición
de estos problemas, explicando las causas que provocan su existencia y mostrando interés por
solventarlos.

Al acabar el cuarto curso, el alumnado será capaz de justificar cómo las acciones que lleva a
cabo a nivel personal inciden directamente en los problemas sociales relevantes, ya que cualquier
cambio en nuestras acciones provoca la mejora o el empeoramiento de estos desafíos. Asimismo,
proporcionará argumentos propios, fundamentados en la historia y en la geografía, sobre los problemas
sociales más relevantes, reconociendo la incidencia que su resolución tendrá en la mejora las
condiciones de vida de las personas. Será capaz de proponer acciones en consonancia con estos
argumentos, teniendo en cuenta también los Objetivos de Desarrollo Sostenible.

2.8. Competencia específica 8

CE 8.  Promover y participar en proyectos cooperativos de convivencia, tomando como base
la construcción histórica de la Unión Europea, que favorezcan un entorno más justo y solidario
mediante la aplicación de valores y procedimientos democráticos

2.8.1.
Descripción competencia 8

Se trata de una competencia específica transversal y con un fuerte componente actitudinal,
que contribuye a la educación en valores y tiene mucho que ver con la adquisición de habilidades
sociales. Para empezar, la geografía y la historia facilitan la comprensión de las acciones humanas en
el tiempo y en el espacio, y favorecen la empatía y la solución de conflictos mediante el diálogo.
Además, la visión global del mundo que ambas disciplinas ofrecen permite la introducción de valores
que lleven al alumnado a adoptar una actitud ética y comprometida en la construcción de una sociedad
plural y justa.

Por otra parte, participar en proyectos cooperativos se relaciona directamente con la
movilización de habilidades sociales. De hecho, el trabajo en equipo comporta la interiorización de los
principios básicos de la convivencia y de diálogo de una sociedad democrática. Además, el alumnado
asumirá principios y valores inclusivos y de rechazo de las situaciones de desigualdad o exclusión.

El ejemplo de la construcción europea le sirve al alumnado como referente de un proyecto
cooperativo activo y propio, que ha favorecido un entorno más seguro y solidario a través de valores y
procedimientos democráticos. Las características básicas económicas, políticas, culturales, sociales y
artísticas que definen la identidad europea se interrelacionan e influyen en la identidad individual de
cada uno de sus ciudadanos.

Esta competencia ya está presente en la Educación Primaria y su desarrollo prosigue en la
Educación Secundaria Obligatoria, en la que el alumnado interiorizará la empatía, la responsabilidad y
la asunción de los principios democráticos para la resolución de los conflictos.

Al final del segundo curso, el alumnado será capaz de denunciar las situaciones injustas y de
exclusión, aplicando los principios democráticos y el diálogo, comparándolos con los que han estado
presentes en la historia de Europa.

Al final del cuarto curso, el alumnado tendrá la capacidad de participar en proyectos colectivos,
asumiendo diversos roles con eficacia y responsabilidad, denunciando las situaciones injustas o de
exclusión en relación con el proceso de construcción histórica de la Unión Europea.

2.9. Competencia específica 9

CE 9. Identificar el origen y reconocer el valor del patrimonio cultural y natural, especialmente
de sus elementos geográficos, históricos y artísticos, tanto a escala local como a escala global,
participando en la elaboración y difusión de propuestas que favorezcan su preservación y puesta en
valor

2.9.1.
Descripción competencia 9

El patrimonio, cultural y natural, en tanto que legado del pasado transmitido de generación en
generación, constituye un bien social común que nos identifica como sociedad en un mundo
globalizado. Esta competencia aproxima al alumnado al descubrimiento del patrimonio en toda su
riqueza y diversidad, geográfica, histórica y artística, e impulsa su preservación para las generaciones
futuras.

Esta competencia promueve la curiosidad por la investigación acerca del origen y la creación
de los diferentes elementos patrimoniales, tanto en las calles de pueblos y ciudades como en las
entidades museísticas encargadas de su conservación y los paisajes que los rodean. Por esta razón,
también contribuye al disfrute y valoración del patrimonio y moviliza la capacidad de emocionarse,
reconociendo que las propias acciones pueden tener consecuencias sobre este en el entorno
inmediato. Esta valoración del patrimonio promoverá el interés por otras culturas, facilitando así la
interacción con ellas. Al mismo tiempo, fomentará el aprecio por la diversidad patrimonial mundial
desde una actitud más tolerante con sociedades diferentes a la propia.

Con esta competencia se aborda cualquier tipo de elemento patrimonial, tanto el más
reconocido como el que pasa más desapercibido. Es importante que el alumnado conozca el primero,
pero también que entienda que el patrimonio más próximo necesita igualmente de nuestro aprecio y
nuestro compromiso. Una catedral o una escultura famosa forman parte del patrimonio como
manifestaciones artísticas más reconocidas. Sin embargo, es también importante transmitir que el
patrimonio está formado por manifestaciones menos reconocidas como pueden ser los paisajes de los
parques naturales, elementos industriales como los molinos o manifestaciones culturales como las
fiestas. Estos elementos son también parte fundamental de todo ese conjunto patrimonial que
representa cada una de las escalas administrativas y físicas en las que vive el alumnado: municipios,
comarcas, comunidades, países y continentes tienen parte de ese patrimonio que estamos obligados
a estudiar, preservar y poner en valor.

Al final del segundo curso, se espera que el alumnado sea competente en la identificación de
elementos patrimoniales, especialmente geográficos, históricos y artísticos, tanto a escala global como
local. Además, elaborará trabajos de síntesis sobre el patrimonio más cercano, que reconozcan su
variedad e importancia como elemento identitario.

Al final del cuarto curso, el alumnado será capaz de identificar las características de los
elementos patrimoniales, relacionándolas con estilos artísticos, época histórica y entorno geográfico.
Así mismo, podrá elaborar y exponer propuestas argumentadas y basadas en los contenidos de la
materia que contribuyan a la preservación del patrimonio y su puesta en valor, reconociéndolo como
bien social.

3. Conexiones de las competencias específicas

3.1
Relaciones o conexiones con las otras CE de la materia

3.1.1. Conexiones competencia específica 1

Se relaciona con la CE 2, relativa al correcto tratamiento de las fuentes documentales y
necesaria para la obtención de información fiable sobre los acontecimientos y procesos más relevantes
de la historia. Por otro lado, se relaciona con la CE 4, puesto que el conocimiento de los hechos del
pasado aporta los referentes factuales para identificar las aportaciones a la construcción de los sujetos
históricos y las identidades colectivas, así como con la CE 9, en cuanto su relación con el contexto
para entender el origen de los elementos patrimoniales y apreciar su valor y el de la diversidad cultural
en la que tienen su origen.

3.1.2. Conexiones competencia específica 2

Cabe destacar su relación con la CE 5 referente al uso de fuentes cartográficas, históricas y
estadísticas que ayudan a indagar y explicar las relaciones entre el medio físico y las actividades
humanas. También se relaciona con la CE 9, favoreciendo que el alumnado sea capaz de trabajar con
elementos geográficos, históricos y artísticos y los considere como fuentes de saber.

3.1.3. Conexiones competencia específica 3

Es destacable su conexión con la CE 1, puesto que los acontecimientos y procesos más
relevantes conforman la materia histórica a partir de la cual se formulan las explicaciones que permiten
comprender la evolución de las sociedades, sus cambios y continuidades hasta llegar a la comprensión
del presente. Es también muy clara la relación con la CE 2 por la necesidad de identificar y explicar
ideas contenidas en fuentes documentales para formar su propio criterio. Esta competencia se
relaciona igualmente con la CE 6 por desarrollar la capacidad para evaluar los diferentes modelos de
organización política, económica y territorial del presente. Por último, se relaciona con la CE 7, por su
análisis de situaciones históricas de cambio y continuidad en diferentes contextos, al aportar referentes
históricos que movilizarán habilidades para formar un criterio propio respecto a los problemas sociales
más relevantes y plantear propuestas de crítica constructiva y de mejora en un sentido más justo,
integrador y equitativo, bien en su entorno más inmediato o bien en la sociedad global.

3.1.4. Conexiones competencia específica 4

Se conecta con la CE 1 y con la CE 3, puesto que ambas pueden aportar información necesaria
para identificar el origen y las causas de la diversidad cultural e identitaria de las personas y sociedades
del presente. También enlaza con la CE 2, ya que fomenta un tratamiento correcto de las fuentes de
información a las que se recurra, y con la CE 8, en la medida en que favorece la empatía y la
comprensión entre las legítimas diferencias culturales e identitarias que conviven en el entorno del
alumnado y en toda la sociedad. Por último, también se relaciona con la CE 9, ya que el conocimiento
y aprecio de otras identidades y tradiciones culturales contribuyen al desarrollo de actitudes de
reconocimiento y respeto por las diferentes manifestaciones del patrimonio cultural.

3.1.5. Conexiones competencia específica 5

Se relaciona con la CE 2, puesto que el uso y contraste de diferentes fuentes documentales
para conseguir información es imprescindible para poder explicar las interrelaciones entre los
elementos del espacio geográfico. Igualmente, está relacionada con la CE 6 porque, para explicar las
interrelaciones entre los elementos del espacio geográfico, hay que comparar diferentes modelos de
organización política, económica y territorial, identificando distintas actividades humanas en un
determinado territorio.

3.1.6. Conexiones competencia específica 6

Enlaza con la CE 3, puesto que para comparar diferentes modelos de organización política,
económica y territorial hay que entender, previamente, los cambios y continuidades que han sufrido en
la historia. Igualmente, entronca con la CE 5, ya que para explicar las interrelaciones entre los
elementos espaciales se han de conocer cuáles son las actividades humanas en un determinado
territorio.

3.1.7. Conexiones competencia específica 7

Se relaciona con la CE 1, facilitando en el alumnado la tarea de explicar los procesos y los
cambios operados en los problemas que estamos estudiando, el reconocimiento de causas que los
explican y la expresión de opiniones y juicios sobre las cuestiones sociales del mundo actual. Además,
se vincula con la CE 3 porque ayuda al alumnado a entender que los problemas sociales actuales
tienen causas que explican su aparición y sobre las que podemos actuar.

3.1.8. Conexiones competencia específica 8

Contribuye a desarrollar la CE 4, dado que, para mejorar la convivencia y favorecer un entorno
más justo y solidario, hay que ensalzar las actuaciones de tolerancia y respeto que existen en la
actualidad y han existido a lo largo del tiempo. Igualmente, se relaciona con la CE 3, al favorecer el
planteamiento de juicios y opiniones fundadas en el reconocimiento del progreso de las sociedades
humanas.

3.1.9. Conexiones competencia específica 9

Entronca con la CE 1, dado que el alumnado desarrollará esta competencia investigando
hechos históricos necesarios para poder interpretar los elementos patrimoniales con los que interactúa.
Igualmente, podemos relacionar esta competencia con la CE 3, dado que ayuda al alumnado a conocer
circunstancias históricas que se relacionan con los bienes con los que está trabajando y que
contribuyen a explicar su configuración.

3.2
Relaciones o conexiones con las CE de otras áreas/materias de la etapa

La materia Geografía e Historia, por su carácter explicativo del mundo social y cultural,
mantiene múltiples conexiones o relaciones con otras materias del currículo, especialmente con las
pertenecientes a su ámbito de ciencias sociales y humanidades, como Valores Éticos y Cultura Clásica,
pero también con las de los ámbitos lingüístico (Valenciano: lengua y literatura y Lengua castellana y
literatura), artístico-expresivo (Educación Plástica Visual y Audiovisual), y de las Ciencias Naturales
(Biología y Geología).

Las competencias de Geografía e Historia centradas en la interacción social respetuosa y
tolerante (CE 4), la interacción sostenible con el medioambiente (CE 5), la argumentación crítica acerca
de problemas sociales y la promoción de la convivencia democrática (CE 7), la justicia y la solidaridad
(CE 8), se relacionan con las competencias específicas de la materia Valores éticos, que ponen el foco
en la gestión de las emociones desde la cultura de la paz (CE 2), el diálogo y debate (CE 1), el
compromiso con la sostenibilidad del planeta (CE 7), la lucha contra la desigualdad y la injusticia (la
CE 6) y los valores democráticos (CE 5).

Respecto a las competencias de Geografía e Historia cuyo foco es la contextualización de
hechos y procesos históricos (CE 1), la búsqueda y crítica de fuentes históricas, geográficas y artísticas
(CE 2), la explicación del origen y evolución del mundo actual (CE 3), las bases históricas de la
construcción de Europa (CE 7) y la valorización del patrimonio cultural (CE 9) se vinculan a las
competencias específicas de la materia Cultura Clásica que subrayan las raíces culturales grecolatinas
de Europa (CE 1), así como su influencia histórica en la configuración sociopolítica europea (CE 2) y
el patrimonio cultural legado por el mundo grecolatino (la CE4).

La conexión entre las competencias específicas de Geografía e Historia y las de Valenciano:
lengua y literatura y Lengua castellana y literatura es total, dado el carácter instrumental de la lengua
y la dimensión social y comunicativa de la primera. Las competencias específicas de esta materia se
refieren, por una parte, a las destrezas lingüísticas básicas, tales como la comprensión oral (CE 2),
comprensión escrita (CE 3), expresión oral (CE 4), la expresión escrita (CE 5). Por otra parte, también
se centran en la lectura (CE 8) y en la lectura y producción de textos literarios contextualizados, así
como en los procesos bidireccionales de la interacción (CE 6) y la mediación (CE 7) que se dan en la
comunicación.

Las competencias de Geografía e Historia que tienen que ver con la contextualización de
hechos y procesos históricos (CE 1), la búsqueda y crítica de fuentes históricas, geográficas y artísticas
(CE 2),  la interacción social respetuosa y tolerante (CE 4) y la promoción de la convivencia
democrática, la justicia y la solidaridad (CE 8) y la valorización del patrimonio cultural (CE 9) se
conectan con las competencias específicas de la materia Educación Plástica Visual y Audiovisual

(EPVA) que analizan diferentes propuestas artísticas y sus contextos socioculturales y el patrimonio
(CE 1), desarrollan una identidad crítica (CE 5) e impulsan la aplicación de conocimientos adquiridos
a producciones artísticas colectivas (CE 6).

Las competencias de la Geografía e Historia relativas a la búsqueda e identificación de fuentes
de información fiables (CE 2), la explicación del origen y evolución del mundo actual (CE 3), el contraste
de identidades personales y colectivas y favorecer actitudes de respeto y tolerancia (CE 4), la
interacción sostenible de los grupos humanos con el medioambiente (CE 5), los modelos de ocupación
territorial (CE 6) y el compromiso con la sostenibilidad del planeta (CE 7)  se relacionan con las
competencias específicas de la materia Biología y Geología que tienen que ver con el análisis de
situaciones problemáticas reales (CE 2), el acceso a fuentes fiables y la utilización crítica del
conocimiento científico (CE 3), el respeto a la variedad de identidades de género (CE 6), la participación
activa en la conservación de las formas de vida y del planeta (CE 7), la prevención de riesgos naturales
sobre las poblaciones (CE8), la adopción de hábitos responsables con el medioambiente (C 10) y la
proposición de soluciones a problemas ecosociales (C 11).

Igualmente, las competencias de Geografía e Historia que tienen que ver con la
contextualización de hechos y procesos históricos (CE 1) y la búsqueda e identificación de fuentes de
información fiables (CE 2) se vinculan con las competencias de Física y Química relacionadas con la
influencia del contexto social e histórico en la construcción del modelo de ciencia (CE 4) y con la
utilización crítica del conocimiento científico y de fuentes fiables (CE 3).

Por último, las materias con las que las conexiones son menos numerosas. Así, la competencia
de Geografía e Historia centrada en la contextualización de hechos y procesos históricos (CE 1) se
conecta con la competencia específica de la materia Música relacionada con el análisis de propuestas
musicales y corporales de diferentes épocas (CE1). La competencia que pone el foco en la valoración
del patrimonio cultural y natural (CE 9) se relaciona con la competencia específica de la materia
Educación Física referida a la interacción físico-expresiva y artística con el patrimonio cultural y natural
(CE 4). La competencia específica referida a la búsqueda e identificación de fuentes de información
fiables (CE 2) enlaza con las competencias específicas relativas a la búsqueda y análisis de
información de la materia Digitalización (CE 2).

3.3
Relaciones o conexiones con las competencias clave

|  |  | CCL |  | CP |  | STEM |  | CD |  | CPSAA |  | CC |  | CE |  | CCEC |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 |  | X |  |  |  |  |  |  |  | X |  | X |  |  |  | X |  |
| CE2 |  | X |  |  |  |  |  | X |  | X |  |  |  |  |  |  |  |
| CE3 |  | X |  |  |  |  |  |  |  |  |  | X |  |  |  |  |  |
| CE4 |  | X |  |  |  |  |  |  |  |  |  | X |  |  |  | X |  |
| CE5 |  |  |  |  |  | X |  |  |  | X |  | X |  |  |  | X |  |
| CE6 |  | X |  |  |  |  |  |  |  | X |  | X |  |  |  | X |  |
| CE7 |  |  |  |  |  |  |  |  |  |  |  | X |  | X |  |  |  |
| CE8 |  |  |  |  |  |  |  |  |  |  |  | X |  |  |  | X |  |
| CE9 |  |  |  |  |  |  |  |  |  |  |  | X |  |  |  | X |  |

Las competencias específicas de Geografía e Historia, materia centrada en la evolución
temporal y espacial de los grupos humanos, mantienen relaciones especialmente relevantes con las
competencias clave más vinculadas a la esfera social. Así, casi todas las competencias específicas de
la materia (salvo la CE 2) están conectadas con la competencia ciudadana. 6 de 9 (CE 1, CE 4, CE 5,
CE 6, CE 8, CE 9) se relacionan con la competencia en conciencia y expresión cultural. 5 de 9 (CE 1,
CE 2, CE 3, CE 4, CE 6) conectan con la competencia en comunicación lingüística. 4 de 9 (CE 1, CE2,
CE 5, CE 6) con la Competencia Personal, Social y de Aprender a Aprender. Una competencia

específica (CE 5) se vincula a la competencia matemática y en ciencia, tecnología e ingeniería, igual
número que a la competencia emprendedora (CE 7) y a la competencia digital (CE 2).

Competencias clave del perfil de salida del alumnado:

•
CCL: competencia en comunicación lingüística

•
CP: competencia plurilingüe

•
STEM: competencia matemática y en ciencia, tecnología e ingeniería

•
CD: competencia digital

•
CPSAA: competencia personal, social y de aprender a aprender

•
CC: competencia ciudadana

•
CE: competencia emprendedora

•
CCEC: competencia en conciencia y expresión cultural

4. Saberes básicos

4.1
Introducción

La geografía y la historia aportan conocimiento sobre la evolución en el tiempo y en el espacio
de las sociedades humanas.  Hay que tener en cuenta que las competencias específicas de la materia
tratan del origen y comprensión de las grandes cuestiones sociales, políticas, económicas y
medioambientales del mundo actual, la búsqueda y tratamiento de la información en ciencias sociales
y humanidades, el compromiso cívico y ético con la democracia y los valores de la convivencia, la
inclusión y el respeto a la diferencia y, por último, el patrimonio cultural y natural. En ese sentido, se
ha considerado que, para que el alumnado adquiera y desarrolle las competencias, la selección de los
saberes básicos debía realizarse conforme a unos criterios adecuados a dicha finalidad.

Así pues, el criterio fundamental ha sido seleccionar estos saberes en función de su capacidad
de favorecer la comprensión del origen y configuración del mundo social y cultural actual. En este
sentido, se ha priorizado la selección de saberes que refieren a procesos de relevancia más que a
hechos puntuales, tratados desde un enfoque multicausal que profundiza en sus dimensiones política,
económica, social y cultural. Conviene destacar la importancia otorgada en la selección a los saberes
que presentan también una dimensión relevante de naturaleza procedimental, actitudinal o axiológica,
aunque su carácter sea predominantemente conceptual.  Así mismo, se ha priorizado, como criterio
complementario, la elección de saberes que ponen de manifiesto conexiones relevantes entre la escala
local y la global, con el fin de favorecer la significatividad de los aprendizajes. Del mismo modo, se ha
dado prioridad a saberes próximos a la realidad social y cultural del alumnado, así como a los que
fomentan el espíritu crítico, el compromiso ético y permiten afrontar los desafíos del siglo XXI y el
desarrollo cívico desde una perspectiva cosmopolita.

Los saberes básicos se presentan organizados en cuatro bloques. Los tres primeros son de
corte disciplinar e incluyen saberes factuales, conceptuales y procedimentales, mientras que el cuarto
bloque contiene fundamentalmente saberes de carácter actitudinal y axiológico, transversales a los
tres bloques anteriores. En lo que concierne a la secuenciación, los saberes de historia e historia del
arte se ordenan desde los más antiguos a los más recientes, y los saberes geográficos en torno al
medio físico y su aprovechamiento y ocupación por las sociedades humanas. En los cuatro bloques,
la propuesta consiste en avanzar desde lo más sencillo y global a lo más complejo y detallado.

4.2
Bloque 1: Geografía

| SUB-BLOQUE DE MÉTODOS Y TÉCNICAS DE GEOGRAFÍA CE2, CE5 | 1er y 2º cursos | 3er y 4º cursos |
| --- | --- | --- |
| • Metodologías de trabajo y vocabulario específico de la | X | X |
| Geografía. |  |  |
| • Identificación y contraste de fuentes de la Geografía. |  | X |
| Técnicas de análisis e interpretación. |  |  |
| • La representación geográfica del espacio terrestre. | X | X |
| Orientación y escalas. Interpretación y elaboración de |  |  |
| mapas, imágenes y representaciones gráficas. |  |  |
| • Técnicas básicas de búsqueda y tratamiento de la | X | X |
| información geográfica mediante las TIC. |  |  |

| SUB-BLOQUE DE FUNDAMENTOS DE LA GEOGRAFÍA FÍSICA CE2, CE5, CE9 | 1er y 2º cursos |  | 3er y 4º cursos |  |
| --- | --- | --- | --- | --- |
| • Los movimientos de la Tierra y sus efectos (rotación y traslación) | X |  |  |  |
| • Formas constitutivas del relieve. | X |  |  |  |
| • Principales unidades de relieve y de la red hídrica de la Tierra. | X |  |  |  |
| • Zonas climáticas y paisajes geográficos de la Tierra. | X |  |  |  |
| • Paisajes geográficos de España y de la Comunidad Valenciana. | X |  |  |  |

| SUB-BLOQUE DE GEOGRAFÍA DEL POBLAMIENTO Y DE LA POBLACIÓN CE2, CE5, CE6, CE7 |  | 1er y 2º cursos |  | 3er y 4º cursos |  |
| --- | --- | --- | --- | --- | --- |
| Poblamiento |  |  |  |  |  |
| • Espacio urbano y rural en el mundo actual. |  | X |  |  |  |
| • El espacio urbano en España y en la Comunidad |  | X |  |  |  |
| Valenciana. |  |  |  |  |  |
| • Distribución de la población mundial. Áreas de |  |  |  | X |  |
| concentración y despoblación. |  |  |  |  |  |
| • Las grandes áreas culturales del planeta. La diversidad |  | X |  |  |  |
| cultural de los grupos humanos. Convivencia e |  |  |  |  |  |
| interculturalidad en un mundo globalizado. |  |  |  |  |  |
| Población |  |  |  |  |  |
| • Crecimiento poblacional y movimientos migratorios. |  |  |  | X |  |
| Estructura por edades de la población. Regímenes |  |  |  |  |  |
| demográficos. |  |  |  |  |  |
| • La población española. Evolución y distribución. |  |  |  | X |  |
| Contrastes regionales. La población de la Comunitat |  |  |  |  |  |
| Valenciana. |  |  |  |  |  |

| SUB-BLOQUE DE GEOGRAFÍA POLÍTICA CE2, CE4, CE6, CE8 |  | 1er y 2º cursos | 3er y 4º cursos |
| --- | --- | --- | --- |
| • Geografía política de las sociedades. El Estado-nación |  |  | X |
| como entidad político-territorial. Estructura política del |  |  |  |
| Estado español. |  |  |  |
| • Integración económica, monetaria y ciudadana. El Estado |  |  | X |
| del Bienestar en Europa y las instituciones europeas. |  |  |  |
| • Las formas de organización política. Democracia frente a |  |  | X |
| autoritarismo. |  |  |  |

| SUB-BLOQUE DE GEOGRAFÍA ECONÓMICA CE2, CE4, CE5, CE6, CE8 |  | 1er y 2º cursos |  | 3er y 4º cursos |  |
| --- | --- | --- | --- | --- | --- |
| Interacción económica con el medioambiente |  |  |  |  |  |
| • El aprovechamiento económico del medio físico: Los |  | X |  |  |  |
| principales recursos naturales del planeta. |  |  |  |  |  |
| • Las áreas mundiales de actividad económica más |  | X |  |  |  |
| importantes. |  |  |  |  |  |
| • Los paisajes del sector primario en el mundo rural. |  |  |  | X |  |
| • El sector secundario y el espacio industrial. Recursos |  |  |  | X |  |
| energéticos y aprovechamiento de la energía. |  |  |  |  |  |
| • El sector terciario y el avance de la terciarización. Redes |  |  |  | X |  |
| de transporte y comunicación y espacios turísticos. |  |  |  |  |  |
| Repercusiones de las actividades económicas |  |  |  |  |  |
| • Sostenibilidad y repercusiones medioambientales de las |  | X |  | X |  |
| actividades económicas. |  |  |  |  |  |
| • Los sistemas económicos. Economías de mercado y |  |  |  | X |  |
| economías centralizadas. |  |  |  |  |  |
| • El reparto desigual de la riqueza mundial. Globalización y |  | X |  | X |  |
| dependencia. El Índice de Desarrollo Humano (IDH) y los |  |  |  |  |  |
| Objetivos de Desarrollo Sostenible (ODS). |  |  |  |  |  |

4.3
Bloque 2: Historia

| SUB-BLOQUE DE MÉTODOS Y TÉCNICAS DE HISTORIA CE1, CE2 |  | 1er y 2º cursos | 3er y 4º cursos |
| --- | --- | --- | --- |
| • Metodologías de trabajo y vocabulario específico |  | X | X |
| historiográfico. |  |  |  |
| • Identificación y contraste de fuentes de la Historia. |  |  | X |
| Técnicas de análisis e interpretación historiográfica. |  |  |  |
| • Ubicación espacial y temporal de los hechos históricos. El |  | X | X |
| cómputo actual del tiempo histórico en la historiografía. |  |  |  |
| Cronología y periodización. |  |  |  |
| • Técnicas básicas de búsqueda y tratamiento de la |  | X | X |
| información histórica mediante las TIC. |  |  |  |

| SUB-BLOQUE DE PREHISTORIA Y PRIMERAS CIVILIZACIONES CE1, CE2, CE3, CE4, CE9 |  | 1er y 2º cursos | 3er y 4º cursos |
| --- | --- | --- | --- |
| • Origen del ser humano y proceso de hominización. Los |  | X |  |
| primeros grupos humanos cazadores-recolectores en la |  |  |  |
| Prehistoria. |  |  |  |
| • Las sociedades prehistóricas productoras de alimentos. El |  | X |  |
| Neolítico y la Edad de los Metales. |  |  |  |
| • Las primeras civilizaciones agrarias. Condicionantes |  | X |  |
| geográficos e interpretaciones históricas. |  |  |  |

| SUB-BLOQUE DE ANTIGÜEDAD CLÁSICA, GRECIA Y ROMA CE1, CE2, CE3, CE4, CE9 |  | 1er y 2º cursos |  | 3er y 4º cursos |  |
| --- | --- | --- | --- | --- | --- |
| Grecia |  |  |  |  |  |
| • La Grecia clásica: la polis. La democracia ateniense. |  | X |  |  |  |
| • La expansión colonial de Grecia en el Mediterráneo. La |  | X |  |  |  |
| extensión del Helenismo. |  |  |  |  |  |

| Roma |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| • Roma, evolución política y factores de su expansión por el |  | X |  |  |  |
| Mediterráneo. |  |  |  |  |  |
| • El proceso de romanización. |  | X |  |  |  |
| • Surgimiento y extensión del cristianismo. |  | X |  |  |  |

| SUB-BLOQUE DE EDAD MEDIA CE1, CE2, CE3, CE4, CE9 |  | 1er y 2º cursos |  | 3er y 4º cursos |  |
| --- | --- | --- | --- | --- | --- |
| • Crisis y desaparición del Imperio romano. |  | X |  |  |  |
| • Los pueblos germánicos y el inicio de la Edad Media. |  | X |  |  |  |
| • Surgimiento y expansión del islam. |  | X |  |  |  |
| • El feudalismo en Europa entre los siglos XI y XII: política, |  | X |  |  |  |
| sociedad y economía. |  |  |  |  |  |
| • El renacer de las ciudades en Europa entre los siglos XIII |  | X |  |  |  |
| y XV: política, sociedad y economía. |  |  |  |  |  |
| • Al-Ándalus: política, sociedad y economía. La vida |  | X |  |  |  |
| cotidiana en las ciudades musulmanas. |  |  |  |  |  |
| • Los reinos cristianos peninsulares durante la Edad Media: |  | X |  |  |  |
| panorámica general y evolución territorial. La vida |  |  |  |  |  |
| cotidiana en las ciudades cristianas. El Reino de Valencia. |  |  |  |  |  |
| • Las personas invisibilizadas en la historia: mujeres, |  | X |  |  |  |
| esclavos y extranjeros. Las mujeres en la prehistoria, la |  |  |  |  |  |
| historia antigua y medieval. |  |  |  |  |  |

| SUB-BLOQUE DE HISTORIA MODERNA CE1, CE2, CE3, CE4, CE9 |  | 1er y 2º cursos | 3er y 4º cursos |
| --- | --- | --- | --- |
| • Renacimiento. Humanismo y crisis religiosa. Reforma y |  |  | X |
| Contrarreforma. El fortalecimiento del poder monárquico |  |  |  |
| en Europa. |  |  |  |
| • La expansión mundial europea. La colonización de |  |  | X |
| América. |  |  |  |
| • La revolución científica. El siglo de las Luces: absolutismo |  |  | X |
| monárquico e Ilustración. |  |  |  |
| • Crisis del Antiguo Régimen. La Revolución Francesa, |  |  | X |
| otras revoluciones liberales y sus repercusiones. |  |  |  |

| SUB-BLOQUE DE HISTORIA CONTEMPORÁNEA CE1, CE2, CE3, CE4, CE9 |  | 1er y 2º cursos |  | 3er y 4º cursos |  |
| --- | --- | --- | --- | --- | --- |
| El siglo XIX |  |  |  |  |  |
| • Revolución industrial e industrialización: cambios |  |  |  | X |  |
| socioeconómicos en Europa a inicios del siglo XIX. |  |  |  |  |  |
| • Liberalismo y nacionalismo. Revoluciones y nuevos |  |  |  | X |  |
| estados nacionales en la Europa del siglo XIX. |  |  |  |  |  |
| • La segunda Revolución industrial. El Imperialismo colonial. |  |  |  | X |  |
| • La construcción y consolidación del Estado liberal en |  |  |  | X |  |
| España. Sociedad y economía de la España del siglo XIX. |  |  |  |  |  |
| El siglo XX |  |  |  |  |  |
| • La crisis de la Restauración en España, la dictadura y la II |  |  |  | X |  |
| República. |  |  |  |  |  |
| • Causas y consecuencias de la Primera Guerra Mundial. La |  |  |  | X |  |
| Revolución rusa. |  |  |  |  |  |
| • La Europa de Entreguerras y la crisis del 29. Causas y |  |  |  | X |  |
| consecuencias de la Segunda Guerra mundial. El |  |  |  |  |  |
| Holocausto. |  |  |  |  |  |

| SUB-BLOQUE DE HISTORIA CONTEMPORÁNEA CE1, CE2, CE3, CE4, CE9 |  | 1er y 2º cursos |  | 3er y 4º cursos |  |
| --- | --- | --- | --- | --- | --- |
| • El mundo tras la Segunda Guerra Mundial: La “Guerra |  |  |  | X |  |
| Fría” y la descolonización de Asia y África. |  |  |  |  |  |
| • El proceso histórico de construcción de la Unión Europea. |  |  |  | X |  |
| • La Guerra Civil y la dictadura franquista. |  |  |  | X |  |
| • La Transición. La España de la democracia. La memoria |  |  |  | X |  |
| democrática. |  |  |  |  |  |
| • El movimiento feminista: las cuatro olas de la lucha por la |  |  |  | X |  |
| igualdad de género. Mujeres de la historia moderna y |  |  |  |  |  |
| contemporánea. |  |  |  |  |  |
| • El mundo tras la caída del muro de Berlín. El siglo XXI |  |  |  | X |  |

4.4
Bloque 3: Historia del Arte

| SUB-BLOQUE DE MÉTODOS Y TÉCNICAS DE LA HISTORIA DEL ARTE CE1, CE2, CE3, CE9 |  | 1er y 2º cursos | 3er y 4º cursos |
| --- | --- | --- | --- |
| • Metodologías de trabajo y vocabulario de la Historia del |  | X | X |
| arte. |  |  |  |
| • Identificación y contraste de fuentes de la Historia del |  |  | X |
| arte. Técnicas de análisis e interpretación. |  |  |  |

| SUB-BLOQUE DEL ARTE DE LA ANTIGÜEDAD Y DE LA EDAD MEDIA CE1, CE2, CE3, CE4, CE9 |  | 1er y 2º cursos |  | 3er y 4º cursos |  |
| --- | --- | --- | --- | --- | --- |
| Arte prehistórico y antiguo |  |  |  |  |  |
| • El arte en la prehistoria. Arte rupestre y megalitismo. |  | X |  |  |  |
| • Las principales tipologías arquitectónicas de la civilización |  | X |  |  |  |
| egipcia (mastabas, pirámides y templos) y de las |  |  |  |  |  |

| SUB-BLOQUE DEL ARTE DE LA ANTIGÜEDAD Y DE LA EDAD MEDIA CE1, CE2, CE3, CE4, CE9 |  | 1er y 2º cursos |  | 3er y 4º cursos |  |
| --- | --- | --- | --- | --- | --- |
| civilizaciones mesopotámicas (zigurat). |  |  |  |  |  |
| • Realizaciones más relevantes del arte griego clásico y |  | X |  |  |  |
| helenístico: la escultura y el templo griego. |  |  |  |  |  |
| • El arte en Roma. La construcción civil romana: templos, |  | X |  |  |  |
| teatros, anfiteatros y circos. |  |  |  |  |  |
| Arte medieval |  |  |  |  |  |
| • El arte románico: el templo, la pintura y escultura. |  | X |  |  |  |
| • El arte gótico: el templo, la pintura y la escultura. |  | X |  |  |  |
| • Principales aportaciones del arte islámico. |  | X |  |  |  |

| SUB-BLOQUE DEL ARTE DE LA EDAD MODERNA Y CONTEMPORÁNEA CE1, CE2, CE3, CE4, CE9 |  | 1er y 2º cursos | 3er y 4º cursos |
| --- | --- | --- | --- |
| • El arte renacentista italiano. Principales características y |  |  | X |
| obras más representativas. |  |  |  |
| • El arte barroco en Europa. Principales características y |  |  | X |
| obras más representativas. |  |  |  |
| • Arte de los siglos XVIII y XIX. Academicismo frente a |  |  | X |
| Romanticismo. |  |  |  |
| • La ruptura de la tradición artística: el impresionismo y las |  |  | X |
| vanguardias históricas. |  |  |  |
| • Movimientos artísticos posteriores a la Segunda Guerra |  |  | X |
| Mundial. |  |  |  |

4.5
Bloque 4: Compromiso social y cívico

| SUB-BLOQUE DE EJERCICIO DE LA CIUDADANÍA CE4, CE5, CE6, CE7, CE8 |  | 1er y 2º cursos | 3er y 4º cursos |
| --- | --- | --- | --- |
| • Técnicas básicas de alfabetización informacional en |  | X |  |
| geografía e historia. |  |  |  |
| • Aprovechamiento crítico de las técnicas de |  |  | X |
| alfabetización informacional en geografía e historia. |  |  |  |
| • Valores, derechos y deberes de la ciudadanía |  | X |  |
| democrática. Diálogo y empatía como instrumentos de |  |  |  |
| resolución pacífica de conflictos. |  |  |  |
| • Hábitos democráticos. Ejercicio de los derechos y |  |  | X |
| deberes de la ciudadanía. Instrumentos para la |  |  |  |
| resolución pacífica de conflictos. Defensa y práctica |  |  |  |
| activa. |  |  |  |
| • Detección y rechazo de las situaciones sociales inicuas |  | X |  |
| e injustas en el mundo actual y en la historia antigua y |  |  |  |
| medieval. |  |  |  |
| • Detección y rechazo de las situaciones sociales inicuas |  |  | X |
| e injustas en el mundo actual y en la historia moderna |  |  |  |
| y contemporánea. |  |  |  |

| SUB-BLOQUE DE SOSTENIBILIDAD CE5, CE6, CE7, CE9 |  | 1er y 2º cursos | 3er y 4º cursos |
| --- | --- | --- | --- |
| • Actuaciones personales de respeto al medioambiente: |  | X |  |
| Reutilizar, Reciclar, Reducir. |  |  |  |
| • Hábitos personales de vida y consumo para el |  |  | X |
| compromiso con los Objetivos de Desarrollo |  |  |  |
| Sostenible. |  |  |  |
| • El desafío de la reducción de las desigualdades |  | X |  |
| sociales y económicas en el mundo actual. |  |  |  |
| • Las bases de la solidaridad internacional. La |  |  | X |
| cooperación y la ayuda al desarrollo. |  |  |  |

| SUB-BLOQUE DE IDENTIDAD Y PATRIMONIO CE4, CE8, CE9 |  | 1er y 2º cursos | 3er y 4º cursos |
| --- | --- | --- | --- |
| • Reconocimiento de la propia identidad cultural. |  | X |  |
| Convivencia y respeto de las diferencias culturales e |  |  |  |
| identitarias. |  |  |  |
| • La resiliencia y la práctica de la tolerancia activa. Los |  |  | X |
| valores del europeísmo y la ciudadanía europea. |  |  |  |
| • Reconocimiento del valor identitario del patrimonio |  | X |  |
| cultural y natural y el compromiso con su preservación |  |  |  |
| como herencia irrenunciable del ser humano. |  |  |  |
| • La puesta en valor y disfrute del patrimonio como bien |  |  | X |
| social e identitario. |  |  |  |

5.
Situaciones de aprendizaje

Las competencias específicas de la materia de Geografía e Historia y su contribución al
desarrollo de las competencias clave movilizan saberes sobre la evolución de las sociedades humanas
en el tiempo y sobre el espacio geográfico en el que se desarrollan sus actividades. En este enfoque
competencial, la adquisición y desarrollo de estas competencias específicas pretende que el alumnado
comprenda el mundo en el que vive, habilitándolo para que se sitúe en su propio contexto social y se
forme una conciencia ciudadana que le permita interactuar en el mismo de manera activa, crítica,
responsable y sostenible en una sociedad cada vez más diversa y cambiante.

Durante esta etapa educativa, el alumnado entra en la adolescencia, un nuevo estado
madurativo esencial en la articulación de un primer proyecto de vida. En este sentido, la consecución
de las competencias específicas del área supone una ampliación de los saberes, una profundización
en su carácter inter y multidisciplinar, así como una mayor capacidad de relacionar la escala global y
local. Todas estas capacidades deben orientarse a su aplicación práctica para que contribuyan a este
inicial proyecto de vida.

La presencia de esta materia en el currículo se justifica por su enfoque crítico, humanístico y
su arraigo académico y docente. Además, los valores humanísticos relacionados con la humanidades
y las ciencias sociales, y más concretamente con la geografía y la historia, contribuyen a promover
posicionamientos éticos claros sobre los desafíos del siglo XXI, como el compromiso ciudadano en el
ámbito local y global, la valoración de la diversidad personal y cultural, el compromiso ante situaciones
de iniquidad y exclusión, la resolución pacífica de los conflictos, la aceptación y manejo de la
incertidumbre, el respeto al medioambiente o el compromiso con la preservación de la herencia social
que supone el patrimonio en sus múltiples tipologías.

Desde el punto de vista didáctico, hay que tener en cuenta que en esta etapa el alumnado
empieza a desarrollar un pensamiento abstracto y una actitud crítica y reflexiva sobre sus experiencias
y su entorno. Por eso, las situaciones de aprendizaje idóneas para el desarrollo y el logro de estas
competencias se fundamentan en los principios constructivistas, es decir, se parte de lo que el
alumnado ya conoce para avanzar e incorporar los nuevos aprendizajes de manera significativa. Así
mismo, es fundamental comprobar el grado de adquisición de estos aprendizajes y de conexión con

las experiencias individuales del alumnado, incorporando como parte de las situaciones de aprendizaje
espacios y tiempos para la reflexión, el debate de puntos de vista y la autoconciencia del aprendizaje.

Dentro de este marco constructivista, las metodologías que favorecen especialmente la
implementación de las competencias específicas son las del aprendizaje cooperativo, el aprendizaje
basado en proyectos, el aprendizaje basado en problemas, la indagación colectiva, el estudio en
profundidad de casos, el aprendizaje dialógico, las simulaciones, y los juegos de rol o debates sobre
procesos abiertos.

Estas metodologías priorizan los procesos de aprendizaje de cooperación entre iguales, que
favorecen la motivación, autonomía y reflexión, y están orientados a conectar con las experiencias
individuales del alumnado en otros ámbitos del aprendizaje escolar y de fuera de la escuela. Además,
permiten la integración de actividades de muy diverso tipo, lo cual facilita y favorece la aplicación
práctica e inmediata de los contenidos de la materia y, por tanto, de la adquisición o desarrollo de las
competencias.

Dadas las características del área, las del alumnado y las metodologías mencionadas, se
recomienda utilizar una serie de criterios para diseñar y desplegar las actividades de aprendizaje
orientadas a promover y favorecer el logro de las competencias. De manera general, las actividades
de aprendizaje tendrían que:

- Favorecer la movilización de saberes interdisciplinares implicados en la adquisición de varias
competencias específicas.

- Presentar al alumnado los aprendizajes en forma de retos, juegos y problemas, aumentando la
motivación por aprender.

- Utilizar la perspectiva coeducativa e inclusiva en el trabajo de los saberes, proporcionando mayor
visibilidad a las mujeres en las ciencias sociales y las humanidades.

- Fomentar la capacidad de trabajo individual y en equipo, además del esfuerzo, como elementos
esenciales del proceso de aprendizaje. El trabajo cooperativo tendría que ser prioritario en el desarrollo
del área, entendiendo el aula como microsociedad de la cual el alumnado forma parte.

- Promover la creatividad y la aportación crítica del propio alumnado en sus realizaciones.

- Recurrir a los elementos patrimoniales y culturales más próximos a la realidad del alumnado como
punto de partida para la propuesta de tareas.

- Aprovechar las posibilidades del entorno como recurso educativo.

- Utilizar el potencial de las tecnologías de la información y la comunicación de manera adecuada y
responsable.

- Favorecer la aplicabilidad de los aprendizajes adquiridos en el aula de ciencias sociales a otros
contextos.

De forma más específica, desde el área sería recomendable diseñar actividades de los
siguientes tipos:

- Actividades de indagación, sobre todo las que implican un trabajo de campo, busca y tratamiento de
información relevante a través de las fuentes tradicionales y el uso de las tecnologías de la información
y de la comunicación, y las que favorecen el trabajo cooperativo situando al alumnado como
protagonista de su propio proceso de enseñanza y aprendizaje.

- Actividades de fomento de la lectura y la escritura a través de obras literarias, documentos históricos
y artículos periodísticos y científicos sobre hechos históricos y geográficos concretos.

- Actividades de elaboración, análisis y tratamiento de ejes cronológicos, textos, mapas, gráficos y
estadísticas históricas y geográficas.

- Actividades que permitan explicar a los demás el resultado de las tareas y argumentarlo de manera
tanto oral como escrita.

- Actividades de reflexión que conecten los contenidos con experiencias y sentimientos personales del
alumnado que han tenido lugar en otros contextos.

- Actividades dialógicas y de debate, complementarias o independientes de las anteriores, en las cuales
el alumnado pueda expresar opiniones personales críticas y constructivas, contrastar elementos o
dudas sobre los contenidos geográficos o históricos, y movilizar la capacidad de argumentación
mediante el lenguaje verbal.

La evaluación de las competencias específicas se realiza mediante los criterios de evaluación
que permiten valorar de manera apropiada el nivel de desarrollo competencial alcanzado por el
alumnado, tanto en lo que concierne a los procesos como a los resultados. En consecuencia, es
aconsejable la utilización de más de un tipo de instrumento de evaluación, especialmente incorporando
aquellos que no sean exclusivamente unidireccionales y que favorezcan la implicación del alumnado
en su propio proceso de aprendizaje, como la coevaluación y la autoevaluación, para lo que se
utilizarán instrumentos acordes con este objetivo como pueden ser, por ejemplo, las rúbricas.

6.
Criterios de evaluación

Criterios de evaluación CE1. Describir y contextualizar en el tiempo y el espacio los
acontecimientos y procesos más relevantes de la historia propia y universal, identificando referentes
de la evolución hacia la sociedad actual y valorando su diversidad.

| SEGUNDO CURSO |  | CUARTO CURSO |  |
| --- | --- | --- | --- |
| 1.1. Construir un relato cronológicamente |  | 3.1. Construir un relato o una síntesis, |  |
| ordenado y coherente sobre hechos y personajes |  | cronológicamente ordenada, coherente y |  |
| relevantes del pasado y sobre su relación con el |  | empleando la terminología adecuada, sobre |  |
| presente. |  | hechos, procesos y personajes relevantes del |  |
|  |  | pasado y su relación con el presente. |  |
|  |  | 3.2. Aportar posibles motivos sobre la distinta |  |
|  |  | relevancia otorgada a unos hechos históricos |  |
|  |  | sobre otros en diferentes momentos del pasado y |  |
|  |  | en el presente. |  |
|  |  | 3.3. Debatir sobre situaciones históricas de |  |
|  |  | intolerancia y formular argumentos que fomenten |  |
|  |  | la tolerancia y el respeto hacia la diversidad |  |
|  |  | histórica y cultural de las sociedades humanas. |  |

Criterios evaluación CE2. Buscar, identificar y seleccionar la información referente a hechos
históricos, geográficos y artísticos a partir de diferentes fuentes documentales, realizando un
tratamiento correcto en cuanto a investigación, clasificación, recogida, organización, crítica y respeto.

| SEGUNDO CURSO |  | CUARTO CURSO |  |
| --- | --- | --- | --- |
| 2.1. Comparar la información obtenida con sus |  | 2.1. Contrastar la información seleccionada para |  |
| ideas previas, desterrando posibles prejuicios. |  | comprender hechos históricos, geográficos y |  |
|  |  | artísticos procedente de diferentes fuentes con la |  |
|  |  | proveniente de organismos oficiales o emisores |  |
|  |  | de reconocido prestigio. |  |
|  |  | 2.2. Identificar y rechazar prejuicios y |  |
|  |  | estereotipos identificando opiniones no |  |
|  |  | fundamentadas en hechos y saberes y |  |
|  |  | comparándolas con información obtenida a partir |  |
|  |  | de fuentes fiables. |  |
|  |  | 2.3. Utilizar la información contenida en |  |
|  |  | diferentes fuentes documentales para explicar |  |
|  |  | hechos históricos, geográficos y artísticos |  |
|  |  | relacionándolos con su época. |  |
|  |  | 2.4. Formular y comunicar de forma textual, |  |
|  |  | gráfica o audiovisual conclusiones y valoraciones |  |
|  |  | propias sobre hechos históricos, geográficos y |  |
|  |  | artísticos, mostrando un dominio adecuado de los |  |
|  |  | conceptos y la metodología de trabajo de este |  |
|  |  | ámbito de conocimiento. |  |

Criterios evaluación CE3. Explicar las nociones básicas de cambio y continuidad en la historia
empleando una perspectiva causal y contextualizada, reconociendo en el pasado el origen y evolución
de las cuestiones más relevantes del mundo actual y expresando juicios y opiniones sobre el presente
y el futuro.

| SEGUNDO CURSO | CUARTO CURSO |
| --- | --- |
| 3.1. Reconocer causas y consecuencias respecto de los hechos y procesos históricos más relevantes de diferentes épocas. | 3.1. Explicar las dinámicas de cambio y |
|  | continuidad en los procesos históricos más |
|  | relevantes de diferentes épocas identificando |
|  | relaciones causales complejas y entre factores |
|  | de distinto ámbito. |
| 3.2. Contextualizar y valorar decisiones históricamente relevantes tomadas por personas representativas del pasado, tanto en el contexto propio como en otros contextos sociales, políticos y culturales. | 3.2. Contextualizar y valorar decisiones tomadas |
|  | por personas del pasado y/o de contextos |
|  | sociales, políticos y culturales distintos al propio, |
|  | y debatir sobre los motivos de sus acciones. |
| 3.3. Producir opiniones y manifestar actitudes de tolerancia y respeto hacia otras culturas y cosmovisiones. | 3.3. Producir opiniones y juicios de valor |
|  | coherentes sobre cuestiones sociales y políticas |
|  | del pasado y del presente, manifestando |
|  | actitudes de tolerancia, respeto e interés hacia |
|  | otras culturas y cosmovisiones. |

Criterios evaluación CE4. Contrastar las identidades individuales con las colectivas,
identificando las aportaciones decisivas en su construcción y reconociendo y valorando las actuaciones
de tolerancia y respeto.

| SEGUNDO CURSO | CUARTO CURSO |
| --- | --- |
| 4.1. Identificar los elementos definitorios más | 4.1. Identificar los elementos definitorios de las identidades individuales y colectivas más significativas del presente estableciendo su conexión con hechos del pasado. |
| significativos de las identidades individuales y |  |
| colectivas del propio entorno. |  |
| 4.2. Expresar opiniones de respeto y tolerancia | 4.2. Argumentar en favor de las actitudes tolerantes, respetuosas y de interés hacia otras identidades, tanto individuales como colectivas. |
| hacia otras identidades, tanto individuales como |  |
| colectivas. |  |
| 4.3. Mostrar actitudes de interés y respeto hacia | 4.3. Promover y ejercer propuestas prácticas de convivencia en el aula y en el propio entorno social. |
| otras identidades, tan individuales como |  |
| colectivas. |  |

Criterios evaluación CE5. Explicar las interrelaciones económicas fundamentales entre los
elementos del espacio físico y las actividades de las sociedades humanas, así como su repercusión
en la sostenibilidad.

| SEGUNDO CURSO |  | CUARTO CURSO |  |
| --- | --- | --- | --- |
| 5.1. Ubicar las actividades económicas y los |  | 5.1. Identificar y describir las interrelaciones entre |  |
| recursos naturales más importantes en el espacio |  | los grupos y sociedades humanas y el |  |
| geográfico. |  | medioambiente que han dado lugar a problemas |  |
|  |  | y conflictos por el acceso a los recursos |  |
|  |  | naturales. |  |
| 5.2. Detectar los problemas territoriales y |  | 5.2. Explicar las causas de problemas y conflictos |  |
| medioambientales más importantes, tanto a |  | territoriales y medioambientales, diferenciando y |  |
| escala global como local y hacer propuestas con |  | relacionando las distintas variables que |  |
| criterios de sostenibilidad. |  | intervienen. |  |
| 5.3. Identificar y describir el impacto sobre el |  | 5.3. Plantear alternativas sostenibles |  |
| territorio de las principales actividades |  | argumentadas a los problemas e impactos |  |
| económicas, diferenciando entre las que son |  | ocasionados por las actividades humanas. |  |
| sostenibles y las que no lo son. |  |  |  |

Criterios evaluación CE6. Contrastar los principales modelos de ocupación territorial, y de
organización política y económica que explican la desigualdad entre los seres humanos, tanto a escala
local como global.

| SEGUNDO CURSO |  | CUARTO CURSO |  |
| --- | --- | --- | --- |
| 6.1. Identificar y localizar los principales modelos |  | 6.1. Describir las principales características de |  |
| de organización territorial, política y económica. |  | los diferentes modelos de organización territorial, |  |
|  |  | política y económica. |  |
| 6.2. Distinguir las entidades políticas y formas de |  | 6.2 Exponer razonadamente las desigualdades |  |
| organización económica más importantes dentro |  | generadas por los modelos de organización |  |
| de los principales modelos de organización |  | territorial, política y económica y explicar sus |  |
| territorial, política y económica, y explicar cómo |  | causas. |  |
| inciden en la vida cotidiana de sus habitantes. |  |  |  |
| 6.3. Señalar los principales problemas |  | 6.3. Explicar los principales problemas |  |
| territoriales, políticos y económicos, así como los |  | territoriales, políticos y económicos generados |  |
| agentes sociales que intervienen a escala local, |  | por las desigualdades y cómo afectan a la vida |  |
| regional, estatal y supraestatal. |  | cotidiana de las personas. |  |

Criterios evaluación CE7. Dar argumentos desde una perspectiva crítica, fundamentada en
conocimientos históricos y geográficos acerca de problemas sociales relevantes, asumiendo valores
democráticos y pronunciándose en su defensa.

| SEGUNDO CURSO |  | CUARTO CURSO |  |
| --- | --- | --- | --- |
| 7.1. Identificar los problemas sociales más |  | 7.1. Justificar cómo las acciones personales |  |
| relevantes de la actualidad, utilizando como guía |  | inciden directamente en los problemas sociales |  |
| los Objetivos de Desarrollo Sostenible. |  | relevantes. |  |
| 7.2. Establecer relaciones causales entre las |  | 7.2. Proporcionar argumentos propios, |  |
| acciones humanas y el origen de los problemas |  | fundamentados en la historia y en la geografía, |  |
| sociales más relevantes de la actualidad. |  | sobre los problemas sociales más relevantes, |  |
|  |  | reconociendo la incidencia que su resolución |  |
|  |  | tendrá en la mejora las condiciones de vida de las |  |
|  |  | personas. |  |
| 7.3. Mostrar interés por los problemas sociales |  | 7.3. Proponer soluciones para los problemas |  |
| más relevantes y proponer soluciones a los |  | basadas en argumentos históricos y geográficos |  |
| mismos fundamentadas en saberes geográficos |  | y que consideren los Objetivos de Desarrollo |  |
| e históricos. |  | Sostenible (ODS). |  |

Criterios evaluación CE8. Promover y participar en proyectos cooperativos de convivencia,
tomando como base la construcción histórica de la Unión Europea, que favorezcan un entorno más
justo y solidario mediante la aplicación de valores y procedimientos democráticos

| SEGUNDO CURSO |  | CUARTO CURSO |  |
| --- | --- | --- | --- |
| 8.1. Participar en proyectos cooperativos, |  | 8.1. Participar en proyectos cooperativos, |  |
| asumiendo varios roles con responsabilidad y |  | asumiendo varios roles con eficacia y |  |
| reconociendo las aportaciones de sus iguales. |  | responsabilidad, apoyando a compañeros y |  |
|  |  | compañeras y demostrando empatía. |  |
| 8.2. Denunciar las situaciones injustas y de |  | 8.2. Denunciar las situaciones injustas y de |  |
| exclusión en cualquier ámbito, tomando como |  | exclusión, argumentando a favor del diálogo y la |  |
| ejemplo la historia de Europa. |  | inclusión como formas de superarlas. |  |
| 8.3. Aplicar los principios democráticos y el |  | 8.3. Argumentar y aplicar los principios |  |
| diálogo para resolver los conflictos. |  | democráticos y el diálogo para plantear la |  |
|  |  | resolución de los conflictos, tanto a nivel cotidiano |  |
|  |  | como a escala global, en especial utilizando el |  |
|  |  | referente de la construcción histórica de la Unión |  |
|  |  | Europea. |  |

Criterios evaluación CE9. Identificar el origen y reconocer el valor del patrimonio cultural y
natural, especialmente de sus elementos geográficos, históricos y artísticos, tanto a escala local como
a escala global, participando en la elaboración y difusión de propuestas que favorezcan su
preservación y puesta en valor.

| SEGUNDO CURSO |  | CUARTO CURSO |  |
| --- | --- | --- | --- |
| 9.1. Identificar bienes patrimoniales históricos, |  | 9.1. Identificar las características de los |  |
| geográficos y artísticos, tanto a escala global |  | elementos patrimoniales, relacionándolas con |  |
| como local. |  | estilos artísticos, época histórica y entorno |  |
|  |  | geográfico. |  |
| 9.2. Elaborar trabajos de síntesis sobre el |  | 9.2. Elaborar y exponer propuestas |  |
| patrimonio más cercano que reconozcan su |  | argumentadas que contribuyan a la preservación |  |
| variedad e importancia como elemento |  | del patrimonio y su puesta en valor, y que lo |  |
| identitario. |  | reconozcan como bien social. |  |
