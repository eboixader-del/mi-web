# LENGUA CASTELLANA Y LITERATURA

> Fuente: Secundaria.pdf, páginas 1022-1055 (versión en castellano).

VALENCIANO: LENGUA Y LITERATURA

LENGUA CASTELLANA Y LITERATURA

1. Presentación

Las materias de Valenciano: Lengua y Literatura y de Lengua Castellana y Literatura,
tienen un papel fundamental en la consecución de las finalidades de la etapa de Educación
Secundaria. Entre los objetivos finales de la etapa se encuentran la capacidad de comprender y
de expresar con corrección, oralmente y por escrito, tanto en valenciano como en castellano,
textos y mensajes complejos, y también iniciarse en el conocimiento, la lectura y el estudio de
la literatura.

Por otro lado, los principios pedagógicos del perfil de salida de esta etapa también
involucran directamente las materias de Valenciano: Lengua y Literatura y de Lengua
Castellana y Literatura en cuanto a la correcta expresión oral y escrita, la comprensión lectora,
el hábito lector, la comunicación audiovisual y la creatividad. Además, al final de esta etapa,
todo el alumnado tiene que haber adquirido los elementos básicos de la cultura, en el caso de
nuestras materias, los aspectos humanísticos y artísticos.

Finalmente, el valenciano y el castellano, como lenguas vehiculares de la enseñanza
son, también, la herramienta fundamental que tiene que garantizar el acceso del alumnado al
conocimiento en las diferentes materias. El dominio eficaz de las dos lenguas, resulta
imprescindible, por lo tanto, para devenir un aprendiz autónomo a lo largo de la vida.

Por otro lado, las materias de Valenciano: Lengua y Literatura y de Lengua Castellana
y Literatura contribuyen de manera directa, junto con el resto, en el desarrollo de la
competencia en comunicación lingüística, además de participar con el resto de lenguas
curriculares en la adquisición de la competencia plurilingüe.

El enfoque plurilingüe del currículum tiene que ayudar también a integrar de manera
creativa y eficaz los procesos de aprendizaje de las diferentes lenguas de la escuela. En
cuanto a la Educación Secundaria, el valenciano, el castellano, la lengua extranjera y la
segunda lengua extranjera, si fuera el caso.

En este sentido, se ha procurado que el diseño de las propuestas curriculares de las
materias de Valenciano: Lengua y Literatura y de Lengua Castellana y Literatura, de la lengua
extranjera y de la segunda lengua extranjera sea en parte complementario y en parte
compartido. Efectivamente, las coincidencias entre las competencias específicas de estas
áreas están pensadas para poder trabajar de una manera integrada la competencia en
comunicación lingüística y la competencia plurilingüe. Por otro lado, la competencia específica
de mediación tiene que servir para favorecer el diseño de situaciones de aprendizaje que
integren las diferentes lenguas del currículum y también, cuando sea posible, las lenguas
presentes en el instituto.

Para llevar a cabo este objetivo de integración de las lenguas del currículum, la
realización de proyectos significativos para el alumnado que promuevan la resolución
colaborativa de problemas puede ser un instrumento inmejorable para integrar las
competencias específicas de las áreas lingüísticas y también de las no lingüísticas. En esta
etapa, especialmente a partir de tercero de ESO y, sobre todo en cuarto, se incorpora el ámbito
profesional como ámbito de uso de las lenguas. Hay que diseñar situaciones de aprendizaje y
proyectos que incorporen este ámbito entre las prácticas discursivas planificadas en el aula y
fuera del aula.

Las materias de Valenciano: Lengua y Literatura y de Lengua Castellana y Literatura
tienen que promover también en esta etapa la reflexión lingüística y el análisis contrastivo

asociados a los usos discursivos. La reflexión se tiene que extender también a la diversidad
lingüística y cultural presente en la misma aula, en el instituto, al entorno familiar y social
próximo, en la Comunidad Valenciana, en España, en Europa y en el mundo, en una
progresión que haga ampliar la mirada del alumnado y lo prepare para vivir y convivir en
sociedades diversas. El trabajo en los institutos de la diversidad lingüística tiene que ir
acompañado de una visión de esta diversidad como una riqueza y como un hecho global. Esta
reflexión se tiene que extender también a la relación entre las lenguas y el poder, y los
procesos de minorización y de sustitución lingüística. La reflexión tiene que ir acompañada de
un trabajo sobre las actitudes y los estereotipos lingüísticos que favorezca la superación de
estas situaciones de desigualdad lingüística.

Las materias de Valenciano: Lengua y Literatura y de Lengua Castellana y Literatura
tiene que contribuir también al desarrollo de la capacidad de diálogo y de mediación en los
conflictos usando el lenguaje. En este sentido, las competencias específicas de interacción y
de mediación son la base para el diseño de situaciones de aprendizaje basadas en
intercambios comunicativos que preparen para una ciudadanía empática, pacífica, dialogante,
que usa el lenguaje para estrechar vínculos, mejorar la convivencia y realizar proyectos
cooperativos.

El fomento de la creatividad en las materias lingüísticas pasa por la creación verbal a
través del juego y de los textos literarios, tanto orales como escritos. La literatura en la escuela
sirve para desarrollar el sentido artístico y la creatividad en el alumnado a través del juego, los
juegos verbales, la creación literaria, la composición de textos literarios de diferentes formatos
y géneros (poesía, cuento, canción, guion, cómic), y también de la creación audiovisual y del
teatro que combinan diferentes lenguajes y que abren la puerta al trabajo interdisciplinar y a la
organización de proyectos artísticos que pueden involucrar los ámbitos formales, informales y
no formales.

Por otro lado, el trabajo con los textos literarios, tanto orales como escritos, tiene que
contribuir a reforzar la capacidad de comprensión de textos literarios escritos y multimodales, y
a continuar desarrollando el gusto por lectura y el hábito lector que ya se habían empezado a
trabajar en la etapa de Educación Primaria. El papel de las bibliotecas de aula y de centro y el
trabajo coordinado con las bibliotecas municipales, como también el trabajo con las familias,
resultan fundamentales para alcanzar este objetivo. El plan de fomento de la lectura y el
proyecto educativo de centro tienen que servir de base para planificar las acciones
pedagógicas necesarias para lograr estos objetivos de una manera coordinada entre todas las
materias, especialmente el tiempo que se dedicará a la lectura en cada centro.

La literatura, en esta etapa, conecta con la cultura popular y permite integrar en el aula
también las culturas populares del alumnado recién llegado y las culturas contemporáneas. Por
otro lado, el trabajo de los textos literarios en la Educación Secundaria tiene que centrarse en
una profundización de la lectura interpretativa de los textos, del estudio de los contextos de
creación, y de la iniciación en la lectura de obras del canon del patrimonio literario.

El uso de las TIC aplicadas al aprendizaje de las lenguas resulta fundamental, y tiene
que continuar completándose progresivamente a lo largo de esta etapa: consultas contrastadas
y verificadas en Internet, uso avanzado de procesadores de textos, de correctores y de
traductores, herramientas de grabación y montaje audiovisual, diccionarios electrónicos,
consulta de ficheros y de fuentes bibliográficas.

Por otro lado, desde las materias de Valenciano: Lengua y Literatura y de Lengua
Castellana y Literatura se tiene que contribuir a la enseñanza de un uso ético del lenguaje en el
ámbito de la comunicación digital, como también ayudar a la construcción de una conciencia
crítica de los mensajes a través del trabajo de la lectura crítica, el debate y la creatividad.

Por otro lado, en las materias lingüísticas se tiene que velar también por la enseñanza
inclusiva de todo el alumnado, con una atención especial hacia las dificultades de aprendizaje
de lenguas. El acompañamiento docente en todo el proceso de aprendizaje y la participación
del grupo de clase en la facilitación del éxito escolar de todos sus miembros, son claves para
lograr este objetivo.

Finalmente, las áreas lingüísticas configuran un contexto óptimo para enseñar el uso
del lenguaje para la gestión de las emociones y en las interacciones durante el trabajo en
grupo; para la participación en la sociedad; y el respecto a la diversidad afectiva y sexual y la
igualdad de género.

El currículum de Valenciano: Lengua y Literatura y de Lengua Castellana y Literatura
se fundamenta en el trabajo de nueve competencias específicas. Estas competencias conectan
con el perfil de salida del alumnado al final de la etapa de enseñanza básica (que viene
determinado a su vez por los retos del siglo XXI y por las competencias clave), y se conectan
entre ellas y con los saberes y los criterios de evaluación de una forma dinámica, a través de la
actuación del alumno en diferentes contextos de la realidad.

Las competencias específicas de la materia son: multilingüismo e interculturalidad;
comprensión oral y multimodal; comprensión escrita y multimodal; expresión oral; expresión
escrita y multimodal; interacción oral, escrita y multimodal; mediación oral, escrita y multimodal;
lectura autónoma; y competencia literaria. De cada una de estas competencias específicas se
realiza una descripción que indica las características de las actuaciones y de las situaciones en
que se despliega, y en la que se apuntan algunos de los contenidos que lleva asociados.
Además, en la descripción se indican de manera sintética los principales hitos en el proceso de
adquisición de la competencia a lo largo de la etapa: final de segundo y de cuarto curso, en el
caso de Secundaria.

En el siguiente apartado se establecen las conexiones de las nueve competencias
específicas con: 1) el resto de las competencias específicas de la materia; 2) las competencias
específicas del resto de las materias de la etapa; 3) las competencias clave.

A continuación se muestran los saberes básicos, es decir, el conjunto de
conocimientos, destrezas, actitudes y valores de la materia que es necesario que el alumno
movilice para poder adquirir las diferentes competencias específicas. Los saberes básicos
están organizados en tres bloques: Lengua y uso; Estrategias comunicativas; y Educación
literaria. En el apartado de los saberes básicos se indican también los ciclos de la etapa en los
cuales se propone trabajarlos.

A continuación se explican las características que podrían presentar las situaciones de
aprendizaje. Este apartado se plantea como una ayuda para que el profesorado diseñe
aquellas actividades didácticas complejas que harían posible que el alumnado pusiera en
práctica los componentes de las competencias específicas y de las competencias clave, al
mismo tiempo que moviliza los saberes básicos necesarios para su adquisición

Al final se exponen los criterios de evaluación de cada competencia específica. Estos
criterios son los referentes que indican los niveles mínimos de aplicación de la competencia en
las diferentes situaciones de aprendizaje que se haya previsto en cada momento del proceso
de enseñanza y aprendizaje. Los criterios de evaluación son la base para el diseño de
situaciones de aprendizaje, junto con los saberes básicos, y tienen que servir también para el
diseño de las situaciones, los procedimientos y los instrumentos de evaluación necesarios para
evaluar la adquisición de cada competencia específica. Estos criterios indican un nivel mínimo
para segundo y cuarto curso de la Educación Secundaria.

2. Competencias específicas

2.1. Competencia específica 1. Multilingüismo e interculturalidad

Describir y apreciar la diversidad lingüística y cultural de la Comunidad Valenciana, de
España y del mundo, a través del reconocimiento de las lenguas del alumnado y de la realidad
multilingüe e intercultural del entorno, analizando las características, el origen y el desarrollo
sociohistórico de las dos lenguas oficiales y de las principales variedades lingüísticas, y
combatiendo los prejuicios lingüísticos.

2.1.1. Descripción de la competencia

La diversidad lingüística y cultural es una realidad presente tanto en la sociedad, como
en las aulas valencianas. Por este motivo, las áreas lingüísticas tienen el reto de abordar esta
diversidad con el objetivo de promover en el alumnado el conocimiento de las diferentes
lenguas y variedades lingüísticas, y de la cultura asociada a ellas. Al mismo tiempo las clases
de lengua tienen que servir para educar el alumnado en la aceptación de esta diversidad como
un enriquecimiento personal rehuyendo prejuicios lingüísticos o xenófobos.

La diversidad lingüística constituye también una característica fundamental del Estado
español, donde se hablan diferentes lenguas con sus respectivas variedades lingüísticas. En
este sentido, el desarrollo de esta competencia tiene que hacer posible que el alumnado
demuestre interés y respeto por las lenguas oficiales del Estado, poniendo especial atención en
el valenciano y en su proceso de normalización. El conocimiento y el aprecio por la lengua
propia de un territorio tiene que ser vista como una de las bases para el desarrollo de una
buena competencia multilingüe e intercultural.

La escuela tiene que reflejar la realidad social, pero también tiene que introducir las
correcciones pertinentes para conciliar el interés general en los contextos en los cuales hay
una lengua predominante y otra minorizada, de forma que se garantice la protección de los
derechos lingüísticos y la igualdad de las lenguas oficiales. La recuperación de su uso y la
corrección de desequilibrios sociales y territoriales serán fundamentales para vertebrar la
sociedad valenciana, así como para profundizar en las diversas variedades lingüísticas y
promover el respecto a la identidad plural, la cooperación entre territorios, y el reconocimiento
del valenciano como lengua propia.

Para la correcta adquisición de esta competencia, el alumnado tiene que tener muy
presente que las dos lenguas oficiales de nuestro territorio cuentan con una diversidad
lingüística enriquecedora, y que cada variedad geográfica presenta unas características
propias que la caracterizan. Es por eso que el conocimiento y el respeto hacia las diferentes
variedades de la lengua, serán fundamentales para que el alumnado pueda lograr esta
competencia.

Por otro lado, vivimos en un contexto social rico en lenguas y culturas que hace que en
las aulas convivan personas que utilizan lenguas diferentes de las lenguas curriculares. Por
este motivo los centros educativos tienen que hacer visible esta diversidad que nos rodea, una
diversidad que posibilita la acogida y la actitud positiva hacia todas las lenguas, evita los
prejuicios lingüísticos, y que permite profundizar en el conocimiento del funcionamiento de las
lenguas, al mismo tiempo que acercará al alumnado a la realidad lingüística de la Comunidad
Valenciana, de España y del mundo. Detectar los prejuicios y estereotipos lingüísticos, así
como el uso del lenguaje no discriminatorio, favorecerá la convivencia democrática y la
construcción de una sociedad más equitativa y responsable.

Para el logro de esta competencia, hay que conocer cuál es el dominio real de las dos
lenguas oficiales por parte del alumnado, como también el abanico de lenguas familiares no
curriculares presentes en el aula, puesto que, solamente partiendo del perfil lingüístico
individual se puede garantizar el dominio equilibrado de las lenguas oficiales y se podrá
aprovechar la diversidad lingüística y cultural como un enriquecimiento para el centro.

Favorecer el contacto con otras lenguas y culturas no curriculares, pero propias de una
parte del alumnado, contribuirá a hacer que reflexione y tome conciencia del funcionamiento de
las lenguas a partir de la observación y la comparación entre ellas, incluyendo una
aproximación a otras formas de comunicación, como por ejemplo la lengua de signos. Poner en
valor las lenguas familiares ayudará a generar, por lo tanto, actitudes positivas hacia el
aprendizaje de lenguas.

En este sentido, el trabajo integrado de las lenguas (TIL) será de gran importancia,
puesto que además de promover un aprendizaje de lenguas más coherente y significativo,
estimula la reflexión sobre el uso del lenguaje para iniciarse en el desarrollo de la conciencia
lingüística.

Aspectos como la diversidad lingüística (individual y social), el análisis de las lenguas
en contacto y la gestión del multilingüismo serán esenciales para el trabajo de la competencia
multilingüe e intercultural.

Finalmente, al final del segundo curso, el alumnado tendría que ser capaz de reconocer
los rasgos característicos de al menos una lengua diferente a las familiares y a las oficiales.
Tendría que saber distinguir características de la diversidad geográfica de las lenguas, como
también otros rasgos relacionados con los sociolectos o con los registros con los cuales el
hablante se adecua a distintas situaciones comunicativas. También tendría que ser capaz de
realizar transferencias entre diferentes lenguas y comunicarse en contextos cotidianos con una
actitud de respeto hacia la diversidad lingüística y cultural de su entorno para mejorar la
convivencia.

Al final del cuarto curso, el alumnado tendría que reconocer y usar algunas estructuras
comunicativas de una o más lenguas diferentes a las familiares y a las oficiales. Tendría que
conocer el origen y el desarrollo histórico y sociolingüístico de las lenguas del Estado, y tendría
que familiarizarse con estas y otras lenguas presentes en su entorno. Tendría que poder
realizar transferencias y contrastes entre diferentes lenguas como estrategia comunicativa y
también conocer, valorar y respetar la diversidad lingüística y cultural, empezando por las
lenguas y las culturas del territorio, tanto para mejorar su formación personal, como para
contribuir a la cohesión social.

2.2. Competencia específica 2. Comprensión oral y multimodal

Comprender, interpretar y valorar, de manera autónoma, textos orales y multimodales
propios de los ámbitos personal, social, educativo y profesional, a través de la escucha activa,
aplicando estrategias de comprensión oral, reflexionando sobre el contenido y la forma, y
evaluando su calidad y fiabilidad.

2.2.1. Descripción de la competencia

Esta competencia específica engloba los procesos de comprensión oral que
contribuyen al desarrollo de la competencia en comunicación lingüística del alumnado con el
objetivo de aportarle conocimientos y estrategias para enfrentarse satisfactoriamente a
cualquier situación comunicativa de la vida personal, social y académica propia de su edad.
Estos conocimientos y estrategias le tienen que servir también como preparación para los
ámbitos profesionales y para la continuación en estudios superiores. Es decir, la comprensión
supone ser capaz de escuchar y comprender informaciones orales en situaciones
comunicativas de diferentes ámbitos y con registros de formalidad diversa, teniendo en cuenta
los elementos prosódicos y no verbales, así como ser capaz de utilizar estrategias de
comprensión oral para obtener e integrar la información y valorarla; y para responder a
necesidades comunicativas significativas.

En síntesis, la comprensión oral implica el conocimiento del léxico y de una serie de

estructuras lingüísticas. Ahora bien, en el desarrollo de esta competencia específica se pueden
distinguir tres tipos de comprensión: la literal, la inferencial y la crítica. Estos niveles de
comprensión se corresponden a diferentes actuaciones por parte del individuo. En la
comprensión literal se puede extraer la información directamente del texto; en la inferencial se
puede deducir; y en la crítica se tiene que tomar un punto de vista más personal y crítico.

Por otro lado, el alumnado tiene que ser capaz de comprender diferentes tipos de
discursos: el discurso producido por una sola persona (monólogo) y el discurso en el cual
participan dos o más interlocutores (diálogo o conversación); así como tener en cuenta que las
tecnologías de la información y la comunicación han ampliado las posibilidades de la
comunicación síncrona y asíncrona.

La comprensión de un texto oral requiere por parte del oyente un grado de atención y
de concentración elevados. Por eso, hay que desarrollar estrategias de selección y de
retención en relación al objetivo de la escucha. La comprensión de textos multimodales
necesita de una específica alfabetización audiovisual y mediática para hacer frente a los
riesgos de manipulación y desinformación.

De este modo, a medida que el alumnado desarrolla las estrategias de comprensión
oral a diferentes niveles, será capaz de identificar el sentido general y la información más
relevante, de anticipar el contenido, de distinguir entre hechos y opiniones, y de diferenciar
diferentes tipologías textuales, registros y contextos, así como de identificar la intención del
emisor, de analizar procedimientos retóricos y de detectar falacias argumentativas. La
comprensión oral se realiza valorando aspectos formales y de contenido para construir
conocimiento y dar respuesta a las diferentes situaciones comunicativas; es decir, que el
alumnado analice el uso de los elementos comunicativos no verbales y aplique los
conocimientos léxicos, gramaticales y textuales para interpretar mensajes orales.

Las reflexiones sobre el lenguaje tienen que partir del conocimiento previo que el
alumnado tiene como usuario de una lengua y tienen que producirse siempre de manera
significativa, en contextos de producción y de comprensión de textos. Por lo tanto, a través de
las actividades que promuevan la mejora de la comprensión oral, se pueden planificar
actividades de reflexión, utilizando la terminología elemental adecuada para iniciarse en el
desarrollo de la conciencia lingüística y mejorar las destrezas de producción y de comprensión.

Hay que tener en cuenta que para desarrollar esta competencia el alumnado al finalizar
el 1.º ciclo de secundaria tendría que ser capaz de identificar la información literal, realizar
inferencias e interpretar el objetivo principal de los textos orales. Al final del 2.º ciclo de
secundaria el alumnado también tendría que interpretar información explícita e implícita, y
valorar de manera crítica y argumentada los contenidos y el propósito de los textos orales.

2.3. Competencia específica 3. Comprensió escrita i multimodal

Comprender, interpretar y valorar, de manera autónoma, textos escritos y multimodales
propios de los ámbitos personal, social, educativo y profesional, a través de la lectura de textos,
aplicando estrategias de comprensión escrita, reflexionando sobre el contenido y la forma, y
evaluando su calidad y fiabilidad.

2.3.1. Descripción de la competencia 3

Esta competencia específica engloba los procesos de comprensión escrita para
desarrollar la competencia comunicativa del alumnado con el objetivo de aportarle
conocimientos y estrategias para enfrentarse satisfactoriamente a cualquier situación
comunicativa de la vida personal, social y académica propia de su edad. La adquisición de esta
competencia también tendría que servir, en esta etapa, como una preparación para la
interacción en ámbitos profesionales de la vida adulta y en contextos académicos. La

comprensión supone recibir y procesar la información expresada a través de textos escritos y
multimodales en situaciones comunicativas de diferentes ámbitos y con registros de formalidad
diversa, así como ser capaz de utilizar estrategias de comprensión escrita para obtener e
integrar la información y valorarla; y para responder a necesidades comunicativas significativas.

En síntesis, la comprensión escrita implica el conocimiento del código escrito y de una
serie de estructuras lingüísticas. Pero, en el desarrollo de esta competencia específica se
pueden distinguir tres tipos de comprensión: la literal, la inferencial y la crítica. Estos niveles de
comprensión se corresponden a diferentes actuaciones por parte del individuo. En la
comprensión literal se puede extraer la información directamente del texto; en la inferencial se
puede deducir; y en la crítica se tiene que tomar un punto de vista más personal y crítico.

Hay que tener en cuenta que la comprensión de un texto escrito requiere por parte del
lector ser capaz de leer con buena fluidez y aplicar las estrategias de comprensión lectora
necesarias. En todos estos aspectos intervienen varios procesos: localizar y obtener
información del texto, saber integrarla e interpretarla, y reflexionar y valorar esta información de
manera crítica. De este modo, a medida que el alumnado desarrolla las estrategias de
comprensión escrita a diferentes niveles, será capaz de diferenciar diferentes tipologías
textuales, registros y contextos.

Para conseguir que los alumnos y las alumnas se conviertan en lectores y lectoras
competentes y sean capaces de adecuar la manera de leer utilizando estrategias lectoras en
función del tipo de texto, de los diferentes formatos y apoyos, y del propósito de la lectura, hace
falta que el alumnado realice todos los procesos que intervienen en las actividades de lectura:
localizar y obtener información del texto, saber integrarla e interpretarla, y reflexionar y valorar.
De este modo, a medida que el alumnado desarrolla las estrategias de comprensión escrita a
diferentes niveles, será capaz de reconocer el sentido global, las ideas principales en función
del objetivo de lectura, captar la información explícita y realizar las inferencias necesarias,
formular hipótesis, y realizar reflexiones sobre aspectos formales y de contenido, para adquirir
y construir conocimiento y dar respuesta a necesidades e intereses comunicativos diversos.

En el desarrollo de esta competencia de comprensión escrita, también es necesario
que el alumno aplique las estrategias relacionadas con la alfabetización informacional. Es decir,
es necesario que el alumno busque, seleccione y contraste la información procedente de dos o
más fuentes, de forma planificada y de manera guiada. De este modo, se irá avanzando en la
evaluación de la fiabilidad de las informaciones. La comprensión de textos multimodales
necesita de una específica alfabetización audiovisual y mediática para hacer frente a los
riesgos de manipulación y desinformación.

Las reflexiones sobre el lenguaje tienen que partir del conocimiento previo que el
alumnado tiene como usuario de una lengua y tienen que producirse siempre de manera
significativa, en contextos de producción y comprensión de textos. Por lo tanto, a través de las
actividades que promuevan la mejora de la comprensión escrita, se pueden planificar
actividades de reflexión en que el alumnado utiliza la terminología elemental adecuada, se
inicia en el desarrollo de la conciencia lingüística y mejora sus destrezas de producción y de
comprensión.

Hay que tener en cuenta que para desarrollar esta competencia el alumnado al finalizar
el 1.º ciclo de secundaria tendría que ser capaz (de manera autónoma), de identificar la
información literal, realizar inferencias e interpretar información explícita e implícita, identificar el
objetivo principal de los textos escritos, así como el tipo de texto y sus características. Al final
del 2.º ciclo de secundaria el alumnado también tendría que interpretar y valorar de manera
crítica y argumentada los contenidos y el propósito de los textos escritos poniendo en
funcionamiento conocimientos externos al texto y previos a la lectura.

2.4.  Competencia específica 4. Expresión oral

Producir mensajes orales con coherencia, cohesión y adecuación, fluidez y corrección,
a través de diferentes soportes y situaciones de comunicación del ámbito familiar, social,
educativo o profesional.

2.4.1. Descripción de la competencia 4

La expresión oral constituye un instrumento de primer orden en el proceso
comunicativo, y su desarrollo implica la producción de mensajes orales estructurados
(coherencia), articulados (cohesión) y adaptados a la finalidad y al registro requerido para cada
situación comunicativa (adecuación).

El aprendizaje de esta competencia se centra tanto en la construcción del discurso,
como en el contenido lingüístico, el control de la norma y la pronunciación, así como en los
aspectos prosódicos que facilitan la comprensión del mensaje. Al mismo tiempo, requiere de
estrategias que garanticen el manejo de un léxico correcto, preciso y variado y del dominio
morfosintáctico, así como de las destrezas que favorecen la comprensión del discurso. Debido
al carácter inmediato y efímero que caracteriza la lengua oral, aspectos como, la fluidez, la
pronunciación, la entonación, los prosódicos y los recursos no verbales resultan indispensables
para reforzar la intención comunicativa.

La correcta adquisición de la expresión oral, además de tener en cuenta aspectos
léxicos, semánticos, fonológicos, morfosintácticos y no verbales, debe favorecer un uso del
lenguaje no discriminatorio, desterrando los abusos de poder a través de la palabra,
fomentando así la construcción de una sociedad más equitativa, democrática y responsable a
través de las prácticas comunicativas. Además, su desarrollo exige unos conocimientos
pragmáticos y socioculturales que sólo pueden aprenderse desde situaciones reales de
diferentes ámbitos, que irán aumentando el grado de complejidad y formalidad a través de
estrategias de planificación y el uso de diferentes soportes.

Para ello será fundamental la selección y contraste de información procedente de
diferentes fuentes de manera progresivamente autónoma, evaluando su fiabilidad y pertinencia
y evitando los riesgos de manipulación y desinformación, para comunicarla eficazmente,
adoptando un punto de vista crítico, personal, y respetuoso con la propiedad intelectual.

Los diferentes tipos de textos (narrativos, descriptivos, argumentativos, expositivos,
instructivos) constituyen el marco perfecto para el desarrollo de esta competencia. El texto es la
unidad básica de trabajo en el aula, por lo que las producciones orales no pueden desligarse
de los géneros textuales (cuento, fábula, noticia), que corresponden a las situaciones concretas
de comunicación. Dotados de una estructura y de unos contenidos lingüísticos, ofrecen un
aprendizaje más significativo y se integran fácilmente en el trabajo por proyectos y ámbitos.
Esta contextualización de los usos reales contribuirá a la reflexión, progresivamente autónoma,
sobre las elecciones lingüísticas y discursivas, y ayudará al aprendiz a desarrollar la conciencia
lingüística, a aumentar el repertorio comunicativo y a mejorar las destrezas de producción oral.

La evaluación a corto y largo plazo, la autoevaluación y el análisis de las propias
producciones, resultan herramientas fundamentales en la mejora del aprendizaje y para
propiciar la reflexión lingüística.

A pesar del carácter inmediato y espontáneo de la lengua oral, la correcta adquisición
de esta destreza es compleja y requiere de un proceso de aprendizaje sistemático y
continuado. La gestión de las emociones y el autocontrol serán fundamentales para consolidar
esta competencia.

Al término del primer ciclo de la etapa, se espera que el alumnado sepa utilizar el
lenguaje oral para expresar, describir, resumir, justificar, opinar, defender, argumentar, con

fluidez y espontaneidad, ideas, sentimientos, emociones, hechos, opiniones y conceptos,
teniendo en cuenta la situación comunicativa y aportando su propio punto de vista.

Al final de la etapa el alumnado debería ser capaz de realizar discursos orales
extensos y con un alto grado de formalidad. Éstos deberán ser adecuados, coherentes y
cohesionados, producirse con fluidez y corrección, y adaptarse a la finalidad que se persigue, a
la situación comunicativa y al destinatario. Para hacerlo el alumnado debería utilizar los
recursos que estén a su alcance para buscar y seleccionar la información a través de fuentes
fiables, contrastando los datos y aplicando el pensamiento crítico en sus producciones.

2.5. Competencia específica 5. Expresión escrita y multimodal

Producir textos escritos y multimodales coherentes, cohesionados, adecuados y
correctos empleando estrategias de planificación, textualización, revisión y edición.

2.5.1. Descripción de la competencia 5

Ser competente en expresión escrita conlleva saber utilizar el registro adecuado a la
situación comunicativa (adecuación), organizar las ideas con claridad (coherencia), enlazar los
enunciados en secuencias textuales cohesionadas (cohesión) y respetar las normas
gramaticales y ortográficas (corrección). Todo ello mientras se incrementa de manera paulatina
tanto la destreza de utilizar las palabras y estructuras precisas en los textos escritos como la
conciencia sobre la calidad, presentación, ética y creatividad de la propia expresión. En este
punto, cobra especial relevancia asegurar que el alumnado emplee un lenguaje no
discriminatorio siendo a su vez capaz de detectar y desterrar cualquier abuso de poder a través
de la palabra.

Asimismo, adquirir esta competencia específica implica considerar la escritura como un
proceso recursivo (individual o colaborativo) en el que siempre son necesarias estrategias de
planificación, textualización, revisión y edición y en el que se ponen en juego múltiples
conocimientos lingüísticos. Se trata, pues, de una escritura consciente y reflexiva, en la que el
uso es cardinal para el aprendizaje.

En este proceso escritor se encuadrará, por consiguiente, el estudio sistemático de la
lengua, siempre sustentado en la reflexión metalingüística e introduciendo progresivamente la
terminología
específica.
Se
estimulará
que
el
alumnado
reflexione
individual
o
colaborativamente, sobre la lengua a partir de sus propias producciones, siendo consciente de
cómo los cambios en los enunciados pueden mejorar sus textos, apreciando la utilidad del
conocimiento lingüístico, discursivo y textual explícito.  Ese recorrido desde la observación
hasta la generalización y sistematización necesitará acompañamiento del docente siendo,
además, el diálogo entre iguales una herramienta clave para este aprendizaje.

A través de una variedad de situaciones de escritura de creciente dificultad, los y las
estudiantes irán familiarizándose con un amplio abanico de géneros discursivos construyendo
una competencia que les permita producir textos de acuerdo a las convenciones
socioculturales, estructurales y lingüísticas.  De esta forma, nuestro alumnado podrá
desenvolverse en cualquier situación comunicativa de su vida personal, social, académica y
profesional.

En este sentido, en la actualidad, el modo de comunicarnos se ha transformado
desdibujándose la separación entre los distintos medios. Ahora contamos con muchos y
distintos recursos para construir significados que van más allá de lo verbal, por ello, esta
competencia específica incluye la creación de textos multimodales.

Dada la complejidad cognitiva de la actividad escritora, en la que se ponen en juego
multitud de conocimientos, el seguimiento del profesorado será imprescindible, así como la
retroalimentación oportuna y la utilización de herramientas de apoyo y ejemplos de escalonada

complejidad. Esta guía del docente será decisiva también para que, progresivamente, el
alumnado adquiera autonomía en la búsqueda y contraste de fuentes con el fin de, tras evaluar
su fiabilidad y pertinencia, puedan organizar, elaborar y trasladar dicha información a su texto
escrito siendo, además de críticos y éticos, respetuosos con la propiedad intelectual.

Al final del primer ciclo de la ESO, el alumnado tendría que ser capaz de escoger, de
entre los géneros discursivos trabajados, aquel que resulte adecuado a la situación
comunicativa teniendo en cuenta el objetivo que persigue y la audiencia a la que se dirige. A
continuación, el alumnado debería poder escribir, individualmente y de manera colaborativa, un
texto breve de acuerdo a las condiciones dadas y empleando, con instrumentos de ayuda y
guía del profesorado si es necesario, estrategias de planificación, textualización, revisión y
edición.

Finalmente, al término de la etapa y de manera autónoma, el alumnado sería capaz de
producir textos escritos y multimodales coherentes, cohesionados, adecuados y correctos
empleando, de manera autorregulada, estrategias de planificación, textualización, revisión y
edición.

2.6. Competencia específica 6. Interacción oral, escrita y multimodal

Interactuar de manera oral, escrita y multimodal, de forma progresivamente autónoma,
a través de textos de complejidad creciente de los ámbitos personal, social, educativo y
profesional, utilizando un lenguaje no discriminatorio y estrategias básicas  de comprensión,
expresión y resolución dialogada de conflictos, de forma síncrona y asíncrona.

2.6.1. Descripción de la competencia 6

La interacción oral, escrita y multimodal abarca la descodificación, la comprensión, la
interpretación y la expresión, propiciando la construcción de un discurso conjunto, que utilizará
los repertorios multilingües e interculturales del alumnado. La interacción supera la suma de las
competencias de comprensión y de expresión, ya que se utilizan estrategias colaborativas
como tomar el turno de palabra, cooperar y pedir aclaraciones para intercambiar información en
situaciones comunicativas de los ámbitos personal, social, educativo y profesional.

Esta competencia implica y promueve el trabajo en grupo, la colaboración y la
predisposición para comunicarse con otros, establecer vínculos personales y construir
conocimiento poniendo las prácticas comunicativas al servicio de la convivencia democrática.
Este proceso supone ser capaz de llegar a un entendimiento y llevar a cabo negociaciones de
manera dialogada, argumentada, empática, asertiva, correcta en las formas y respetuosa hacia
la diversidad asegurando la igualdad de derechos de todas las personas. En este sentido, el
alumnado debe manejar situaciones comunicativas, tanto en soportes analógicos como
digitales, a través de la etiqueta digital, los elementos verbales y los no verbales, haciendo uso
en todo momento de un lenguaje ético y no discriminatorio.

En Educación Secundaria el alumnado debe entender, seleccionar, analizar y expresar
información en textos orales, escritos y multimodales, de manera autónoma, sobre temas
complejos que se ajusten a la situación comunicativa y a los géneros discursivos del ámbito
personal, social, educativo y profesional, interactuando con el profesorado, con sus iguales,
con otros usuarios de la lengua o con otros textos.

Paralelamente, para ser competente en interacción oral, escrita y multimodal también
es necesario identificar y saber utilizar el registro adecuado a la situación comunicativa
(adecuación), organizar las ideas con claridad (coherencia), enlazar los enunciados en
secuencias textuales cohesionadas (cohesión) y respetar las normas gramaticales y
ortográficas (corrección). Asimismo, para la construcción del discurso, será necesario que el
alumnado consulte fuentes variadas, para seleccionar y contrastar información, evaluando su

fiabilidad y adoptando un punto de vista crítico y respetuoso con la propiedad intelectual.

A lo largo de esta etapa, el alumnado avanzará en autonomía para identificar,
seleccionar y utilizar elementos como la cortesía lingüística y la etiqueta digital, los elementos
verbales y no verbales de la comunicación y expresiones tanto predecibles como no
predecibles. Estrategias como el uso de la repetición, mantener un ritmo adecuado, tomar la
palabra, cooperar y pedir aclaraciones son esenciales en esta competencia. Asimismo, la
escucha activa, la deliberación argumentada, la resolución dialogada de conflictos y el respeto
serán fundamentales, puesto que contribuyen a la convivencia, a la cooperación, a la tolerancia
y a la comunicación eficaz.

Al final del primer ciclo de ESO, el alumnado utilizará estrategias de interacción oral de
acuerdo con la situación comunicativa para iniciar, mantener y cerrar el discurso; sobre
conocimientos del ámbito personal, social y educativo, utilizando estrategias para expresar
mensajes cohesionados, coherentes y adecuados con un vocabulario preciso.  La interacción
escrita y multimodal, incluirá situaciones de interacción síncronas y asíncronas, y favorecerá la
progresiva autonomía del alumnado.

Al término de la etapa, el alumnado deberá interactuar oralmente, con autonomía, y
cooperar con el interlocutor para facilitar el diálogo y, además, ofrecerá y pedirá aclaraciones,
implicándose activa y reflexivamente con una actitud dialogante y de escucha para la
construcción de un discurso común. Respecto a la interacción escrita y multimodal, el
alumnado deberá participar de manera autónoma en situaciones de interacción utilizando
diferentes soportes.

2.7. Competencia 7. Mediació oral, escrita y multimodal

Mediar entre interlocutores aplicando estrategias de adaptación, simplificación y
reformulación del lenguaje para procesar y transmitir información más elaborada, en
situaciones comunicativas de ámbito personal, social, educativo y profesional.

2.7.1.
Descripción de la competencia 7

La mediación es la actividad del lenguaje consistente en explicar y facilitar la
comprensión de mensajes o textos orales, escritos y multimodales entre interlocutores que no
comparten el mismo código. En este proceso se utilizan estrategias como la reformulación, la
adaptación o la simplificación del lenguaje, en consonancia con el objetivo, la situación y los
destinatarios de la comunicación.

En la mediación el alumno se reconoce como agente social encargado de crear
puentes, ayudando a construir y trasvasar significados, facilitando la comprensión y la
expresión de mensajes, y transmitiendo información general y específica de manera autónoma,
tanto en su propia lengua (mediación intralingüística), como entre otras lenguas (mediación
interlingüística).

La mediación lingüística responde a desafíos como la resolución de conflictos de
manera dialogada, el uso de repertorios lingüísticos personales procedentes de distintas
lenguas, o la valoración de la diversidad lingüística y cultural de su entorno. En este sentido, la
mediación lingüística supone el uso de estrategias y de conocimientos destinados a la
superación de barreras lingüísticas y culturales de forma cooperativa, la negociación de
significados, y el logro de un entendimiento entre los interlocutores de manera empática y
creativa.

En Educación Secundaria la mediación está orientada a procesar y reformular
información e ideas de textos orales, escritos y multimodales, sobre asuntos cotidianos, de
interés personal y público, utilizando tanto medios convencionales como virtuales, y
apoyándose de soporte visual. La medición también incluye estrategias discursivas como la

simplificación, la adaptación y la transformación del lenguaje; o el uso de gestos, repeticiones o
aclaraciones, todo ello de manera autónoma, responsable y constructiva.

La mediación en esta etapa incluye actividades como resumir, explicar datos,
parafrasear, tomar notas, interpretar, traducir textos mientras se participa en tareas
colaborativas que tienen como objetivo facilitar la interacción y el entendimiento cuando se
producen intercambios de información en entornos multilingües (L2-L2, L2-L1, L1-L2).

Para lograrlo, resulta fundamental la reflexión y el contraste tanto entre los elementos
lingüísticos y discursivos (L2-L2, L2-L1, L1-L2): fonética, gramática, sintaxis, vocabulario o
tipología textual; como también los extralingüísticos: lenguaje corporal, signos visuales, pausas,
ritmo y entonación.

Al término del segundo curso de la ESO, la mediación se realiza combinando el
repertorio lingüístico del alumnado, comunicando, describiendo y explicando conceptos a un
tercero, pudiendo para ello apoyarse en soportes analógicos o digitales. En este proceso se
pueden incorporar elementos lingüísticos y culturales en textos orales, escritos y multimodales
de los ámbitos personal, social y educativo. En este momento el alumnado debería ser capaz
de mediar entre lenguas (valenciano o castellano u otras), o dentro de una misma lengua
(valenciano o castellano), a partir de gráficos y de textos de una complejidad media con ayudas
muy puntuales.

Al finalizar la etapa, el alumnado ha de ser capaz de parafrasear y de reformular en la
L1 (valenciano o castellano) las comunicaciones, descripciones o explicaciones realizadas en
una L2 (valenciano o castellano u otras) sin tener siempre que recurrir a apoyos, e incorporar
elementos lingüísticos y culturales de los ámbitos personal, social, educativo y profesional. En
este momento el nivel de los discursos de partida puede ser de una complejidad creciente. En
toda la etapa se podría realizar mediación inversa: desde una L1 (valenciano o castellano u
otras) hacia una L2 (valenciano o castellano), en este caso se trataría de discursos de
complejidad baja o media.

2.8. Competencia 8. Lectura autónoma

Leer obras y textos de carácter diverso y de complejidad progresiva, seleccionados con
autonomía, reflexionando sobre el perfil lector que se va configurando.

2.8.1.
Descripción de la competencia 8

El fundamento de esta competencia específica es la motivación libre por la lectura,
desde el interés personal del alumnado, de forma que se genere hábito lector a partir de
experiencias lectoras positivas y placenteras.

La lectura autónoma favorece la ampliación del conocimiento sobre el mundo y la
interacción social con otros lectores para compartir las experiencias lectoras. El aprendiz tiene
que progresar en la habilidad y el gusto por las lecturas del ámbito social, académico, literario y
de los medios de comunicación, en tipologías y funciones diferentes y en formatos
multimodales, analógicos y digitales, en un grado de complejidad creciente. Como apoyo al
gusto por la lectura se generan contextos de diálogo, de debate, de intercambio de
experiencias, que retroalimentan el descubrimiento de nuevas lecturas. Son escenarios que el
profesorado tiene que facilitar a través del diseño de situaciones de aprendizaje que incentivan
el fomento lector y que incluyan actividades de compartición de las experiencias lectoras (foros
de lectores, tertulias y círculos de lectura) en diferentes formatos: oral, escrito y multimodal, en
contextos analógicos, y también digitales.

Los procesos de lectura ayudan a organizar las ideas y a distinguir los contenidos
relevantes. Permiten también el conocimiento y la aplicación de tipologías textuales y de
géneros discursivos a la práctica oral y escrita. El éxito en la competencia lectora es clave para

controlar el acceso a la información en los procesos de comprensión, reflexión e interpretación
y para mejorar la capacidad crítica. El aprendiz lee, reflexiona e interpreta a partir de las obras
y, además, comparte y socializa sus experiencias lectoras.

Los circuitos comunicativos actuales están estrechamente relacionados con las TIC;
como consecuencia, el conocimiento y la iniciación en el uso de aplicaciones de lectura, como
también las plataformas digitales e Internet, serán un entorno favorable y necesario para la
práctica lectora y el intercambio de experiencias lectoras.

Para mejorar la propia experiencia lectora y de asentar el hábito lector, se tendría que
estimular el uso de las bibliotecas, tanto las del ámbito educativo como las públicas. Además,
para ir configurando de manera progresiva un perfil lector entre el alumnado, habría que
fomentar también la creación de una biblioteca personal. Por otro lado, el desarrollo de la
personalidad, acompañado de un entorno en que la lectura es una actividad habitual y
placentera, aporta al aprendiz el bagaje cultural necesario para un aprendizaje a lo largo de la
vida.

Al final del primer ciclo, el alumnado tendrá que ser capaz de elegir los textos que
mejor se adaptan a sus gustos, intereses o necesidades, a partir de una selección previa, con
el fin de leerlos e incorporarlos a su itinerario lector.

Al finalizar la etapa, el alumnado tendrá que ser capaz de seleccionar y leer de manera
autónoma textos diversos, de diferentes ámbitos, partiendo de los intereses personales y
necesidades formativas, que marquen un avance en el interés por la lectura como placer. El
alumnado también tendrá que dejar constancia de su itinerario lector, con criterio, y tendrá que
compartir la propia experiencia lectora.

2.9. Competencia 9. Competencia literaria

Leer y producir textos literarios, contextualizados en la cultura y la sociedad, como
fuente de placer y de conocimiento.

2.9.1.
Descripción dela competencia 9

La competencia literaria aporta un gran potencial en el objetivo de lograr el hábito lector
de obras literarias, a lo largo de la vida, de los ámbitos formal y no formal. Tiene que orientarse
a la capacidad de lectura, comprensión, reflexión y producción de obras literarias, por medio de
los varios géneros (narrativa, poesía, teatro) y de la interpretación de obras que permitan
activar las emociones y conocer la literatura en valenciano, en castellano y universal, por medio
de autores y autoras de etapas cronológicas y movimientos literarios relevantes. Habría que
prever dos modalidades de lectura, la intensiva y la extensiva. La lectura intensiva focaliza más
el detalle para obtener informaciones y, como consecuencia, es más pausada y analítica; la
lectura extensiva sigue un ritmo más ágil, usa textos más extensos o completos, del interés del
alumno, y tiene un carácter más lúdico.

Se pretende dar sentido al conocimiento literario desde la contextualización de los
textos, en las implicaciones sociales, históricas y culturales, y en la intencionalidad, así como
en la experiencia biográfica de los autores. En la investigación de información sobre obras y
autores se evitará la focalización excesiva en la asimilación de datos, si no son relacionados
con el sentido o la intencionalidad de la obra.

Las propiedades y características del lenguaje literario tienen que ser incorporadas en
proporción productiva a las capacidades discursivas del alumnado. La producción de textos con
intencionalidad literaria también tiene que prever los géneros literarios principales, basándose
en modelos clásicos y actuales, en registros orales y escritos y multimodales.

La fusión de la literatura y el arte tiene que ser una experiencia de aula y fuera del aula,

en la cual entran en juego la música, el teatro, las artes plásticas y las escénicas. El alumnado
tiene que investigar, interpretar las conexiones y asumir roles creativos.

Habría que implicar recursos tecnológicos, redes digitales y multimedia que sean
enriquecedores para la recepción y la creación literaria.

La lectura es una práctica ligada a potenciar el aprovechamiento de las bibliotecas (de
aula, de centro, públicas) y a hacer del alumnado un usuario habitual y organizado en la
práctica de su uso.

El camino pedagógico del alumnado en la competencia literaria tiene que pautar-se a
partir de la guía del profesorado, desde la imitación de modelos y el versionado de los
diferentes géneros. El alumnado tendrá que enfrentarse a textos de nivel de complejidad
progresiva, tanto en la recepción como en la producción textual, hasta llegar a una autonomía
suficiente. Todo esto, en un proceso ascendente adaptado al ritmo de aprendizaje del
alumnado.

Al finalizar el primer ciclo de Secundaria, el alumno tendrá que leer e interpretar obras
literarias sencillas adecuadas a sus intereses; tendrá que aportar opinión desde la reflexión,
utilizando recursos retóricos y metalenguaje, y también tendrá que ser capaz de crear textos
literarios sencillos (cuentos, poemas breves, textos para la dramatización) aplicando los
recursos y elementos característicos de los géneros estudiados. Todo este proceso se
planificará de forma que se estimule una autonomía progresiva del alumnado. El alumnado
también tendrá que participar en representaciones teatrales y en espectáculos que incluyan la
recitación y la dramatización de textos.

Al finalizar la etapa de Secundaria, el alumno tendrá que ser capaz de leer,
comprender e interpretar obras literarias de manera autónoma, adecuadas en la edad (fábulas,
relatos, novelas breves, poemas, textos dramatizados), y de relacionar obras y autores dentro
de los contextos socioculturales, además de construir opinión sobre las obras. También tendrá
que crear textos literarios sencillos aplicando los recursos retóricos y estilísticos, y de organizar
y participar activamente en representaciones de recitación y de dramatización, de manera
autónoma y colaborativa, partiendo de apoyos y modelos.

3. Conexiones de las competencias específicas entre sí, con las competencias de otras
materias y con las competencias clave (para el conjunto de las competencias de la
materia).

4.1. Relaciones o conexiones con las otras CE de la materia

Las conocidas como destrezas lingüísticas básicas: expresión oral (CE4), expresión
escrita (CE5), comprensión oral (CE2) y comprensión escrita (CE3); así como de los complejos
procesos bidireccionales que ocasionan interacción (CE6) y mediación (CE7) coinciden de
manera natural en la comunicación. Si a ello le unimos el indiscutible potencial epistémico que
poseen, así como que la reflexión sobre la propia lengua subyace en toda el área, podemos
decir que, a grandes rasgos, la mayoría de competencias específicas de Valenciano: Lengua y
Literatura y de Lengua Castellana y Literatura están, de una u otra manera, muy relacionadas
entre sí.

En este sentido, conviene hacer hincapié en que la expresión oral/escrita constituye la
base para el desarrollo de las otras destrezas orales/escritas: interacción (CE6), mediación
(CE7), comprensión oral (CE2) y/o escrita (CE3). Además de compartir canal y características,
se complementan entre sí. No hay mediación o comprensión sin expresión. Y lo mismo sucede
con la interacción, porque en ella se activan de forma indisociable la expresión y la
escucha/lectura. En dos canales diferentes se trabajan habilidades parecidas ligadas a la

comprensión, la interpretación y la valoración de mensajes. En otras palabras, muchas de las
competencias específicas de la materia se necesitan unas a las otras para poderse desarrollar
plenamente y comparten los saberes básicos necesarios para lograrlo.

Respecto al resto de competencias específicas del área, la competencia multilingüe e
intercultural (CE1) requiere de la comprensión oral (CE2) y la comprensión escrita (CE3),
puesto que comprender supone un primer paso para familiarizarse con la diversidad lingüística
y cultural y evitar así los prejuicios lingüísticos. Pero, además, para valorar la diversidad
lingüística y cultural como fuente de riqueza cultural, es necesario adoptar una actitud activa,
por lo que guarda una estrecha relación con la expresión oral (CE4) y escrita (CE5) y la
interacción (CE6), puesto que estos usos de la lengua favorecen la reflexión interlingüística y el
uso de la función metalingüística del lenguaje. El desarrollo de esta competencia encuentra en
la lectura autónoma (CE8) y en la literatura (CE9) unas poderosas aliadas para acercar al
aprendiz a una lengua, a una cultura, a un contexto y a unas tradiciones de manera lúdica,
poniendo en valor la diversidad lingüística y cultural existente.

Así mismo, la lectura autónoma (CE8) y la competencia literaria (CE9) se empiezan a
desarrollar a través de la lectura (CE2), comprensión de textos literarios (CE3) y la expresión
oral (CE4). En las actividades de fomento lector se suelen realizar comentarios orales sobre las
lecturas, con lo cual se trabajan también a partir de la lectura: la expresión oral (CE4), la
interacción oral (CE6) y la mediación oral (CE7).

Finalmente, la competencia literaria (CE9) se asocia con las competencias lingüísticas,
porque necesita de la comprensión, de la expresión, de la interacción y de la mediación. Por
medio del potencial de la literatura, el alumnado desarrolla el resto de competencias para
comprender los textos literarios, los de tradición oral y los géneros escritos, para producir textos
con intención literaria y también para interactuar y mediar con otros individuos como
característica de la dimensión social de la literatura.

4.2. Relaciones o conexiones con las CE de otras áreas de la etapa

Las competencias específicas de expresión oral (CE4), expresión escrita (CE5),
comprensión oral (CE2), comprensión escrita (CE3) y la interacción (CE6) vertebran el proceso
de aprendizaje haciendo que estas se vinculen, de manera global e inherente, con las
competencias específicas del resto de materias lingüísticas y no lingüísticas. Así mismo, son
también clave para la gestión personal y emocional en la relación con los otros.

Por otro lado, la mediación lingüística (CE7) tiene relación con el resto de
competencias específicas del ámbito lingüístico puesto que la mediación entre diferentes
códigos hace que se activen los mecanismos de comprensión y de expresión propios de la
Competencia en comunicación lingüística y de la Competencia plurilingüe, y que se transfieran
conocimientos, tanto lingüísticos como socioculturales y pragmáticos mediante el uso
combinado de las diferentes lenguas del currículo.

Así mismo, la competencia específica en lectura autónoma (CE8) contribuye al
desarrollo de las competencias específicas del resto de áreas dado que la lengua escrita está
presente en todas las situaciones educativas, y por ello, la lectura se trabaja en todas las
áreas. En el resto de áreas lingüísticas se promueven, además, muchas transferencias
lingüísticas del alumnado de unas lenguas a las otras, partiendo de un enfoque comunicativo y
de un tratamiento integrado de lenguas.

Finalmente, alcanzar la competencia literaria (CE9) pasa por la vinculación con
disciplinas que no forman parte del área lingüística, pero que son partes del material para
edificarla. Conecta especialmente con Geografía e Historia, Música y Educación Plástica,
Visual i Audiovisual, Tecnología y Digitalización, Valores Cívicos y Éticos.

4.3. Relaciones o conexiones con las competencias clave

El cuadro adjunto muestra la existencia de una relación especialmente significativa y
relevante entre las 9 competencias específicas de esta área y la mayoría de las competencias
clave incluidas en el perfil de salida del alumnado al finalizar la educación básica. En todos los
casos la adquisición y el desarrollo de las competencias específicas señaladas contribuye a la
adquisición y al desarrollo de las competencias clave con las que aparecen estrechamente
vinculadas.

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE 1 Multilingüismo e interculturalidad | X | X |  | X | X | X | X | x |
| CE 2 Comprensión oral y multimodal | X | X |  | X | X | X |  |  |
| CE 3 Comprensión escrita y multimodal | X | X |  | X | X | X |  |  |
| CE 4 Expresión oral | X | X |  | X | X | X |  |  |
| CE 5 Expresión escrita y multimodal | X | X |  | X | X | X |  |  |
| CE 6 Interacción oral, escrita y multimodal | X | X |  | X | X | X | X |  |
| CE 7 Mediación oral, escrita y multimodal | X | X |  | X | X | X | X |  |
| CE 8 Lectura autónoma | X | X |  | X | X | X | X | X |
| CE 9 Competencia Literaria | X | X |  | X | X | X | X | X |

CCL: Competencia en comunicación lingüística
CP: Competencia plurilingüe
CMCT: Competencia matemática y competencia en ciencia y tecnología (STEM, por sus siglas
en inglés)
CD: Competencia digital
CPSA: Competencia personal, social y de aprender a aprender
CC: Competencia ciudadana
CE: Competencia emprendedora
CCEC: Competencia en conciencia y expresión culturales

En primer lugar, es necesario remarcar que la totalidad de competencias específicas de
la materia están indisolublemente conectadas con la Competencia en comunicación lingüística

(CCL) puesto que posibilitan, entre otros descriptores operativos del perfil de salida, la
expresión de sentimientos, hechos, opiniones y pensamientos y la comprensión de discursos y
de textos sencillos de varios ámbitos. Así mismo, también permiten el desarrollo de la lectura
de obras diversas y aseguran el respecto a la diversidad lingüística y cultural.

En segundo lugar, la Competencia multilingüe e intercultural (CE1) es fundamental
para el desarrollo de la Competencia plurilingüe (CP), puesto que para utilizar distintas lenguas
y reconocer los perfiles lingüísticos individuales es necesario valorar la diversidad lingüística
como una fuente de enriquecimiento.

En tercer lugar, la Competencia en interacción (CE6) se relaciona con la Competencia
personal, social y de aprender a aprender (CPSAA) dado que promueve el diálogo, los
debates, el trabajo en grupo y la distribución de tareas y responsabilidades de manera
equitativa a través de la cooperación para conseguir alcanzar una comunicación efectiva, así
como la comprensión proactiva de otras perspectivas y experiencias. De esta manera
contribuye a que el alumnado sea consciente de las propias emociones, ideas y
comportamientos personales empleando estrategias para gestionarlas en situaciones de
tensión o conflicto y adaptándose a los cambios y armonizándolos para alcanzar sus propios
objetivos.

En cuarto lugar, la Competencia en interacción (CE6) y la Competencia en mediación
(CE7) se vinculan con la Competencia ciudadana (CC) en tanto que realizan un papel
fundamental en la participación en actividades de grupo, en la toma de decisiones y en la
resolución de conflictos de forma constructiva y pacífica. También promueve la comprensión de
la propia identidad y las relaciones interculturales con la finalidad de establecer interacciones
comunicativas respetuosas, empáticas, igualitarias y constructivas.

4. Saberes básicos (para el conjunto de las competencias del área/materia)

4.1. Introducción

Los saberes básicos son aquellos conocimientos, destrezas y actitudes necesarios
para la adquisición de las diferentes competencias específicas de esta área.

Los saberes se organizan en tres bloques: Lengua y uso; Estrategias comunicativas; y
Educación literaria. Estos bloques generales se dividen en subbloques de saberes y, en
algunos casos, también en grupos de saberes bajo un mismo subbloque. Esta distribución
permite observar mejor las relaciones disciplinares entre los saberes. Estas relaciones de tipo
disciplinar se completan con unas indicaciones sobre la vinculación de los diferentes bloques,
subbloques y grupos de saberes con las diferentes competencias específicas del área. La
gradación de los saberes vendrá marcada por los criterios de evaluación establecidos.

En cada uno de los bloques y subbloques se disponen los contenidos básicos de
manera ordenada, siguiendo un orden de más concreto a más general; también se sugiere el
ritmo de adquisición a lo largo de la etapa, especialmente al final del segundo y del tercer ciclo.
En cualquier caso, el orden de disposición de los tres bloques de contenidos básicos no denota
en ningún caso, ni una posición jerárquica, ni sugiere un trabajo separado de los saberes de
cada apartado. Antes al contrario, los diferentes saberes básicos de los tres bloques se tienen
que combinar entre sí en el momento del diseño de las situaciones de aprendizaje. Esta
elección y combinación de los contenidos vendrá determinada por las competencias
específicas involucradas en cada práctica de aula concreta que los docentes planifiquen.

Estos bloques de saberes tienen una correspondencia en el área de lengua extranjera,
de forma que se puedan organizar para trabajar las competencias específicas de las diferentes
lenguas de una forma integrada. Así se prepara el terreno para que se puedan planificar
situaciones de aprendizaje que incluyan las diferentes lenguas del currículum. El objetivo final

de esta organización es que el alumnado pueda desarrollar de una manera coherente la
competencia en comunicación lingüística y la competencia plurilingüe, siguiendo los principios
de la competencia plurilingüe global.

4.2. Bloque 1: Lengua y uso

El primer bloque, Lengua y uso, recoge todos aquellos saberes que tienen que ver con
la lengua en relación con suyo uso social, desde la biografía lingüística y el mapa lingüístico del
aula, hasta la diversidad lingüística y los prejuicios lingüísticos presentes a la sociedad. Este
bloque abraza, pues, de una manera progresiva a lo largo de la etapa, los contenidos básicos
sobre elementos extralingüísticos que resultan fundamentales para la comunicación en
sociedades plurilingües y multiculturales: la diversidad lingüística en el entorno inmediato y
global, la situación social de las diferentes lenguas en contacto, la relación entre las lenguas y
los poderes, o los elementos culturales que configuran y determinan los usos lingüísticos.

En esta etapa la biografía lingüística se amplía a las experiencias personales en
entornos diferentes: familia, barrio, ciudad, viajes, redes sociales e Internet, lecturas, cine,
música. En cuanto a la reflexión sobre la diversidad lingüística, en primero y segundo, se
profundiza en la diversidad en el Estado español y Europa y en segundo y tercero se llega a
hasta una aproximación muy básica a las lenguas del mundo. La reflexión interlingüística se
relaciona de manera especial con la competencia específica de Mediación, se empieza por la
reflexión a partir de experiencias de análisis contrastivo entre las lenguas del currículum en el
contexto de situaciones de intercambios comunicativos plurilingües; en primero y en segundo
en usos y en discursos de poca complejidad, en tercero y en cuarto se puede elevar
ligeramente el grado de complejidad del análisis contrastivo. El lenguaje no discriminatorio y
respetuoso se amplía en esta etapa a todas las situaciones en que se despliegan las
competencias específicas de expresión, interacción y mediación; especialmente a los contextos
sociales en primero y segundo; y también los profesionales en tercero y cuarto. El repertorio de
las expresiones idiomáticas se amplía en secundaria más allá de los usos coloquiales y de la
variedad más próxima, hasta los usos generales y estándares y más formales y literarios en
tercero y en cuarto.

| Las lenguas y sus hablantes: CE1, CE4, CE5, CE6 y CE7 | CICLO |  |
| --- | --- | --- |
|  | 1º (Cursos 1º y 2º) | 2º (Cursos 3º y 4º) |
| • Biografía lingüística personal. Diversidad lingüística del entorno | X | X |
| • Plurilingüismo, las familias lingüísticas y las lenguas del mundo | X | X |
| • Variación lingüística |  | X |
| • Las lenguas de España | X |  |
| • Desarrollo sociohistórico de las lenguas de España | X | X |
| • Aproximación a las lenguas de signos |  | X |
| • Reflexión interlingüística | X | X |
| • Estrategias de identificación de prejuicios y estereotipos lingüísticos y exploración de formas de evitarlos | X |  |
| • Estrategias de exploración y cuestionamiento de prejuicios y estereotipos lingüísticos. Fenómenos del contacto entre lenguas. |  | X |
| • Derechos lingüísticos y su expresión en leyes y |  | X |

| declaraciones institucionales. |  |  |
| --- | --- | --- |
| • Lenguaje no discriminatorio y respetuoso con las diferencias. | X |  |
| • Expresiones idiomáticas de la lengua | X | X |

•
Expresiones idiomáticas de la lengua
X
X

4.3. Bloque 2: Estrategias comunicativas

El segundo bloque, Estrategias comunicativas, reúne las diferentes estrategias y
destrezas vinculadas a los procesos de producción, recepción, interacción y mediación. En este
bloque encontramos seis subbloques de saberes básicos. Los subbloques 2.1, 2.2 y 2.3 son
transversales, puesto que se trabajan en todas las competencias comunicativas; y en los
subbloques 2.4, 2.5 y 2.6 se encuentran los saberes sobre cada destreza básica. Además, se
incluyen en este apartado aquellos aspectos actitudinales, axiológicos y emocionales que están
presentes transversalmente en todos los intercambios comunicativos y que pueden determinar
su éxito o su fracaso.

Se tiene en cuenta también en este bloque todos aquellos saberes necesarios para una
adecuada reflexión lingüística sobre las estructuras lingüísticas y su uso. Se empieza por los
sonidos, las grafías y los gestos y se acaba en los niveles textual y pragmático. El análisis y la
progresiva reflexión sobre las convenciones ortográficas, la ortofonía y la ortoepia, las
estructuras gramaticales, las tipologías y los géneros textuales, tiene que ir siempre asociada a
la mejora de la recepción y de la producción discursiva.

La gradación de los saberes básicos de este bloque dependerá en primera instancia
del tipo de situación comunicativa en que se encuentre involucrado el alumnado. En segundo
lugar dependerá también de la experiencia previa del alumnado, de su grado de maduración
personal, y del repertorio de recursos lingüísticos y de estructuras comunicativas que sea
capaz de movilizar en cada momento de la etapa y en cada situación comunicativa concreta. El
grado de cohesión discursiva, por ejemplo, dependerá de los mecanismos lingüísticos y
textuales que el alumnado sea capaz de manejar y del nivel de complejidad textual de los
discursos. El acompañamiento docente, los andamiajes y los modelos facilitados al alumnado
en los primeros niveles disminuyen a lo largo de la etapa a medida que el alumnado avanza en
la adquisición de autonomía.

El trabajo relacionado con los diferentes tipos de textos y géneros discursivos, tanto en
lo que respecta a la estructura como a las características lingüísticas, se planifica a lo largo de
la etapa, y cada nivel desarrolla las tipologías textuales y géneros discursivos que mejor
encajan en las situaciones de aprendizaje propuestas.

En cuanto a la reflexión lingüística, en este etapa va siempre unida a los procesos de
uso y de recepción y no es todavía una finalidad en sí misma. Mediante la reflexión se
consolida de manera progresiva la conciencia lingüística del alumnado para mejorar las
destrezas comunicativas asociadas a las diferentes competencias específicas del área. En esta
etapa se amplía progresivamente el uso del metalenguaje en los momentos de reflexión
lingüística y se profundiza en tercero y en cuarto. En cualquier caso, el dominio más completo
del metalenguaje se continúa en la etapa de bachillerato.

| Sub-bloque 2.1 Saberes comunes: CE2, CE3, CE4, CE5, CE6 y CE7 | CICLO |  |
| --- | --- | --- |
|  | 1º (Cursos1º y 2º) | 2º (Cursos 3º y 4º) |
| • Estrategias para adaptar el discurso a la situación comunicativa: grado de formalidad y carácter público o privado; distancia social entre los interlocutores; propósitos comunicativos e interpretación de intenciones; canal de comunicación y elementos no verbales de la comunicación | X | X |
| • Tipologías textuales y géneros discursivos | X | X |
| • Géneros discursivos propios del ámbito profesional: el currículum vitae, la carta de motivación y la entrevista de trabajo |  | X |
| • Propiedades textuales: coherencia, cohesión y adecuación | X | X |
| • Estrategias de detección y uso de un lenguaje verbal e icónico no discriminatorio | X | X |
| • Estrategias de reflexión sobre el proceso de aprendizaje, autoevaluación y autocorrección | X | X |
| • Estrategias de gestión de las emociones en la comunicación |  | X |

| Sub-bloque 2.2 Alfabetización informacional: transversal a todas las CE | CICLO |  |
| --- | --- | --- |
|  | 1º (Cursos 1º y 2º) | 2º (Cursos 3º y 4º) |
| • Redes sociales y medios de comunicación. Etiqueta digital. Riesgos de desinformación, manipulación y vulneración de la privacidad en la red. | X | X |
| • Hábitos y conductas para la comunicación segura en entornos virtuales. | X | X |
| • Análisis de la imagen y elementos paratextuales de los textos icónico-verbales y multimodales. | X | X |
| • Usos de la escritura para la organización del pensamiento: notas, esquemas, mapas conceptuales, resúmenes, etc. | X | X |
| • Estrategias de búsqueda en fuentes documentales diversas y con distintos soportes y formatos con criterios de fiabilidad, calidad y pertinencia. | X | X |
| • Estrategias de uso y tratamiento de fuentes documentales diversas. | X | X |
| • Uso de modelos para analizar, valorar, reorganizar y sintetizar la información en esquemas propios. | X | X |
| • Comunicación y difusión creativa y respetuosa con la propiedad intelectual. | X | X |

| • Utilización de la biblioteca y de los recursos digitales. | X | X |
| --- | --- | --- |
| • Herramientas digitales para el trabajo colaborativo y la comunicación. | X | X |

| Sub-bloque 2.3 Reflexión sobre la lengua: CE1, CE2, CE3, CE4, CE5 y CE7. | CICLO |  |
| --- | --- | --- |
|  | 1º (Cursos 1º y 2º) | 2º (Cursos 3º y 4º) |
| • La implicación del emisor en los textos. | X | X |
| • La expresión de la subjetividad en textos. |  | X |
| • Adecuación del registro a la situación de comunicación. | X | X |
| • Cohesión: Conectores textuales temporales, explicativos, de orden y de contraste, distributivos, causa, consecuencia, condición e hipótesis. | X | X |
| • Cohesión: Mecanismos de referencia interna gramaticales (sustituciones pronominales) y léxicos (nominalizaciones e hiperónimos de significado abstracto, sinónimos, repeticiones y elipsis). | X | X |
| • Uso coherente de las formas verbales en los textos. | X | X |
| • Correlación temporal en la coordinación y subordinación de oraciones. | X | X |
| • Corrección lingüística y revisión ortográfica y gramatical de los textos. | X | X |
| • Uso de diccionarios, manuales de consulta y de correctores en soporte analógico o digital. | X | X |
| • Los signos de puntuación como mecanismo organizador del texto escrito. Su relación con el significado. | X | X |
| • Observación, comparación y manipulación de estructuras lingüísticas. | X | X |
| • Estrategias para el contraste y la transferencia entre las lenguas. | X | X |
| • Diferencias e intersecciones entre lengua oral y lengua escrita en situaciones comunicativas. | X | X |
| • La lengua como sistema y sus unidades básicas. | X | X |
| • Formas gramaticales y funciones sintácticas. | X | X |
| • Relación entre los esquemas semántico y sintáctico de la oración simple. Observación y transformación de enunciados y uso de la terminología sintáctica. | X | X |
| • Procedimientos léxicos (afijos) y sintácticos para el cambio de categoría gramatical. | X | X |
| • Procedimientos de adquisición y formación de palabras: los cambios en su significado. | X | X |

| • Las relaciones semánticas entre palabras y sus valores en función del contexto y el propósito comunicativo. | X | X |
| --- | --- | --- |

| Sub-bloque 2.4 Comunicación e interacción oral | CICLO |  |
| --- | --- | --- |
|  | 1º (Cursos 1º y 2º) | 2º (Cursos 3º y 4º) |
| G1: Comprensión oral: C2, C6 y C7 |  |  |
| • Estrategias de comprensión oral: sentido global del texto y relación entre sus partes, selección y retención de la información relevante | X | X |
| • Valoración de la forma y el contenido del texto | X | X |
| G2: Expresión oral: C4, C6 y C7 |  |  |
| • Discursos orales en situaciones comunicativas de carácter formal | X | X |
| • Rasgos discursivos y lingüísticos de la oralidad formal. Deliberación oral argumentada |  | X |
| • Adecuación a la audiencia y al tiempo de exposición | X | X |
| • Planificación, producción y revisión de textos orales y multimodales | X | X |
| • Rasgos discursivos y lingüísticos de la oralidad formal | X | X |
| • Estrategias de expresión oral: interpretación y uso de elementos de la comunicación no verbal | X | X |
| G3: Interacción oral: C6 y C7 |  |  |
| • Estrategias de escucha activa, asertividad y resolución dialogada de los conflictos, teniendo en cuenta la perspectiva de género | X | X |
| • Interacciones orales en situaciones comunicativas de carácter formal e informal | X | X |
| • Estrategias de cortesía lingüística y cooperación conversacional | X | X |

| Sub-bloque 2.5 Comprensión escrita: C3, C6 y C7 | CICLO |  |
| --- | --- | --- |
|  | 1º (Cursos 1º y 2º) | 2º (Cursos 3º y 4º) |
| • Estrategias de comprensión antes de la lectura: conocimientos previos, objetivos de lectura, hipótesis a través de información paratextual, tipología, género y estructura del texto. | X | X |
| • Estrategias de comprensión durante la lectura: coherencia interna del texto, inferencias, sentidos figurados y significados no explícitos. | X | X |
| • Estrategias de comprensión después de la lectura: tema, | X | X |

| tesis, idea principal, argumentos, intención del autor y organización del contenido. |  |  |
| --- | --- | --- |
| • Valoración de la forma y el contenido del texto. | X | X |

| Sub-bloque 2.6 Expresión escrita y multimodal: C5, C6 y C7 | CICLO |  |
| --- | --- | --- |
|  | 1º (Cursos 1º y 2º) | 2º (Cursos 3º y 4º) |
| • Estrategias del proceso de escritura y multimodal: planificación, textualización, revisión y corrección. | X | X |
| • Aplicación de las normas ortográficas y gramaticales. Propiedad léxica. | X | X |
| • Presentación cuidada de las producciones escritas. | X | X |
| • Elementos gráficos y paratextuales. | X | X |
| • Interacciones escritas en situaciones comunicativas de carácter formal e informal. | X | X |

4.4. Bloque 3: Lectura i literatura

El tercer bloque, Lectura y literatura, reúne los saberes básicos necesarios para el
desarrollo de la competencia literaria. Contenidos relativos a las convenciones poéticas y
genéricas; sobre elementos retóricos, narratológicos o teatrales; conocimientos sobre la
tradición literaria, más o menos complejos según la etapa o el ciclo; y también relaciones entre
la literatura y otras manifestaciones artísticas. Este apartado está dividido en dos subbloques.
El primero se centra en la lectura autónoma y en la construcción de la identidad lectora; y el
segundo, en la literatura.

La identidad lectora en esta etapa evoluciona progresivamente hacia la autonomía
lectora completa en cuarto. El alumnado se capaz de reconocer sus gustos, intereses y
necesidades personales de lectura y elige las lecturas de manera autónoma o buscando
consejos expertos. El alumnado es capaz también de compartir sus experiencias lectoras con
recursos expresivos cada vez más complejos y matizados a lo largo de la etapa. En primero y
en segundo relaciona las lecturas con las experiencias biográficas y las propias emociones; y
en tercero y en cuarto es capaz de relacionar también experiencias de tipo cultural. Los
soportes en los que puede compartir sus experiencias lectoras se amplían también al ámbito
digital a lo largo de la etapa.

En el subbloque 3.2 se reúnen las estrategias de comprensión, interpretación y
producción de textos y obras literarias; la relación entre los textos literarios y otros textos y
manifestaciones artísticas y culturales; y el conocimiento de las estructuras y de los aspectos
formales de los géneros, aplicado con progresiva autonomía.

Se emplean estrategias compartidas en la interpretación de las obras y se incorpora
información sociohistórica procedente de fuentes diversas. Estos saberes se vinculan con otras
materias de la etapa que aportan los conocimientos necesarios para relacionar el contexto o
bien que pueden ayudar a contextualizar hechos históricos o movimientos artísticos vinculados
a las obras. En cualquier caso, el establecimiento de relaciones entre las obras literarias y el
contexto sociohistórico se reserva para tercero y para cuarto, pero de una manera básica; este

tipo de análisis se amplía y se profundiza en la etapa de bachillerato.

Por otro lado, en los cursos de primero y de segundo se continúa con la compartición
de experiencias emocionales y de opiniones vinculadas a la lectura de textos literarios. Se
reserva para tercero y para cuarto la iniciación a la comprensión y la interpretación más
profunda de los textos literarios. En toda la etapa se estimula la reflexión sobre los referentes
culturales, éticos y no discriminatorios a partir de la lectura de textos literarios; se reserva para
tercero y para cuarto la profundización en una perspectiva de lectura crítica más estructurada.

En cuanto al uso del metalenguaje de los estudios literarios por parte del alumnado,
hay una progresividad a lo largo de la etapa. Se domina y se emplea un repertorio de formas
más reducido en primero y en segundo curso, que se amplía en tercero y en cuarto en
contextos de lectura y de interpretación más complejos.

| Sub-bloque 3.1 Hábito lector: CE8 | CICLO |  |
| --- | --- | --- |
|  | 1º (Cursos 1º y 2º) | 2º (Cursos 3º y 4º) |
| • Identidad lectora: selección de obras variadas y lectura autónoma, conciencia y verbalización de los propios gustos. | X | X |
| • Identidad lectora: valoración crítica de los textos y sobre la propia práctica de lectura. | X | X |
| • Expresión de la experiencia lectora y de diferentes formas de apropiación y recreación de los textos leídos. | X | X |
| • Uso de la biblioteca escolar y pública. Circuito literario y lector. Participación en actos culturales. | X | X |
| • Estrategias para la recomendación de las lecturas. | X | X |

| Sub-bloque 3.2 Literatura: CE9 | CICLO |  |
| --- | --- | --- |
|  | 1º (Cursos 1º y 2º) | 2º (Cursos 3º y 4º) |
| • Obras relevantes de la literatura juvenil contemporánea y del patrimonio literario universal, inscritas en itinerarios temáticos o de género, que incluyan la presencia de autoras y autores. | X |  |
| • Obras relevantes del patrimonio literario nacional y universal y de la literatura actual inscritas en itinerarios temáticos o de género, que incluyan la presencia de autoras y autores. |  | X |
| • Estrategias de construcción compartida de la interpretación de las obras. Conversaciones literarias. | X | X |
| • Lectura y comprensión de textos literarios: estructura, aspectos formales, recursos estilísticos y retóricos. | X | X |
| • Estrategias de utilización de información sociohistórica, cultural y artística básica para construir la interpretación de las obras literarias. | X | X |

| • Relación y comparación de los textos leídos con otros textos y manifestaciones artísticas y culturales, y con las nuevas formas de ficción en función de temas, tópicos, estructuras y lenguajes. | X |  |
| --- | --- | --- |
| • Relación y comparación de los textos leídos con otros textos, orales, escritos o multimodales, y manifestaciones artísticas y culturales, y con las nuevas formas de ficción en función de temas, tópicos, estructuras y lenguajes. Elementos de continuidad y ruptura. |  | X |
| • Estrategias, modelos y pautas para la expresión de la interpretación y la valoración personal de obras y fragmentos literarios. Lectura con perspectiva de género. | X |  |
| • Estrategias para interpretar obras y fragmentos literarios atendiendo a los valores culturales, éticos y estéticos presentes en los textos. Lectura con perspectiva de género. |  | X |
| • Lectura expresiva, dramatización y recitación de los textos atendiendo a los procesos de comprensión, apropiación y oralización implicados. | X | X |
| • Planificación y creación de textos a partir de la apropiación de las convenciones del lenguaje literario y en referencia a modelos dados (imitación, transformación, continuación). | X | X |

5. Situaciones de aprendizaje para el conjunto de las competencias del área/materia

Comunicarse de manera eficaz y respetuosa a través del lenguaje es una habilidad
esencial para la vida en el siglo XXI, aún más si cabe debido a los nuevos retos que suma, a
ritmo apresurado, la cultura digital. Se trata de alcanzar, al completar la educación secundaria,
un uso consciente del lenguaje que permita al alumnado participar en las prácticas discursivas
de la esfera personal, social, educativa y profesional. Y participar, además, de forma apropiada,
eficaz y respetuosa tanto con ellos y ellas mismas, como con sus interlocutores. Para lograrlo,
resultará imprescindible utilizar las estrategias pedagógicas y didácticas que aseguren que los
aprendizajes tienen sentido y valor personal para nuestros alumnos y alumnas.

Así mismo, estas situaciones de aprendizaje deberían contemplar no solo los usos
lingüísticos en los contextos de educación formal sino todos aquellos contextos de actividad a
los que nuestro alumnado tiene acceso y que le suponen oportunidades de aprendizaje. Hay
que tener en cuenta del mismo modo las diferentes esferas de la vida en que se proyectan las
competencias específicas de esta materia: el espacio personal, el social y el escolar. El aula se
tiene que abrir a la comunidad educativa y al entorno del centro educativo.

En toda la etapa, como paso previo al planteamiento didáctico, e incorporando los
principios del diseño universal, tendremos que asegurarnos de que no existen barreras que
impidan la accesibilidad física, cognitiva, sensorial y emocional de nuestro alumnado con el fin
de asegurar su participación y aprendizaje. En el caso de las lenguas oficiales, habrá que
analizar también si son o no las lenguas familiares del alumnado a la hora de plantear las
situaciones, para programar las propuestas de manera contextualizada y con los andamios
necesarios aprovechando al mismo tiempo la extraordinaria riqueza de la diversidad lingüística,
cultural o humana. Así mismo, en cada contexto sociolingüístico se tienen que promover
transferencias entre diferentes lenguas para comprender y producir mensajes y textos.

Las situaciones de aprendizaje promoverán que el alumnado consiga afianzar su
autonomía mientras desarrolla estrategias que le resultarán útiles mucho más allá del aula.

Para ello, es fundamental que la práctica sea frecuente y que cuente, además, con
retroalimentación constante tanto por parte del profesorado como de sus iguales. Esto
favorecerá, además, la consideración del error como una parte natural y necesaria del
aprendizaje.

Los objetivos serán exigentes, pero alcanzables modulando la dificultad si es
necesario. En este sentido, es esencial que el alumnado los conozca y tenga clara la finalidad
de la tarea, puesto que esto que le permitirá focalizar la atención en el objetivo y activar, con
ayuda del profesorado, sus conocimientos previos. Así, las situaciones de aprendizaje deberán
suponer un desafío, pero adaptándose siempre a las características del alumnado al cual van
dirigidas incluyendo distintos soportes y formatos tanto analógicos como digitales.

Los y las estudiantes construirán su aprendizaje mientras reflexionan, de manera
progresivamente autónoma y con textos cada vez más complejos, sobre las estructuras
comunicativas, los conocimientos lingüísticos, los usos convencionales, las estrategias, las
actitudes y los sentimientos implicados en las tareas lectoras, escritoras, de interacción, o de
mediación. En este sentido, podremos favorecer el procesamiento de la información si
programamos con distintos niveles de complejidad cognitiva, utilizando estrategias y
metodologías adecuadas.

Las situaciones de aprendizaje deberán ser variadas y auténticas partiendo de un
problema o necesidad que se quiere resolver y que tiene, por una parte, sentido en el mundo
real y, por otro, conexión con las experiencias e intereses del alumnado. Es decir, deben ser
situaciones comunicativas reales, con función social, y significativas para el alumnado tomando
el profesorado un rol de facilitador. Las prácticas discursivas en contextos laborales tendrían
que trabajarse en el segundo ciclo de la ESO como parte de la orientación educativa y
profesional del alumnado. Esta diversidad de situaciones contribuirá a desarrollar mentes
complejas capaces de crear soluciones creativas y colectivas, y proporcionará al alumnado las
bases necesarias para afrontar los retos que encontrará en el futuro. De manera transversal, se
fomentará la curiosidad y la aceptación positiva de la diversidad lingüística, cultural y humana
del entorno y general.

El papel determinante de las competencias específicas de la materia para afrontar los
desafíos del siglo XXI los convierte en un excelente marco para el diseño de situaciones de
aprendizaje con el objetivo de capacitar a nuestro alumnado a tomar la palabra en el ejercicio
de una ciudadanía activa y comprometida.

Las situaciones de aprendizaje movilizarán al mismo tiempo diversas competencias
específicas interrelacionándolas. Escuchar un mensaje oral o leer un texto puede ser el inicio
de una secuencia didáctica que pone en marcha otras muchas destrezas: conversar, escribir,
mediar u otras. Así mismo, el trabajo interdisciplinar en las distintas materias resulta
fundamental para que el alumnado conozca y trabaje tanto las destrezas lingüísticas como los
géneros discursivos propios de los distintos campos. En este sentido, el proyecto lingüístico de
centro marcará, entre otros aspectos, los acuerdos metodológicos y de organización y apoyo
relacionados con el uso y enseñanza de las lenguas, y también indicará en qué lengua se
imparten determinadas áreas o materias para poder planificar situaciones de aprendizaje
interdisciplinares.

Las metodologías activas promoverán el trabajo individual, así como la interacción,
colaboración y cooperación entre iguales, favoreciendo que el alumnado tome más decisiones
sobre los objetivos, la planificación del proceso y la evaluación. Estas situaciones incorporarán
de manera paralela la gestión de las emociones: clima de confianza, seguridad afectiva,
empatía, cooperación emocional, mediación.

Las actividades de lectura tienen que ir encaminadas a promover el fomento de la

lectura y a la mejora de la competencia lectora, combinando los diferentes objetivos: leer para
aprender y leer por placer. Hay que diseñarlas teniendo en cuenta el plan de fomento lector del
centro y el uso de las bibliotecas de aula, de centro y virtuales, como parte del proceso de
aprendizaje en cuanto al tratamiento de la información.

El aprendizaje de la lengua y la literatura transciende a la escuela, por lo que es
necesario generalizar los aprendizajes. Así pues, las situaciones deben dar respuesta a las
diferentes situaciones comunicativas, ya que el uso de la lengua varía según las necesidades
del contexto, que es el que determina tanto la forma como el contenido. Por ello, los textos, en
cuanto a géneros discursivos, han de ser tenidos en cuenta, por una parte, como práctica
discursiva de una esfera de actividad social y, por otra, como una construcción con unas
características específicas.  En cualquiera de los contextos, de manera transversal y continua,
se favorecerá el uso de un lenguaje no discriminatorio y se entrenará la detección y rechazo de
los usos sexistas y racistas y los abusos de poder a través de la palabra.

A) Contexto personal: es fundamental diseñar situaciones que tengan conexión con las
experiencias personales del alumnado e impliquen la expresión oral de sentimientos, vivencias,
opiniones y hechos en un clima de confianza, respeto, escucha, afectividad, empatía,
cooperación y mediación. Estas situaciones incidirán en las vivencias para posteriormente dar
paso a los aspectos formales (forma, planificación, acción y retroacción), utilizando para ello
diferentes soportes (físicos y digitales).

B) Contexto social: se deben diseñar situaciones que promuevan la cooperación y la
participación del alumnado tanto en la vida del centro como en su entorno local. Se fomentará
el compromiso ciudadano y la resolución pacífica de los conflictos a través del lenguaje, así
como el desarrollo de sentimientos de empatía y compasión, aportando los recursos necesarios
para actuar ante situaciones de inequidad y exclusión. Para ello es necesario ofrecer
situaciones que ayuden a corregir los desequilibrios entre las lenguas oficiales, y ayuden a
valorar los beneficios del plurilingüismo para el desarrollo personal y social, tanto desde una
perspectiva del entorno local como desde un análisis más global.

Así mismo, se reflexionará sobre problemas éticos fundamentales y de actualidad
favoreciendo el desarrollo del pensamiento crítico de los y las estudiantes y asegurando una
actitud dialogante y respetuosa.  La utilización de las TIC nos permitirá, entre otros aspectos,
trasladar de manera casi inmediata los discursos del ámbito social al aula y viceversa.

C) Contexto educativo: las situaciones deben propiciar que el alumnado emplee la lengua para
vehicular los distintos conocimientos que establece el currículum a través definir, describir,
enunciar, explicar, demostrar, aplicar y practicar. Pero, sobre todo, estas situaciones han de
fomentar una actitud más activa del aprendiz, usando el lenguaje para analizar, diseñar, crear y
evaluar lo que dice, escribe y hace. Este carácter crítico y reflexivo le ayudará a tomar
conciencia de lo aprendido y a conocerse a sí mismo como aprendiz, valorando la necesidad
de entender la realidad para poder desenvolverse en ella con autonomía, y desarrollando las
habilidades que le permitirán seguir aprendiendo a lo largo de la vida. Así pues, estas
situaciones promoverán en el alumnado la autoevaluación y el autoconocimiento sobre su
proceso de aprendizaje.

En este contexto se fomentará el uso de soportes digitales, incidiendo en el
aprovechamiento crítico, ético y responsable de la cultura digital.

D) Contexto profesional: a partir del segundo ciclo de ESO, las situaciones de aprendizaje se
abrirán a aquellos contextos que el alumnado pueda encontrar al acabar la educación
obligatoria, tanto en relación con documentos administrativos propios de la vida adulta, como a
textos relacionados con el ámbito laboral. Para ello, se pondrán en relieve las habilidades
discursivas incidiendo tanto en aspectos verbales como no verbales.

Respecto a las situaciones de evaluación, cualquier expresión del conocimiento del
alumnado es evaluable, es decir, las propias situaciones de aprendizaje nos aportarán los
datos que facilitan un adecuado seguimiento del proceso de enseñanza-aprendizaje. Por ello,
el papel de la evaluación es esencial y deberá estar presente en toda situación de aprendizaje
destacando su dimensión formativa y formadora teniendo especial relevancia la autoevaluación
y la coevaluación.

En este sentido, es imprescindible diseñar unos instrumentos de evaluación adecuados
y variados que faciliten el seguimiento por parte del profesorado y la reflexión y la
autorregulación del alumnado. Entre los instrumentos de evaluación estarían los dosieres de
aprendizaje; las rúbricas; las listas de comprobación: la grabación y la revisión de las
producciones discursivas; los cuadernos de campo; los diarios de trabajo; el cuaderno de
trabajo en el laboratorio; las exposiciones orales; los ensayos escritos; las entrevistas; o los
debates. En todo caso, las situaciones de evaluación deberán promover que el alumnado
exprese su conocimiento utilizando diferentes vías, orales, escritas, gráficas y audiovisuales.

Finalmente, respecto a la evaluación sumativa, se deberá tener siempre en cuenta la
accesibilidad en la presentación, los tiempos y los ritmos, y habrá que ajustarse en cada caso,
a las características y necesidades del alumnado.

6. Criterios de evaluación

6.1. Competencia específica 1. Criterios de evaluación

CE1. Multilingüismo e interculturalidad

| 2º de ESO | 4º de ESO |
| --- | --- |
| 1.1. Identificar y valorar las lenguas de España y del mundo, y las variedades lingüísticas de las dos lenguas oficiales de la Comunidad Valenciana, identificando nociones básicas de las lenguas, y contrastando algunas características en discursos orales, escritos y multimodales. | 1.1. Identificar y valorar las lenguas de España y del mundo, y las variedades lingüísticas de las dos lenguas oficiales de la Comunidad Valenciana a partir de la explicación de su origen y de su desarrollo socio-histórico, contrastando aspectos lingüísticos y discursivos, así como los rasgos de las diferentes variedades, en manifestaciones orales, escritas y multimodales. |
| 1.2. Mostrar interés por el uso del valenciano en las diferentes situaciones comunicativas del ámbito personal, social y educativo, y valorar su importancia como lengua propia del territorio. | 1.2. Mostrar interés por el uso del valenciano en las diferentes situaciones comunicativas del ámbito personal, social, educativo y profesional, y valorar su importancia como lengua propia del territorio. |
| 1.3 Mostrar interés y respeto por las variedades lingüísticas, contrastando algunas de sus características en diferentes contextos de uso e identificando expresiones de uso habitual y menos habitual. | 1.3 Mostrar interés y respeto por las diversas variedades lingüísticas, identificando y contrastando sus características principales, y diferenciándolas otras variedades en diferentes contextos de uso. |
| 1.4 Identificar prejuicios y estereotipos lingüísticos a partir de la observación de la diversidad lingüística del entorno, con una actitud de respeto y valoración de la riqueza cultural, lingüística y dialectal. | 1.4 Identificar y cuestionar prejuicios y estereotipos lingüísticos a partir del análisis de la diversidad lingüística del entorno, de las lenguas en contacto, y de los derechos lingüísticos individuales y colectivos, con una actitud de respeto y valoración de la riqueza cultural, lingüística y dialectal. |
| 1.5. Reflexionar y ejemplificar, con cierta autonomía, aspectos del funcionamiento de las lenguas, a partir de la observación, comparación entre ellas y manipulación de | 1.5. Formular generalizaciones, con progresiva autonomía, sobre aspectos del funcionamiento de las lenguas, a partir de la manipulación, la comparación y la transformación de enunciados, |

palabras, oraciones y textos de distintas
lenguas, haciendo uso del metalenguaje.

como también de la formulación de hipótesis y la
busca
de
ejemplos,
haciendo
uso
del
metalenguaje
específico
y
consultando
diccionarios, manuales y gramáticas.

6.2. Competencia específica 2. Criterios de evaluación

CE2. Comprensión oral y multimodal

| 2º de ESO | 4º de ESO |
| --- | --- |
| 2.1 Escuchar de forma activa, interpretar y valorar, con progresiva autonomía, textos orales y multimodales de géneros, tipologías y registros diferentes, propios del ámbito personal, social y educativo, reflexionando sobre el contenido y la forma, y evaluando su calidad, fiabilidad y la idoneidad del canal utilizado. | 2.1 Escuchar de forma activa, interpretar y valorar, de manera autónoma, textos orales y multimodales de géneros, tipologías y registros diferentes, propios del ámbito personal, social, educativo y profesional, reflexionando sobre el contenido y la forma, y evaluando su calidad, fiabilidad e idoneidad del canal utilizado. |
| 2.2. Interpretar el sentido global y las ideas principales y secundarias de textos orales y multimodales de conocimientos ajustados a diferentes ámbitos del conocimiento. | 2.2. Interpretar el sentido global y las ideas principales y secundarias de textos orales y multimodales de conocimientos complejos y ajustados a la situación comunicativa. |
| 2.3. Extraer e interpretar información (explícita e implícita) de los textos orales y multimodales, de los elementos no verbales, valorar el propósito del texto y la intención del emisor. | 2.3. Extraer e interpretar información (explícita e implícita) de los textos orales y multimodales, de los elementos no verbales y de los elementos prosódicos, identificar incongruencias entre texto y elementos no verbales, valorar de manera crítica y razonada los contenidos, el propósito del texto y la intención del emisor. |

6.3. Competencia específica 3. Criterios de evaluación

CE3.  Comprensión escrita y multimodal

| 2º de ESO | 4º de ESO |
| --- | --- |
| 3.1 Leer, interpretar y valorar, con progresiva autonomía, textos escritos y multimodales de géneros, tipologías y registros diferentes propios del ámbito personal, social y educativo, a través del análisis de los elementos formales y de contenido propios del nivel educativo, y evaluando su calidad, fiabilidad y la idoneidad del canal utilizado, así como la eficacia de los procedimientos comunicativos empleados | 3.1 Leer, interpretar y valorar, de manera autónoma, textos escritos y multimodales de géneros, tipologías y registros diferentes propios del ámbito personal, social, educativo y profesional, reflexionando sobre el contenido y la forma, y evaluando su calidad, fiabilidad y la idoneidad del canal utilizado, así como la eficacia de los procedimientos comunicativos empleados. |
| 3.2 Aplicar, con progresiva autonomía, todo tipo de estrategias para comprender el sentido global y la información específica, distinguir las ideas principales de las secundarias, obtener información literal, interpretar información explícita e implícita, valorar el propósito de diferentes textos y la intención del emisor. | 3.2 Aplicar, de manera autónoma, todo tipo de estrategias para comprender el sentido global y la información específica, distinguir las ideas principales de las secundarias, obtener información literal, interpretar información explícita e implícita y valorar de manera razonada y crítica los contenidos, el propósito de diferentes textos y la intención del emisor. |
| 3.3 Identificar las tipologías textuales y los géneros discursivos, reconocer la estructura y algunas de las características lingüísticas específicas de cada tipo de texto. | 3.3 Identificar las tipologías textuales y los géneros discursivos, reconocer la estructura compleja y el formato de los textos y las características lingüísticas específicas de cada tipo de texto. |

| 3.4 Localizar, seleccionar y contrastar información procedente de diferentes fuentes, evaluando su fiabilidad y pertenencia, en diferentes textos multimodales en medios digitales, con progresiva autonomía, del ámbito personal, social y educativo. | 3.4 Localizar, seleccionar y contrastar información procedente de diferentes fuentes, evaluando su fiabilidad y pertenencia en función de los objetivos de lectura y evitando los riesgos de manipulación y desinformación, en diferentes textos multimodales en medios digitales, de manera autónoma, del ámbito personal, social, educativo y profesional. |
| --- | --- |
| 3.5 Aplicar, con progresiva autonomía, todo tipo de estrategias para la busca, selección, gestión y edición de la información, en diferentes textos multimodales, para ampliar conocimientos de manera responsable, contrastar la información de fuentes de carácter general, atendiendo el contexto y la intención comunicativa y utilizarla citando las fuentes. | 3.5 Aplicar, de manera autónoma, todo tipo de estrategias para la busca, selección, gestión y edición de la información, en diferentes textos multimodales, para ampliar conocimientos de manera responsable, contrastar y valorar la información de fuentes diversas, atendiendo el contexto y la intención comunicativa y utilizarla citando las fuentes y respetando los principios de propiedad intelectual. |

6.4. Competencia específica 4. Criterios de evaluación

C4. Expresión oral

| 2º de ESO | 4º de ESO |
| --- | --- |
| 4.1 Producir, con progresiva autonomía, discursos orales sobre diferentes ámbitos del conocimiento, ajustados a la situación comunicativa y a los géneros discursivos del ámbito personal, social y educativo, con adecuación y coherencia, haciendo uso de conectores, aportando su propio punto de vista. | 4.1 Producir, con autonomía, discursos orales extensos sobre conocimientos complejos ajustados a la situación comunicativa y a los géneros discursivos del ámbito personal, social, educativo y profesional, con adecuación, coherencia y cohesión, manifestando una conciencia crítica hacia el tema. |
| 4.2 Producir discursos orales con una pronunciación correcta y una entonación adecuada, utilizando los elementos prosódicos y los recursos no verbales adecuados que refuercen el discurso, utilizando diferentes soportes audiovisuales. | 4.2 Producir discursos orales con fluidez, una buena pronunciación y entonación, utilizando de manera eficaz los elementos prosódicos, los recursos no verbales y diferentes soportes audiovisuales que refuercen las ideas expresadas y capten la atención del receptor. |
| 4.3 Realizar producciones orales con un registro estándar, un lenguaje no discriminatorio y un vocabulario preciso y ajustado a la norma, mostrando un buen dominio lingüístico y morfosintáctico, reflexionando sobre la lengua y su uso. | 4.3 Realizar producciones orales con un registro formal, un lenguaje no discriminatorio y un vocabulario rico y ajustado a la norma, haciendo uso de expresiones idiomáticas, con un dominio óptimo de la morfosintaxis, reflexionando sobre la lengua, su uso y el propósito comunicativo. |
| 4.4 Seleccionar y contrastar información procedente de diferentes fuentes, de manera progresivamente autónoma, sobre temas del ámbito personal, social y educativo, evaluando su fiabilidad, y compartir oralmente los resultados adoptando un punto de vista personal y respetuoso con la propiedad intelectual. | 4.4 Seleccionar y contrastar información procedente de diferentes fuentes, de manera autónoma, sobre temas de interés académico, personal o social, calibrando su fiabilidad y pertinencia, reelaborarla y comunicarla de manera creativa adoptando un punto de vista crítico respetando los principios de propiedad intelectual. |

6.5. Competencia específica 5. Criterios de evaluación

CE5. Expresión escrita y multimodal

| 2º de ESO | 4º de ESO |
| --- | --- |
| 5.1 Producir, con progresiva autonomía, textos escritos y multimodales de géneros discursivos del ámbito personal, social y educativo que respondan a la situación comunicativa con adecuación, coherencia, cohesión y corrección utilizando elementos de cohesión variados. | 5.1 Producir, de manera autónoma, textos escritos y multimodales complejos de géneros discursivos del ámbito personal, social, educativo y profesional que respondan a la situación comunicativa con adecuación, coherencia, cohesión y corrección. |
| 5.2 Utilizar un lenguaje no discriminatorio detectando, de manera progresivamente autónoma, los posibles usos manipuladores de la lengua durante el proceso de composición escrita. | 5.2 Utilizar un lenguaje no discriminatorio detectando, de forma autónoma, los usos manipuladores de la lengua durante el proceso de composición escrita. |
| 5.3. Utilizar, durante el proceso de escritura, de forma reflexiva y con ayuda puntual del profesorado e incorporando progresivamente metalenguaje, los conocimientos lingüísticos, textuales y discursivos necesarios en la situación de aprendizaje. | 5.3. Utilizar, durante el proceso de escritura, de forma reflexiva, autónoma y utilizando metalenguaje, los conocimientos lingüísticos textuales y discursivos necesarios en la situación de aprendizaje. |
| 5.4. Planificar, textualizar, revisar y editar, con progresiva autonomía, durante el proceso de escritura mediante estrategias gradualmente complejas. | 5.4 Planificar, textualizar, revisar y editar, de manera autónoma, durante el proceso de escritura, utilizando las estrategias necesarias de manera precisa. |

6.6. Competencia específica 6. Criterios de evaluación

CE6. Interacción oral, escrita y multimodal

| 2º de ESO | 4º de ESO |
| --- | --- |
| 6.1 Interactuar oralmente, con progresiva autonomía, sobre conocimientos ajustados a la situación comunicativa del ámbito personal, social y educativo, a través de diferentes soportes, aplicando la escucha activa y utilizando un vocabulario preciso y no discriminatorio, la cortesía lingüística, la etiqueta digital y aquellos recursos no verbales que faciliten la construcción de un discurso consensuado. | 6.1 Interactuar oralmente, con autonomía, sobre conocimientos complejos ajustados a la situación comunicativa del ámbito personal, social, educativo y profesional, a través de diferentes soportes, utilizando un vocabulario rico y correcto y no discriminatorio e implicándose activa y reflexivamente con una actitud dialogante y de escucha para la construcción de un discurso común consensuado. |
| 6.2. Identificar y rechazar, con ayuda puntual, los usos discriminatorios y manipuladores de la lengua a partir de la reflexión y el análisis de los elementos verbales y no verbales utilizados en el discurso. | 6.2. Identificar y rechazar, de forma autónoma, los usos discriminatorios y manipuladores de la lengua a partir de la reflexión y el análisis de los elementos verbales y no verbales utilizados en el discurso. |
| 6.3. Utilizar, con ayuda puntual, estrategias para la gestión dialogada de conflictos en el ámbito personal, educativo y social. | 6.3. Utilizar estrategias, de manera autónoma, para la gestión dialogada de conflictos en el ámbito personal, educativo y social. |
| 6.4. Interactuar en textos escritos y multimodales de manera asíncrona y síncrona con progresiva autonomía; mostrando empatía y respeto por las diferentes necesidades, ideas y motivaciones de los interlocutores, utilizando estrategias para expresar mensajes cohesionados, coherentes y adecuados con un vocabulario preciso y no discriminatorio. | 6.4. Interactuar en textos escritos y multimodales complejos de manera asíncrona y síncrona, con autonomía; mostrando empatía y respeto por las diferentes necesidades, ideas y motivaciones de los interlocutores, con adecuación, coherencia, cohesión, corrección y vocabulario rico y no discriminatorio. |

6.7. Competencia específica 1. Criterios de evaluación

CE7. Mediación oral, escrita y multimodal

| 2º de ESO | 4º de ESO |
| --- | --- |
| 7.1 Mostrar interés por participar en la solución de problemas de comprensión recíproca entre hablantes de lenguas o variedades lingüísticas diferentes, sobre asuntos diversos del ámbito personal, social y educativo. | 7.1 Mostrar interés por participar en la solución de problemas de comprensión recíproca entre hablantes de lenguas o variedades lingüísticas diferentes, sobre asuntos diversos del ámbito personal, social, educativo y profesional. |
| 7.2 Comprender, comunicar y describir textos de complejidad media en diferentes soportes, o explicar conceptos, de forma oral o escrita, combinando su repertorio lingüístico (L1-L1, L1-L2, L2-L1); | 7.2 Comprender, comunicar, describir y parafrasear textos de una cierta complejidad en diferentes soportes, o explicar conceptos, de forma oral o escrita, combinando su repertorio lingüístico (L1-L1, L1-L2, L2-L1) |
| 7.3 Seleccionar y aplicar, de forma progresivamente autónoma, estrategias de simplificación y adaptación de la lengua, que faciliten la comprensión y expresión oral y escrita de la información en distintas lenguas de su repertorio lingüístico (L1-L1, L1-L2, L2- L1). | 7.3 Seleccionar y aplicar, de forma autónoma, estrategias de simplificación, adaptación y reformulación de la lengua, que faciliten la comprensión y expresión oral y escrita de la información en distintas lenguas de su repertorio lingüístico (L1-L1, L1-L2, L2-L1). |

6.8. Competencia específica 8. Criterios de evaluación

CE8. Lectura autónoma

| 2º de ESO | 4º de ESO |
| --- | --- |
| 8.1 Leer obras diversas y textos escritos y multimodales del ámbito personal, social y educativo, seleccionando con progresiva autonomía aquellos que mejor se ajustan en cada momento vital a sus gustos, intereses y necesidades personales. | 8.1 Leer obras diversas y textos escritos y multimodales del ámbito personal, social, educativo y profesional, seleccionando de manera autónoma aquellos que mejor se ajustan en cada momento vital a sus gustos, intereses y necesidades personales. |
| 8.2 Dejar constancia del propio itinerario lector y de las experiencias lectoras. | 8.2 Dejar constancia del propio itinerario lector y cultural, explicando los criterios de selección de las lecturas, las formas de acceso a la cultura literaria y las experiencias lectoras. |
| 8.3. Compartir las experiencias de lectura, en apoyos diversos, participando en comunidades lectoras en el ámbito educativo y social, y relacionando el sentido de la obra con la propia experiencia biográfica y lectora. | 8.3. Compartir las experiencias de lectura, en diferentes soportes, participando en comunidades lectoras en el ámbito educativo y social, y relacionando el sentido de la obra con la propia experiencia biográfica, lectora y cultural. |

8.3. Compartir las experiencias de lectura, en
diferentes soportes, participando en comunidades
lectoras en el ámbito educativo y social, y
relacionando el sentido de la obra con la propia
experiencia biográfica, lectora y cultural.

6.9. Competencia específica 9. Criterios de evaluación

CE9. Competencia literaria

| 2º de ESO | 4º de ESO |
| --- | --- |
| 9.1. Leer y escuchar fragmentos literarios y obras completas, con progresiva autonomía y en contextos socioculturales próximos, teniendo en cuenta los intereses del alumno | 9.1. Leer y escuchar fragmentos literarios y obras completas, de manera autónoma, teniendo en cuenta los intereses del alumno |
| 9.2. Interpretar la información relevante de los textos literarios, de las obras completas, y aportar conclusiones de manera reflexiva. | 9.2. Interpretar la información relevante de las obras literarias, de manera autónoma, y aportar conclusiones con reflexión y visión crítica. |
| 9.3. Establecer, de manera guiada, vínculos entre los textos leídos y otros textos escritos, orales o multimodales, o bien con otras manifestaciones artísticas en función de temas, tópicos, estructuras, lenguaje y valores éticos o estéticos, mostrando, además implicación y respuesta personal del lector en la lectura | 9.3. Establecer, de manera progresivamente autónoma, vínculos entre los textos leídos y otros textos escritos, orales o multimodales, o bien con otras manifestaciones artísticas en función de temas, tópicos, estructuras, lenguaje y valores éticos o estéticos, mostrando, además implicación y respuesta personal del lector en la lectura |
| 9.4. Expresar opinión sobre textos y obras literarias, utilizando algunos recursos retóricos y el metalenguaje literario, con apoyo puntual del profesorado | 9.4. Expresar opinión sobre textos y obras literarias, utilizando los recursos retóricos fundamentales, el metalenguaje y las características de los géneros, de manera autónoma |
| 9.5. Crear textos literarios sencillos de los géneros básicos, (cuentos, dramatizaciones, poemas, canciones), aplicando los recursos literarios básicos adecuados, con progresiva autonomía | 9.5. Crear textos literarios (relatos breves, dramatizaciones, poemas, canciones) aplicando los recursos literarios adecuados a cada género, de manera autónoma |
| 9.6. Participar en manifestaciones literarias, recitales y representaciones teatrales partiendo de modelos | 9.6. Organizar y participar en manifestaciones literarias, recitales y representaciones teatrales |

Annex IV / Anexo IV

CURRÍCULUM DE LES MATÈRIES OPTATIVES D’EDUCACIÓ SECUNDÀRIA OBLIGATÒRIA

CURRÍCULO DE LAS MATERIAS OPTATIVAS DE EDUCACIÓN SECUNDARIA OBLIGATORIA
