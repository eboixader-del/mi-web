# FORMACIÓN Y ORIENTACIÓN PERSONAL Y PROFESIONAL

> Fuente: Secundaria.pdf, páginas 838-852 (versión en castellano).

FORMACIÓN Y ORIENTACIÓN PERSONAL Y PROFESIONAL

1. Presentación

Una de las finalidades de la educación básica es contribuir al desarrollo integral de todo el
alumnado, así como a la preparación para la participación activa en la vida económica, social y cultural
con autonomía, responsabilidad, actitud crítica y habilidades para adaptarse a los cambios y
transiciones.

Desde la materia de Formación y Orientación Personal y Profesional se pretende que,
integrando en el currículum competencias que proporcionen al alumnado experiencias de aprendizaje
sobre sí mismo, conocimiento del entorno y del mundo laboral, se contribuya a reforzar la acción
orientadora fomentando una mayor madurez vocacional del alumnado con proyección hacia el futuro.

Esta materia está vinculada a un gran número de los objetivos considerados como metas de la
educación secundaria, entre ellos que el alumnado movilice los conocimientos, habilidades y actitudes
para participar en la sociedad de manera activa y responsable, con iniciativa y confianza en sí mismo
y desarrolle la competencia para aprender a aprender, planificar y tomar decisiones.

En términos generales, y de acuerdo con los objetivos educativos y el perfil de salida del
alumnado al término de la enseñanza básica, la materia integra los conocimientos, destrezas y actitudes
en el desarrollo de sus competencias específicas, que van a permitir al alumnado entender los conflictos
como consustanciales a la vida y resolverlos de manera pacífica. También permitirá a los y las
estudiantes aprovechar las oportunidades de la cultura digital desde una perspectiva crítica haciendo
un uso ético y responsable, aceptar la incertidumbre inherente a la realidad actual aprendiendo a
manejar la ansiedad, así como desarrollar habilidades que le permitan seguir aprendiendo a lo largo de
la vida. En definitiva, la materia enlaza directamente con el objetivo fundamental del perfil de salida al
finalizar la enseñanza básica de dotar al alumnado de las herramientas imprescindibles para que
desarrolle un proyecto de vida personal, social y profesional satisfactorio.

En relación con los principios pedagógicos de la etapa, la materia fomenta la capacidad de
aprender por sí mismos y promueve el trabajo en equipo por medio de la resolución colaborativa de
problemas. Intensifica la inclusión de todo el alumnado reforzando la autoestima, la autonomía, la
reflexión y la responsabilidad. Y, por último, es en sí misma una medida para la orientación educativa,
psicopedagógica y profesional, elemento fundamental en la ordenación de esta etapa. Asimismo, se
ocupa de forma explícita de aspectos tratados en otras áreas y materias: uso crítico y responsable de
las tecnologías de la información y la comunicación, educación para la salud y educación emocional y
en valores. De manera transversal conecta con la comprensión y expresión tanto oral como escrita,
considerando el lenguaje como el vehículo imprescindible para el conocimiento propio, la relación con
los demás y con el entorno.

La materia contribuye al desarrollo personal fortaleciendo el conocimiento sobre las propias
fortalezas y debilidades, identificando la influencia del grupo social y de la cultura, también ayuda al
dominio de destrezas básicas para la utilización crítica de las fuentes de la información y la
comunicación potenciando el uso responsable de las tecnologías y, por último, contribuye a desarrollar
las capacidades de aprender a aprender, aprender a ser, aprender a decidir y aprender a convivir.

La materia de Formación y Orientación Personal y Profesional se concibe con carácter
eminentemente práctico y aplicado. Desde una metodología de aprendizaje activa y experiencial, el
alumnado tendrá la posibilidad de entrenar habilidades de autorreflexión, explorar el contexto y adquirir
herramientas para la toma de decisiones y para el diseño de un proyecto de orientación personal,
académico y profesional. Mediante actividades de trabajo en equipo podrá ejercitar habilidades
personales y sociales necesarias para participar, crear y desarrollarse en los grupos humanos en los
que interactúa y habilidades que le facilitarán la gestión de las transiciones a lo largo de su vida.

Formación y Orientación Personal y Profesional está planteada como materia de opción para
cuarto curso de la Educación Secundaria Obligatoria, un curso con un claro carácter orientador. Las
competencias planteadas tienen continuidad con las adquiridas durante la etapa de primaria y los tres
primeros cursos de la Educación Secundaria Obligatoria y están formuladas con relación al perfil de
salida del alumnado al finalizar la enseñanza básica.

Cada competencia específica va acompañada de una descripción que detalla el sentido y la
fundamentación de lo que se espera que el alumnado adquiera, ampliando la información acerca de la
actuación o actuaciones que el alumnado llevaría a cabo, el contexto en que lo haría y los saberes que
movilizaría para ello. Esta descripción nos informa, además, de las conexiones con las competencias
clave y los desafíos del siglo XXI.

Los saberes básicos necesarios para desarrollar las competencias están organizados en tres
bloques. El primero se centra en el conocimiento propio e incluye por ello contenidos relativos al
conocimiento y la autorreflexión a través del análisis de los procesos cognitivos y biológicos que influyen
en la conducta, el aprendizaje y las emociones. También se aborda la exploración de los propios
valores, fortalezas y debilidades y las estrategias para identificar momentos de ansiedad y saber
potenciar las capacidades propias para afrontar de manera equilibrada las tensiones, desafíos e
incertidumbres que se producen a lo largo de la vida.

En el segundo bloque, conocimiento del entorno, se abordan los saberes que permiten conocer
las posibilidades que ofrece el contexto, tanto a nivel personal, académico y profesional. Asimismo, se
recogen las estrategias necesarias para potenciar la autonomía en la búsqueda de información fiable y
actualizada y desarrollar la competencia digital.

En el tercer bloque se abordan los saberes necesarios para desarrollar las competencias
propias tanto de la toma de decisiones como para la construcción de un proyecto de vida personal,
académica y profesional. Se incluyen las fases en el proceso de toma de decisiones y las estrategias
de incorporación al mundo laboral.

Por último, los criterios de evaluación que se han establecido van orientados a conocer el grado
de adquisición de cada una de las competencias específicas de la materia, es decir, el nivel en el que
al alumnado es capaz de movilizar los saberes, conceptuales, procedimentales y relativos a actitudes
y valores en el ámbito personal, social, académico y profesional.

2. Competencias específicas de la materia.

2.1. Competencia específica 1.

Identificar en sí mismo algunos procesos psicológicos básicos implicados en el aprendizaje, la
conducta y las emociones, desarrollando procesos de autorregulación que le permitan un aprendizaje
a lo largo de la vida.

2.1.1. Descripción de la competencia 1.

El conocimiento de sí mismo y la construcción de la propia personalidad son elementos
fundamentales en el proceso de planificación del proyecto de vida personal, social y profesional. Se
inicia durante la infancia y es clave en la adolescencia para adquirir el control sobre las propias
decisiones que guían la transición al mundo adulto.

El y la adolescente van a tomar conciencia de los cambios físicos y psicológicos que se dan
durante esa etapa vital y cómo influyen en el desarrollo de la personalidad, la autoestima, la formación
del autoconcepto e identidad personal y a desarrollar habilidades para identificar intereses y valores
personales.

Esta competencia supone una aproximación a los procesos psicológicos básicos implicados en

el aprendizaje especialmente la atención, motivación y  memoria, las estrategias de aprendizaje y
estudio, el desarrollo del pensamiento crítico, la creatividad, curiosidad intelectual y persistencia, en
definitiva, aspectos que contribuyen a desarrollar procesos metacognitivos de retroalimentación que le
permitan aprender de sus errores, mejorar las debilidades identificadas  y mantener conductas que
están favoreciendo el desarrollo personal y académico. Resulta clave para desarrollar habilidades y
actitudes que le permitan afrontar el aprendizaje a lo largo de la vida. Así mismo, es esencial tomar
conciencia de los procesos implicados en las emociones y su relación con el aprendizaje y la conducta.
Y, también, conocer los fundamentos biológicos básicos para entender la conducta.

Para la adquisición de esta competencia será necesario explorar y evaluar las fortalezas,
debilidades, metas, intereses y valores personales para aplicarlos en el diseño del proyecto personal,
académico y profesional, donde serán claves las expectativas y la autopercepción.

Tomando como referencia los grandes retos que plantea el siglo XXI resulta de gran
importancia desarrollar una vida saludable y generar hábitos que promuevan la salud personal y
colectiva. Afrontar este desafío supone conocer cómo funciona el organismo, los riesgos derivados de
factores tanto personales como sociales y hacer uso de la ciencia para mejorar la salud física y mental.
Por lo tanto, los procesos de conocimiento de sí mismo deben ir orientados a favorecer el bienestar
emocional, desarrollando estrategias para identificar momentos de ansiedad y saber potenciar las
capacidades propias para afrontar las tensiones, desafíos e incertidumbres, que se producen a lo largo
de la vida, de manera equilibrada.

En primaria, el alumnado comienza a ser consciente de sus propias emociones, ideas y
comportamientos personales y se inicia, a su vez, en el uso de estrategias de aprendizaje
autorregulado. Al completar la enseñanza básica, el alumnado debe ser capaz tanto de regular las
emociones y los comportamientos dirigiendo su motivación hacia el aprendizaje, como de desarrollar
habilidades para la reflexión sobre sí mismo, el autoconocimiento y la promoción de un crecimiento
personal constante.

2.2. Competencia específica 2

Reconocer algunos factores personales y socioculturales que intervienen en la comprensión de
sí mismo en relación con los demás y en la adaptación al contexto social y profesional, respetando y
valorando la diversidad.

2.2.1. Descripción de la competencia 2.

La existencia del ser humano va ligada a la necesidad intrínseca de ser parte de una
comunidad, estar y relacionarse con grupos sociales.

Cómo pensamos, nos expresamos y nos relacionamos; qué valoramos o qué percibimos viene
influenciado por los aspectos que componen la cultura del grupo social. La construcción de la
personalidad se desarrolla en interacción con la pertenencia a una comunidad.  Es por ello que, para
completar el conocimiento propio, resulta imprescindible explorar las relaciones interpersonales y el
impacto que tienen sobre sí mismo los distintos agentes de socialización como la familia, la escuela, el
grupo de pares, los medios de comunicación y las redes sociales entre otros.

Además, es necesario desarrollar habilidades de pensamiento crítico que permitan al alumnado
decidir con autonomía, conociendo y controlando la influencia que el grupo puede ejercer sobre él, sin
obviar el papel que juegan los estereotipos y las atribuciones sociales.

El contexto social y económico en que nos encontramos hace necesario que el alumnado
conozca y desarrolle destrezas personales que le permitan el desarrollo profesional y personal en el
contexto de un mundo plural y cambiante.

En el entorno laboral son valoradas tanto las habilidades relacionadas con los conocimientos y
destrezas técnicas adquiridas en el ámbito académico, como las destrezas relacionadas con la
comunicación eficaz oral y escrita, la gestión y planificación, la capacidad de trabajo en equipo o el

liderazgo. Estas últimas son adquiridas a lo largo de la vida y están directamente relacionadas con
habilidades emocionales, sociales y cognitivas.

Resulta imprescindible, por tanto, que el alumnado tenga la oportunidad de explorar, conocer
y entrenar aquellas habilidades emocionales (empatía, manejo de emociones y sentimientos, manejo
de tensiones y estrés), habilidades sociales (comunicación asertiva, relaciones interpersonales, manejo
de problemas y conflictos), y cognitivas (toma de decisiones, autoconocimiento, pensamiento crítico y
creativo) que pueden beneficiar su transición a la vida laboral y adaptarse a los cambios que se pueden
producir a lo largo de su vida.

Durante la educación primaria, el alumnado participa en actividades comunitarias, toma de
decisiones y resolución de los conflictos tomando conciencia de los valores democráticos, los derechos
humanos y de la infancia, el valor de la diversidad y el logro de la igualdad de género y la cohesión
social. Al finalizar la enseñanza básica se profundiza y amplía desarrollando una actitud crítica que le
permite una participación activa e informada en procesos como la toma de decisiones o la resolución
de conflictos.

2.3. Competencia específica 3.

Explorar el entorno identificando las oportunidades de desarrollo personal, académico y
profesional, utilizando de forma crítica la información.

2.3.1. Descripción de la competencia 3.

En un mundo globalizado y cambiante como el actual, los contextos académicos y laborales
son cada vez más complejos. En la actualidad existen multitud de itinerarios formativos con opciones y
alternativas que el alumnado necesita conocer en profundidad para trazar con seguridad un camino
académico y profesional acorde con sus intereses. Se pretende que el alumnado cuente con estrategias
para la exploración del entorno y búsqueda de oportunidades para el desarrollo personal, social,
académico y profesional.

Por otro lado, el mercado laboral está sujeto a cambios constantes influenciado en la
actualidad, especialmente, por la revolución digital. El desarrollo de esta competencia fomenta, a través
del análisis de perfiles profesionales, de la formación vinculada y las tendencias del mercado laboral,
la identificación de oportunidades para desarrollar sus metas de aprendizaje y competencias para la
empleabilidad, además de entender cómo funciona el mercado de trabajo; cómo encontrar un trabajo;
apreciar cómo y por qué están cambiando las industrias y los puestos de trabajo individuales dentro de
ellas; y los tipos de habilidades que se necesitan para progresar.

Un último aspecto que valorar son las tecnologías como una herramienta fundamental para la
exploración del entorno, abriendo nuevas posibilidades y ampliando los horizontes. El alumnado tiene
que ser capaz de realizar búsquedas en internet seleccionando la información de manera crítica y
gestionando su entorno personal digital de aprendizaje permanente, configurando su propio mapa de
recursos para el asesoramiento que contribuya a mejorar la autoorientación a lo largo de la vida.

El conocimiento que va adquiriendo a lo largo de su escolarización le va a permitir entender y
valorar la realidad que le rodea para afrontar los retos e ir construyendo su proyecto de vida a lo largo
de su trayectoria personal y profesional. Asumiendo que la realidad actual se caracteriza por la
incertidumbre y afrontando que es necesario articular soluciones creativas para poder desarrollarse
personal y profesionalmente con autonomía.

Durante la etapa de primaria el alumnado se inicia en la búsqueda y selección de información
sencilla, con la mediación del o la docente. Al finalizar la etapa de secundaria el alumnado consolida
habilidades para localizar, seleccionar y contrastar la información de manera autónoma, siendo capaz
de hacer búsquedas avanzadas en internet atendiendo a criterios de validez, actualidad y fiabilidad. Así
mismo, el conocimiento de las profesiones y la exploración de los intereses vocacionales comienza en

primaria y se profundiza a través de la acción tutorial y orientadora de toda la etapa de secundaria.

2.4 Competencia específica 4

Definir metas realistas, ajustadas al conocimiento de sí mismo, utilizando la información
relevante para resolver la incertidumbre y adoptar una actitud proactiva en la toma de decisiones
personales, académicas y profesionales.

2.4.1 Descripción de la competencia 4.

Las personas estamos constantemente tomando decisiones, escogiendo qué hacer tras
considerar distintas alternativas, haciendo uso de herramientas para evaluar las diferentes
posibilidades, teniendo en cuenta necesidades, valores, motivaciones, influencias y posibles
consecuencias presentes y futuras, tanto en la propia vida como en la de otras personas.

La complejidad actual del sistema educativo y del mercado laboral hacen que sea necesaria
una detallada planificación del proceso de toma de decisiones académicas y profesionales, y que el
alumnado desarrolle las competencias necesarias para gestionar el proceso desde una actitud reflexiva,
responsable, sistemática y metódica.

Para sistematizar el proceso de toma de decisiones es necesario que el alumnado desarrolle
habilidades de análisis sobre las oportunidades que le ofrece el entorno, a partir de sus intereses,
valores y expectativas y teniendo en cuenta los factores que pueden influir en la toma de decisiones
como las modas, la presión social o las conductas de evitación cuando siente temor. De esta manera
comienza a definir los primeros objetivos a modo de hipótesis, haciendo confluir toda la información de
que dispone, analizando las necesidades, identificando las mejores opciones, evaluando su viabilidad
y estableciendo estrategias de verificación de los resultados previstos.

En este proceso es fundamental aprender a anticiparse a las consecuencias, asumir la
incertidumbre y responsabilizarse por las decisiones implementando las acciones necesarias para
desarrollar la opción elegida. Es importante tener en cuenta que cualquier decisión puede ser errada y
requiere volver a puntos anteriores. El error forma parte de la vida y debe ser útil para afrontar
situaciones futuras integrándolo en el conocimiento de uno mismo favorecerá un crecimiento personal
constante.

Esta competencia específica se ejercita durante la etapa de primaria mediante la participación
en actividades comunitarias y en la toma de decisiones que requieren actuar con eficacia y seguridad.
Al completar la enseñanza básica el alumnado, además de identificar las necesidades, también las
analiza, evalúa las fortalezas y debilidades propias para aportar soluciones valiosas y planifica el
proceso de toma de decisiones, en base a la información y el conocimiento con actitud estratégica,
reflexiva y poniendo el foco en las oportunidades que ofrece el entorno.

2.5 Competencia específica 5.

Diseñar un proyecto personal, académico y profesional propio conjugando las necesidades e
intereses personales y vocacionales con las oportunidades del entorno y las destrezas necesarias en
la toma de decisiones.

2.5.1 Descripción de la competencia 5.

Esta competencia, puesto que articula un proyecto personal, académico y profesional, requiere
la contribución de todas las demás competencias e implica, por parte del alumnado, planificar los
objetivos a corto, medio y largo plazo y poner en acción las competencias necesarias para alcanzarlos.
La meta que articula esta materia es que el alumnado no solo desarrolle estrategias y adquiera recursos
para su autorientación, sino que también diseñe su propio proyecto personal, académico y profesional

movilizando a su vez las destrezas relacionadas con la competencia digital y las propias de cualquier
proceso creativo y de indagación.

Recoger el resultado del análisis del conocimiento propio es el punto de partida, con la finalidad
de identificar las áreas de mejora para definir metas personales y diseñar un plan para la mejora y el
crecimiento personal, valorando las cualidades e intereses personales.

Así mismo, será necesario contar con la información de las oportunidades que ofrece el
contexto y hacerlas confluir con los valores e intereses personales y vocacionales y la reflexión sobre
el futuro profesional. Para ello se establecerán unas metas que guíen las primeras tomas de decisiones
personales, académicas y profesionales coherentes con sus preferencias y aspiraciones, en definitiva,
estableciendo una hoja de ruta.

Un aspecto a tener en cuenta respecto al proyecto en su vertiente académica y profesional es
que el contexto social y laboral actual hace necesario que el proyecto sea lo más amplio y flexible
posible, que priorice la formación continuada como idea aprendizaje a lo largo de la vida y que
contribuya al desarrollo de la carrera profesional.

En este momento de la etapa, como complemento a lo anterior, es importante introducir los
saberes básicos para aproximar al alumnado al mercado laboral mediante el desarrollo de
competencias para la búsqueda activa de empleo y el conocimiento de estrategias y recursos básicos
para el emprendimiento. Las habilidades contempladas en esta competencia específica contribuyen a
aumentar la madurez personal y la empleabilidad.

El alumnado al completar la Etapa de Primaria es capaz de planear objetivos a corto plazo,
reconociendo las limitaciones. Al finalizar Secundaria identifica las oportunidades de desarrollo
personal, social y económico que le ofrece el entorno, es capaz de planear objetivos a medio plazo y
desarrolla procesos para aprender de sus errores.

3. Conexiones de las competencias específicas entre sí, con las competencias específicas de
otras materias y con las competencias clave

3.1 Relaciones o conexiones con las otras CE de la materia

Las cinco competencias planteadas están en continua interacción y se complementan
contribuyendo al desarrollo de estrategias y recursos para la autoorientación del alumnado al finalizar
4º de la ESO y a lo largo de su vida.

La CE1, el autoconocimiento, es el primer paso para la orientación, implica analizar los propios
procesos de aprendizaje, emocionales y conductuales y su autorregulación, así como la exploración de
los valores, intereses o fortalezas propios. Este conocimiento es esencial para el desarrollo de la CE2,
CE4 y CE5.

La CE2 complementa la anterior en el conocimiento de uno mismo en el contexto de las
interacciones sociales, vinculándose con las competencias CE1, CE4 y CE5.

La CE3 conecta con la CE4 y CE5 ya que la exploración del entorno académico y profesional
ofrece el conocimiento necesario para tomar decisiones y diseñar el proyecto personal, académico y
profesional.

La CE4 pone en acción el resto de competencias, la toma de decisiones conjuga la CE1, CE2
y CE3 y su resultado se plasma en el desarrollo de la CE5.

La CE5 puesto que articula un proyecto personal, académico y profesional requiere la
contribución de todas las demás competencias: la CE1, CE2, CE3 y CE4.

3.2 Relaciones o conexiones con las CE de otras materias de la etapa

La CE1 y CE2 son competencias relacionadas con todas las materias de la etapa. El
conocimiento de uno mismo, de cómo aprende y se relaciona con los demás, se ponen en juego en
cualquier situación de aprendizaje y convivencia en el contexto escolar. Así mismo la CE4 contribuirá
a mejorar la toma de decisiones presente en las distintas materias.

Y viceversa, el resto de materias también contribuirán al desarrollo de las competencias de
esta materia. Todas las competencias de las materias de lenguas son imprescindibles para el desarrollo
de las competencias planteadas en Formación y Orientación Personal y Profesional vertebrando el
aprendizaje. Se ponen en acción en los procesos comunicativos en los ámbitos personal, social,
académico y profesional, son un instrumento esencial en el autoconocimiento y el conocimiento del
entorno y fundamentales en el desarrollo de los proyectos personales y profesionales.

Una de las materias con la que presenta una gran vinculación es la de Valores Éticos y Cívicos,
especialmente las CE1, CE2, CE4 y CE6 que se relacionan con las CE1, CE2, CE4 y CE5 de Formación
y Orientación Personal y Profesional en la medida en que contribuyen a la gestión emocional en
situaciones de conflicto, al uso del diálogo para llegar a acuerdos, a la identificación de estereotipos y
a la responsabilidad y justicia social en nuestras acciones para combatir la desigualdad.

La materia de Geografía e Historia también está estrechamente relacionada. Sus CE4, CE7 y
CE8 se relacionan con todas las competencias de la materia de Formación y Orientación Personal y
Profesional, desde el análisis de la actividad económica, a la asunción de valores democráticos y
participación en proyectos que favorezcan un entorno social más justo y solidario.

En este sentido la Cultura Clásica, en sus CE1 y CE2, contribuye a ese conocimiento del mundo
y el funcionamiento social, relacionándose especialmente con la CE2 de Formación y Orientación
Personal y Profesional.

Desde la Educación Plástica y Visual la CE2, CE4 y CE5 se relacionan con la CE1, CE3 y CE5
de Formación y Orientación Personal y Profesional ya que favorecen el proceso creativo necesario para
mejorar las habilidades personales, el uso de los recursos digitales y son imprescindibles en la
elaboración de cualquier proyecto. De la misma manera contribuye la CE4 de Música y la CE3 de
Educación Física.

Siguiendo con la materia de Educación Física, también presentan una vinculación la CE1 y
CE5 con la CE1, CE4 y CE5 de Formación y Orientación Personal y Profesional en su contribución a
la mejora del bienestar físico y mental y la promoción de hábitos de vida saludables.

Encontramos una relación estrecha entre la CE2, CE5 y CE7 de Tecnología y Digitalización y
todas las competencias de Formación y Orientación Personal y Profesional. Son fundamentales estas
competencias para la exploración del entorno virtual en los ámbitos personal, social, académico y
profesional, también por su contribución al desarrollo de los ámbitos mencionados y en el proceso
creativo de elaboración de proyectos.

La CE1 y CE8 de Matemáticas se vinculan con la CE2, CE2 y CE4 de Formación y Orientación
Personal y Profesional en la medida que se aborda la resolución de problemas sociales y profesionales
y la gestión de las emociones ante la incertidumbre y el error para mejorar los procesos de aprendizaje.

Biología se relaciona en su CE2, CE3 y CE5 con la CE1, CE3, CE4 y CE5 de Formación y
Orientación Personal y Profesional en cuanto a su planteamiento respecto al uso de la ciencia para
analizar los problemas y encontrar soluciones, en el desarrollo del pensamiento crítico y el uso de
fuentes fiables de información y en el desarrollo de hábitos de vida saludables y prevención de las
adicciones y situaciones de riesgo.

La materia de Física y Química está relacionada en su CE3 y CE4 con la CE1, CE2, CE3 y
CE4 de Formación y Orientación Personal y Profesional en la medida que coinciden en el uso del
conocimiento científico como instrumento del pensamiento crítico y la importancia de la ciencia en los

avances sociales y en el uso del conocimiento.

La materia optativa de 2º de la ESO de Emprendimiento Social y Sostenible se relaciona en su
CE1 y CE2 con la CE2, y CE4 de Formación y Orientación Personal y Profesional en la medida que
favorecen el desarrollo de las destrezas para identificar cualidades personales y de las habilidades
socioemocionales para el trabajo en equipo, para favorecer los procesos de toma de decisiones y para
afrontar las diferentes transiciones a lo largo de la vida.

La materia de Economía y Emprendimiento en sus C1, C2 y C5 se relaciona con la C2, C4 y
C5 de Formación y Orientación Personal y Profesional en la medida que ambas coinciden en plantear
el diseño y desarrollo de un proyecto personal y desarrollar habilidades sociales y emocionales para el
trabajo en equipo y estrategias de comunicación eficaz.

Por último, cabe señalar la vinculación directa de la materia Formación y Orientación
Personal y Profesional con la orientación académica y profesional que se lleva a cabo durante toda la
etapa y especialmente en 4º de la ESO.

3.3 Relaciones o conexiones con las competencias clave

El cuadro adjunto muestra la existencia de una relación especialmente significativa y relevante
entre las cinco competencias específicas de esta materia y algunas competencias clave incluidas en el
perfil de salida del alumnado al finalizar la educación básica. En todos los casos, esta relación opera
en las dos direcciones. Por una parte, la adquisición y desarrollo de las competencias específicas
señaladas contribuye a la adquisición y desarrollo de las competencias clave con las que aparecen
estrechamente vinculadas; por otra parte, estas competencias clave juegan un papel importante en la
adquisición y desarrollo de las competencias específicas señaladas.

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 | X |  | X | X | X |  | X | X |
| CE2 | X |  |  | X | X | X |  |  |
| CE3 | X | X |  | X |  |  |  |  |
| CE4 | X |  | X |  | X |  | X |  |
| CE5 | X | X | X | X | X |  | X | X |

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica

•
CCL: Competencia en comunicación lingüística
•
CP: Competencia plurilingüe
•
CMCT: Competencia matemática y competencia en ciencia y tecnología
•
CD: Competencia digital
•
CPSAA: Competencia personal, social y de aprender a aprender
•
CC: Competencia ciudadana
•
CE: Competencia emprendedora
•
CCEC: Competencia en conciencia y expresión culturales

En primer lugar, todas las competencias de la materia Formación y Orientación Personal y
Profesional se relacionan con la competencia en comunicación lingüística. El lenguaje es el vehículo
para conocerse mejor, para relacionarse con los demás y comprender el contexto social, para explorar
las opciones académicas y profesionales, para tomar decisiones y para el diseño de proyectos. La CCL
es la base del pensamiento y de la construcción del conocimiento.

En segundo lugar, la CE1 se relaciona con la CPSAA en la medida que ambas persiguen
mejorar las competencias personales a partir de la reflexión sobre sí mismo, el autoconocimiento, el
crecimiento personal, aprender a aprender y el desarrollo de la metacognición, el bienestar físico y
emocional y la promoción de una vida saludable.

En tercer lugar, la CE2, de la misma forma que la anterior, se relaciona con la CPSAA en la
vertiente social del conocimiento propio, la gestión de los conflictos, trabajo en grupo y el empleo de
estrategias cooperativas. Además, se vincula con la CC en cuanto que se analiza la dimensión social
de la identidad personal y la interacción con los demás en los distintos contextos socio-institucionales
y aborda el valor de la diversidad y la justicia social.

En cuarto lugar, la CE3 está conectada a la CD en la medida que implica el uso de la tecnología
en la exploración del entorno personal, académico y profesional y, en particular, el uso crítico de la
información de internet, la identificación de fuentes fiables y la gestión de la información. La CP permitirá
al alumnado ampliar el conocimiento del entorno más allá de nuestras fronteras.

En quinto lugar, la CE4 se vincula a la CE en la detección de necesidades y oportunidades, en
el pensamiento estratégico y en la toma de decisiones. También con la CPSAA en la validación y
contrastación de información para obtener conclusiones y definir metas realistas para resolver la
incertidumbre. Y con la CMCT en la aplicación del pensamiento científico para el planteamiento de
hipótesis y la indagación.

En sexto lugar, la CE5 se relaciona con la CPSAA en el establecimiento de metas personales,
la autoevaluación del proceso de toma de decisiones, la planificación de objetivos a medio y largo plazo
y la gestión del aprendizaje a lo largo de la vida. También se relaciona con la CCEC en la expresión de
ideas, opiniones, sentimientos y emociones de manera creativa y abierta y con la CD en la elaboración
del proyecto personal, académico y profesional. Así mismo, se relaciona con la CE al conjugar las
necesidades e intereses personales y vocacionales junto con las oportunidades del entorno y las
destrezas necesarias en la toma de decisiones para llevarlas a la acción a través de la planificación y
gestión de proyectos.

4. Saberes básicos

4.1 Introducción

La selección de los saberes básicos responde a aquellos que se consideran necesarios para
el desarrollo de las competencias específicas. La organización, por su parte, se corresponde con las
distintas fases de la orientación personal, académica y profesional y está vinculada directamente al
plan de orientación académica y profesional que se desarrolla en los centros educativos. Se establecen
tres bloques de saberes que son necesarios para la adquisición y desarrollo de las cinco competencias
específicas de la materia.

El primer bloque es el dedicado al conocimiento propio, tanto en el conocimiento de los propios
procesos de aprendizaje, la regulación emocional y de la conducta y otros aspectos clave para el
autoconocimiento, como en la interacción con los demás para identificar áreas de mejora para el
desarrollo personal y social, valorando la cultura, los factores sociales y las habilidades necesarias.
Para ello se tendrá en cuenta la contribución de la psicología, la sociología o la antropología, en sus
vertientes más prácticas y aplicadas.

El segundo bloque reúne los contenidos relacionados con la exploración del entorno personal,
académico y profesional, la utilización y gestión de distintas fuentes de información, el análisis de las
oportunidades de desarrollo personal y social que ofrece el entorno y el conocimiento de las opciones
para la formación y el empleo.

El tercer bloque recoge los saberes necesarios para la toma de decisiones, para el desarrollo
personal y para la orientación académica y profesional y las estrategias del análisis del mundo laboral.

4.2 Saberes básicos

Bloque 1 Autoconocimiento y relaciones interpersonales

Subbloque 1.1 Procesos psicológicos básicos y fundamentos biológicos de la conducta

•
Procesos psicológicos básicos implicados en el aprendizaje.
•
Procesos psicológicos básicos implicados en las emociones.
•
Fundamentos biológicos de la conducta.

Subbloque 1.2 Conocimiento de uno mismo

•
Adolescencia y formación de la identidad.
•
Fortalezas, debilidades, metas, intereses y valores.
•
Autopercepción, expectativas y autoeficacia.
•
Conductas de riesgo, adicciones y hábitos de vida saludables.
•
Habilidades para la vida: cognitivas, emocionales y sociales.
•
Afrontamiento de la incertidumbre y el estrés.
•
Habilidades de organización y gestión.
•
Autoconocimiento vocacional.
•
Ocio y tiempo libre.
•
Autonomía personal.

Subbloque 1.3 Interacción social

•
Cultura y desarrollo individual y social.
•
Desarrollo personal dentro del grupo. Influencia de la presión del grupo.
•
Conciencia social y compromiso con la justicia social.
•
Valor de la diversidad.
•
Convivencia y resolución pacífica de los conflictos.
•
Atribuciones sociales y estereotipos.
•
Habilidades para relacionarse y para la comunicación eficaz.

Bloque 2 Exploración del entorno personal, académico y profesional

Subbloque 2.1 Fuentes de información para el desarrollo personal, académico y profesional

•
Internet y otras fuentes de información.
•
Fiabilidad de las fuentes y actualidad de la información.
•
Servicios de orientación en el entorno personal, académico y laboral.
•
Mapa de recursos de información y asesoramiento.

Subbloque2.2 Oportunidades de desarrollo personal y social

•
Oportunidades de participación activa para el compromiso social.
•
Opciones para el desarrollo de habilidades y competencias personales y sociales.

Subbloque 2.3 Formación académica y profesional

•
Campos profesionales y formación asociada.
•
Ocupaciones profesionales y estilos de vida.
•
Bachillerato, Formación Profesional y otras opciones de estudios después de 4º de la
ESO.
•
Titulaciones, grados, cualificaciones y programas de formación: oferta, acceso,
vinculaciones y continuidad académica y profesional.
•
Oportunidades académicas en otros países.

Subbloque 2.4 Mundo laboral

•
Exploración y descubrimiento del entorno de trabajo.
•
Opciones trabajo por cuenta ajena e iniciativa emprendedora.
•
Mercado laboral y relaciones en entorno de trabajo.
•
Revolución digital en el entorno laboral.

Bloque 3 Proceso de toma de decisiones y diseño de un proyecto personal, académico y
profesional

Subbloque 3.1 Proceso de toma de decisiones

•
Análisis reflexivo, sistemático y metódico para la toma de decisiones.
•
Identificación de las mejores opciones y planteamiento de hipótesis y su viabilidad.
•
Factores que influyen en las decisiones.
•
Asunción de responsabilidades y análisis de los riesgos.
•
Verificación de los resultados y detección de errores.

Subbloque 3.2. Toma de decisiones para el desarrollo personal

•
Cualidades personales y apoyos del entorno.
•
Habilidades para la gestión de la carrera.
•
Metas personales.
•
Planificación de estrategias para mejorar el desarrollo y bienestar personal y social.

Subbloque 3.3. Toma de decisiones académicas y profesionales

•
Descubrimiento de los intereses vocacionales y priorización de las necesidades.
•
Oportunidades académicas y profesionales, valorando aquellas que mejor se adaptan
a las cualidades e intereses personales.
•
Identificación del itinerario formativo y de otras áreas de mejora de las competencias
académicas y profesionales.
•
Apoyos y recursos con los que se cuentan y dificultades a superar para alcanzar los

objetivos.
•
Plan de orientación académica y profesional. Establecimiento de una hoja de ruta.

Subbloque 3.4. Aproximación a la incorporación al mundo laboral y aprendizaje a lo largo de la
vida

•
Estrategias e instrumentos para la búsqueda activa de empleo.
•
Estrategias y recursos básicos para el emprendimiento.
•
Entorno personal de aprendizaje para el desarrollo personal, académico y profesional
a lo largo de la vida.
•
Aproximación al concepto de desarrollo de la carrera profesional.

5. Situaciones de aprendizaje para el conjunto de las competencias de la materia

Las situaciones de aprendizaje deben estar conectadas con los principales desafíos del siglo
XXI y con los objetivos de la etapa de la Educación Secundaria Obligatoria (ESO). Permiten ofrecer un
contexto práctico para el desarrollo y adquisición de las competencias.

Como marco general de las situaciones de aprendizaje, con el objetivo de atender a la
diversidad de intereses y necesidades del alumnado, se incorporarán los principios del diseño universal
de aprendizaje, asegurándonos de que no existen barreras que impidan la accesibilidad física,
cognitiva, sensorial y emocional para garantizar su participación y aprendizaje.

Dado el carácter eminentemente práctico de esta materia, las situaciones de aprendizaje
promoverán que el alumnado consiga afianzar su autonomía mientras desarrolla estrategias que le
resultarán útiles más allá del aula. Para ello, es fundamental diseñar actividades que permitan la
práctica y entrenamiento en las distintas habilidades que se proponen y realizarlas tanto
individualmente como en equipo. El papel del profesorado será fundamental para guiar la práctica y
ofrecer la retroalimentación necesaria.

Las situaciones de aprendizaje deberán ser variadas y auténticas y estar conectadas tanto con
el mundo real como con las experiencias e intereses del alumnado. Las metodologías activas
promoverán el trabajo individual, así́ como la interacción, colaboración y cooperación entre iguales,
favoreciendo que el alumnado tome decisiones cada vez más autónomas.

Deberían plantearse situaciones de reflexión que ayudarán al alumnado a tomar conciencia de
lo que han aprendido y las decisiones que han tomado, así como a conocerse a sí mismos como
estudiantes, desde una mirada que tenga en cuenta su trayectoria y que incluya sus experiencias de
aprendizaje fuera y dentro de la escuela.

Es fundamental diseñar situaciones de aprendizaje que vinculen el contexto educativo y el
contexto social en los que se desarrolla nuestro alumnado, a través de la participación activa tanto en
la vida del centro como en su entorno local tomando conciencia de la contribución de sus acciones en
el bienestar individual y colectivo. En este sentido puede ser útil plantear actividades solidarias o
desarrollar proyectos de aprendizaje y servicio.

El autoconocimiento se favorecerá a través de situaciones de aprendizaje, tanto individuales
como colectivas, que planteen retos al alumnado, que promuevan la reflexión sobre sí mismo y sobre
las relaciones del grupo o que utilicen estrategias y herramientas para el conocimiento intra e
interpersonal; por ejemplo, cuestionarios de intereses, estudios de caso, técnicas de afrontamiento del
estrés ante situaciones de incertidumbre o de cambio, simulaciones en grupo para entrenar habilidades
sociales y emocionales, dinámicas de grupo donde ensayar habilidades comunicativas en contextos
sociales y laborales, asambleas y debates, entre otras.

Sería interesante, para contribuir al desarrollo de las competencias planteadas, que las
situaciones de aprendizaje se diseñen tanto en el contexto escolar como en el entorno próximo del
alumnado, por ejemplo, situaciones que permitan al alumnado conocer aspectos académicos y
profesionales de su entorno, que pueden incluir visitas a centros de formación, encuentros con
estudiantes, talleres de búsqueda de información, etc.

En este sentido, las situaciones de aprendizaje también pueden enfocarse al mundo profesional
mediante actividades en las que se utiliza la creación de empresas por parte del alumnado generando
un aprendizaje vivencial, simulación de entrevistas de selección, elaboración del currículum vitae,
visitas a empresas, experiencias en centros de trabajo, proyectos de investigación sobre las profesiones
de la familia o de personas cercanas, encuentros con profesionales, ferias de formación y empleo, etc.

Una de las situaciones de aprendizaje más específicas de esta materia es la que guía al
alumnado en la elaboración del proyecto personal, académico y profesional. Además de las actividades
necesarias para obtener la información y tomar decisiones, se utilizarán las tecnologías como fuente
de recursos y como herramienta de desarrollo del proyecto.

6. Criterios de evaluación

Competencia específica 1

Identificar en sí mismo algunos procesos psicológicos básicos implicados en el aprendizaje, la
conducta y las emociones, desarrollando procesos de autorregulación que le permitan un aprendizaje
a lo largo de la vida.

1.1. Reconocer los procesos cognitivos y emocionales básicos y reflexionar sobre el propio
aprendizaje.

1.2. Reconocer y gestionar la ansiedad en situaciones de estrés, en los contextos personales,
académicos y profesionales, mediante estrategias de control de las emociones.

1.3. Identificar y analizar críticamente las fortalezas, debilidades, metas, intereses y valores
personales para aplicarlos en la planificación del proyecto personal, académico y profesional.

1.4. Reconocer situaciones de riesgo y hábitos de vida saludables, investigar de forma rigurosa
los medios para mejorar la salud física y mental y utilizar la información adquirida para mejorar los
hábitos de la vida cotidiana.

Competencia específica 2

Reconocer algunos factores personales y socioculturales que intervienen en la comprensión de
sí mismo en relación con los demás y en la adaptación al contexto social y profesional, respetando y
valorando la diversidad.

2.1 Analizar las habilidades socioemocionales necesarias para desenvolverse en los contextos
interpersonales y profesionales y planificar algunas estrategias para mejorarlas.

2.2. Identificar creencias y valores culturales y sociales que influyen en la construcción de la
identidad personal.

2.3. Analizar y argumentar los derechos de las personas valorando la diversidad y planteando
acciones frente a las situaciones de violencia y exclusión.

2.4. Participar de manera activa en dinámicas de trabajo grupal y cooperativo contribuyendo a
la elaboración de proyectos colaborativos, poniendo en acción habilidades comunicativas y estrategias
que permitan llegar a consensos.

2.5 Investigar los sesgos y estereotipos que pueden influir en la construcción de expectativas

sobre las posibilidades personales, académicas y profesionales.

Competencia específica 3

Explorar el entorno identificando las oportunidades de desarrollo personal, académico y
profesional utilizando de forma crítica la información.

3.1 Buscar, seleccionar y manejar críticamente información de distintas fuentes para tomar
decisiones vocacionales de los ámbitos personal, académico y profesional.

3.2 Participar activamente en las visitas a centros de formación y centros de trabajo y analizar
la información significativa.

3.3 Explorar los distintos campos profesionales conociendo los requisitos, las vías de acceso,
los estudios necesarios y las condiciones laborales.

3.4. Investigar y analizar las características del mercado laboral, los cambios del entorno
profesional y productivo y los empleos emergentes, detectando las habilidades que mejor se adaptan
a esta nueva realidad.

3.5. Identificar las diferentes opciones de empleo, a partir de las posibilidades de inserción por
cuenta ajena y por cuenta propia y explorar las relaciones presentes en cada una de ellas.

Competencia específica 4

Definir metas realistas, ajustadas al conocimiento de sí mismo, utilizando la información
relevante para resolver la incertidumbre y adoptar una actitud proactiva en la toma de decisiones
personales, académicas y profesionales.

4.1 Analizar el contexto social, en relación con la familia, amistades, situación económica y
oportunidades académicas y profesionales y valorar los apoyos con los que se cuentan y las dificultades
a superar.

4.2 Identificar las cualidades personales y apoyos del entorno con los que afrontar con eficacia
nuevos retos y facilitar el proceso de transición a la vida adulta.

4.3 Contrastar y comparar la información recopilada planteando hipótesis, identificando las
opciones que mejor se adaptan a nuestros intereses y evaluando su viabilidad.

4.4 Verificar en el proceso de toma de decisiones si los pasos nos conducen a la meta correcta
o se requiere realizar ajustes o replantear los objetivos.

4. 5 Tomar decisiones a partir de los valores y expectativas propias sin ceder a modas, presión
social o conductas de evitación, asumiendo la responsabilidad de las decisiones.

Competencia específica 5

Diseñar un proyecto personal, académico y profesional propio conjugando las necesidades e
intereses personales y vocacionales con las oportunidades del entorno y las destrezas necesarias en
la toma de decisiones

5.1 Priorizar las necesidades e identificar los intereses personales y vocacionales mediante la
exploración de las oportunidades académicas y profesionales que ofrece el entorno mostrando las
destrezas necesarias en el proceso de toma de decisiones.

5.2 Explorar el mundo laboral y extraer conclusiones sobre el futuro profesional propio.

5.3 Construir el entorno personal de aprendizaje para el desarrollo personal, académico y

profesional a lo largo de la vida.

5.4 Elaborar un proyecto personal, académico y profesional propio, incorporando el
autoconocimiento, el conocimiento del entorno académico y profesional y la aproximación al mundo
laboral.
