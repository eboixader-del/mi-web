# EDUCACIÓN FÍSICA

> Fuente: Secundaria.pdf, páginas 720-745 (versión en castellano).

EDUCACIÓN FÍSICA

1. Presentación

La actual Ley orgánica de modificación de la LOE (LOMLOE) destaca el principio de una
educación de calidad y para toda la ciudadanía, además de reconocer la necesidad de atender
al desarrollo sostenible de acuerdo con la Agenda 2030 (ODS). El presente decreto que
desarrolla la ley educativa en la Comunitat Valenciana sostiene estos principios abordables en
el ámbito de la Educación Física desde una situación privilegiada hacia una mejora de la salud
personal y social y una alfabetización motriz y competencial respecto a los nuevos retos a los
que se enfrenta el alumnado.

La adquisición de las competencias clave está necesariamente ligada a la consecución
de los objetivos planteados en la LOMLOE. La educación física ayuda a cumplir estos objetivos
de etapa, especialmente los que tienen que ver con el desarrollo de la personalidad y las
habilidades sociales. Así mismo, contribuye en la etapa de Secundaria al objetivo de conocer y
aceptar el funcionamiento del propio cuerpo y de los otros, respetándolo y afianzando hábitos de
cuidado y salud corporal.

El perfil de salida del alumnado de Secundaria se guía por la adquisición de las
competencias clave que tienen como referencia los desafíos del siglo XXI.

La Educación Física, a partir de sus competencias específicas, facilita la consecución de
las competencias clave y la consecución de los desafíos.

Además, la sociedad actual avanza a un ritmo vertiginoso respecto a la escuela. El
contacto de la escuela con la realidad que la rodea es un hecho necesario si se quiere conseguir,
con el cuerpo en movimiento, una adquisición competencial del alumnado respecto a un estilo
de vida activo y saludable, la resolución de retos motrices en situaciones específicas, el
autoconocimiento, la expresión de ideas, valores y emociones mediante propuestas artístico-
expresivas y su relación con el entorno próximo y global, la interacción sostenible con el medio
y el patrimonio que nos rodea y, finalmente, el empoderamiento de los recursos tecnológicos
como facilitadores de una vida activa.

En referencia a los principios pedagógicos que marca la actual Ley orgánica de
modificación de la LOE, cobra especial importancia la atención a la diversidad en la materia de
Educación Física, atendiendo a una íntegra alfabetización motora del alumnado. Así mismo, es
importante respetar los diferentes ritmos de aprendizaje, así como el trabajo en equipo y
autónomo con propuestas saludables adaptadas y graduadas según las características propias
de esta etapa, tanto con el grupo como de forma individual en una continuidad con la anterior
etapa de Primaria.

La Educación Secundaria Obligatoria (ESO) continúa la estructura competencial de la
etapa de Primaria en el área de Educación Física con una especificación competencial que pueda
ser aplicable desde los distintos bloques de contenidos o saberes y con una gradación de estos
favoreciendo el proceso de evaluación. Así, los criterios de evaluación permiten al alumnado
conocer lo que tienen que conseguir y buscan, durante todo el proceso, la reflexión del alumnado
con el docente, entre sus iguales y consigo mismo, en un proceso activo continuo. Las nuevas
pedagogías o metodologías activas aplicadas a la materia de Educación Física pueden ayudar y
ser motor, en este sentido, en un sistema educativo sostenible y saludable para el siglo XXI.

El trabajo por ámbitos favorecerá una comprensión transversal y un logro competencial
de los saberes esenciales de la materia. Por consiguiente, la administración educativa tendrá
que favorecer la interconexión entre áreas en forma de proyectos, siempre que las condiciones
estructurales y de calificación interdisciplinaria de los centros sean las adecuadas, y tal como
marca la LOMLOE.

La tutoría y el gabinete psicopedagógico del centro son elementos de apoyo y
cooperación necesaria para atender al alumnado con diferentes necesidades específicas de
apoyo educativo (NEAE).

La propuesta curricular para la materia de Educación Física presenta cinco
competencias específicas que concretan las competencias clave recogidas en el perfil de salida
para la materia, que contienen una descripción y su vinculación con otras competencias y con
las características del alumnado. También se dan orientaciones sobre las situaciones de
aprendizaje que favorecen la adquisición de la competencia. Los saberes esenciales se
estructuran en los seis bloques de contenidos asociados a los criterios de evaluación
secuenciados para los cursos de segundo y cuarto de ESO.

Finalmente, se establece la relación con otras áreas en una visión holística, relacionando
el currículum, de forma que tanto el alumnado como el profesorado pueda establecer conexiones
en lugares de aprendizaje comunes para lograr las competencias clave, como hito en una
personalización e interrelación de todo el proceso.

2. Competencias específicas de la materia de Educación Física

2.1. Competencia específica 1

Integrar un estilo de vida activo mediante la práctica de la actividad física y deportiva
autorregulada y el establecimiento de conexiones entre los hábitos de comportamiento cotidianos
y el bienestar físico y mental.

2.1.1. Descripción de la competencia específica 1

Esta competencia supone un enfoque hacia un conocimiento holístico del concepto de
salud conectado con la aplicación de habilidades para una vida saludable de manera
autorregulada. El alumnado lleva desde la educación primaria aprendiendo y vivenciando los
comportamientos y las actitudes que facilitan un estado de vida saludable con el refuerzo del
entorno familiar y social que lo rodea. Así, en esta etapa los criterios y saberes asociados a esta
competencia tienen que ayudar al alumnado a desarrollar las habilidades y los conocimientos
necesarios para participar de manera regular y segura en las diferentes propuestas de actividad
física que pueden encontrar, dentro y fuera de la escuela, disfrutando de las sensaciones
intrínsecas que esto conlleva y desarrollando un espíritu crítico para poder establecer hitos reales
respecto a una mejora de la forma física y su estado de salud. Se pone énfasis en la aplicabilidad
de los conocimientos acerca de una vida sana con el fin de transmitir la capacidad de tomar
decisiones personales y asumir la responsabilidad y el compromiso hacia su salud, ahora y para
el resto de su vida. Mediante esta competencia, el alumnado comprende lo que necesita para
comprometerse con una vida activa y saludable, desarrollando la intención de vivir de manera
emocionalmente satisfactoria y proactiva. Este concepto multidimensional de la salud es
dinámico y complejo y supone una relación indivisible, tal como manifiesta la OMS, que englobe
el estado físico, mental y social, y se define como uno de los Objetivos de Desarrollo Sostenible
(ODS) y retos del siglo XXI.

Los saberes que se vinculan a esta competencia son: los componentes físicos y
fisiológicos con impacto directo en la salud y el bienestar y los componentes relacionados con el

aparato cardiorrespiratorio, fuerza y resistencia muscular, flexibilidad y composición corporal; la
actividad física, entendida como el movimiento intencional que supone un gasto de energía en
una oposición clara a los comportamientos sedentarios, interactuando con las personas y el
entorno; técnicas y métodos que favorecen una regulación del estado de ánimo y emocional, y
el respeto a la diversidad de pensamiento, físico y de género, tan importante en la etapa de la
adolescencia. Todo ello facilita la adquisición y comprensión competencial de hábitos y rutinas
saludables.

Esta vida activa está conectada con el mundo que nos rodea y la salud de los otros. El
entorno de esta práctica física tiene que ser necesariamente inclusivo para posibilitar que el
alumnado se sienta atraído por ella con la idea de aumentar al máximo los beneficios y minimizar
los riesgos. Del mismo modo, el buen uso de la tecnología tiene que ser aliado de todos los
enunciados que describen esta competencia, especialmente en la lucha contra el sedentarismo
y las enfermedades hipocinéticas ocasionadas, en gran medida, por la exposición a las pantallas.
Los y las jóvenes deberán sentirse implicados en un proceso creciente de mejora, escuchando
su cuerpo y aprendiendo estrategias para adoptar una actitud crítica para mantener y mejorar su
salud.

Al final de los dos primeros cursos de Secundaria, el alumnado deberá ser capaz de
desarrollar, implementar y evaluar un plan de acción diseñado para mejorar sus hábitos de salud,
reconociendo las conductas o los hábitos que pueden comportar un riesgo.

Al final de los dos últimos cursos de Secundaria se pondrá énfasis en consolidar y
desarrollar el aprendizaje adquirido en los dos primeros cursos. Esto se apoyará en la capacidad
del alumnado para aplicar su capacidad de autogestión y la readaptación necesaria en función
de sus características físicas, cambiantes en la adolescencia, los desafíos del entorno y sus
relaciones personales, a los efectos de sus comportamientos y hábitos de estilo de vida acerca
de su salud y bienestar.

2.2. Competencia específica 2

Resolver con éxito diferentes retos y situaciones motrices a través de propuestas físicas
y deportivas específicas aplicando las técnicas, tácticas y estrategias de juego adecuadas.

2.2.1. Descripción de la competencia específica 2

Mediante esta competencia el alumnado demuestra su eficiencia y variabilidad motriz
seleccionando las habilidades y secuencias de movimientos adecuadas, ajustando y adquiriendo
nuevos patrones motores y habilidades respecto a las adquiridas en la etapa de Primaria.
Recordamos que en Primaria contábamos con una competencia específica dedicada al
desarrollo motriz. Ahora en la etapa de Secundaria se tendrán en cuenta los cambios propios de
la adolescencia, anatómicos, fisiológicos y sociales, que afectarán en las actividades recurrentes
a esta competencia. Especialmente, aquellas actividades relacionadas con las actividades
deportivas regladas, los juegos predeportivos y de cualquier tipo de adaptación inclusiva de
deporte escolar. El alumnado será capaz de demostrar competencia en la aplicación de las
técnicas y estrategias de decisión tanto en el ámbito motriz como cognitivo, anticipándose en
diferentes contextos de juego, a la vez que mejora actitudes de cooperación, diálogo y trabajo
en equipo, con y sin oposición. El aprendizaje de las habilidades motrices y la aplicación de
conceptos implicados como comunicación y contracomunicación motriz ayudará al alumnado a
aumentar su seguridad, competencia, eficacia y eficiencia en el movimiento, el proceso del juego
y el resultado como inicio de un proceso reflexivo. Así mismo, el deporte escolar y las
competencias motrices implicadas pueden mejorar su desarrollo físico, cognitivo y emocional,
siendo importante que el contexto de práctica sea inclusivo respecto a las características

individuales, identidad de género y nivel de habilidad. En este sentido, es fundamental el
desarrollo de valores y sentido crítico de los aspectos sociales y culturales que rodean de manera
intrínseca el fenómeno deportivo, como por ejemplo sus valores positivos, como la bonhomia, y
negativos, como la xenofobia o el machismo, especialmente en el deporte de masas. Esta
competencia en la variabilidad motriz ayuda al alumnado a desarrollar su capacidad para
participar en actividades físico-deportivas a la vez que incrementa su nivel de práctica de
actividad física y mejora su salud y socialización con el entorno y el grupo, tan importante en
estas edades.

Fisiológica y anatómicamente, los cambios en las proporciones y los somatotipos,
especialmente en la etapa de la adolescencia, pueden generar situaciones de rechazo que se
deberán trabajar mediante esta competencia para conseguir juegos y deportes inclusivos que
generen y fomenten hábitos para una práctica deportiva adecuada en cada etapa de la vida.

Todavía más, el trabajo de las funciones y responsabilidades de roles del contexto
deportivo, como por ejemplo los de entrenador y entrenadora, árbitro o preparadora y preparador
físico, nos ayudarán a desarrollar varias competencias, especialmente las sociales y cívicas,
aprender a aprender, el sentido de iniciativa y el espíritu emprendedor, favoreciendo la autonomía
del alumnado.

La maduración y la experimentación motriz se pueden emplear en la aplicación de
habilidades en juegos y actividades que impliquen estrategias, tácticas y técnicas más complejas.
En este sentido, estas habilidades se contextualizarán aplicando la variabilidad metodológica,
tanto al grupo clase como de forma individualizada, para tomar conciencia de cómo se utilizará
dentro y a través de actividades físicas para ser capaz de aplicarlas y transferirlas a actividades
más generales, incluso las posibles transferencias en la vida diaria, como por ejemplo las caídas
en los deportes de lucha. Se debe tener en cuenta que cuando los estudiantes están aprendiendo
o desarrollando una habilidad, necesitan oportunidades para practicarla y recibir una
retroalimentación especialista y entre iguales durante todo el proceso. Así, el papel de las
llamadas ayudas o los roles diferenciados son especialmente importantes en esta competencia.
A medida que se desarrollan y trabajan para consolidar sus habilidades, podrán combinar
habilidades y aplicarlas en actividades más complejas. Estas habilidades de movimiento más
elaboradas no son el resultado de la maduración física únicamente, sino producto de la práctica
y de la capacidad neuromotriz de relacionar con otras habilidades de movimiento dentro de una
gran variedad de actividades físicas.

Al final de los dos primeros cursos de Secundaria, el alumnado debería ser capaz de
resolver diferentes situaciones y secuencias de movimientos relacionadas con los juegos y el
deporte mediante el bagaje motor adquirido en este periodo.

Durante los dos últimos cursos de Secundaria, el alumnado debería consolidar los
aprendizajes adquiridos durante los dos primeros cursos, además de implicarse activamente y
colaborar en la organización de juegos y actividades físico-deportivas reforzando su papel
transmisor de valores como el respeto, la tolerancia, la no discriminación y la universalidad.

2.3. Competencia específica 3

Participar en procesos de creación de naturaleza artístico-expresiva mediante el uso del
cuerpo, el gesto y el movimiento como medios de autoconocimiento para expresar ideas y
sentimientos.

2.3.1. Descripción de la competencia específica 3

Esta competencia se centra en explorar las situaciones comunicativas que se dan
consciente e inconscientemente con el cuerpo, el gesto y el movimiento. Las conexiones entre
sus experiencias motrices y su bienestar emocional a través de la vivencia corporal consciente,
garantizan un aprendizaje significativo, duradero y profundo por sus connotaciones introyectivas.

En la etapa de Primaria, la competencia específica que hace referencia a la identificación
de los aspectos fundamentales sobre la conciencia, la percepción y el control del cuerpo, a través
de la resolución de situaciones motrices variadas, tiene una continuidad clara con esta
competencia en Secundaria en cuanto al conocimiento del cuerpo y la representación de ideas,
emociones y valores con las actividades artístico-expresivas. Este planteamiento redefine la
relación del cuerpo y la salud hacia un enfoque que conecta el cuerpo con el aprendizaje
cognitivo y la comunicación personal.

La experiencia creativa articulada desde la corporalidad beneficia el proceso de
aprendizaje del alumnado, permitiendo la comprensión de conceptos a través del cuerpo y la
posibilidad de comunicarse y vivir la emoción desde el movimiento. Mediante el juego dramático
y teatral, las improvisaciones, la pantomima, el clown, las actividades circenses, la danza
creativa, el trabajo con máscaras y las danzas populares, esta competencia favorece la
comprensión de las diferentes manifestaciones culturales y artísticas, dotándolas de valor,
además de facilitar el diálogo intercultural y permitir la adquisición de nuevos recursos de
expresión, comunicación e inclusividad. Desde esta perspectiva, la danza, el teatro y las artes
vivas como actividades artístico-expresivas ayudan a desarrollar la sensibilidad, la creatividad,
la imaginación y la comunicación para que el individuo pueda sentirse, percibirse y manifestarse
mediante la exploración de las complejidades de estas conexiones y ayudando al alumnado a
reconocer los sentimientos y las emociones. Se contempla el cuerpo como origen de la identidad
personal y la relación con el mundo, proponiendo el cuerpo como vehículo de expresión y
comunicación imprescindible para el ser humano. Enriquecer las experiencias perceptivas y
ofrecer una exploración activa y constructiva del mundo a través de la experimentación del
movimiento permite que el alumnado desarrolle movimientos motores finos y gruesos,
afianzando su creatividad, la autoconfianza y la exploración de diferentes formas de
comunicación y de relacionarse que favorecen su salud y el bienestar emocional.

Esta competencia permite influir sobre los sentimientos y emociones como base sobre
la cual se puede desarrollar la empatía y el autoconocimiento, favoreciendo el trabajo emocional
y perceptivo, así como las técnicas corporales de comunicación. Se tienen que promover
situaciones y condiciones educativas que favorezcan la adquisición competencial, haciendo
partícipe al alumnado del diseño de proyectos artísticos y mostrando la interdisciplinariedad de
los saberes para un logro competencial pleno. Finalmente, se colabora con la adquisición del
valor per se de las artes en cualquier disciplina ampliando el bagaje cultural del alumnado con
propuestas del entorno.

Al final de los dos primeros cursos de Secundaria, el alumnado tendría que ser capaz de
expresar sentimientos y emociones, comunicando ideas, con recursos corporales sencillos, sin
y con apoyo musical.

Durante los dos últimos cursos de Secundaria, debería poner énfasis en consolidar y
desarrollar el aprendizaje adquirido en los dos primeros cursos y en participar activamente en el
diseño de proyectos artísticos mediante la utilización creativa y estética de los recursos
expresivos del propio cuerpo en contextos diferentes, comunicando ideas, sentimientos y
emociones.

2.4. Competencia específica 4

Interaccionar de manera sostenible con el patrimonio natural y cultural mediante
actividades físicas y artístico-expresivas.

2.4.1. Descripción de la competencia específica 4

Esta competencia se fundamenta en la capacidad de interactuar activamente con el
entorno natural y urbano mediante las actividades físicas, haciendo un uso respetuoso del medio
físico, social y cultural. Se refuerza y amplía uno de los saberes transversales que el alumnado
ha trabajado en la etapa de Primaria, como apreciar y respetar el medio ambiente, una parte
integral de la educación ambiental. Esta competencia enfatiza el aprendizaje de aspectos como
el valor de los espacios al aire libre, los beneficios ambientales de la salud, prácticas como el
transporte activo, el impacto de usar sendas y comprender los riesgos para la salud asociados
con factores ambientales como la exposición al sol y la contaminación del aire. Mediante esta
competencia se ofrece a los estudiantes la oportunidad de integrar la ética ambiental, el
aprendizaje sostenible y una comprensión de la conexión con la naturaleza, reconociendo esta
interacción del mundo natural y la salud emocional. Además, desarrolla la conciencia del impacto
ambiental de las actividades deportivas y recreativas y la aportación que puede hacer el área por
la reducción de la huella de carbono. A medida que el alumnado va aprendiendo más sobre el
cuerpo y el movimiento, a través del desarrollo de habilidades personales, a trabajar de manera
colaborativa y respetuosa con el resto y adquirir la capacidad de pensamiento sistémico, a través
de habilidades de pensamiento creativo, mejoran su capacidad para hacer conexiones con el
mundo a su alrededor y convertirse en ciudadanos ambientalmente responsables. Para facilitar
estas conexiones, será fundamental que estos aprendizajes se desarrollen fuera del centro
educativo para ayudar al alumnado a observar, explorar y apreciar el valor de nuestra riqueza
natural y topográfica, especialmente con actividades tanto costeras como de montaña, mientras
descubren los beneficios de estar activo al aire libre. Esto incluye en entornos urbanos los
parques y espacios públicos adecuados para el uso deportivo y de la actividad física en general.
Por otro lado, no dejamos de lado la seguridad que se debe extremar especialmente en estos
entornos. Así, las habilidades básicas de asistencia en primeros auxilios, donde se incluye la
RCP, son saberes que todo el alumnado tiene que conocer.

Al final de los dos primeros cursos de Secundaria, el alumnado debería ser capaz de
participar en deportes, actividades físicas y artístico-expresivas por su bienestar personal y el de
toda la comunidad, creando conexiones sostenibles con su entorno natural y urbano y
conociendo las medidas de seguridad y primeros auxilios en función de la actividad llevada a
cabo.

Durante los dos últimos cursos de Secundaria, se debería poner énfasis en consolidar y
desarrollar el aprendizaje adquirido en los dos primeros cursos. Además, se debería participar
de manera activa en la planificación y evaluación de estrategias para conectar de manera
sostenible con el entorno natural y urbano que promuevan su salud y el bienestar comunitario
con los protocolos de seguridad y autoprotección adecuados al contexto y tipo de actividad
propuesta.

2.5. Competencia específica 5

Seleccionar y hacer un uso crítico y seguro de las tecnologías de la información y la
comunicación como facilitadoras de la actividad física y de una vida activa y saludable.

2.5.1. Descripción de la competencia específica 5

A través de esta competencia sobre el uso creativo, crítico y seguro de las tecnologías
de la información y la comunicación, el alumnado debe relacionarlas necesariamente con el
acceso a las fuentes, el procesamiento de la información, la curación de contenidos y el
conocimiento de sus derechos y deberes digitales, fomentando una alfabetización digital que
amplía el concepto de salud al actual y futuro mundo digital.

Este planteamiento competencial supone enseñar habilidades comunicativas que
favorezcan un alumnado autónomo, eficaz, responsable, crítico y reflexivo que disponga de
habilidades para el manejo de la información y el uso de las herramientas tecnológicas. Mediante
la movilización integrada del conjunto de capacidades relacionadas con la tecnología, la
información y los medios de comunicación tradicionales y digitales, así como las redes sociales,
la competencia integra saberes, dimensiones y habilidades personales, cognitivas y éticas,
sociales y actitudinales yendo más allá del saber tecnológico o técnico-instrumental y
capacitando al estudiante en el uso creativo, práctico e inteligente de las tecnologías del
aprendizaje y el conocimiento (TAC). Esto implica la enseñanza de valores y actitudes, conocidos
en el entorno TIC como netiqueta, que permiten al alumnado adaptarse a los continuos cambios
producidos por las tecnologías, su uso y adaptación a los objetivos propios y la capacidad de
interacción social mediante estas herramientas tecnológicas. Igualmente, requiere el desarrollo
de aspectos relacionados con la participación, el trabajo colaborativo, el acceso a la información,
el procesamiento y uso para la comunicación, así como la creación de contenidos, la seguridad
y la resolución de problemas. El uso de la tecnología en la Educación Física contribuye a la
integración de elementos para el intercambio de experiencias y conocimientos, el análisis de los
comportamientos motores, el control, la gestión y la organización de la propia actividad física y
deportiva, entre otras. Evaluando y seleccionando nuevas fuentes de información e innovaciones
tecnológicas, el alumnado tiene que ser capaz de hacer una curación de contenidos y de los
recursos tecnológicos disponibles con el fin de resolver los problemas cotidianos de forma
eficiente, utilizándolos de manera creativa, cooperativa y autónoma. Con la aplicación de las TAC
al proceso de aprendizaje, el alumnado debe ser capaz de tomar decisiones de manera
autónoma, crítica y creativa, innovando y creando un nuevo conocimiento que sea aplicable y
útil, y escoger entre los actuales recursos multimedia interactivos, programas, las aplicaciones
móviles, la realidad virtual (VR), la aumentada (AR) y la mixta (MR) en animaciones y vídeos y
otros proyectos relacionados con  el área.

Al final de los dos primeros cursos de Secundaria, el alumnado tendría que ser capaz de
conocer y usar fuentes de información, contenidos y aplicaciones fiables en relación con la
actividad física, la salud, el medio natural, los deportes y otros saberes que se relacionan con su
vida cotidiana, haciendo un buen uso de ellas.

Durante los dos últimos cursos de Secundaria, el alumnado debería aumentar y
consolidar los aprendizajes adquiridos en los dos primeros cursos, además de ser capaz de
producir y difundir contenidos relacionados con la actividad física y la salud en distintos formatos,
haciendo una elección consciente de qué medios son los más adecuados, basándose en criterios
de adecuación y respetando la propiedad intelectual.

3. Conexiones de las competencias específicas entre sí, con las competencias de otras
áreas y con las competencias clave.

3.1. Conexión con las competencias específicas de la materia

A causa de su carácter transversal, la competencia específica 1 está claramente
vinculada con el resto de competencias de la materia, puesto que, mediante esta, el alumnado
se tiene que comprometer con un proceso orientado hacia el cambio de algunos de sus hábitos

de estilo de vida a través del desarrollo y la implementación de un plan que debe incluir actividad
física regular y, por otro lado, por la capacidad de criticar sus propios procesos y hábitos de vida
y analizar el impacto en su salud y bienestar. Por todo ello, esta competencia estará presente a
la hora de desarrollar los contenidos del resto de competencias de la materia, como por ejemplo
los juegos y deportes, las actividades artístico-expresivas y las actividades en el medio natural.

La conexión de la competencia específica 2 con el resto de la materia facilitará la
creación de proyectos y las unidades de programación combinando saberes para aumentar la
relación del alumnado con su entorno y grupo. El deporte escolar y el deporte inclusivo, dentro
de una práctica saludable, está directamente relacionado con la competencia específica 1.
Asimismo, el uso sostenible del patrimonio natural en actividades deportivas y juegos está
necesariamente conectado con la competencia específica 4. Finalmente, las aplicaciones y los
videotutoriales actuales facilitan la tarea docente a la vez que promueven la autonomía y el
sentido crítico del alumnado, consumidor proactivo tanto en las redes y plataformas digitales
como en los medios audiovisuales tradicionales, relacionándose directamente con la
competencia específica 5.

|  | a expresión corporal ayuda al enriquecimiento de su identidad emocional y personal y a la |  |  |
| --- | --- | --- | --- |
| participación en propuestas expresivas, adaptadas y guiadas, que fomentan la creatividad y |  |  |  |
| autoconfianza. |  | Del mismo modo, el | conocimiento, respeto y el placer de disfrutar de las diferentes |
| representaciones y expresiones artísticas del patrimonio cultural, en especial del patrimonio |  |  |  |
| cultural del territorio, |  |  |  |

La conexión de esta competencia, la competencia específica 4, con el resto de la materia
facilitará la creación de proyectos y unidades de programación combinando saberes para
aumentar la relación del alumnado con su entorno y grupo. Directamente relacionada con la
competencia específica 1, la realización de actividades físicas, deportivas y de ocio activo en el
medio rural y costero permitirá la mejora de la condición física y la salud física y mental utilizando
los espacios naturales. Asimismo, la resolución de situaciones motrices en diferentes actividades
físicas, adaptando las habilidades a los entornos y al grado de incertidumbre y el aprendizaje
autónomo en el medio, está necesariamente conectada con la competencia específica 2.
Finalmente, relacionada con la competencia específica 5, encontramos el uso activo y
responsable de las TIC en las actividades en el medio natural.

La conexión de esta competencia, competencia específica 5, con el resto de la materia
facilitará la creación de proyectos y las unidades de programación combinando saberes para
aumentar la relación del alumnado con su entorno y grupo, además de poder contactar y trabajar
colaborativamente con otros iguales de manera ubicua. También directamente relacionada con
la competencia específica 1, las TIC y las TAC son elementos facilitadores de una práctica física
regular y saludable. Las propuestas artístico-expresivas, competencia específica 3, descubren
en esta competencia la posibilidad de utilización de las aplicaciones y las herramientas de
grabación y edición pueden facilitar recursos expresivos que complementan los propios
proyectos.

También la resolución y el análisis de situaciones motrices en diferentes actividades
físicas, la organización y gestión de competiciones deportivas y la actitud crítica con las

informaciones relacionadas con el mundo del deporte y está necesariamente conectada con la
competencia específica 2.

3.2. Relaciones o conexiones con las competencias específicas de otras materias de la
etapa.

Evidentemente, las conexiones entre las competencias específicas de Educación Física
y las otras materias no tendrá el mismo protagonismo e intencionalidad. Aun así, podemos
establecer conexiones claras con otras materias de la etapa teniendo en cuenta las mismas
competencias clave, los saberes y los criterios de evaluación y su carácter transdisciplinario,
como se acaba de señalar, en mayor o menor medida.

La Educación Física se relaciona con la materia de Plástica, Visual y Audiovisual en el
uso de los diferentes recursos audiovisuales por la transformación de espacios motrices,
creativos e inclusivos y en las diferentes propuestas artísticas y elementos de apoyo visual.
También se relaciona con la utilización de lenguajes gráficos no convencionales, especialmente
aquellos en los que el cuerpo y el movimiento son protagonistas.

En cuanto a las relaciones con la materia de Música, destacamos la expresión corporal,
la danza, la percusión corporal y el proceso de interpretación y creación de coreografías.

La asignatura de Geografía e Historia se relaciona directamente con los saberes
relacionados con los periodos históricos en los que el deporte como fenómeno cultural, la
actividad física en sus diferentes dimensiones y la salud o la creación de mitos a su alrededor es
protagonista.

Las materias de Ciencias Naturales o Biología y Geología son las que tienen una
conexión más directa competencialmente en cuanto al conocimiento del cuerpo a nivel
estructural, fisiológico y cinesiológico. Además, el conocimiento de los saberes relacionados con
Biología y Geología es complementario para el aprovechamiento sostenible del entorno físico
como recurso en nuestra materia.

La asignatura de Matemáticas y Física se relaciona, más allá del cálculo y las
operaciones, con el razonamiento matemático en cuanto a la solución de problemas de juego
táctico, estrategia y probabilidad. La interpretación de la realidad respecto al espacio, las formas,
trayectorias, coordenadas y fuerzas, tanto del cuerpo humano como de los elementos del entorno
e implementos, que pueden interactuar con él.

La materia de Tecnología y Digitalización comparte necesariamente saberes y saber
hacer respecto al uso de dispositivos, herramientas y aplicaciones para la optimización del
proceso, la compilación y la transformación de la información. Favoreciendo también el trabajo
colaborativo e incidiendo en sus peligros, en cuanto al llamado sedentarismo tecnológico, la falta
de curación de contenidos y el respeto por la privacidad de nuestra imagen y nuestros datos
corporales, entre otros elementos de carácter ético que relacionan ambas materias. Finalmente,
destacamos las materias lingüísticas, que permiten el trabajo textual de reglamentos, guiones
para las dramatizaciones en proyectos interdisciplinarios y tecnicismos en cualquiera de los
saberes de las materias, especialmente en inglés en el mundo del deporte y el fitnes, y el
valenciano en nuestros deportes, juegos y danzas autóctonas. Además, la resolución de
conflictos de manera dialogada implica la mejora de la competencia para transmitir ideas y
sentimientos. La mejora de la oratoria o el fomento de la lectura también es un lugar común entre
todas las materias curriculares.

3.3. Conexiones con las competencias clave

El cuadro adjunto muestra las relaciones más significativas entre las cinco competencias
específicas de esta materia y las competencias clave incluidas en el perfil de salida del alumnado
al finalizar la educación básica. En todos los casos, esta relación opera en las dos direcciones.

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 | X |  | X | X | X | X | X |  |
| CE2 | X | X | X |  | X | X |  | X |
| CE3 | X |  |  | X | X | X | X | X |
| CE4 |  |  | X | X | X | X | X |  |
| CE5 |  | X |  | X | X |  | X |  |

●
CCL: Competencia en comunicación lingüística
●
CP: Competencia plurilingüe
●
CMCT: Competencia matemática y competencia en ciencia, tecnología e ingeniería
●
CD: Competencia digital
●
CPSAA: Competencia personal, social y de aprender a aprender
●
CC: Competencia ciudadana
●
CE: Competencia emprendedora
●
CCEC: Competencia en conciencia y expresión cultural

Competencias clave del perfil de salida del alumnado al final de la enseñanza básica:

La competencia en comunicación lingüística se desarrolla cuando el alumnado expresa
de manera oral o escrita hechos, pensamientos o sentimientos de manera correcta y adecuada
en los diferentes contextos sociales, participando en interacciones comunicativas con actitud
cooperativa y respetuosa, tanto para intercambiar información como para construir vínculos
personales. La participación y escucha activa en debates sobre la salud y la actividad física, la
creación de proyectos e interconexiones fuera del centro, entre otros, son objeto directo de estas
relaciones (CE1). La terminología específica, así como los aspectos culturales y sociales
presentes en la CE2, hacen necesaria una conexión directa con esta competencia clave a la hora
de emplear el lenguaje adecuado y seleccionar la información desde un punto de vista crítico. La
resolución dialogada y pacífica de los conflictos que surgen durante los juegos y deportes
también fomenta la tolerancia y la valoración del diálogo como medio para solucionar los
conflictos. Finalmente, la CE3 se puede desarrollar a través de la dramatización, por parte del
alumnado, de textos y obras teatrales y la colaboración en podcast para la radio del centro
educativo. Estas situaciones requieren que el alumnado emplee varios canales de comunicación
usando un lenguaje apropiado. En la materia de Educación Física es de especial relevancia esta
competencia clave respecto a la comunicación no verbal, tanto voluntaria como involuntaria, que
además tendrá una importancia clara en su vida diaria presente y futura.

|  | se puede desarrollar a través de la dramatización, por parte del |
| --- | --- |
| alumnado, de textos y obras teatrales y la colaboración en podcast para la radio del centro |  |
| educativo. Estas situaciones requieren que el alumnado emplee varios canales de comunicación |  |
| usando un lenguaje apropiado. En la materia de Educación Física es de especial relevancia esta |  |
| competencia clave respecto a la comunicación no verbal, tanto voluntaria como involuntaria, que |  |
| además tendrá una importancia clara en su vida diaria presente y futura. |  |

La competencia clave plurilingüe (CP) en la sociedad globalizada actual tiene una
conexión transversal, especialmente en el mundo del deporte, los materiales, las instalaciones y
los tecnicismos propios (CE02).  Cuando se trabaja con recursos tecnológicos, plataformas
virtuales y aplicaciones en una lengua diferente de la materna se contribuye a esta competencia
clave.

La competencia en matemáticas, ciencia, tecnología e ingeniería, implicará aquellas
acciones fundamentadas científicamente, conscientes y responsables, para preservar la salud e
integridad física y mental aplicando principios de ética y seguridad en la realización de proyectos
para transformar su entorno próximo de manera sostenible, valorando su impacto global (CE01).
Cuando se trabajan contenidos relacionados con el cuerpo y su funcionamiento, así como los
efectos de la actividad física en el organismo se contribuye a la competencia STEM (del inglés
Science, Technology, Engineering and Mathematics). Respecto a la conexión con esta
competencia, la utilización del pensamiento científico para entender los conceptos planteados,
formulándose preguntas y comprobando hipótesis mediante la experimentación, mostrando una
actitud crítica y la posibilidad de generar proyectos con el ámbito matemático y tecnológico, se
refiere a conceptos relacionados con fuerzas, velocidades, tiros, probabilidades, fisiología,
cineantropometría, creación y diseño de material y otros que aumentan el nivel motivacional y de
comprensión del alumnado (CE2). Las actividades físicas en el medio natural contribuyen a esta
competencia en ciencia mediante el conocimiento del medio natural y su uso sostenible y
responsable. Del mismo modo, se vinculan con contenidos tecnológicos cuando fomentamos el
uso crítico de los recursos digitales o cuando el alumnado planifica una salida en bicicleta, con
lo que fomenta la movilidad sostenible, puesto que tiene que tener en cuenta aspectos como la
mecánica de la bicicleta y comprender los factores energéticos implicados en la actividad (CE4).

|  |  | ontribuyen a esta |
| --- | --- | --- |
| competencia en ciencia mediante el conocimiento del medio natural y su uso sostenible y |  |  |
| responsable. | Del mismo modo, se vinculan con contenidos tecnológicos cuando fomentamos el |  |
| uso crítico de los recursos digitales o cuando el alumnado planifica una salida en bicicleta, con |  |  |
| lo que fomenta la movilidad sostenible, puesto que tiene que tener en cuenta aspectos como la |  |  |
| mecánica de la bicicleta y comprender los factores energéticos implicados en la actividad |  |  |

|  | través de la utilización de recursos técnicos, visuales y audiovisuales, |
| --- | --- |
| aplicaciones y herramientas de difusión que favorezcan una actitud de consumo proactivo del |  |
| alumnado ( |  |

Cuando el alumnado prioriza las actividades que contribuyen a la salud y bienestar a lo
largo de la vida (CE1) contribuye al desarrollo personal y social mediante esta competencia. El
alumnado, así, conoce los riesgos para la salud relacionados con factores sociales, y consolida
hábitos de vida saludable a nivel físico y mental. Trabajando en colaboración con otros, en

cooperación y en situaciones competitivas desarrollan relaciones afectivas y de autoconfianza,
mientras se enfrenta a la creciente influencia de los compañeros. A través de la práctica de
actividades físicas en grupo se contribuye a la socialización del alumnado desarrollando un
comportamiento cívico y enfatizando el uso consciente y responsable del material, de las
instalaciones y de su entorno natural (CE4 y CE5). El trabajo en equipo y la cooperación presente
en las actividades de grupo también ayudan al profesorado a trabajar este tipo de competencia
clave donde la aceptación de las diferencias y las limitaciones del resto de compañeros es
fundamental para aprender aspectos como la igualdad y la integración. Mediante la práctica de
los juegos y deportes (CE2) aparecen conceptos y actitudes como estrategias de colaboración,
oposición, integración, respeto, fair play, solidaridad, etc. La realización de juegos y deportes
cooperativos ayudan el profesorado a trabajar este tipo de competencia clave donde la valoración
de los juegos y deportes como medios de integración social y de mejora del clima de clase es
fundamental para aprender aspectos como la igualdad y la integración con sus compañeros y
compañeras. Con todo esto, el aprovechamiento del tiempo de ocio en momentos en los cuales
no es posible la práctica motriz, mediante los juegos de mesa, además, ayudará a desarrollar el
pensamiento táctico y la estrategia, así como el razonamiento divergente. Se contribuye a esta
competencia clave del alumnado mediante el desarrollo de un comportamiento cívico y
enfatizando el uso consciente y responsable del material, de las instalaciones y del entorno.

La capacidad de aprender a aprender se relaciona con la materia de Educación Física
en la medida que hace posible que el alumnado conozca sus propias capacidades a través de
un proceso reflexivo en el cual el alumnado mejora su propia conducta motriz partiendo del
conocimiento de sus puntos fuertes y débiles consiguiendo de este modo una mayor autonomía.
Mediante el aprendizaje de la planificación de actividades físicas (CE1 y CE4) la materia de la
educación física posibilita al alumnado regular su propio proceso de aprendizaje ocupando su
tiempo libre de manera activa y organizada, al mismo tiempo que se desarrolla la capacidad de
trabajo en equipo y su capacidad de transferir los nuevos aprendizajes técnicos y tácticos a otras
situaciones y actividades cotidianas (CE2). Mediante el aprendizaje de la vivenciación, creación
y planificación de actividades artístico-expresivas (CE3) se posibilita al alumnado regular su
propio proceso de aprendizaje además de ampliar sus recursos por la ocupación de su tiempo
libre.

|  | el aprendizaje de la vivenciación, creación |
| --- | --- |
| y planificación de actividades artístico-expresivas (CE3) se posibilita al alumnado regular su |  |
| propio proceso de aprendizaje además de ampliar sus recursos por la ocupación de su tiempo |  |
| libre. |  |

|  | l alumnado se implica |
| --- | --- |
| activamente por la mejora física y social colaborando de manera directa o indirecta en |  |
| intervenciones culturales artístico-expresivas (CE3) y |  |

|  | Con la asunción de responsabilidades en la organización y planificación de las |
| --- | --- |
| actividades artístico-expresivas (CE03) y de actividades en el medio (CE04) propuestas se |  |
| fomenta el hecho de conocerse a sí mismo, l |  |

|  | Se contribuye a la competencia de conciencia |
| --- | --- |
| y expresión cultural a través del desarrollo de una actitud positiva y una valoración de las |  |
| actividades de carácter artístico-expresivo. Mediante la práctica y ampliación de su bagaje |  |
| cultural de las técnicas expresivas y dramatizaciones se entienden estas manifestaciones de la |  |
| motricidad humana como hechos culturales presentes en todas las civilizaciones y se educa la |  |
| mirada valorando la diversidad cultural. El alumnado desarrolla la creatividad y el sentido de |  |
| pertenencia a través de la expresión cultural y artística conociendo y utilizando varios medios, |  |
| apoyos y técnicas corporales para crear productos artísticos y culturales a través de la |  |
| interpretación, ejecución, improvisación y composición, identificando las oportunidades de |  |
| desarrollo personal, social y económico que le ofrecen, protegiendo su creatividad y respetando |  |
| la de los otros. |  |

4. Saberes básicos

Desde una perspectiva epistemológica, los saberes básicos detallados a continuación
han sido seleccionados como el conjunto de conocimientos necesarios para adquirir y desarrollar
las competencias específicas que se han formulado previamente a la materia de Educación
Física. Respecto a la estructura, se establece una gradación de contenidos tanto para los dos
primeros cursos como para los dos últimos, con el propósito de dar continuidad y ampliar los
conocimientos adquiridos y también con una visión propedéutica. Estos saberes básicos
suponen la movilización integrada y la relación con la práctica pedagógica de las diferentes
capacidades motrices, cognitivas, emocionales y sociales a través de un enfoque flexible para
que el profesorado los adapte a las características socioculturales del entorno del centro
educativo, a la diversidad del alumnado y a su vínculo con la vida real. La programación de aula
que se genera a partir estos contenidos tendrá que propiciar unidades y proyectos integrando
varios saberes tanto en el mismo bloque como entre los otros, dejando a criterio del profesorado
el enfoque de estas manifestaciones, a favor de una Educación Física sensiblemente holística,
competencial e integrada en su vida.

Bloque 1. Vida activa i saludable. Este bloque aborda los tres elementos básicos que
integran el concepto de salud según la OMS: salud física, mental y social. A través de estos
contenidos se pretende generar una actitud positiva hacia la participación regular en actividades
físicas y deporte relacionadas con la salud y promover la adopción de estilos de vida activos, así
como la responsabilidad personal de un cuerpo saludable para toda la vida.

Bloque 2. Organización y gestión de la actividad física. Este bloque aborda aquellos
componentes relacionados con la planificación, organización y autorregulación de la práctica
física, así como aquellos aspectos relacionados con la seguridad de la práctica motriz.

Bloque 3. Resolución de problemas en situaciones motrices. Los saberes de este bloque
se relacionan con una variedad de experiencias motrices desarrolladas a través de juegos y
deportes y sus capacidades condicionales. Estos saberes se desarrollan en diferentes contextos
modificados de forma que se contribuya a la participación segura, a una mejor comprensión del
juego por parte del alumnado y a una práctica más inclusiva. Mediante estas actividades el
alumnado tiene la oportunidad de desarrollar su capacidad de toma de decisiones a través de
desafíos y retos individuales, cooperativos y/o de oposición con sus iguales en contextos
competitivos y no competitivos.

Bloque 4. Autorregulación emocional e interacción social en situaciones motrices.
Mediante estos saberes el alumnado tiene la oportunidad de vivenciar situaciones de gestión de
conflictos y regulación emocional fomentando el fair play y la deportividad, el conocimiento de
las respuestas comunicativas de su propio cuerpo ante diferentes mensajes y contextos
emocionales, el respeto a un mismo y a los otros, así como el sentido de responsabilidad hacia
su propio bienestar y el de sus compañeros.

Bloque 5. Manifestaciones de la cultura motriz. Quedan estructuradas en: cultura
artístico-expresiva, deporte como manifestación cultural y la cultura motriz tradicional, como la
Pilota Valenciana. La danza, la recreación dramática, las artes circenses, los juegos y deportes
populares y el deporte como fenómeno sociocultural, profundizando en el deporte inclusivo y
adaptado, conforman este subbloque.

Bloque 6.  Interacción eficiente y sostenible con el entorno. Agrupación de los saberes
conectados con el medio natural y el entorno urbano, relacionándose con el conjunto de
habilidades y experiencias físicas practicadas al aire libre, el conocimiento de las medidas de
seguridad, así como el protocolo de actuación y el uso de la tecnología como instrumento
facilitador, en estos entornos. Estos saberes facilitan la adopción de actitudes y valores
conectados con la conservación del medio natural, su uso sostenible y un aprendizaje autónomo
para toda la vida, relacionado con las actividades físicas al aire libre.

|  | Bloque 1. VIida activa y saludable |  | 2.º curso | 4.º curso |
| --- | --- | --- | --- | --- |
|  | CE1, CE3, CE5 |  |  |  |
|  | Subbloque 1.1 Salud física |  |  |  |
| Grupo 1. Características de las actividades físicas saludables |  |  |  |  |
| Conductas para la mejora de la salud física, mental y social |  |  | X |  |
| Frecuencia, intensidad, duración, tipo, progresión y variedad (FITT-PV). |  |  |  | X |
| La postura corporal y la ergonomía aplicada en la vida diaria, la actividad física y el deporte. |  |  |  | X |
| Grupo 2. Indicadores fisiológicos básicos relacionados con la salud y el ejercicio físico |  |  |  |  |
| Las pulsaciones (ppm) y el cálculo de la Zona de Actividad física Saludable (ZAS). |  |  | X | X |
| Síndrome general de adaptación, umbral aeróbico y anaeróbico, sobreentrenamiento y dolor muscular de aparición tardía (DOMS). |  |  |  | X |
| Métodos de entrenamiento y nuevas tendencias en fitness |  |  |  | X |
| Programación autónoma del ejercicio. |  |  |  | X |

| Grupo 3. Conocimiento anatómico, fisiológico y funcional |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Elementos del aparato locomotor relacionados con la motricidad. |  |  | X |  |  |  |  |  |
| Sistemas corporales: la nutrición y el gasto energético y su relación con el movimiento. |  |  | X |  |  |  |  |  |
| Conocimiento anatómico, fisiológico y funcional de los sistemas corporales relacionados con el movimiento, la actividad física y la salud. |  |  |  |  |  | X |  |  |
| La pisada como elemento trascendental en la marcha y la carrera. |  |  | X |  |  |  |  |  |
| Grupo 4. Cuidado del cuerpo |  |  |  |  |  |  |  |  |
| Análisis crítico de contenidos relacionados con el movimiento, la actividad física, el deporte y la salud. |  |  | X |  |  |  |  |  |
| Mitos y falsas creencias en el ámbito de la actividad física y el deporte. |  |  |  |  |  | X |  |  |
| Valoración de la práctica de la actividad física y el deporte en la escuela y en su entorno por sus efectos saludables. |  |  | X |  |  |  |  |  |
| Calentamiento general: partes esenciales. |  |  | X |  |  |  |  |  |
| Calentamiento específico autónomo. |  |  |  |  |  | X |  |  |
| La alimentación como factor decisivo en la salud personal, elementos y la dieta personalizada. |  |  |  |  |  | X |  |  |
|  | Subbloque 1.2 Salud social |  |  | 2.º curso |  |  | 4.º curso |  |
| Efectos negativos y conductas de prevención del consumo de tabaco, alcohol, otras drogas y la ludopatía asociada al deporte. |  |  | x |  |  | x |  |  |
| Ayudas ergogénicas legales y dopaje. |  |  |  |  |  | x |  |  |
|  | Subbloque 1.3 Salut mental |  |  | 2.º curso |  |  | 4.º curso |  |
| Grupo 1. Métodos y técnicas de relajación |  |  |  |  |  |  |  |  |
| Métodos de relajación y estiramientos |  |  | x |  |  | x |  |  |
| Técnicas de relajación y estiramientos. |  |  |  |  |  | x |  |  |
| Grupo 2. Efectos negativos y trastornos vinculados al cuerpo |  |  |  |  |  |  |  |  |
| Trastornos de la conducta alimentaria, así como sus efectos negativos en la salud personal y social. |  |  | X |  |  |  |  |  |

| Estados de desarrollo, prevención y detección de los trastornos de la conducta alimentaria (TCA) y de enfermedades en general. |  |  |  |  |  | X |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Bloque 2. Organización y gestión de la actividad física |  |  | 2.º curso |  |  | 4.º curso |  |
|  | CE1, CE4, CE5 |  |  |  |  |  |  |  |
|  | Subbloque 2.1. Medidas preventivas y de seguridad |  |  |  |  |  |  |  |
| Valoración de la correcta ejecución de las actividades físicas: lesiones deportivas y hábitos no saludables. |  |  |  |  |  | X |  |  |
| Higiene y actividad física |  |  | X |  |  | X |  |  |
|  | Subbloque 2.2. Actuaciones básicas y críticas ante situaciones de urgencia por lesión o accidente |  |  |  |  |  |  |  |
| Protocolos de actuación (PAS / RICE) |  |  | X |  |  | X |  |  |
| Dispositivos DEA |  |  |  |  |  | X |  |  |
| Uso de las TIC |  |  | X |  |  | X |  |  |
| RCP |  |  | X |  |  |  |  |  |
|  | Subbloque 2.3. Herramientas digitales para la gestión de la actividad física |  |  |  |  |  |  |  |
|  |  |  | X |  |  | X |  |  |
|  | Aplicaciones, recursos web y dispositivos específicos: seguimiento y control |  |  |  |  |  |  |  |
|  | del esfuerzo. Gestión práctica de actividad física. |  |  |  |  |  |  |  |
|  |  |  |  |  |  | X |  |  |
|  | Reconocimiento y gestión del buen uso de la tecnología relacionada con el |  |  |  |  |  |  |  |
|  | movimiento, la actividad física, el deporte y la salud, en diferentes entornos |  |  |  |  |  |  |  |
|  | de aprendizaje digital: planificación, control y análisis. Creación y curación |  |  |  |  |  |  |  |
|  | de contenidos |  |  |  |  |  |  |  |
|  | Bloque 3. Resolución de problemas en situaciones motrices |  |  | 2.º curso |  |  | 4.º curso |  |
|  | CE1, CE2, CE5 |  |  |  |  |  |  |  |
|  | Subbloque 3.1. Capacidades condicionales |  |  |  |  |  |  |  |
| Actividades y juegos de resistencia aeróbica, fuerza general y flexibilidad |  |  | X |  |  | X |  |  |
| Ejercicios específicos de resistencia, tonificación y flexibilidad (ROM) |  |  |  |  |  | X |  |  |
|  | Subbloque 3.2. Juegos y deportes |  |  |  |  |  |  |  |
| Individuales |  |  | X |  |  | X |  |  |
| Colectivos |  |  | X |  |  | X |  |  |

| Adversario |  |  | X |  |  | X |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Fundamentos técnicos deportivos |  |  | X |  |  | X |  |  |
| Fundamentos tácticos deportivos |  |  | X |  |  | X |  |  |
| Pensamiento estratégico |  |  |  |  |  | X |  |  |
|  | Bloque 4. Autorregulación emocional e interacción social en situaciones |  |  | 2.º curso |  |  | 4.º curso |  |
|  | motrices CE1 + CE3 |  |  |  |  |  |  |  |
|  | Subbloque 4.1. Habilidades sociales |  |  |  |  |  |  |  |
| Resolución dialogada y control emocional |  |  | X |  |  |  |  |  |
| Estrategias de resolución de conflictos: autonomía emocional |  |  |  |  |  | X |  |  |
|  | Subbloque 4.2. Gestión emocional |  |  |  |  |  |  |  |
| El estrés |  |  | X |  |  | X |  |  |
| La frustración |  |  | X |  |  |  |  |  |
|  | Subbloque 4.3. El cuerpo como elemento comunicativo |  |  |  |  |  |  |  |
| La expresión de mensajes y emociones |  |  | X |  |  |  |  |  |
| La comunicación no verbal consciente e inconsciente. |  |  |  |  |  | X |  |  |
| Contextualizaciones de la comunicación corporal en la vida cotidiana. |  |  |  |  |  | X |  |  |
| Bloque 5. Manifestaciones de la cultura motriz CE2, CE3, CE4, CE5 |  |  |  | 2.º curso |  |  | 4.º curso |  |
|  | Subbloque 5.1. Cultura artistico-expresiva |  |  |  |  |  |  |  |
| Grupo 1. Técnicas expresivas relacionadas con la danza, teatro y las artes vivas |  |  |  |  |  |  |  |  |
| Respecto de la propiedad intelectual |  |  | X |  |  | X |  |  |
| Valoración de las actividades artísticas como bien cultural. |  |  | X |  |  | X |  |  |
| La danza, el teatro y las artes vivas: desarrollo de la identidad artística. |  |  |  |  |  | X |  |  |
| Estereotipos y diversidad de género |  |  | X |  |  | X |  |  |
| Grupo 2. Montajes e intervenciones artísticas individuales y colectivas |  |  |  |  |  |  |  |  |

| Creatividad y autoconfianza | X |  |
| --- | --- | --- |
| Estereotipos | X | X |
| Las ayudas y la seguridad en las actividades expresivas | X |  |
| Proyectos interdisciplinarios artísticos |  | X |
| La luz y el sonido |  | X |
| Uso de la tecnología |  | X |
| Procesos de reflexión sobre temáticas sociales |  | X |
| Ayudas, seguridad y prevención de riesgos en los montajes artísticos |  | X |
| Grupo 3. La recreación dramática |  |  |
| Interpretación de textos. |  | X |
| La mirada y el gesto como elementos expresivos. | X |  |
| La postura corporal y el tono muscular | X |  |
| La postura corporal como elemento expresivo. |  | X |
| Las emociones. | X | X |
| Elementos de la comunicación verbal y no verbal. |  | X |
| Escenografía |  | X |
| Grupo 4. Actividades y artes circenses |  |  |
| Equilibrios con y sin material. | X |  |
| Juegos malabares. | X | X |
| El clown y el mimo | X | X |
| Lucha escénica. |  | X |
| Habilidades gimnásticas. | X |  |
| Artes circenses: Combinaciones y fusión con otras disciplinas. |  | X |
| Grupo 5. El ritmo y el cuerpo en movimiento |  |  |

| Apropiación del espacio |  | X |  |  |
| --- | --- | --- | --- | --- |
| Percusión corporal. |  | X | X |  |
| Montajes audiovisuales con y sin apoyo musical. |  | X | X |  |
| Grupo 6. Danza y bailes |  |  |  |  |
| Danzas propias del patrimonio cultural de la Comunidad Valenciana. |  | X |  |  |
| Danzas urbanas: medios de difusión y protección de la identidad personal. |  |  | X |  |
| Danzas del mundo: elementos inclusivos de los bailes y danzas. |  | X |  |  |
| Danza contemporánea. |  | X | X |  |
| Bailes de salón: baile latino y baile estándar |  |  | X |  |
|  | Subbloque 5.2. Deporte com manifestación cultural |  |  |  |
| Grupo 1. El deporte como manifestación cultural |  |  |  |  |
| Consumo responsable en el ámbito de la actividad física y el deporte: capacidad crítica y seguridad personal. |  | X | X |  |
| Grupo 2. El deporte inclusivo y adaptado |  |  |  |  |
| Diversidad funcional física, psíquica y sensorial. |  | X | X |  |
| Entidades próximas . |  | X | X |  |
| Acontecimientos deportivos. |  |  | X |  |
| Práctica y concienciación. |  | X | X |  |
|  | Subbloque 5.3. Cultura motriz tradicional |  |  |  |
| Grupo 1. Juegos populares |  |  |  |  |
| Juegos populares autóctonos. |  | X |  |  |
| Juegos populares del mundo. |  | X |  |  |
| Grupo 2. La Pelota Valenciana |  |  |  |  |
| Nyago y sus variantes. |  | X | X |  |
| Raspall y sus variantes de joc a carrer y en el trinquete. |  | X | X |  |

| El joc a paret: Frontón y frare. |  |  | X | X |
| --- | --- | --- | --- | --- |
| Los valores de la pilota: Bonhomia, equidad y pacto deportivo. |  |  | X | X |
| Otras modalidades: Escala i corda, galotxetes, pilota grossa, llargues, etc. |  |  |  | X |
| Referentes deportivos. |  |  | X | X |
| Mujer y Pilota. |  |  | X | X |
|  | Bloque 6. Interacción eficiente y sostenible con las otras personas |  | 2.º curso | 4.º curso |
|  | CE1, CE4, CE5 |  |  |  |
| Subbloque 6.1. Organización de actividades inclusivas físico-deportivas y de ocio activo en el medio rural y costero |  |  |  |  |
| Regulación del esfuerzo. |  |  | X |  |
| Medidas de protección y conservación del medio ambiente. |  |  | X | X |
| Reducción del impacto ambiental y la huella de carbono. |  |  | X |  |
| Proyectos de sostenibilidad de mejora del entorno. |  |  |  | X |
| Entidades y proyectos de centro. |  |  |  | X |
| Subbloque 6.2. Los parques y espacios públicos como espacios para la práctica deportiva y ejercicio físico. |  |  |  |  |
| Movilidad sostenible. |  |  | X | X |
| Promoción de buenas prácticas. |  |  | X |  |
| Subbloque 6.3. Riqueza natural y topográfica |  |  |  |  |
| La riqueza natural y topográfica de la Comunidad Valenciana. |  |  | X | X |
| La riqueza natural y topográfica otras regiones. |  |  |  | X |
| Adecuación del espacio, técnicas de acampada y supervivencia. |  |  |  | X |
| Subbloque 6.4. Las TIC desde las actividades en el medio natural |  |  |  |  |
| Las TIC en las actividades en el medio natural (GPS, pulsómetro, tracks, etc.). |  |  | X | X |

| Control y evaluación de las actividades en el medio a través de dispositivos electrónicos. |  | X |
| --- | --- | --- |
| Creación de contenidos |  | X |

5. Situaciones de aprendizaje

El propósito central del Sistema Educativo es preparar a los y las jóvenes para su vida,
ayudándolos a desarrollar estrategias y recursos mentales, emocionales y sociales para afrontar
la incertidumbre, complejidad y desafíos presentes y futuros. Las situaciones de aprendizaje
tendrán que incluir tareas competenciales, que forman parte intrínseca de la evaluación auténtica
como oportunidad de aprendizaje, atendiendo a las siguientes características:

Las situaciones de aprendizaje tienen que ser significativas. Deben conectarse con los
conocimientos, habilidades y valores del alumnado, al mismo tiempo que amplían y desafían sus
formas actuales de pensar y de actuar. La capacidad de expresar pensamientos y sentimientos
de manera clara con variedad de medios y formas y de compartirlo, favorecerá la creatividad y
readaptación del diseño de las tareas. En Educación Física, donde el cuerpo en movimiento es
el elemento central, implica establecer conexiones entre los conocimientos, las habilidades, las
experiencias, las actitudes y los valores, promoviendo que el alumnado pueda aprender de
manera efectiva a vincular y aplicar estos conocimientos a través de diferentes áreas de
aprendizaje de manera significativa y transmitirlo a sus iguales y su entorno.

Las situaciones de aprendizaje tienen que ser funcionales y deben garantizar que se
puedan aplicar y practicar los procesos, habilidades y valores, en una variedad de contextos,
tanto dentro como fuera del aula. Se trata de desarrollar habilidades para participar
constructivamente en la sociedad y en los procesos que la sostienen. Este aprendizaje será más
efectivo en la medida que el alumnado es capaz de establecer vínculos entre el entorno escolar
y su entorno comunitario, laboral y doméstico. Estas experiencias de aprendizaje tienen que ser
variadas y tienen que permitir al alumnado observar y practicar la realidad de los procesos y los
valores relacionados con la salud, que se espera buscando un estilo de vida saludable. Todo
esto, con una actitud proactiva y en un entorno inclusivo donde los principios del Diseño Universal
del Aprendizaje (DUA) pueden ser muy útiles proporcionando varias formas de representación,
expresión e implicación.

Las experiencias de aprendizaje tienen que potenciar la práctica autónoma, de animar
al alumnado a aprender tanto de manera independiente como entre sus iguales,
proporcionándole experiencias de aprendizaje que suponen aprender tanto de manera individual
como colaborativa. En este sentido, será fundamental motivarlos al hecho que tomen
responsabilidad de su propio proceso de aprendizaje convirtiéndolos en aprendices
independientes que eligen la manera individual para explorar problemas relacionados con los
saberes de nuestra materia. A través del trabajo de manera individual se fomenta en el alumnado
la comprensión personal de conceptos y procedimientos relacionados con el movimiento. Por
otro lado, trabajar en grupos permite que el alumnado sienta el desafío de lograr las tareas, a la
vez que es apoyado y motivado por las opiniones y habilidades de los otros compañeros y
compañeras, ampliando sus habilidades de colaboración, de trabajo en equipo y colaboración
entre iguales (peer to peer) y la capacidad de resolver conflictos de manera dialogada. El
aprendizaje cooperativo involucra al alumnado en un aprendizaje interactivo y con propósito en
los programas de educación física, proyectos educativos interdisciplinarios y ámbitos. Esto no

relega la competición a un modelo necesariamente excluyente sino más bien a un recurso de
reflexión y práctica para implementar propuestas y actividades de mejora mientras continúa, si
es el caso, el modelo competitivo.

Por el hecho que toda situación de aprendizaje genera un efecto específico en cada
alumno y alumna, la tarea presentada tiene que ser vivida por el alumnado como un problema a
resolver, y ante el cual el estudiante dispone de posibilidades reales de solución, ya sea
individualmente o mediante algún tipo de ayuda. Buscamos una reflexión intrínseca al proceso
de aprendizaje, en el cual todas las tareas tienen que actuar como elemento evaluador, dando
información y retroalimentado el mismo. Los desafíos o retos tienen que estar al alcance del
alumnado y variarán según las características individuales y del grupo.

Se recomienda plantear retos integrados en un escenario motor en el cual no aparezcan
las características específicas de ejecución de la habilidad o habilidades pedidas. Es decir, se
presenta una situación cuyas respuestas diferentes son posibles y, por lo tanto, no se describe
una única respuesta válida que el alumnado tenga que atender con criterios de eficiencia motriz.
Esto comporta la posibilidad que el alumnado, en nombre de su individualidad, pueda poner de
manifiesto su motricidad particular ante un problema concreto que él o ella tiene que resolver.
Esta situación problema tiene que permitir y estimular que el abanico de respuestas que puedan
ser consideradas válidas sea bastante amplio. Esta amplitud y validez de las respuestas depende
básicamente del margen de maniobra que ofrecen los dos rasgos descritos anteriormente.
Plantear las tareas como un reto a realizar y, como consecuencia, como un problema a resolver
sitúa al alumnado ante una necesidad a la cual debe responder. De esta manera, abre el espacio
a la curiosidad y busca ofrecer una respuesta motriz adecuada y pertinente para un posterior
proceso de autorreflexión y mejora. Todo esto sin perjuicio de la enseñanza del gesto motor
técnico específico como resolución más eficiente y eficaz.

En definitiva, para el profesorado representa una opción que facilita su función de ayuda
pedagógica y que, metodológicamente, le permite la graduación en un proceso de evaluación
continuo por la readaptación y las propuestas de mejora del alumnado y el profesorado, elemento
fundamental para la consecución del criterio específico de evaluación.

A lo largo de la etapa de Secundaria se buscará la autonomía, autogestión y espíritu
crítico en una transferencia progresiva para situaciones de aprendizaje competenciales. De este
modo, mediante el logro de los objetivos de desarrollo sostenible, se trabajan algunos de los
retos del siglo XXI, como son el respeto al medio ambiente y la práctica de un estilo de vida
saludable.

Además, encontramos relación con los otros retos, como son el consumo responsable,
la resolución pacífica de los conflictos, la aceptación y manejo de la incertidumbre, el compromiso
ante las situaciones de inequidad, la valoración de la diversidad personal y cultural, la confianza
en el conocimiento como motor del desarrollo, y el aprovechamiento crítico, ético y responsable
de la cultura digital.

En cuanto a la movilización de recursos en contexto, las características de las
situaciones de aprendizaje tienen que acercarse progresivamente a contextos reales de práctica
y, especialmente, a los recursos e instalaciones que rodean en el centro. El alumnado tiene que
conocer las entidades, clubes y asociaciones deportivas de su entorno, así como la gestión de
los recursos implicados, como instalaciones municipales y otras no específicas que igualmente
son adecuadas, para una mejora de su calidad de vida mediante la actividad física y el deporte.

Las situaciones de aprendizaje tienen que involucrar los recursos internos del alumnado,
animándolos a utilizar sus recursos permitiéndolos adoptar o descubrir nuevas maneras de hacer

y pensar las cosas en diferentes contextos, conocidos y nuevos, de actividad física. Se tiene que
alentar a los estudiantes al hecho que adopten un comportamiento que demuestre respeto por
ellos mismos, los otros y su entorno, y que se adhieran a las reglas de seguridad impuestas por
cualquier situación dada. Los diferentes grados de complejidad de las tareas pueden reflejarse
también en términos de su estructura, grado de familiaridad, ritmo, duración y nivel de dificultad
del desempeño esperado y especialmente la interconexión competencial asociada.

Las situaciones de aprendizaje tienen que promover una ciudadanía activa. Así mismo,
atendiendo a la alfabetización digital como aliada, desde una perspectiva conectivista
entendemos que los recursos y contenidos de la materia se pueden encontrar también de manera
virtual de las páginas web y en las redes sociales. Se busca de este modo que el alumnado sea
capaz de asumir contenidos durante todo proceso, a través de la evaluación de su propio
aprendizaje y ajustando sus elecciones y habilidades de acuerdo con los retos que se les plantea,
al grupo y de manera individual. El análisis y argumentación razonada en dicha interacción con
el grupo favorecerá el espíritu crítico necesario en la sociedad actual de las fake news.

El alumnado tiene que comprender varias posibilidades de acción e interrelación de
contenidos entre las diferentes áreas curriculares. Los desafíos derivados de estas situaciones
tienen que adaptarse a sus capacidades y les obliga a seleccionar y a reconocer las conexiones
entre su aprendizaje previo y los requisitos asociados con la práctica de actividades físicas
relacionadas con la competencia trabajada, relacionando con las competencias específicas otras
áreas y adaptando cada una de las competencias a otros contextos para adoptar un estilo de
vida activo y saludable.

6. Criterios de evaluación

CE 1. Integrar un estilo de vida activo mediante la práctica de la actividad física y
deportiva autorregulada, y el establecimiento de conexiones entre los hábitos de comportamiento
cotidianos y el bienestar físico y mental

|  | 2.º de ESO |  |  | 4.º de ESO |  |
| --- | --- | --- | --- | --- | --- |
| 1.1. Utilizar los recursos de su entorno relacionados con la actividad física, la alimentación y el bienestar personal, aplicando propuestas básicas de mejora de la salud física, mental y social. |  |  | 1.1. Seleccionar y utilizar diferentes recursos del entorno relacionados con la actividad física, la alimentación y el bienestar personal poniéndolos al servicio de la salud física, mental y social. |  |  |
| 1.2. Aplicar los conocimientos anatómico-fisiológicos adquiridos a la creación de un plan de mantenimiento y mejora de la condición física personal. |  |  | 1.2. Diseñar un plan específico de mejora de la condición física aplicando métodos y sistemas de desarrollo físico adaptados a las características individuales y del entorno. |  |  |
| 1.3. Relacionar el estilo de vida activo con los efectos positivos sobre la salud y la imagen personal con las actividades físico- deportivas, identificando las conductas de riesgo. |  |  | 1.3. Adoptar un estilo de vida activo con sus efectos positivos sobre la salud, la imagen personal y las actividades físico- deportivas, identificando las conductas de riesgo y aplicando diferentes técnicas para |  |  |

|  | Seleccionar y utilizar diferentes |
| --- | --- |
| recursos del entorno relacionados con la |  |
| actividad física, la alimentación y el bienestar |  |
| personal poniéndolos al servicio de la salud |  |
| física, mental y social. |  |

|  | Diseñar un plan específico de |
| --- | --- |
| mejora de la condición física aplicando |  |
| métodos y sistemas de desarrollo físico |  |
| adaptados a las características individuales y |  |
| del entorno. |  |

|  | el estilo de vida activo |
| --- | --- |
| con los efectos positivos sobre la salud y la |  |
| imagen personal con las actividades físico- |  |
| deportivas, identificando las conductas de |  |
| riesgo. |  |

compensar las tensiones propias de la vida
cotidiana.

CE 2. Resolver con éxito diferentes retos y situaciones motrices a través de propuestas
físicas y deportivas específicas aplicando las técnicas, tácticas y estrategias de juego adecuadas.

| 2.º de ESO |  |  | 4.º de ESO |
| --- | --- | --- | --- |
| 2.1. Participar activamente y colaborar en juegos y actividades físico- deportivas practicando el respeto, la tolerancia y el trabajo en equipo. |  | 2.1. Participar activamente y colaborar en la organización de juegos y actividades físico- deportivas favoreciendo el respeto, la tolerancia y el trabajo en equipo. |  |
| 2.2 Resolver con éxito situaciones reales de competición y cooperación sencillas a través de la aplicación de habilidades motrices específicas y de estrategias. |  | 2.2 Resolver con éxito diferentes situaciones reales de competición y cooperación a través de la aplicación de habilidades motrices específicas y de estrategias, por medio del fomento de la autogestión de la práctica de la actividad física y deportiva. |  |
| 2.3. Reconocer los aspectos culturales y sociales que rodean el fenómeno deportivo tomando conciencia de sus valores positivos y de los aspectos que generan desigualdad en diferentes contextos de actuación. |  | 2.3. Valorar críticamente los aspectos culturales y sociales que rodean el fenómeno deportivo tomando conciencia de sus valores positivos y de los aspectos que generan desigualdad en diferentes contextos de actuación. |  |

CE 3. Participar en procesos de creación de naturaleza artístico-expresiva mediante el
uso del cuerpo, el gesto y el movimiento como medios de autoconocimiento para expresar ideas
y sentimientos.

| 2.º de ESO |  |  | 4.º de ESO |
| --- | --- | --- | --- |
| 3.1. Crear situaciones comunicativas con el gesto, el cuerpo y el movimiento corporal, mediante modelos y creatividad. |  | 3.1. Explorar y generar situaciones comunicativas con el gesto, el cuerpo y el movimiento corporal. |  |
| 3.2. Producir movimientos creativos con apoyo musical, combinando ritmos y segmentos corporales y mostrando fluidez, desinhibición y autoconfianza. |  | 3.2. Ampliar la calidad y experiencia en cuanto a la creatividad relacionada con el movimiento, especialmente con apoyo musical combinando ritmos y segmento corporales y mostrando fluidez, desinhibición y autoconfianza. |  |
| 3.3. Crear montajes artísticos colectivos y participar en ellos comunicando ideas, sentimientos y emociones. |  | 3.3. Diseñar proyectos artísticos multidisciplinarios y participar en ellos como medio de comunicar ideas, sentimientos y emociones. |  |

CE 4. Interaccionar de manera sostenible con el patrimonio natural y cultural mediante
actividades físicas y artístico-expresivas.

|  | 2.º de ESO |  |  | 4.º de ESO |  |
| --- | --- | --- | --- | --- | --- |
| 4.1. Colaborar en la organización y diseño de actividades físico-deportivas inclusivas respetuosas con el medio ambiente, teniendo en cuenta el paisaje y la toponimia del entorno. |  |  | 4.1. Participar de manera activa en la organización y diseño de actividades físico- deportivas inclusivas respetuosas con el medio ambiente, teniendo en cuenta el paisaje y la toponimia del entorno. |  |  |
| 4.2. Conocer y practicar técnicas y procedimientos de primeros auxilios, así como los protocolos de seguridad y de autoprotección personal incluida la RCP. |  |  | 4.2. Mejorar mediante la práctica y la relación con entidades del entorno, las técnicas y procedimientos de primeros auxilios, así como los protocolos de seguridad y de autoprotección personal, incluida la RCP. |  |  |
| 4.3. Participar en las actividades artístico-expresivas del entorno natural y urbano, y valorar la diversidad personal y cultural. |  |  | 4.3. Descubrir y participar activamente en las actividades artístico- expresivas del entorno natural rural, de nuestra costa y urbano, y valorar la diversidad personal y cultural. |  |  |
| 4.4. Implementar de manera colaborativa con la comunidad educativa medidas relacionadas con la movilidad, el reciclaje y la alimentación para promover un centro sostenible. |  |  | 4.4. Implementar de manera colaborativa con la comunidad educativa propuestas para promover un entorno sostenible, relacionando este hecho directamente con la materia de Educación Física, mediante la movilidad, el reciclaje y la alimentación. |  |  |
| 4.5. Reconocer el valor cultural de la Pilota Valenciana mediante la pràctica y los elementos sociales que rodean este deporte. |  |  | 4.5. Valorar la Pilota valenciana como bien de interés inmaterial de especial protección, mediante la práctica de sus diferentes modalidades. |  |  |

CE 5. Seleccionar y hacer un uso crítico y seguro de las tecnologías de la información y
la comunicación como facilitadoras de la actividad física y de una vida activa y saludable.

|  | 2.º de ESO |  |  | 4.º de ESO |  |
| --- | --- | --- | --- | --- | --- |
| 5.1. Emplear recursos tecnológicos relacionados con la actividad, el deporte y la salud, utilizando varias fuentes de información y tecnología en función de su eficiencia para la resolución de situaciones cotidianas. |  |  | 5.1. Escoger en función de su idoneidad los recursos tecnológicos relacionados con la actividad, el deporte y la salud, evaluando las fuentes de información e innovación. |  |  |

| 5.2. Conocer fuentes de información y de contenido digital relevantes y fiables, relacionadas con los saberes de la materia, empleando estrategias de investigación y organización de la información. | 5.2. Diferenciar las fuentes de información y de contenido digital relevantes y fiables relacionadas con los saberes de la materia, actualizando las estrategias de investigación y organización de la información y la manera de interacción, netiqueta. |
| --- | --- |
| 5.3. Elaborar colaborativamente contenidos digitales sencillos relacionados con la actividad física y la salud, integrando la información de manera crítica. | 5.3. Producir contenidos relacionados con la actividad física y la salud en diferentes formatos digitales, integrando la información de manera crítica y participando colaborativamente en los escenarios de comunicación y aprendizaje. |
