# INTELIGENCIA ARTIFICIAL, PROGRAMACIÓN Y ROBÓTICA

> Fuente: Secundaria.pdf, páginas 1125-1138 (versión en castellano).

INTELIGENCIA ARTIFICIAL, PROGRAMACIÓN Y ROBÓTICA

1.
Presentación

|  | La inteligencia artificial y la robótica se han incorporado a nuestras vidas en muchas de |
| --- | --- |
| las tareas cotidianas y, junto con las posibilidades asociadas a la programación, conforman |  |
| algunos de los elementos clave en la transformación de nuestra sociedad. La revolución digital |  |
| de la segunda mitad del siglo XX posibilitó la aparición de la era de la información. Sin embargo, |  |
| no fue hasta años más tarde, con el acceso mejorado a Internet, el procesamiento de grandes |  |
| volúmenes de datos y su tratamiento automático a través de medios informáticos, cuando |  |
| evolucionamos hacia la sociedad de la información, sucesora de la industrial. Actualmente, desde |  |
| principios del siglo XXI, la incorporación y desarrollo de la computación y su aplicación en |  |
| sistemas de inteligencia no biológica y en robots suponen un efecto disruptor hacia una nueva |  |
| revolución industrial y un punto de inflexión en el desarrollo de la sociedad. Este nuevo escenario |  |
| proporciona suficientes motivos para que la codificación de algoritmos sea considerada una |  |
| disciplina instrumental. La materia Inteligencia Artificial, Programación y Robótica utiliza los |  |
| fundamentos del pensamiento computacional para profundizar en el desarrollo del software, |  |
| actuar sobre técnicas de inteligencia artificial, de la virtualización de la realidad y programar |  |
| sistemas robóticos. Asimismo, las implicaciones de estas tecnologías para la sociedad son fruto |  |
| de análisis y debate en esta materia, que contribuye al desarrollo científico, ético y social del |  |
| alumnado. |  |

|  | La aportación de esta materia al logro de los objetivos de etapa es muy relevante por las |
| --- | --- |
| implicaciones de los aprendizajes que promueve. Su relación directa con las ciencias de la |  |
| computación y la ingeniería le confiere las características necesarias para el desarrollo de las |  |
| competencias tecnológicas y digitales básicas, así como de la reflexión ética sobre su |  |
| funcionamiento y utilización. Las metodologías activas que se proponen en las situaciones de |  |
| aprendizaje favorecen el desarrollo del espíritu emprendedor y la confianza en sí mismo, la |  |
| participación, el sentido crítico, la iniciativa personal y la capacidad para aprender a aprender, |  |
| planificar, tomar decisiones y asumir responsabilidades. La transversalidad del conocimiento |  |
| tecnológico y digital de esta materia es cada vez mayor en la sociedad, y la educación no es |  |
| ajena a ello, siendo un magnífico soporte para otras materias de esta y sucesivas etapas |  |
| educativas y laborales. |  |

|  | Inteligencia Artificial, Programación y Robótica contribuye al perfil de salida del alumnado |
| --- | --- |
| de la Educación Secundaria Obligatoria mediante aportaciones específicas valiosas para la |  |
| formación integral del alumnado y que conectan con otras materias, principalmente del ámbito |  |
| científico. El carácter práctico e inclusivo de esta materia también le confiere una importante |  |
| relación con materias del ámbito lingüístico y ético debido al continuo diálogo que se debe |  |
| mantener para poder abordar y resolver los desafíos del siglo XXI. |  |

|  | Mediante la adquisición y desarrollo de las competencias específicas de esta materia se |
| --- | --- |
| asegura el aprendizaje, articulación y movilización de los conocimientos, actitudes, destrezas y |  |
| habilidades necesarias para que el alumnado pueda afrontar las situaciones de incertidumbre y |  |
| con la confianza en el conocimiento como motor de desarrollo y solventarlas. También se |  |
| fomenta la ciudadanía comprometida con los desafíos del S. XXI desde una perspectiva ética, |  |
| igualitaria, inclusiva, responsable, ecosocial y sostenible. |  |

En lo que concierne a las competencias clave incluidas en el perfil de salida del alumnado
de la Educación Básica, por un lado, esta materia está especialmente relacionada con las

competencias matemática y en ciencia, tecnología e ingeniería y digital mediante los
aprendizajes asociados al pensamiento computacional, la robótica, la inteligencia artificial y la
virtualización de la realidad. Por otro lado, está relacionada con las competencias clave
emprendedora, personal social y aprender a aprender, lingüística y plurilingüe habida cuenta del
carácter práctico de la materia y de la necesidad de buscar y llegar a soluciones creativas y éticas
a los retos diseñados según las recomendaciones de las situaciones de aprendizaje.

La materia Inteligencia Artificial, Programación y Robótica aplica los principios
pedagógicos de la LOMLOE planteando situaciones de aprendizaje que contemplan las
diferentes capacidades del alumnado y promueven el trabajo autónomo individual o en equipo,
así como la reflexión crítica. La realización de proyectos tecnológicos e informáticos es una tarea
significativa y relevante para el alumnado adolescente, mediante la cual se consigue potenciar
la creatividad, la reflexión, la autoestima, la responsabilidad, así como el desarrollo de la
comprensión y expresión oral, escrita y audiovisual y la comprensión y uso de las matemáticas.

El enfoque didáctico competencial y fundamentalmente práctico se concreta en
situaciones de aprendizaje desafiantes, motivadoras y auténticas que parten de los intereses e
inquietudes del alumnado adolescente. De esta forma, se les otorga el protagonismo en el
aprendizaje y la movilización de los saberes necesarios que les conducirán con éxito a la
consecución de los objetivos planteados.

En la materia Inteligencia Artificial, Programación y Robótica, el alumnado desarrolla una
serie de competencias específicas cuyo grado de consecución se valora mediante los
correspondientes criterios de evaluación. En la Educación Primaria, el alumnado se ha iniciado
en la realización de proyectos guiados utilizando operadores tecnológicos sencillos para dar
solución a problemas concretos, así como en desarrollar el pensamiento computacional,
proporcionando la base sobre la que se asienta esta materia. La adquisición de las competencias
específicas de esta materia durante la Educación Secundaria Obligatoria facilita el desarrollo
personal, social, educativo y profesional posteriores.

A continuación, se describe una propuesta de los aprendizajes esenciales en Inteligencia
Artificial, Programación y Robótica. Tomando como ideas vertebradoras el pensamiento
computacional, el funcionamiento y técnicas de inteligencia artificial y de la virtualización de la
realidad, el montaje y análisis de sistemas robóticos, el impulso de la colaboración y el trabajo
en equipo, así como el fomento de actitudes, perseverancia y la responsabilidad en el desarrollo
sostenible y ecosocial.

Concretamente, se formulan las cuatro competencias específicas. Cada una de ellas
tiene un conjunto de conexiones con algunas de las competencias clave, con el resto de
competencias específicas de la materia y con las del resto de las materias de la etapa, que se
presentan también brevemente. Los saberes básicos exigidos para la adquisición y desarrollo de
las competencias específicas se organizan en tres bloques de contenidos: Inteligencia artificial,
programación y robótica.

En el apartado dedicado a situaciones de aprendizaje se presentan algunos principios y
directrices para diseñar tareas y actividades que promuevan la adquisición y desarrollo de las
competencias específicas. La idea directriz en este punto es partir de situaciones relevantes y
significativas para el alumnado, poniendo en marcha procesos pedagógicos flexibles e inclusivos,
ajustados a sus características y diferentes ritmos de aprendizaje siguiendo los principios del
Diseño Universal de Aprendizaje Accesible.

Por último, se formulan unos criterios de evaluación para cada competencia específica
que indican el nivel de desarrollo competencial que se espera que el alumnado alcance mediante

el aprendizaje, articulación y movilización de los saberes básicos en las distintas situaciones de
aprendizaje.

2.
Competencias específicas

2.1.
Competencia específica 1

Identificar, investigar y emplear técnicas de inteligencia artificial y virtualización de la
realidad en el abordaje y la búsqueda de soluciones a problemas básicos de la sociedad
valorando los principios éticos e inclusivos aplicados.

2.1.1.
Descripción de la competencia 1

Esta competencia parte de la comprensión del funcionamiento de la inteligencia humana
para llegar a identificar e investigar los principios en los que se basan las técnicas de inteligencia
artificial utilizadas en cualquier dispositivo electrónico. Los saberes básicos asociados a esta
competencia abarcan desde las decisiones y el libre albedrío que utilizamos los humanos para
desarrollar nuestra inteligencia, hasta los sistemas expertos, las redes neuronales y el
aprendizaje automático que desarrolla una máquina. Es en las situaciones de aprendizaje donde
se incluye la propuesta de incorporar algún algoritmo de inteligencia artificial a las soluciones de
los problemas básicos planteados, teniendo en cuenta los principios éticos que permitan el
desarrollo de una sociedad digital igualitaria e inclusiva.

También se incorpora a esta competencia específica y a su conjunto de saberes básicos
la realización de técnicas de virtualización de la realidad, siendo en las situaciones de aprendizaje
donde se diseñan estrategias para movilizar los conocimientos, destrezas y habilidades
adquiridos.

Con el desarrollo de esta competencia, el alumnado adopta una posición ética y crítica
con la que buscar el bienestar común a través de la consecución del bienestar personal, para lo
que abandona la visión próxima de sus problemas y se compromete con desafíos más globales.
También se debe trabajar con un grado de incertidumbre y empatía mayores, ya que las
dimensiones globales de las problemáticas les exigirán soluciones más críticas, reflexivas,
creativas, justas, equitativas e inclusivas.

Al final del primer año en que se cursa la materia, el alumnado es capaz de valorar a
nivel elemental las implicaciones sociales que en los campos éticos y culturales de la sociedad
digital actual tiene la Inteligencia Artificial, tales como el respeto por la privacidad, la seguridad,
los abusos potenciales que se pueden producir y el balance entre beneficios y perjuicios que
representa. También se identifican los fundamentos y el funcionamiento básicos de la Inteligencia
Artificial e investigan las situaciones en las que se pueden aplicar. Se utilizan con ayuda,
funciones de inteligencia artificial en aplicaciones sencillas. Al final del segundo año, se aumenta
el nivel de complejidad en la identificación, investigación y valoración ética de las técnicas de
inteligencia artificial. Al mismo tiempo, el uso de estas funciones se realiza incrementando la
autonomía del alumnado y aplicando criterios éticos e inclusivos. Además, el alumnado es capaz
de emplear técnicas sencillas de virtualización de la realidad.

2.2.
Competencia específica 2

Aplicar el pensamiento computacional en el análisis y resolución de problemas básicos
significativos para el alumnado mediante el desarrollo de software.

2.2.1.
Descripción de la competencia 2

El pensamiento computacional requiere analizar problemas y modelizar la realidad para
definir algoritmos y estructuras de datos que planteen soluciones eficientes e inclusivas,

pudiendo desarrollarlos mediante aplicaciones multiplataforma y los paradigmas o entornos de
programación que se consideren oportunos para conseguir la solución de la manera más
eficiente. Con el desarrollo de esta competencia específica se aplica el pensamiento
computacional para analizar problemas y plantear sus posibles soluciones de manera que
puedan llevarse a cabo tanto por una persona, como por una máquina o inteligencia artificial. La
competencia está enfocada a la resolución de problemas relevantes y significativos para el
alumnado a nivel elemental y básico, de manera individual o en equipo de trabajo, de forma que
suscite el interés y la curiosidad por la innovación y el progreso científico-tecnológico desde una
perspectiva igualitaria, inclusiva y sostenible en el alumnado.

Esta competencia específica aporta a la consecución del perfil competencial del
alumnado la aceptación y el manejo de la incertidumbre provocada por los problemas reales
planteados, y la construcción del concepto positivo de la diversidad como potenciador de
sinergias en el proceso de desarrollo creativo del software. Obviamente, exige un
aprovechamiento crítico, ético y responsable de la cultura digital, con el uso de repositorios de
programas y el respeto a las diferentes licencias de autoría. Por otra parte, la programación
continúa con el desarrollo de las competencias relacionadas con el pensamiento computacional
iniciado en etapas anteriores facilitando el proceso de aprender a aprender en los ámbitos
personales y educativos posteriores.

Tras cursar el primer nivel de esta materia, el alumnado es capaz de analizar problemas
elementales que se resuelven programando aplicaciones sencillas de forma guiada, las cuales
se validan para demostrar su eficacia. Se adquieren las destrezas básicas implicadas en la
programación a través del análisis de aplicaciones existentes y de la utilización de algoritmos y
estructuras de datos, y se describen y valoran los derechos de autoría y licencias del software.
En el segundo curso, se profundiza en el análisis de problemas básicos y el alumnado es capaz
de resolverlos con un nivel de autonomía mayor y una mayor eficiencia en las soluciones
generadas. Estas soluciones se desarrollan para diferentes dispositivos, usando el entorno de
desarrollo más adecuado, aplicando y respetando los derechos de autoría, y sobre las que se
realiza un posterior mantenimiento.

2.3.
Competencia específica 3

Montar sistemas robóticos sencillos, analizando las respuestas que proporcionan en su
interacción con el entorno y valorando la eficacia de estas frente a los retos planteados.

2.3.1.
Descripción de la competencia 3

Esta competencia permite solucionar pequeños retos mediante montajes robóticos
sencillos. En el montaje del robot intervienen distintos módulos de entrada y salida que facilitan
la interacción con el entorno y los objetos. La eficacia de las distintas respuestas que el robot
proporcione serán objeto de análisis y validación, con la finalidad de poder valorar
adecuadamente su idoneidad frente a la tarea que se pretende realizar. Estos procesos
conducen a una revisión iterativa de las decisiones adoptadas en el montaje y selección de
componentes que integran el robot hasta alcanzar aquella que proporciona la respuesta más
satisfactoria.

Al final del primer curso, el alumnado es capaz de montar robots para poder realizar
tareas y resolver retos sencillos propuestos en las situaciones de aprendizaje, empleando los
sensores de entrada y los actuadores que les sean facilitados, de forma que para resolver los
retos planteados analice y valide el programa de control adecuado. Al acabar el segundo curso,
el alumnado ha adquirido los conocimientos para montar robots en respuesta a problemas de
mayor complejidad, siendo capaz de elegir los dispositivos de entrada y salida más adecuados

en función del problema al que se enfrentan, controlando de forma remota el robot para su
interacción con el entorno.

2.4.
Competencia específica 4

Afrontar retos tecnológicos sencillos y proponer soluciones mediante la programación, la
Inteligencia Artificial y la robótica, analizando las posibilidades y valorando críticamente las
implicaciones éticas y ecosociales.

2.4.1.
Descripción de la competencia 4

La constante evolución tecnológica de la sociedad provoca situaciones y desafíos que
requieren dar respuestas adecuadas al entorno ecosocial presente y futuro mediante distintos
paradigmas. Así, mediante una correcta planificación de las tareas y estableciendo una
estructura de trabajo en equipo, se diseñan las posibles soluciones a los retos planteados cuya
gestión debe desembocar en una solución tecnológica de manera eficiente, accesible, sostenible,
inclusiva e innovadora. Todo lo cual necesariamente comporta situaciones de incertidumbre que
deben ser abordadas con actitudes positivas y el empleo del conocimiento adquirido.

La importancia de estas tecnologías en la transformación de la sociedad hace necesaria
una reflexión crítica de sus implicaciones en los ámbitos donde se aplican, así como del impacto
de la innovación y sus repercusiones a nivel personal, profesional, social y ético. De ahí, el
importante carácter actitudinal que tiene esta materia, puesto que implica la movilización de
intereses, motivaciones, convicciones, apreciaciones y valores.

Al final del primer curso, el alumnado es capaz de analizar las tecnologías, entornos de
desarrollo, dispositivos y componentes necesarios para abordar y superar los retos propuestos.
Retos en cuyo abordaje colaboran activamente organizados en equipos, de forma guiada y
siguiendo los roles asignados por el profesorado, para proponer posibles soluciones. Al finalizar
el segundo curso, además de realizar un uso básico de las distintas tecnologías, el alumnado es
capaz de valorarlas con el fin de elegir la opción que mejor se adapte u ofrezca el servicio más
adecuado según la demanda. El grado de autonomía aumenta, siendo el alumnado el que
organiza los equipos y distribuye las tareas. Y es capaz de valorar la importancia de la Inteligencia
Artificial, la programación y la robótica como elementos disruptores de la transformación y del
desarrollo social, cultural y científico actuales.

3.
Conexiones de las competencias específicas entre sí, con las competencias de
otras áreas/materias y con las competencias clave.

3.1.
Relaciones o conexiones con las otras CE de la materia

3.1.1.
Competencia 1 Conexiones

Esta competencia específica tiene una relación muy directa con CE2 en lo que concierne
al desarrollo del software, debido a la necesidad de que el alumnado adquiera los conocimientos
y habilidades necesarias para entender y seguir el funcionamiento del código. También con la
CE 3 centrada en la robótica, en la que se integra código de inteligencia artificial en las
situaciones de aprendizaje diseñadas.

3.1.2.
Competencia 2 Conexiones

Esta competencia específica, centrada en la programación de algoritmos, sirve como
instrumento para analizar y crear aplicaciones de inteligencia artificial (CE1) y controlar el
funcionamiento de cualquier tipo de robot (CE3). Asimismo, mantiene una estrecha conexión con
la CE4, en tanto que la gestión de la incertidumbre a través del establecimiento de estrategias o
comportamientos se relaciona con los procesos implicados en el desarrollo de software.

3.1.3.
Competencia 3 Conexiones

La integración de la técnica de inteligencia artificial (CE1) a la creación y programación
de robots da cuenta de la estrecha relación existente entre ambas competencias. Los
fundamentos de la programación desarrollados en esta competencia específica y los algoritmos
de inteligencia artificial que sirven para complementar y mejorar las funcionalidades que los
robots pueden desempeñar están en la base de su interrelación.

3.1.4.
Competencia 4 Conexiones

Esta competencia conecta con las otras tres, puesto que se sirve de ellas para poder
desarrollarse.

3.2.
Relaciones o conexiones con las CE de otras materias de la etapa

3.2.1.
Competencia 1 Conexiones

La CE1, que aborda la Inteligencia Artificial y la virtualización de la realidad, está
relacionada con competencias específicas de Matemáticas, de las materias del ámbito científico,
tecnológico y lingüístico y de la materia Educación en Valores Cívicos y Éticos. Los contenidos
de estas materias ayudan a identificar los principios en los que se fundamenta la Inteligencia
Artificial.

3.2.2.
Competencia 2 Conexiones

La CE2, relativa a la programación, tiene una especial relación con la competencia que
trata el pensamiento computacional de Matemáticas, con su competencia homóloga de la materia
Tecnología y Digitalización, y con la competencia que pone el foco en la creación de contenidos
de la materia Digitalización, ya que en todas ellas se aborda la programación desde diferentes
enfoques.

3.2.3.
Competencia 3 Conexiones

La CE3, centrada en el análisis y montaje de robots o de partes robotizadas, está muy
relacionada con las competencias específicas de Matemáticas y de las otras materias del ámbito
tecnológico de la etapa. Las posibles analogías existentes entre las estructuras de elementos
mecánicos y los de la naturaleza la conectan igualmente con competencias de la materia Biología
y Geología.

3.2.4.
Competencia 4 Conexiones

Esta competencia específica aborda retos desde una perspectiva global e integradora,
lo que conecta muy especialmente con la de la materia de Tecnología y Digitalización que
contribuye al desarrollo sostenible analizando la tecnología y valorando su impacto y repercusión,
así como con la de Digitalización que afronta los desafíos informáticos y digitales que la sociedad
de la información plantea.

3.3.
Relaciones o conexiones con las competencias clave

La materia de Inteligencia artificial, programación y robótica incorpora en sus
competencias específicas y los saberes básicos asociados una buena parte del ámbito de
conocimiento y de actividad de la ciencia, la tecnología y las matemáticas. En el ámbito de la
comunicación e interrelación personal, las metodologías activas que se proponen en las
situaciones de aprendizaje permiten que el alumnado interactúe con los componentes de su
equipo de trabajo o del grupo de clase para dar solución a los retos que se le plantean, pudiendo
aplicar medios digitales y audiovisuales.

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 | X | X | X | X | X |  |  |  |
| CE2 | X |  | X | X | X |  |  |  |
| CE3 |  |  | X | X | X |  |  |  |
| CE4 |  |  | X | X | X | X | X |  |

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

•
CCL: competencia en comunicación lingüística

•
CP: competencia plurilingüe

•
CMCT: competencia matemática, ciencia y tecnológica

•
CD: competencia digital

•
CPSAA: competencia personal, social y de aprender a aprender

•
CC: competencia ciudadana

•
CE: competencia emprendedora

•
CCEC: competencia en conciencia y expresión cultural

3.3.1.
 Competencia 1 Conexiones

Esta competencia específica mantiene una estrecha relación con la competencia clave
matemática y en ciencia, tecnología e ingeniería; y, por supuesto, con la competencia digital,
puesto que las soluciones en el ámbito de la inteligencia artificial exigen la compresión de
aplicaciones informáticas sencillas y soluciones, así como mostrar interés y curiosidad por la
evolución de estas tecnologías. La autonomía personal que favorece esta competencia
específica está relacionada con la competencia clave personal, social y de aprender a aprender,
ya que se han de gestionar los retos que plantea la investigación y desarrollo de técnicas básicas
de inteligencia artificial, aumentando su motivación para aprender y plantear mecanismos para
hacerlo también de los errores. Además, el análisis de datos de distintas fuentes e idiomas para
el aprendizaje de una inteligencia artificial, pone en juego las competencias clave en
comunicación lingüística y plurilingüe para su adecuada adquisición.

3.3.2.
Competencia 2 Conexiones

Esta competencia específica conecta directamente con la competencia clave matemática
y en ciencia, tecnología e ingeniería y, por supuesto, con la competencia digital. En el desarrollo
de esta competencia se utilizan métodos inductivos, deductivos y lógicos para plantear modelos
y transmitir los razonamientos utilizando lenguaje formal con rigor y precisión científica, y por
esto último también refuerza la competencia clave en comunicación lingüística. La búsqueda de
información fiable, como la organización del entorno de desarrollo, la gestión colaborativa de
proyectos, la seguridad y sostenibilidad en el trabajo y soluciones, así como el desarrollo
aplicaciones informáticas, son aspectos que abarca esta competencia específica. Además,
conecta también con la competencia personal, social y de aprender a aprender, ya que en su

desarrollo se favorece la autonomía personal y se desatan procesos metacognitivos que facilitan
determinar cómo se ha aprendido y plantear mecanismos para aprender de los errores a medio
plazo.

3.3.3.
Competencia 3 Conexiones

Esta competencia conecta con la competencia clave matemática y en ciencia, tecnología
e ingeniería que entraña la comprensión del mundo utilizando los métodos científicos, el
pensamiento y representación matemáticos, la tecnología y los métodos de la ingeniería para
afrontar los desafíos propuestos. Estos desafíos desembocan en montajes robóticos que se
implementan colaborando de forma constructiva gestionando el tiempo y la información
eficazmente para conseguir el objetivo, lo que la conecta igualmente con la competencia
personal, social y de aprender a aprender y se programan; y en la programación de algoritmos,
lo que conecta con la competencia digital.

3.3.4.
Competencia 4 Conexiones

El análisis crítico de las implicaciones de la inteligencia artificial, la programación de
algoritmos y su uso en la robótica requieren del necesario dominio de las competencias clave
digital, matemática y en ciencia, tecnología e ingeniería para valorar sus repercusiones, así como
para proponer soluciones adecuadas. Gestionar la incertidumbre analizando posibilidades y
tomando decisiones confiere al alumnado autonomía para aceptarse y promover un crecimiento
personal constante, colaborar con otras personas de forma constructiva y gestionar el
aprendizaje a lo largo de la vida, lo que la conecta con la competencia clave personal, social y
de aprender a aprender. La reflexión crítica acerca de los grandes problemas éticos de nuestro
tiempo y el desarrollo de un estilo de vida sostenible recogidos en la competencia ciudadana se
relaciona igualmente con esta competencia específica. Además, debido a que el alumnado debe
mostrar iniciativa para diseñar soluciones creativas a los retos planteados, tomar decisiones
basadas en la información y el conocimiento y colaborar de manera ágil con otras personas, esta
competencia específica también conecta con la competencia clave emprendedora.

4.
Saberes básicos

4.1.
Introducción

Los saberes básicos son los conocimientos, destrezas, actitudes habilidades y valores
cuyo aprendizaje, articulación y movilización son necesarios para la adquisición y desarrollo de
las competencias específicas.

La organización de los contenidos en bloques tiene como finalidad facilitar su
comprensión y no debe interpretarse en ningún caso como una propuesta para abordarlos y
trabajarlos por separado o siguiendo el orden en el que se presentan. Su tratamiento integral y
no de forma aislada va a permitir que el alumnado desarrolle las competencias específicas
contribuyendo, a través de ellas, a la adquisición y desarrollo de las competencias clave y al logro
del perfil de salida.

En el primer bloque, Inteligencia Artificial, se abordan las estrategias que utilizan el
cerebro y los algoritmos informáticos para poder solucionar las tareas que requieren del
pensamiento racional e inteligente. También se aborda el uso de tecnologías y técnicas que
permiten que realidades difíciles de presenciar por el alumnado debido a circunstancias tales
como la lejanía física, el tamaño o de naturaleza económica puedan recrearse en un entorno de
dos o tres dimensiones.

El bloque de Programación incluye los fundamentos del pensamiento computacional
para entender la realidad, analizar y buscar soluciones creativas mediante algoritmos a

problemas básicos. Las soluciones se podrán implementar con diferentes alternativas que el
alumnado debe conocer para seleccionar la más adecuada.

El bloque de Robótica incluye los fundamentos para complementar o llevar al ámbito
global o cotidiano del alumnado el código generado mediante la programación en las situaciones
de aprendizaje propuestas. Los robots o componentes desarrollados también pueden ser la base
sobre la que implementar técnicas de inteligencia artificial.

4.2.
Bloque 1: Inteligencia Artificial. CE1

| CONTENIDOS | 2º curso | 3er curso |
| --- | --- | --- |
| El aprendizaje en sistemas biológicos. Decisiones y libre albedrío. | X |  |
| Sensores, tipología y aplicaciones. | X | X |
| Fundamentos de la IA. Árboles de decisión. Big data, redes neuronales. | X |  |
| Técnicas iniciales de IA: sistemas expertos, redes neuronales y aprendizaje automático. | X | X |
| Procesado automático de la información. | X | X |
| Equidad e inclusión en sistemas de IA. Sesgos en IA. | X | X |
| Implicaciones sociales y éticas de la inteligencia artificial. | X | X |
| Técnicas de virtualización de la realidad. |  | X |

4.3.
Bloque 2: Programación. CE2

| CONTENIDOS | 2º curso | 3er curso |
| --- | --- | --- |
| Habilidades del pensamiento computacional. | X |  |
| Interpretación de la realidad mediante modelado de problemas. | X | X |
| Abstracción, secuenciación, algorítmica y su representación con lenguaje natural y diagramas de flujo. | X | X |

| Detección y reutilización de patrones. Generalización. |  | X |
| --- | --- | --- |
| Sostenibilidad e inclusión como requisitos del diseño del software. |  | X |
| Estructuras de control del flujo del programa. | X | X |
| Variables, constantes, condiciones y operadores. | X | X |
| Programación por bloques: composición de las estructuras básicas y encaje de bloques. | X |  |
| Introducción a la programación en lenguajes de alto nivel. Tipos de lenguajes. Sintaxis y semántica. |  | X |
| Programación de aplicaciones para dispositivos móviles. |  | X |
| Análisis y validación de software. | X |  |
| Evaluación y mantenimiento de software. |  | X |
| Licencias de software. El software libre y el software propietario. | X | X |
| Simuladores de tarjetas controladoras. |  | X |
| Iniciativa, autoconfianza y metacognición en el proceso de aprendizaje del desarrollo de software. | X | X |

4.4.
Bloque 3: Robótica. CE3

| CONTENIDOS | 2º curso | 3er curso |
| --- | --- | --- |
| Robots: tipos, grados de libertad y características técnicas básicas. | X |  |
| Montaje de robots. | X | X |
| Control de sistemas robotizados. | X | X |
| Sensores, actuadores y controladores. | X | X |

| Carga y ejecución de los algoritmos en robots. | X | X |
| --- | --- | --- |
| Sistemas robotizados en la experimentación con prototipos diseñados. |  | X |

5.
Situaciones de aprendizaje

Uno de los objetivos de las situaciones de aprendizaje es conseguir que el alumnado
pueda aprender, articular y movilizar los saberes que requieren la adquisición y desarrollo de las
competencias específicas, para lo cual deben sustentarse en retos presentes o cercanos a su
entorno cotidiano. Con este planteamiento, los desafíos globales deben partir de situaciones
locales que permitan comprender mejor cuál es la problemática en el entorno más próximo para
que de esta forma el alumnado sea capaz de aportar su solución y generalizarla. Las temáticas
que se proponen deben fundamentarse en la práctica y en retos que la materia de Inteligencia
Artificial, Programación y Robótica pueda resolver. Las problemáticas versarán sobre desafíos
de la sociedad del siglo XXI tales como la sostenibilidad, la sociedad digital crítica e inclusiva o
la sociedad del bienestar personal y global. Las situaciones de aprendizaje deben dar lugar a
experiencias auténticas y motivadoras que ayuden a conectar las competencias y los saberes
básicos, favoreciendo la realización de nuevos aprendizajes y planteando nuevas perspectivas.
Estas temáticas se pueden implementar mediante la interconexión de todos los bloques de
saberes o incluso con proyectos multidisciplinares.

En las situaciones de aprendizaje el alumnado tiene que ser capaz de gestionar la
incertidumbre que genera cualquier actividad o trabajo, y lo debe hacer respetando las opiniones
de los demás componentes del grupo, reconociendo que las diferencias pueden ser una
oportunidad y desde la crítica, el razonamiento, la igualdad y el diálogo. Al igual que en el resto
de materias de la Educación Secundaria Obligatoria, se aplican los principios del Diseño
Universal de Aprendizaje en las situaciones de aprendizaje, teniendo en cuenta la presencia,
participación y aprendizaje de todo el alumnado. Asimismo, debe fomentarse la ruptura de
estereotipos e ideas preconcebidas sobre las materias científico-tecnológicas asociadas a
cuestiones individuales, como por ejemplo las de género, con una actitud de resiliencia y
proactividad ante nuevos retos tecnológicos.

El papel del alumnado es muy importante en todo el proceso de enseñanza y
aprendizaje, por lo que se ha de utilizar metodologías activas, pudiendo trabajar los contenidos
individualmente o en equipos de trabajo. Siempre que la organización escogida sea por grupos,
se tienen que respetar los roles asignados y fomentar la empatía y el consenso a la hora de
conseguir acuerdos entre sus miembros.

El profesorado asume la responsabilidad de diseñar los retos con los que se movilizan
los saberes, especificando detalladamente los objetivos y las tareas que debe realizar el
alumnado, así como los pasos. En un primer momento, el profesorado adoptará el papel de guía
y progresivamente irá asumiendo el papel de observador, que en ocasiones puntuales y
justificadas podrá revertir para hacer aportaciones que sirvan para mejorar o reconducir el trabajo
del alumnado o del equipo. Esta retroalimentación tiene como finalidad corregir errores, mejorar
el desempeño del alumnado y afianzar los procedimientos y sus respuestas correctas para que
este conozca su rendimiento, identifique cómo puede mejorarlo y aprenda a autorregularse en la
ejecución de las tareas de aprendizaje. Es conveniente incluir en la práctica docente actividades

de naturaleza metacognitiva, facilitando así que el alumnado reflexione sobre qué ha aprendido
y cómo lo ha hecho, y promoviendo la adquisición de las estrategias, procedimientos, recursos o
técnicas que le ayudarán a saber qué ha hecho bien y porqué, así como qué debe mejorar y de
qué manera. También se deben promover diversos modos de expresarse y representar el
conocimiento, con el fin de que el alumnado valore y reconozca lo que aprende fuera del aula y
del centro escolar.

6.
Criterios de evaluación

6.1 Competencia específica 1. Criterios de evaluación

CE1. Identificar, investigar y emplear técnicas de inteligencia artificial y virtualización de
la realidad en el abordaje y la búsqueda de soluciones a problemas básicos de la sociedad
valorando los principios éticos e inclusivos aplicados.

| 2º curso | 3º curso |
| --- | --- |
| 1.1. Identificar los fundamentos y el funcionamiento de las técnicas básicas de IA. | 1.1. Identificar el funcionamiento de técnicas de IA. |
| 1.2. Investigar situaciones donde se aplican técnicas básicas de IA. | 1.2. Investigar situaciones donde se aplican técnicas de IA. |
| 1.3. Valorar las implicaciones éticas y sociales de las técnicas básicas de IA. | 1.3. Valorar criterios éticos aplicados a las funciones de IA. |
| 1.4. Emplear funciones de IA en aplicaciones sencillas de forma guiada para buscar soluciones a problemas básicos. | 1.4. Emplear funciones de IA en aplicaciones sencillas siguiendo criterios éticos e inclusivos para buscar soluciones a problemas básicos. |
|  | 1.5 Emplear técnicas sencillas de virtualización de la realidad. |

6.2 Competencia específica 2. Criterios de evaluación

CE2. Aplicar el pensamiento computacional en el análisis y resolución de
problemas básicos significativos para el alumnado mediante el desarrollo de software.

| 2º curso | 3º curso |
| --- | --- |
| 2.1. Analizar problemas elementales significativos para el alumnado, mediante la abstracción y modelización de la realidad. | 2.1. Analizar problemas básicos significativos para el alumnado, mediante el uso de las estructuras de control más adecuadas. |
| 2.2. Analizar y validar aplicaciones informáticas existentes. | 2.2. Evaluar y mantener las aplicaciones informáticas desarrolladas por el propio alumnado. |
| 2.3. Resolver de forma guiada problemas elementales utilizando los algoritmos y las estructuras de datos necesarias. | 2.3. Planificar de forma autónoma la solución de problemas básicos, utilizando los algoritmos y las estructuras de datos más adecuados. |
| 2.4. Programar aplicaciones sencillas de forma guiada para resolver problemas elementales. | 2.4. Programar aplicaciones sencillas multiplataforma de manera autónoma para resolver problemas básicos. |

| 2.5. Describir y valorar los derechos de autoría y licencias de derechos y explotación. | 2.5. Aplicar y respetar los derechos de autoría, licencias de derechos y explotación durante la creación de software. |
| --- | --- |

6.3 Competencia específica 3. Criterios de evaluación

CE3. Montar sistemas robóticos sencillos, analizando las respuestas que
proporcionan en su interacción con el entorno y valorando la eficacia de estas frente a
los retos sencillos planteados.

| 2º curso |  | 3º curso |  |
| --- | --- | --- | --- |
| 3.1. Montar robots sencillos siguiendo una guía, |  | 3.1. Montar robots de mayor complejidad |  |
| empleando los sensores, actuadores y otros |  | empleando sensores, actuadores y otros |  |
| operadores que se indiquen. |  | operadores. |  |
| 3.2. Conectar, transferir y ejecutar el programa |  | 3.2. Conectar, transferir y validar la ejecución del |  |
| de control seleccionado al robot. |  | programa de control seleccionado al robot. |  |
| 3.3. Resolver desafíos modificando un robot disponible. |  | 3.3. Seleccionar los módulos de entrada y salida |  |
|  |  | para montar robots sencillos, que sean capaces de |  |
|  |  | realizar tareas de forma autónoma. |  |
| 3.4. Analizar y validar el programa de control del |  | 3.4. Analizar y evaluar la eficacia de la interacción |  |
| robot que permite que interactúe con el entorno. |  | del robot con el entorno. |  |
| 3.5. Programar instrucciones sencillas de forma guiada para controlar un robot programable. |  | 3.5. Programar instrucciones sencillas multiplataforma de manera autónoma para controlar un robot programable. |  |
|  |  | 3.6. Controlar el robot por parte del usuario en |  |
|  |  | tiempo real y de forma remota. |  |

6.4 Competencia específica 4. Criterios de evaluación

CE4. Afrontar retos tecnológicos sencillos y proponer soluciones mediante la
programación, la Inteligencia artificial y la robótica analizando las posibilidades y
valorando críticamente las implicaciones éticas y ecosociales.

| 2º curso | 3er curso |
| --- | --- |
| 4.1. Participar activamente en equipos de trabajo para desarrollar soluciones digitales y tecnológicas demostrando empatía y respetando los roles asignados y las aportaciones del resto de personas integrantes. | 4.1. Planificar tareas sencillas, crear estructuras de equipos de trabajo, distribuir funciones y responsabilidades de las personas integrantes y colaborar proactivamente en el desarrollo de soluciones digitales y tecnológicas. |
| 4.2. Analizar críticamente las implicaciones que la programación y las tecnologías tienen en la | 4.2. Valorar la importancia de la Inteligencia Artificial, la programación y la robótica como |

| transformación de la sociedad valorando las repercusiones éticas y ecosociales. | elementos disruptores de la transformación social, cultural y científica actuales |
| --- | --- |
| 4.3. Describir y valorar la adecuación de las tecnologías, entornos de desarrollo, dispositivos y componentes para resolver los retos planteados, analizando sus características y especificaciones. | 4.3. Diseñar soluciones utilizando la programación, la Inteligencia artificial y la robótica eligiendo la opción que mejor se adapte a los retos planteados. |
| 4.4. Resolver problemas técnicos sencillos surgidos en el análisis, desarrollo y uso de software, módulos de inteligencia artificial y robótica reformulando el procedimiento utilizado en caso necesario. | 4.4. Gestionar situaciones de incertidumbre en entornos digitales y tecnológicos con una actitud positiva, y afrontarlas utilizando el conocimiento adquirido y sintiéndose competente. |
|  | 4.5. Aplicar la sostenibilidad e inclusión como requisitos del diseño de soluciones tecnológicas. |
