# EMPRENDIMIENTO SOCIAL Y SOSTENIBLE

> Fuente: Secundaria.pdf, páginas 1100-1111 (versión en castellano).

EMPRENDIMIENTO SOCIAL Y SOSTENIBLE

1. Presentación

El desarrollo de una cultura emprendedora social y sostenible a través de la educación y la
formación contribuye a que nuestro alumnado aprenda a apoyarse en iniciativas propias, mejore su
capacidad de generar ideas, se adapte a los cambios y retos de la sociedad actual, contribuya y se implique
en la transformación y mejora de dicha sociedad.

La formación en emprendimiento social es fundamental para promover la competencia
emprendedora y el resto de las competencias establecidas por Recomendación del Consejo de la Unión
Europea de 22 de mayo de 2018, relativa a las competencias clave para el aprendizaje permanente. Esa
misma aspiración se recoge en la Ley Orgánica 3/2020 por la que se modifica la Ley Orgánica de
Educación, que incluye la competencia emprendedora y el sentido de iniciativa como una de las claves del
sistema educativo.

Esta materia incluye aspectos teóricos y prácticos orientados a preparar a nuestro alumnado para
ejercer una ciudadanía responsable y comprometida con su entorno a través del emprendimiento social,
para cubrir necesidades recogidas en los Objetivos de Desarrollo Sostenible (ODS). Además, ayuda al
autoconocimiento y a identificar a las personas emprendedoras, qué hacen y su importancia en el progreso
social, y también enseña a nuestro alumnado a ser responsable y crítico con sus decisiones de gasto y
consumo.

Esta materia se propone como optativa en segundo curso de la ESO con la finalidad de introducir al
alumnado en el autoconocimiento, en el mundo empresarial y en la gestión de sus finanzas personales. La
materia de Emprendimiento Social y Sostenible se enmarca en el conjunto de asignaturas que persiguen
que el alumnado alcance capacidades relacionadas con la creatividad y espíritu innovador, la valoración de
las ideas como motor para detectar oportunidades de negocios viables y sostenibles y el desarrollo de una
cultura financiera básica que le permita actuar con sentido crítico y responsabilidad.

La materia sirve para aproximar al alumnado a proyectos de emprendimiento social relacionados
con la actividad económica y empresarial de su entorno más próximo. Estos proyectos van encaminados a
crear un triple valor: valor económico, valor social y valor medioambiental. El alumnado descubrirá en esta
materia saberes de actualidad y cercanos a su realidad y realizarà actividades que ayuden al
autoconocimiento e introduzcan a este alumnado en el mundo empresarial, de las finanzas personales y del
emprendimiento social.

El enfoque de esta materia es eminentemente práctico y la metodología será, por tanto, en su
mayoría inductiva, yendo de lo concreto a lo general. Se intentará que la aproximación a muchos de los
contenidos de la materia se realice partiendo de hechos concretos, observaciones, experiencias y vivencias
personales sobre realidades próximas. Se quiere facilitar así la motivación e interés de los alumnos y las
alumnas por los contenidos y las actividades que se proponen. Se favorecerá la motivación por aprender,
mediante la realización de tareas en las que el alumnado, a través de situaciones reales y la investigación
de su entorno, genere aprendizajes duraderos y consiga el desarrollo de una actitud proactiva y
responsable. Mediante estas tareas, se fomentarán las habilidades sociales, la capacidad de comunicación,
la iniciativa personal, la creatividad, la búsqueda de soluciones originales, la planificación y reflexión y el
trabajo cooperativo.

El estudio de esta materia potencia el razonamiento y la abstracción, y proporciona herramientas
para desarrollar una visión crítica de nuestra sociedad tan presente en los objetivos de la etapa secundaria
obligatoria y de los retos del siglo XXI.

La materia se asocia con los estudios previos realizados en el primer curso de la Educación
Secundaria Obligatoria y tiene especial relación con las materias comunes de Matemáticas, Geografía e
Historia, Valenciano, Castellà e Inglés. Asimismo, se diseña con la vista puesta en los objetivos fijados para

la etapa de Enseñanza Secundaria Obligatoria contribuyendo a desarrollar en el alumnado el espíritu
emprendedor y la confianza en sí mismo, la participación y el sentido crítico, la iniciativa personal, y la
capacidad para aprender a aprender, planificar, tomar decisiones y asumir responsabilidades.

Por lo que respecta a las competencias específicas, en esta materia se analizarán las diferentes
cualidades y las habilidades sociales de las personas y se conformarán equipos de trabajo eficaces para la
búsqueda de diseño de proyectos sostenibles e innovadores que tengan presente el papel relevante de la
Economía social como generador de desarrollo de una ciudadanía global. Al mismo tiempo, en esta materia
el alumnado aprenderá a planificar de forma coherente un presupuesto personal sencillo que garantice la
importancia del ahorro y que conozca el riesgo del endeudamiento excesivo y se formará a una ciudadanía
que tome decisiones de consumo desde una perspectiva responsable y sostenible que detecte sus
derechos como consumidor, así como sus obligaciones.

La materia se divide en tres bloques de saberes. En un primer bloque se recogen los contenidos
que ayudarán al alumnado a adquirir, gracias a un proceso reflexivo y crítico, el conocimiento sobre sus
propias capacidades y el desarrollo de la toma de decisiones asumiendo con responsabilidad los resultados
obtenidos tanto del trabajo personal como del trabajo en equipo. Se incluye asimismo la comunicación como
punto de encuentro y la innovación al servicio de la sociedad. Un segundo bloque de saberes se centra en
el marco de la ciudadanía global incidiendo en la importancia de la Responsabilidad Social Corporativa, las
obligaciones fiscales y la economía sumergida. La desigualdad de género en el mercado de trabajo, el
comercio justo y la economía circular son contenidos fundamentales de este bloque, así como los Objetivos
de Desarrollo Sostenible y la Agenda 2030 que no pueden pasar desapercibidos en el aprendizaje de esta
materia y que se aplicarán a través de un proyecto básico de emprendimiento social y sostenible. El tercer
bloque presenta los saberes necesarios para introducir al alumnado en las finanzas personales y el
consumo responsable de manera que como consumidores puedan tomar decisiones informadas, siendo
conscientes de sus deberes y derechos. Es importante en este bloque el ahorro y la consciencia de
planificar las decisiones de naturaleza financiera. Asimismo, se incluyen saberes relacionados con la
influencia de la publicidad y el problema del juego y las apuestas.

Los criterios de evaluación van dirigidos a comprobar el grado de adquisición de las competencias
específicas, es decir, el nivel en el que el alumnado es capaz de movilizar los saberes, conceptuales,
procedimentales y relativos a actitudes y valores, en situaciones o actividades del ámbito personal, social y
académico con una futura proyección profesional.

2. Competencias específicas

2.1. CE1 Identificar en sí mismo cualidades personales y habilidades sociales que favorezcan la
toma de decisiones, la creatividad, la actuación responsable y el espíritu de superación.

2.1.1. Descripción de la competencia

Es importante que el alumnado vaya desarrollando su autoconocimiento y autoestima, así como una
actitud de superación, continua mejora y perfeccionamiento. Es decir, el alumnado necesita conocerse a sí
mismo y saber que está en un proceso de continua mejora y crecimiento personal. De esta forma, llegará a
conocer los aspectos internos que conllevan su propia manera de pensar, sentir y actuar.

Las destrezas y actitudes que integran esta competencia y que los alumnos y las alumnas
adquirirán, se evidencian en la necesidad de reflexión y planificación previa a la realización de una tarea, en
el empleo de conocimientos adquiridos con anterioridad en la solución de situaciones y en la elección de los
recursos necesarios para realizar tareas, aplicando cuando fuera necesario soluciones nuevas, originales y
creativas.

El alumnado será capaz de desarrollar su inteligencia emocional intrapersonal entendida como la
capacidad de construir una percepción precisa de sí mismo y de organizar su propia vida. Se trata de
trabajar con los propios sentimientos y emociones, conocer y saber diferenciar las situaciones que provocan

unos sentimientos determinados y detectar patrones, generando una actitud de seguridad y confianza en
sus propias cualidades. Así pues, en esta competencia se proponen aprendizajes que ayudan al alumnado
a afrontar los cambios físicos, mentales, emocionales y sociales a los que se enfrenta en esta etapa de su
vida, y a conocer y controlar sus propios procesos de aprendizaje.

2.2. CE2 Participar en equipos de trabajo, valorando el planteamiento y discusión tanto de las
propuestas personales como de grupo, ejerciendo el liderazgo de una manera positiva y
organizando el trabajo en común.

2.2.1. Descripción de la competencia

El mundo está cada vez más globalizado, por lo que las empresas deben abrir sus perspectivas
para captar talento. De hecho, la inclusión en la empresa de personas con grandes diferencias entre sí es
un factor muy positivo. La diversidad debe ir de la mano de un liderazgo inclusivo. La capacidad de
liderazgo permite cohesionar un equipo de personas muy diferentes. El objetivo final debe ser que exploren
sus capacidades mutuamente y de forma cooperativa. Además, se deben desarrollar las diferencias de cada
empleado para que aporten valor.

En el entorno empresarial impredecible de hoy, se valora a las organizaciones que dan valor a las
personas y su diversidad, por lo que es necesario fomentar la participación del alumnado en equipos
diversos e inclusivos. Es por ello que el alumnado desarrollará su inteligencia emocional para participar en
actividades grupales y de trabajo en equipo, favoreciendo estrategias de comunicación asertivas basadas
en el respeto hacia uno mismo y hacia los demás y generando una actitud de empatía y proactividad. Se
potenciará el trabajo en equipo entendiendo que las habilidades y conocimientos son aportados por todos
sus miembros, con interdependencia entre ellos para realizar de forma coordinada sus actividades y a
través del apoyo mutuo alcanzar sus objetivos y metas. Para ello, el alumnado debe desarrollar la
capacidad no sólo para motivarse a sí mismo sino también para motivar e influir positivamente en los
demás.

La participación en grupos inclusivos promoverá un correcto desarrollo y uso de las habilidades
sociales como la empatía, la asertividad, la negociación, el liderazgo y el respeto hacia los intereses,
elecciones e ideas de los demás, así como el uso de habilidades de comunicación, la creación de un buen
clima de trabajo y la construcción de vínculos de cooperación que favorezcan el crecimiento personal y
colectivo e intensifiquen valores de respeto, equidad e igualdad entre hombres y mujeres.

2.3. CE3 Argumentar el papel de la Economía Social como marco que favorece el desarrollo de
una ciudadanía global, valorando los efectos positivos que genera sobre su entorno.

2.3.1. Descripción de la competencia

Los cambios tan rápidos que se producen en la sociedad actualmente precisan que se valore cuál
es nuestro papel en un entorno local que forma parte de uno global. En esta situación hay que favorecer en
el alumnado aprendizajes que tengan como objetivo un enfoque más colectivo que individualista. La
respuesta a este enfoque la tiene el concepto de Ciudadanía Global, como perspectiva educativa que
impulsa un nuevo modelo de ciudadanía comprometida activamente en la consecución de un mundo más
equitativo y sostenible y que apueste por el respeto y la valoración de la diversidad, la defensa del medio
ambiente, el consumo responsable y el respeto a los derechos humanos tanto individuales como sociales.

En la actualidad, no se puede entender ni trabajar por un mundo global si no se trabaja, se enseña y
se educa desde el respeto a un entorno local. El alumnado conocerá la existencia de alternativas y puntos
de vista diferentes sobre cuestiones económicas para así contraponer ideas y conceptos, reflexionará sobre
la contribución de los proyectos emprendedores al servicio de la Economía social, sobre la importancia de la
creación de valor compartido y el comercio justo. Además, el alumnado hará una primera aproximación al
mercado laboral identificando las desigualdades que en él se producen, especialmente las desigualdades
de género, y valorando el papel de la Economía social para minimizarlas.

Así pues, el alumnado estudiará los diferentes tipos de entidades que forman la Economía Social,
su financiación, las estrategias de desarrollo que utilizan, trámites básicos para su constitución que le
permitirá aproximarse a otra forma de hacer economía. Todas estas reflexiones le permitirá realizar análisis
críticos y bien fundamentados y descubrir cuál es el papel que desempeña como agentes de cambio y que
otro mundo es posible.

2.4. CE4 Diseñar proyectos básicos sostenibles e innovadores, utilizando herramientas de la
Economía Social y comprobando su retorno a la sociedad dentro de un ámbito local o global.

2.4.1. Descripción de la competencia.

Los intereses de las distintas generaciones son muy diferentes pero la sensibilidad hacia los
problemas sociales y medioambientales es una preocupación común que se visibiliza a través de los
diferentes canales de comunicación.  Detectar los problemas y buscar soluciones de forma cooperativa
mediante el diseño de un proyecto básico permite alcanzar el máximo nivel de implicación con su entorno
más cercano, valorar la repercusión de sus decisiones y formarse como ciudadanía crítica y responsable.

El alumnado buscará diferentes ejemplos de emprendimiento social en la Comunitat Valenciana. De
esta manera conocerán cómo se comporta este tipo de empresas que han adquirido el perfil social, cómo se
organizan internamente, qué papel tienen las personas que trabajan en la empresa, cómo gestionan el
crecimiento empresarial y en qué invierten los beneficios, y también si incluyen protocolos de igualdad. Al
mismo tiempo conocerán los Objetivos de Desarrollo Sostenible que les harán comprender un modelo de
producción y consumo que implica compartir, reutilizar, reparar y reciclar materiales y productos todas las
veces que sea posible para crear un valor añadido fundamental que dé respuesta a problemas básicos que
la sociedad les plantea y que están comprometidos en la Agenda 2030.

El compromiso del alumnado con la sociedad más cercana se hará patente ante la detección de
necesidades y la elaboración de proyectos básicos de emprendimiento social y sostenible que tengan en
cuenta todos principios de la Economía Social que permiten la mejora de la sociedad.

2.5 CE5. Planificar un presupuesto personal sencillo, evaluando la importancia del ahorro y el
riesgo que supone un endeudamiento excesivo e identificando los medios de pago utilizados.

2.5.1. Descripción de la competencia.

Un presupuesto personal permite tener una mejor organización para administrar los recursos y
realizar una planeación eficiente sobre estos. Dicho proceso es una tarea importante que sirve para llevar
un control y seguimiento de los ingresos y gastos, dado que la buena gestión de las finanzas personales
ayuda a alcanzar los objetivos y las metas de nuestro día a día.

Esta competencia busca que el alumnado sea capaz de aprender a utilizar herramientas y
estrategias financieras básicas en sus decisiones personales, relacionadas con la planificación
presupuestaria. Es importante que el alumnado sea capaz de valorar los gastos en relación con los ingresos
previstos, la importancia del ahorro familiar presente y futuro, y darse cuenta de que no respetar el
presupuesto previsto puede conducirle en un futuro a un endeudamiento excesivo con todas las
implicaciones económicas y sociales que ello puede tener.

Con esta competencia los alumnos y las alumnas aprenden también a valorar la importancia de
hacer un presupuesto, no solo a nivel personal y familiar, sino también a nivel de proyectos emprendedores.

Esta competencia busca ayudar al alumnado a saber administrar mejor su dinero y comprender
cuáles son las mejores opciones financieras en su día a día. De esta forma tomará decisiones correctas con
una mayor confianza y seguridad que repercutirán en su calidad de vida. En definitiva, que el alumnado
conozca la importancia de un consumo responsable y de la necesidad de ahorro que tienen las economías
domésticas ayudan sin duda a un desarrollo personal y social más equilibrado y sostenible.

2.6. CE6 Analizar documentos relativos al consumo, desde una perspectiva responsable y
sostenible, e identificar los organismos que velan por los derechos del consumidor.

2.6.1. Descripción de la competencia

Es necesario formar al alumnado en aspectos que permitan desarrollar hábitos y comportamientos
que ayuden por un lado a su mejora personal y por otro a la mejora de su entorno social y económico,
consiguiendo consumidores responsables de forma individual y colectiva, para así conseguir una sociedad
más justa y un desarrollo más sostenible. Se trata de que el alumnado conozca los derechos y deberes de
los consumidores y concienciarlo de la necesidad de cambiar las pautas de nuestro consumo, haciéndoles
ver que un consumo excesivo resulta perjudicial para la sociedad y el medio ambiente.

Como persona consumidora y usuaria entenderá cuáles son sus derechos identificando los criterios
sociales y medioambientales que contribuyen a un entorno favorable para todos, de esta forma afianzará los
saberes en consumo responsable y su impacto en el medio ambiente, y la manera en que mejora la calidad
de vida de las personas hoy y en generaciones futuras. Es importante enseñar a los alumnos y las alumnas
tomar decisiones valorando las ventajas de un consumo responsable.

También con esta competencia se busca que los alumnos y las alumnas conozcan los organismos
tanto públicos como privados que velan por sus derechos como consumidores responsables, promoviendo
la libre competencia, así como un desarrollo económico y social sostenible. Así mismo, el alumnado
conocerá las distintas alternativas y vías que como consumidor tiene para poder reclamar lo que considere
abusos o engaños de las empresas.

3.Conexiones de las competencias específicas entre sí, con las competencias específicas de otras
materias y con las competencias clave

3.1.  Relaciones o conexiones entre las competencias específicas

Conexiones Competencia Específica 1

Se relaciona con la CE2 por su relación con la formación de grupos de trabajo que ayuda a
descubrir cualidades y habilidades personales. Por otro lado, se relaciona con la CE 3, valorando el papel
que tienen las personas en la toma de decisiones desde una perspectiva de economía social, así como con
la CE4, por lo que respecta al análisis de las cualidades personales que permitirán diseñar proyectos
sostenibles. Finalmente se relaciona con la CE5 y la CE6 con la asunción de responsabilidades en temas
relacionados con el presupuesto personal y el consumo responsable.

Conexiones Competencia Específica 2

Cabe destacar su relación con la CE4 por la importancia del trabajo en equipo para el diseño de
proyectos básicos y sostenibles. También se relaciona con la CE6, a la hora de trabajar para analizar
documentos e investigar sobre los organismos relacionados con las decisiones de consumo y con la CE1
por la importancia de las cualidades personales a la hora de formar equipos de trabajo.

Conexiones Competencia Específica 3

Es destacable su conexión con la CE4, ya que es imprescindible que las personas conozcan su
entorno económico y social a la hora de desarrollar proyectos. Asimismo, se relaciona con la CE6 por la
importancia que ese entorno juega en la toma de decisiones de consumo responsable. Además, se
relaciona con la CE1 viendo el papel de las personas dentro de una economía social y sostenible.

Conexiones Competencia Específica 4

Esta competencia se relaciona con la CE5 debido a la importancia de un buen presupuesto a la
hora de diseñar un proyecto. Existe una relación con la CE1 por la importancia de las cualidades personales
a la hora de diseñar un proyecto básico y sostenible.

Conexiones Competencia Específica 5

Se relaciona con la CE6, pues la elaboración correcta del presupuesto es fundamental para la toma
de decisiones de consumo. Con la CE4, por la importancia de presupuesto equilibrado a la hora del diseño

de proyectos y con la CE1 en cuanto a la importancia de las cualidades personales a la hora de hacer un
presupuesto.

Conexiones Competencia Específica 6

Se relaciona con la CE5 porque a la hora de tomar decisiones de consumo es importante contar con
un presupuesto. También con la CE3 en el sentido de conocer el entorno económico a la hora de tomar
decisiones responsables y con la CE1 por la importancia de las cualidades y habilidades personales a la
hora de decidir.

3.2. Relaciones o conexiones con competencias específicas de otras áreas

Las competencias específicas de la materia de Emprendimiento Social y Sostenible tienen especial
relación con las áreas lingüísticas, matemáticas, ciencias naturales y sociales que el alumnado estudia
durante el primer ciclo de la ESO. El carácter práctico de la materia hace posible que se apliquen a la vida
real aquellas competencias más abstractas de otros ámbitos.

Las competencias 1 y 2 están asociadas a las competencias comunicativas de las lenguas
estudiadas en el currículo por parte de todo el alumnado. Al mismo tiempo, la gestión y la organización
estudiadas en Tecnología y Digitalización ayudan a la adquisición de las competencias.

•
Lengua Castellana y Literatura y Valencià: Llengua i Literatura, ya que ambas lenguas permiten una
acción comunicativa y son de gran ayuda para expresar los principios económicos y la interacción
en los grupos de trabajo necesarios en la materia. Así pues, competencias como la comprensión
oral (CE2), comprensión escrita (CE3), expresión oral (CE4), la expresión escrita (CE5), la
mediación (CE7) y la lectura (CE8) y son fundamentales para conseguir los objetivos del curso.

•
Primera Lengua Extranjera: la competencia 2 (comprensión oral) y la competencia 3 (comprensión
escrita) son de gran relevancia para comprender mejor los diferentes aspectos de la economía
global.

•
Tecnología y Digitalización: la competencia 1 resuelve problemas sencillos aplicando el método de
proyectos de manera similar al de la materia.

Las competencias 3, 4 y 6 de nuestra materia tienen relación con las materias de Geografía e
Historia y Biología y Geología.

•
Geografía e Historia: las competencias de la materia tienen un nexo común con la materia. La
competencia 5 explica las interrelaciones económicas y su repercusión en la sociedad tan
necesarias para poder dar respuesta mediante soluciones innovadoras que se realizan en la
materia de Emprendimiento Social y Sostenible y la competencia 8 de la materia de sociales
promueve proyectos cooperativos teniendo como base la Unión Europea.

•
Biología y Geología: las competencias específicas de la materia trabajan temas sobre sostenibilidad
como la conservación con responsabilidad todas de las formas de vida y el planeta (CE7) y la
adopción de hábitos de comportamiento en la actividad cotidiana responsables con el entorno
(CE10).

La competencia 5 tiene especial relación con las Matemáticas y la Física y Química, debido a la
necesidad de estas para el cálculo de aspectos técnicos y financieros.

•
Matemáticas: algunas de las competencias matemáticas que son necesarias tratan de resolver
problemas relacionados con situaciones diversas del ámbito social (CE1), construir modelos
matemáticos funcionales con el objetivo de interpretar problemas relevantes (CE3) e interpretar
mensajes orales y escritos complejos de manera formal, empleando el lenguaje matemático (CE6)

•
Física y Química: desde la materia se trabaja la resolución de problemas científicos a partir de
trabajos de investigación abordables en el ámbito experimental (CE1), analizar fenómenos naturales
(CE5) y la utilización de representaciones gráficas (CE7).

3.3. Relaciones o conexiones con las competencias clave

La competencia específica CE1 se vincula con la competencia en comunicación lingüística (CCL),
con la competencia digital (CD), con la competencia personal, social y de aprender a aprender (CPSAA),
con la competencia ciudadana (CC), la competencia emprendedora (CE) y con la competencia en
conciencia y expresión culturales (CCEC) pues al fomentar el autoconocimiento y la autoestima del
alumnado así como la ayuda a la hora de afrontar los cambios físicos, mentales, emocionales y sociales que
se producen en esta etapa vital se contribuye a la adquisición de los objetivos descritos en el perfil de
salida.

La CE2, que se relaciona con la formación de equipos de trabajo eficaces, valorando el
planteamiento y discusión tanto de las propuestas personales como de grupo, ejerciendo el liderazgo de
una manera positiva, está directamente vinculada a la competencia en comunicación lingüística (CCL), a la
competencia digital (CD), la competencia personal, social y de aprender a aprender (CPSAA), la
competencia ciudadana (CC) y competencia en conciencia y expresión culturales (CCEC). Además, es una
competencia necesaria para la competencia emprendedora (CE)

La competencia en Economía Social (CE3) forma parte de todas las competencias clave pues
desarrolla la competencia en comunicación lingüística (CCL) y la comunicación plurilingüe (CP) así como de
la competencia digital (CD). Igualmente se relaciona con la competencia matemática y competencia en
ciencia, tecnología e ingeniería (STEM) al utilizar métodos inductivos y el pensamiento científico para
explicar las situaciones que ocurren a su alrededor. Del mismo modo se relaciona con la competencia
ciudadana (CC), la competencia emprendedora (CE) y la competencia en conciencia y expresión culturales
(CCEC) al trabajar saberes que impulsan a formar una ciudadanía comprometida activamente en el entorno
que le rodea.

La competencia CE4, que se relaciona con el diseño de proyectos básicos sostenibles e
innovadores, utilizando herramientas de la Economía Social y comprobando su retorno a la sociedad, está
directamente vinculada con la competencia matemática y competencia en ciencia, tecnología e ingeniería
(STEM) y la competencia personal, social y de aprender a aprender (CPSAA) al utilizar el pensamiento
científico para explicar las situaciones que ocurren a su alrededor. También se relaciona con la competencia
ciudadana (CC), la competencia emprendedora (CE) y la competencia en conciencia y expresión culturales
(CCEC) al trabajar saberes que impulsan a formar una ciudadanía comprometida y respetuosa con la
diversidad cultural

La competencia específica 5, que implica la planificación de un presupuesto básico, se relaciona
con la competencia en comunicación lingüística (CCL), la competencia plurilingüe (CP), competencia
matemática y la competencia en ciencia, tecnología e ingeniería (STEM) así como con la competencia
digital (CD) y la competencia ciudadana (CC). Además, es una herramienta necesaria para la competencia
emprendedora (CE).

Por último, la competencia específica 7 sobre consumo responsable y sostenible se enlaza
directamente con la competencia en comunicación lingüística (CCL), con la competencia matemática y
competencia en ciencia, tecnología e ingeniería (STEM) y con la competencia digital (CD). Además se
relaciona con la competencia personal, social y de aprender a aprender (CPSAA), la competencia
ciudadana (CC) y la competencia emprendedora (CE) al enseñar al alumnado a tomar decisiones valorando
las ventajas de un consumo responsable.

|  | CCL | CP | STEM | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE 1 | X |  |  | X | X | X | X | X |
| CE 2 | X |  |  | X | X | X | X | X |

| CE 3 | X | X | X | X | X | X | X | X |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE 4 |  |  | X |  | X | X | X |  |
| CE 5 | X | X | X | X |  | X | X |  |
| CE 6 | X |  | X | X | X | X | X |  |

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

CCL. Competencia en comunicación lingüística

CP. Competencia plurilingüe

STEM. Competencia matemática y competencia en ciencia, tecnología e ingeniería

CD. Competencia digital

CPSAA. Competencia personal, social y de aprender a aprender

CC. Competencia ciudadana

CE. Competencia emprendedora

CCEC. Competencia en conciencia y expresión culturales

4. Saberes básicos del área de Emprendimiento Social y Sostenible

4.1. Introducción

La materia de Emprendimiento Social y Sostenible trata de aportar conceptos económicos y
empresariales necesarios para que el alumnado tenga una visión global que le permita realizar análisis
críticos y fundamentados a partir del estudio de la realidad económica, valorar la importancia de generar
ideas, de conocer las cualidades de quien emprende, las técnicas para desarrollar la creatividad, la
importancia de implantar la Responsabilidad Social Corporativa en las empresas y cumplir con los Objetivos
de Desarrollo Sostenible, así como las finanzas personales, el consumo responsable y los efectos que
provocan en los distintos ámbitos de la vida. Aprovechar estos aprendizajes servirá para generar una actitud
proactiva y comprometida con la sociedad y la búsqueda de un mayor bienestar tanto colectivo como
individual a partir de ideas innovadoras y responsables con su entorno.

Los saberes básicos que contribuyen a adquirir las competencias específicas se organizan en tres
bloques. El primero se vincula al emprendimiento como oportunidad, conociendo las cualidades y destrezas
de la persona emprendedora, las técnicas para desarrollar la creatividad, el trabajo en equipo y la
innovación al servicio de la sociedad. El segundo bloque de saberes se relaciona con la economía social y
sostenible en el marco de la ciudadanía global elaborando un proyecto básico de emprendimiento social. El
tercer bloque se centra en las finanzas personales y en el consumo responsable analizando saberes como
el endeudamiento, el ahorro y el presupuesto personal y valorando inconvenientes como pueden ser los
peligros de las casas de apuestas.

4.2. Bloques

Bloque 1 El emprendimiento como oportunidad (CE1, CE2, CE3, CE6)

Subbloque 1.1 La persona emprendedora

- Cualidades y destrezas de las personas emprendedoras.

- El autodiagnóstico del emprendedor. Fortalezas y debilidades personales.

- Perseverancia, iniciativa y flexibilidad en el análisis de toma de decisiones del proyecto

personal.

Subbloque 1.2 Herramientas para emprender

- El trabajo en equipo, la inteligencia emocional, la comunicación y el liderazgo.

-Técnicas para desarrollar la creatividad. Innovación al servicio de la sociedad.

- El desarrollo de iniciativas emprendedoras.

Bloque 2 Economía social y sostenible (CE2, CE3, CE4, CE6)

Subbloque 2.1 Economía social y sostenible en el marco de la ciudadanía global

- Contribución de los proyectos emprendedores al servicio de la Economía social.

- Creación de valor compartido y Responsabilidad Social Corporativa. El comercio justo.

- Valoración de las obligaciones fiscales y de la economía sumergida.

- Introducción al mercado de trabajo. Desigualdad de género en el mundo laboral.

- La Economía Circular y la sostenibilidad. Análisis de las 7R.

Subbloque 2.2 Soluciones innovadoras ante los retos sociales y medioambientales

- Búsqueda y observación de emprendimiento social en la Comunidad Valenciana.

- Compromiso social y sostenibilidad: Los Objetivos de Desarrollo Sostenible y la Agenda 2030.

- Estrategias para la elaboración de un proyecto básico de emprendimiento social y sostenible,
con impacto local.

Bloque 3 Finanzas personales y consumo responsable (CE5, CE6)

Subbloque 3.1 Finanzas personales

- El dinero y los instrumentos de pago.

- Presupuesto personal: valoración responsable de los gastos en relación con los ingresos.

- Importancia del ahorro. El riesgo del endeudamiento.

- Herramientas de interpretación básica de documentación de las economías domésticas:
nómina, facturas y recibos.

Subbloque 3.2 Consumo responsable

- Consumo responsable. Derechos de los consumidores.

- Publicidad y promociones.

- Sensibilidad ante los riesgos del juego y las apuestas.

5. Situaciones de aprendizaje

Las situaciones de aprendizaje deben estar conectadas con los “Principales retos del siglo XXI” y
con los objetivos de la etapa de la Educación Secundaras Obligatoria (ESO). La capacidad de actuación del
alumnado al enfrentarse a una situación de aprendizaje requiere movilizar todo tipo de saberes implicados
en las competencias específicas: conceptos, procedimientos, actitudes y valores.

La materia de Emprendimiento Social y Sostenible contribuye a formar personas críticas y
responsables ante los problemas actuales relativos al medio ambiente, degradación del planeta y exceso de
consumo, para ser conscientes de la importancia de sus acciones y su repercusión negativa en el bien
común. Al mismo tiempo, la materia contribuye a dar respuesta a problemas del entorno próximo poniendo
de manifiesto su compromiso en el ámbito local y global, valorando las competencias, cualidades y hábitos
que debe tener una persona emprendedora consciente de los retos del siglo XXI.

Para ello, es necesario hacer reflexionar al alumnado ante situaciones de inequidad y exclusión que
generen un sentimiento de empatía y justicia social desde una perspectiva colectiva, una resolución pacífica
de los conflictos con soluciones creativas que tengan como premisa la cooperación. Igualmente, el
alumnado debe reflexionar sobre el papel del emprendimiento como motor de la economía y la creación de
valor, el análisis de nuevos modelos de negocio más sostenibles con el entorno.

Algunos criterios para diseñar situaciones de aprendizaje desde esta perspectiva serían los
siguientes:

•
Estar relacionadas con actividades del ámbito local y próximo al alumnado que establezcan
relaciones con los Objetivos de Desarrollo Sostenible, que incorporan los desafíos globales a los
que nos enfrentamos día a día, tales como la desigualdad, medio ambiente, empleo, escasez,
propiedad intelectual, permitiendo descubrir el funcionamiento de la economía y la actividad
empresarial.

•
Establecer relaciones con otras materias para adquirir una visión integral de la economía y asumir
responsabilidades y compromisos, desde una perspectiva interdisciplinar.

•
Diseñarse para incentivar la reflexión, promover la competencia clave de aprender a aprender, y
desarrollar un enfoque crítico, con la finalidad de conseguir actitudes sensibles, comportamientos
responsables y proactivos que permitan aprovechar las oportunidades sociales y económicas.

•
Estimular el fomento de la lectura y la escritura a través de diferentes canales que les permitan ser
ciudadanos críticos y respetuosos ante diferentes argumentos y opiniones, así como remarcar la
necesidad de potenciar las habilidades comunicativas necesarias a la hora de emprender un
proyecto personal.

•
Permitir que sean abordadas tanto de manera individual como grupal, incorporando un enfoque
inclusivo, coeducativo, dando visibilidad a la relevancia del papel de las mujeres en la actividad
empresarial, y con el uso de técnicas de trabajo tanto cooperativo como colaborativo, a través de
actividades dialógicas, de debate, de explicación de resultado de tareas, etc.

•
Conectar los contenidos con experiencias y sentimientos personales del alumnado que han tenido
lugar en otros contextos, movilizando la capacidad de argumentación mediante el lenguaje verbal y
no verbal.

•
Potenciar los talentos individuales utilizando herramientas que posibiliten el estímulo de la
creatividad, la participación activa del alumnado, para afrontar los problemas desde diferentes
perspectivas según su diversidad personal y cultural.

•
Incluir la aceptación y el manejo de la incertidumbre tratada desde el aula de forma que dé
respuesta a cuestiones que le servirán para enfocar su futuro de trabajo o estudios e incluso la
posibilidad de, a partir de una iniciativa diseñada en el aula, poder trasladarlas fuera de la misma.

•
Es necesario que impulsen un buen uso de las nuevas tecnologías en el aula, aprendiendo nuevos
programas, aplicaciones y herramientas informáticas para fomentar la alfabetización digital y

audiovisual del alumnado y la ludificación en el aula para incrementar su motivación, autonomía y el
abanico de recursos necesarios para el correcto análisis de la disciplina.

•
Utilizar actividades inclusivas a través del Diseño Universal de Aprendizaje.

6. Criterios de evaluación

Competencia específica 1

Identificar en sí mismo cualidades personales y habilidades sociales que favorezcan la toma de
decisiones, la creatividad, la actuación responsable y el espíritu de superación.

1.1. Realizar una planificación y organización de las diferentes tareas necesarias para llevar a
cabo un trabajo, resolviendo posibles dificultades con creatividad y mostrando esfuerzo y
tenacidad.

1.2. Analizar los resultados alcanzados con conciencia del esfuerzo personal aplicado y los
logros obtenidos, realizando propuestas de mejora sobre el propio trabajo.

1.3. Identificar las fortalezas y debilidades personales, relacionándolas con los diferentes
ámbitos del desarrollo personal y la vida diaria y aplicándolas en las tareas propuestas.

Competencia específica 2

Participar en equipos de trabajo, valorando el planteamiento y discusión tanto de las propuestas
personales como de grupo, ejerciendo el liderazgo de una manera positiva y organizando el trabajo en
común.

2.1. Participar en equipos de trabajo utilizando estrategias que faciliten conseguir los objetivos
propuestos y valorando la riqueza de la diversidad.

2.2. Poner en práctica habilidades sociales, de motivación, liderazgo y de cooperación en
distintos contextos de trabajo en equipo, utilizando diferentes estrategias comunicativas.

2.3 Respetar las aportaciones de los demás en las distintas dinámicas de trabajo y fases del
proceso llevado a cabo, asumiendo las decisiones tomadas de forma colectiva.

Competencia específica 3

Argumentar el papel de la Economía Social como marco que favorece el desarrollo de una
ciudadanía global, valorando los efectos positivos que genera sobre su entorno.

3.1. Identificar el impacto social y medioambiental de la economía social en su entorno,
relacionándolo con experiencias próximas.

3.2 Detectar situaciones discriminatorias en el mercado laboral, proponiendo soluciones para
corregirlas.

3.3 Describir el funcionamiento de la economía circular, valorando las aportaciones positivas en
la sociedad.

Competencia específica 4

Diseñar proyectos básicos sostenibles e innovadores, utilizando herramientas de la Economía
Social y comprobando su retorno a la sociedad dentro de un ámbito local o global.

4.1. Describir los elementos necesarios básicos que se deben incorporar para desarrollar un
proyecto sostenible e innovador.

4.2. Identificar los objetivos de desarrollo sostenible incluidos en su proyecto.

4.3. Aplicar el modelo de Economía Circular a su proyecto, poniendo ejemplos de cómo han
incorporado las 7 R: rediseñar, reducir, reutilizar, reparar, renovar, recuperar y reciclar.

Competencia específica 5

Planificar un presupuesto personal sencillo, evaluar la importancia del ahorro y el riesgo que supone
un endeudamiento excesivo, e identificar los medios de pago utilizados.

5.1. Diseñar un presupuesto personal, reflexionando sobre su importancia para actuar de forma
responsable.

5.2. Describir los efectos que suponen un endeudamiento excesivo para su economía personal
y cómo afectaría a su entorno.

5.3. Identificar los distintos medios de pago, buscando información en diferentes fuentes y
trasladando sus impresiones al aula de forma crítica y respetuosa.

5.4. Identificar los elementos básicos de la factura, el recibo y la nómina a través de casos
prácticos y experiencias familiares.

Competencia 6

Analizar documentos relativos al consumo, desde una perspectiva responsable y sostenible, e
identificar los organismos que velan por los derechos del consumidor.

6.1. Describir hábitos de consumo responsable y aplicarlos en la toma de decisiones en su vida
cotidiana.

6.2. Explicar los criterios sociales y medioambientales que tiene un consumo responsable y el
impacto al entorno desarrollando actitudes creativas.

6.3. Apreciar actuaciones de empresas y organismos públicos que tengan un compromiso social
y sostenible, reflexionando de forma crítica sobre la relevancia de las buenas prácticas e
incorporándolas a sus hábitos de consumo.

6.4 Identificar organismos que velan por los derechos de los consumidores, detectando los
documentos válidos y necesarios.
