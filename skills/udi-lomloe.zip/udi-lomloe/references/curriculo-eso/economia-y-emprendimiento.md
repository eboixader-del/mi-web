# ECONOMÍA Y EMPRENDIMIENTO

> Fuente: Secundaria.pdf, páginas 684-698 (versión en castellano).

ECONOMÍA Y EMPRENDIMIENTO

1. Presentación.

La economía está presente en todos los aspectos de nuestra vida cotidiana, de ahí la
importancia de que el alumnado adquiera conocimientos económicos y de emprendimiento que
le permitan comprender la realidad, especialmente tras los profundos cambios que ha
experimentado en los últimos años nuestra sociedad, en un contexto cada vez más globalizado
y en el que las relaciones económicas son cada vez más complejas. Además, el estudio de la
materia permite realizar una adecuada gestión de los recursos individuales y colectivos
contribuyendo a fomentar la mejora en su calidad de vida, el progreso y el bienestar social. En la
actualidad, la economía y el emprendimiento además de dar a conocer los elementos y las reglas
que explican los acontecimientos económicos y las consecuencias que se derivan de las
decisiones emprendedoras, proyectan valores relacionados con la solidaridad entre personas, la
importancia de la sostenibilidad, o la gestión de los recursos y de la desigualdad. En este sentido,
juega un papel importante la persona emprendedora que integra, por un lado, una formación
económica y financiera y, por otro, una visión que la anima a buscar oportunidades e ideas que
contribuyan a satisfacer las necesidades detectadas en el entorno, desarrollando estrategias
para llevar esas ideas a la acción. Así, genera valor para los demás, innova y contribuye a mejorar
el bienestar personal, social y cultural.

La finalidad educativa de la materia Economía y Emprendimiento está en consonancia
con la Recomendación del Consejo de la Unión Europea de 22 de mayo de 2018 relativa a las
competencias clave para el aprendizaje permanente, que refiere a la necesidad de introducir en
la educación herramientas que permitan lograr que lo aprendido se pueda aplicar en tiempo real,
y que genere nuevas ideas, nuevas teorías, nuevos productos y conocimientos.

Economía y emprendimiento está planteada como materia de opción en cuarto curso de
la Educación Secundaria Obligatoria y persigue que el alumnado cuente con una educación
económica y financiera para desenvolverse y asumir riegos de manera responsable en su vida
cotidiana y gestionar y llevar a la acción de manera viable proyectos vitales, profesionales y
empresariales y que busque soluciones innovadoras y valiosas para afrontar los retos
propuestos, a través de estrategias de gestión del conocimiento, del autoconocimiento y de la
colaboración con los demás.

El currículo de esta materia de 4º de la ESO se diseña tomando como referentes las
competencias conforme establece el perfil de salida del alumnado al término de la enseñanza
básica. Asimismo, se diseña con la vista puesta en los objetivos fijados para la etapa de
Enseñanza Secundaria Obligatoria contribuyendo a desarrollar en el alumnado el espíritu
emprendedor y la confianza en sí mismo, la participación y el sentido crítico, la iniciativa personal,
y la capacidad para aprender a aprender, planificar, tomar decisiones y asumir
responsabilidades.

Se desarrolla a partir de aprendizajes significativos, funcionales y de interés para el
alumnado y está organizada en torno a la adquisición de competencias específicas que tratan de
promover en primer lugar, un espíritu proactivo que lleve a desarrollar una cultura de
emprendimiento personal, social y empresarial más ágil e innovadora. A partir de un análisis
preciso de sí mismos, el alumnado desarrollará habilidades personales y sociales, así como las
estrategias necesarias para afrontar retos, gestionar la incertidumbre y tomar decisiones
adecuadas para llevar el proyecto a la realidad.

En segundo lugar, las competencias específicas de esta materia ayudan a que el
alumnado comprenda que la persona emprendedora debe abrirse camino en un contexto global
cuyos elementos se relacionan entre sí. Para ello, analizarán el entorno desde una perspectiva
económica, social y medioambiental, identificando necesidades y oportunidades para encontrar
los recursos tanto humanos, materiales, inmateriales y digitales necesarios, y aplicarlos a la
realización de un proyecto personal o profesional con visión emprendedora.

En tercer lugar, las competencias específicas contribuyen a que el alumnado transfiera
los aprendizajes a un plano práctico desarrollando la planificación, gestión y ejecución de un
proyecto emprendedor que suponga una solución innovadora y de valor en su entorno más
próximo.

La materia se asocia con los estudios previos realizados en la Educación Secundaria
Obligatoria y tiene especial relación con las materias comunes de Matemáticas, Geografía e
Historia, Lengua Castellana, Lengua Valenciana, Lengua Inglesa, así como con las materias
optativas de Emprendimiento Social y Sostenible impartida en segundo de la ESO y el Taller de
Economía ofertada en tercero de la ESO. Además, hay una especial relación con la materia de
opción de Formación y Orientación Personal y Profesional. Estas materias permiten al alumnado
tener un primer contacto con el funcionamiento de la economía, de las empresas y del perfil de
las personas emprendedoras, reflexionando de forma crítica y constructiva, además de proponer
soluciones a problemas y retos contemporáneos con una visión interdisciplinar.

Los saberes básicos que contribuyen a adquirir las competencias específicas se
organizan en tres bloques. El primero se vincula a aspectos económicos como el análisis de la
escasez, el problema económico, la necesidad de elegir, el estudio del entorno y los principales
objetivos de la economía actual. El segundo bloque de saberes va ligado al emprendimiento, al
análisis y desarrollo del perfil de la persona emprendedora, la adquisición y puesta en práctica
de habilidades personales y estrategias de gestión de emociones, de la incertidumbre y del riesgo
financiero para hacer frente a contextos cambiantes e inciertos en los que emprender. El tercer
bloque incluye las distintas fases del proyecto emprendedor desde la ideación hasta la ejecución
y validación del prototipo final.

Los criterios de evaluación de esta materia van dirigidos a comprobar el grado de
adquisición de las competencias específicas, esto es, el nivel en el que al alumnado es capaz de
movilizar los saberes, conceptuales, procedimentales y relativos a actitudes y valores en
situaciones o actividades del ámbito personal, social y académico con una futura proyección
profesional.

Finalmente, en cuanto a las situaciones de aprendizaje de la materia, se propone la
concreción curricular de la misma desde una perspectiva competencial. De este modo, los
aprendizajes se construirán en la acción y desde la acción. El alumnado ideará, gestionará
recursos, desarrollará prototipos, participará en la validación iterativa de los mismos y tomará
decisiones en un ambiente flexible y abierto que le permita desplegar sus aptitudes y potenciar
sus destrezas y actitudes emprendedoras trabajando en equipo. Esta dinámica de trabajo genera
una cultura creativa, colaborativa y de participación dirigida a crear valor para los demás.

2. Competencias específicas de Economía y Emprendimiento

2.1. CE1. Diseñar un proyecto personal que genere valor para la sociedad, analizando
las fortalezas y debilidades propias y gestionando de forma eficaz las emociones.

2.1.1. Descripción de la competencia

El autoconocimiento permite a la persona indagar en sus aspiraciones, necesidades y
deseos personales, descubrir sus aptitudes, distinguir sus inteligencias y, así, reflexionar sobre
sus fortalezas y debilidades, para aprender a valorarlas como fuente de crecimiento personal.

Además, ayuda a reconocer y gestionar emociones para adaptarse a contextos inciertos y
cambiantes, que puedan generar un conflicto cognitivo y emocional, con el objetivo de poner en
marcha y llevar a cabo un proyecto personal con una propuesta de valor única, que garantice
nuevas oportunidades en todos los ámbitos y situaciones de la vida (personales, sociales,
académicas y profesionales).

El proyecto personal es importante afrontarlo desde una actitud emprendedora,
resolutiva, innovadora y sostenible que permita la adaptación a distintos entornos y comprender
la importancia de desarrollar el hábito de actuar con creatividad, tanto individual como
colectivamente, mediante el entrenamiento de la capacidad creadora aplicándola en diferentes
escenarios para lograr avances no sólo personales, sino sociales, culturales, artísticos y
económicos de valor.

2.2. CE2.Utilizar estrategias de conformación de equipos y mostrar habilidades
sociales de empatía, respeto y liderazgo en las dinámicas de trabajo en distintos
contextos, analizando el valor de cooperar con otras personas.

2.2.1. Descripción de la competencia

Identificar y analizar rasgos característicos y cualidades personales propias y del resto
de personas resulta indispensable para afrontar con éxito un proyecto. Una correcta identificación
de las potencialidades permite la constitución de un equipo de trabajo equilibrado, eficaz,
cooperativo, motivado y responsable, adecuándose así a las necesidades del proyecto que se
pretende abordar.

Se requiere la puesta en marcha de diferentes estrategias para constituir los equipos de
trabajo, definiendo objetivos, normas, roles y responsabilidades de manera equitativa y
favoreciendo la diversidad entre sus integrantes. Se consiguen así, equipos multidimensionales,
inclusivos, capaces de generar, a través del diálogo, una inteligencia colectiva que les permita
funcionar con autonomía y contribuir a la innovación ágil.

Un correcto desarrollo y uso de las habilidades sociales como la empatía, la asertividad,
la negociación, el liderazgo y el respeto hacia los intereses, elecciones e ideas de los demás, así
como el conocimiento de distintas lenguas y uso de habilidades de comunicación, facilita una
visión compartida entre los y las componentes del equipo, la creación de un buen clima de trabajo
y la construcción de vínculos de cooperación que redunden en el crecimiento personal y colectivo
e intensifiquen valores de respeto, equidad e igualdad entre mujeres y hombres.

2.3. CE3. Identificar necesidades de las personas a nivel local y global y proponer
soluciones sencillas, innovadoras y sostenibles para satisfacerlas, con sentido
ético y solidario, analizando sus puntos fuertes y débiles y su posible impacto en
el entorno económico.

2.3.1. Descripción de la competencia

En la actualidad, resulta necesario dotar a las personas de herramientas que les ayuden
a buscar, promover y desarrollar eficazmente ideas y soluciones innovadoras y sostenibles que
den respuesta a necesidades detectadas en su entorno, tanto local como global, desde una visión
emprendedora. Para lograrlo, es conveniente que el alumnado utilice métodos de ideación o
generación de ideas y los someta a procesos de validación a través del uso de metodologías
ágiles tanto individuales como grupales, analizando el impacto que la materialización de esas
ideas pudiera provocar en los distintos ámbitos y contextos de su entorno.

Este proceso de validación está inevitablemente ligado a los valores sociales y
personales del alumnado, por lo que en el diseño y desarrollo de soluciones es necesario
considerar los Objetivos de Desarrollo Sostenible y actuar desde un punto de vista ético, de

igualdad, equidad y sostenibilidad para lograr la superación de retos relacionados con la
preservación y cuidado del entorno natural, social, cultural y artístico.

2.4. CE4. Identificar los recursos necesarios en el proceso de desarrollo de la idea o
solución creativa propuesta y las posibles fuentes financieras necesarias para la
obtención de dichos recursos y aplicarlas a su proyecto emprendedor.

2.4.1. Descripción de la competencia

Dentro del proceso que conlleva transformar las ideas en prototipos de valor es obligado
contemplar una fase dirigida a conseguir y gestionar los recursos humanos, materiales,
inmateriales y digitales disponibles, reuniendo y seleccionando aquellos recursos que de manera
ética, eficiente y sostenible puedan hacer realidad una idea o solución emprendedora,
implantando un modelo de buenas prácticas que impacte positivamente en el entorno hacia el
que va dirigida la idea.

Este modelo debe de impregnar también la protección de las ideas y soluciones, lo que
requiere de un conocimiento específico para garantizar el respeto a las creaciones de los demás
y los derechos sobre las propuestas y soluciones propias. Por otro lado, poner en marcha una
idea viable supone asumir el reto con responsabilidad y que las personas emprendedoras posean
conocimientos económicos, financieros, legales y técnicos entendidos también como recursos
propios adquiridos a través de la formación, que los orienten en la búsqueda de financiación y el
uso de herramientas digitales que den difusión y proyección a las ideas y soluciones durante el
proceso de realización de las mismas.

2.5. CE5.Presentar y exponer ideas y soluciones creativas que transmitan mensajes
convincentes adecuados al contexto y a los objetivos de cada situación, utilizando
estrategias comunicativas eficaces, respetuosas e inclusivas.

2.5.1. Descripción de la competencia

En la actualidad, las relaciones interpersonales e intergrupales requieren una
comunicación eficaz lo cual exige formación para mejorar la competencia comunicativa de las
personas. Es importante que el alumnado entienda que las estrategias de comunicación son
elementos necesarios en cualquier aspecto de las relaciones humanas pero que cobran especial
importancia para que una persona emprendedora interactúe con otras de manera efectiva y
positiva. Compartir los conocimientos y las experiencias con los demás permite idear soluciones
contrastadas e innovadoras, motivar, convencer, tomar decisiones y generar oportunidades.

En este sentido, la utilización de estrategias de comunicación ágil facilita la tarea de
explicar una idea original transmitiendo, con claridad y rapidez, sus puntos fuertes y débiles.
Asimismo, permite que los equipos compartan las ideas creativas generadas, se validen o
descarten con rapidez y se tomen decisiones sobre las soluciones que finalmente se elijan para
afrontar los objetivos propuestos. Por otro lado, también es necesario que las personas adquieran
las herramientas para presentar y exponer, de manera clara, atractiva y convincente, la idea o
solución que se va a desarrollar en el proyecto emprendedor, con objeto de reunir los recursos
necesarios para llevarla a cabo o para difundirla.

2.6. CE6. Analizar aspectos básicos de la economía y las finanzas, valorando
críticamente el problema de la escasez de recursos, la necesidad de elegir, así
como los principales objetivos de la economía actual, desarrollando ideas que den
soluciones eficaces, equitativas y sostenibles.

2.6.1. Descripción de la competencia

Actualmente conocer y comprender la economía es fundamental, pues es en ella es
donde surgen las necesidades y oportunidades a las que hay que atender ofreciendo soluciones
realistas, eficientes y sostenibles que den respuesta a los nuevos retos que se plantean. La

economía se enfrenta a múltiples objetivos y abordarlos con información relevante ayuda a poder
buscar respuestas más eficaces.

En primer lugar, la economía se enfrenta al problema de la escasez que condiciona la
toma de decisiones de las personas para cubrir las necesidades individuales y colectivas. Al
mismo tiempo, la sociedad se enfrenta a problemas relacionados con el crecimiento,
externalidades medioambientales, la desigualdad, el desempleo, el fraude fiscal y la inflación,
que deben ser analizados para poder ser abordados con conocimiento de causa. Por otro lado,
es necesario adquirir una educación financiera que aporte los conocimientos necesarios para
guiar las decisiones personales de manera responsable.

Es por ello que el estudio de la economía y las finanzas son el punto de partida para
detectar necesidades no cubiertas y generar ideas innovadoras que den solución a los retos
actuales, de manera eficaz, equitativa y sostenible.

2.7. CE7. Diseñar y analizar de manera cooperativa y ágil prototipos innovadores y
sostenibles, a través de estrategias eficaces de diseño, validando sus resultados
de forma ética, crítica y sostenible.

2.7.1. Descripción de la competencia

El propósito de un proyecto emprendedor es dar respuestas innovadoras y sostenibles,
a partir de un prototipo, a las necesidades de un entorno en el que se producen cambios
constantemente. Este prototipo es el resultado de un proceso constructivo de una idea de
negocio, que se lleva a cabo de manera cooperativa e implica el paso por distintas fases que han
de ser evaluadas de manera continua con una actitud crítica y ética.

En el proceso creativo de ideación o generación de ideas se plantean soluciones que se
transforman en aprendizajes validados o demostrables, recurriendo al diseño, planificación y
construcción de prototipos con garantía de éxito. Tras el diseño del prototipo, se realiza el
proyecto y se elaboran estrategias de gestión de los recursos, del modelo organizativo o de
negocio y del plan de ejecución. Es importante aprender a tomar decisiones adecuadas y
autónomas, para que el proyecto se realice de forma viable y sostenible, considerando la
importancia de un aprendizaje validado.

3. Conexiones de las competencias específicas entre sí, con las competencias específicas
de otras materias y con las competencias clave.

3.1. Relaciones o conexiones entre las competencias específicas.
3.1.1. Conexiones Competencia Específica 1

Se relaciona con la CE 2 relativa a la formación de grupos de trabajo, en el proceso de
ideación de soluciones emprendedores. Por otro lado, se relaciona con la CE 3, puesto que el
autoconocimiento y conocimiento de los demás es fundamental para luego generar esas
soluciones emprendedoras, así como con la CE 6, en cuanto a su relación con el análisis crítico
de la escasez y demás problemas básicos de la economía. Finalmente se relaciona con la CE 7
ya que dicha competencia es el proceso constructivo del prototipo.

3.1.2 Conexiones Competencia Específica 2

Cabe destacar su relación con la CE 3 por la importancia del trabajo en equipo para el
diseño de ideas innovadoras. También se relaciona con la CE 5, en el sentido de la puesta en
marcha de estrategias de comunicaciones efectivas y respetuosas, por medio de los equipos de
trabajo. Además, se relaciona con la CE7, dada la importancia de los grupos de trabajo a la hora
del diseño y planificación de prototipos. Como hemos visto antes, existe una relación estrecha
con la CE 1.

3.1.3 Conexiones Competencia Específica 3

Es destacable su conexión con la CE 4, dada la necesidad de la búsqueda de recursos
en el proceso de creación de soluciones emprendedoras. Es también muy clara la relación con
la CE 5 por la exigencia de comunicar y explicar de manera efectiva las mismas. Esta
competencia se relaciona igualmente con la CE 6 al poner en valor la idea emprendedora dentro
de un entorno económico sostenible desde un punto de vista ético. Por último, se relaciona con
la CE 7, por la necesidad de plasmar la solución innovadora en un prototipo. Asimismo, hemos
nombrado antes su relación con la CE 1 y la CE 2.

3.1.4 Conexiones Competencia Específica 4

Se relaciona con la CE 6 ya que hay que tener en cuenta, a la hora de la búsqueda de
recursos necesarios para la puesta en marcha de soluciones innovadoras, el problema de la
escasez de recursos. Además, tiene relación con la CE 7, porque también hay que considerar
los recursos a la hora de diseñar prototipos ágiles e innovadores.

3.1.5. Conexiones Competencia Específica 5

Esta competencia se relaciona con la CE 6, teniendo en cuenta la importancia de una
comunicación efectiva y respetuosa a la hora de valorar los problemas económicos, y con la CE2
por la necesidad de una buena comunicación en los equipos de trabajo, así como la CE7 por la
necesidad de exponer el prototipo trabajado.

3.1.6 Conexiones Competencia Específica 6

Ya se ha comentado anteriormente la relación de esta competencia con la CE1, CE 3,
CE 4 y CE 5. Esta competencia está relacionada con la CE 1 debido a la necesidad de realizar
un proyecto personal antes de identificar los problemas económicos actuales, la CE3 por la
elaboración de ideas, la CE4 necesaria para detectar los recursos necesarios y la CE5 dado que
se presenta y se expone el proyecto.

3.1.7 Conexiones Competencia Específica 7

La competencia 7 tiene relación con el resto de competencias ya que el prototipo es el
resultado final del proyecto de emprendimiento realizado por el alumnado.

3.2. Relaciones o conexiones con competencias específicas de otras áreas

La materia de Economía y Emprendimiento tiene relaciones con otras materias
estudiadas tanto en el curso de cuarto de la ESO como los cursos previos de la etapa de
educación secundaria obligatoria debido a su visión amplia del mundo y la sociedad. Así pues,
la materia tiene especial relación con las materias del área de las ciencias sociales y
humanidades como Geografía e Historia, Educación en Valores Cívicos y Éticos, pero también
con ámbitos relacionados con las matemáticas, lenguas o las ciencias naturales. Al mismo
tiempo, tiene relación con materias optativas relacionadas con la Economía tales como
Emprendimiento Social y Sostenibilidad, Taller de Economía o Formación y Orientación Personal
y Profesional.

Las competencias 1, 2 y 5 de la materia de Economía y Emprendimiento están asociadas
con las competencias comunicativas de las diferentes lenguas estudiadas:

•
Lengua Castellana y Literatura y Valenciano: Lengua y Literatura, ya que ambas
lenguas permiten una acción comunicativa y son de gran ayuda para expresar los principios
económicos y la interacción en los grupos de trabajo necesarios en la materia. Así pues,
competencias como la comprensión oral (CE 2), comprensión escrita (CE 3), expresión oral
(CE4), la expresión escrita (CE5), la mediación (CE7) y la lectura (CE8) y son fundamentales
para conseguir los objetivos del curso.

•
Primera Lengua Extranjera, la competencia 2 (comprensión oral) y la
competencia 3 (comprensión escrita) son de gran relevancia para comprender mejor los
diferentes aspectos de la economía global.

Las competencias 3 y 6 de nuestra materia tienen relación con las materias de Geografía
e Historia, Biología y Geología y Educación en Valores Cívicos y Éticos.

•
Geografía e Historia: Las competencias de la materia de Geografía e Historia
tienen un nexo común con la materia de Economía y Emprendimiento. La competencia 5 explica
las interrelaciones económicas y su repercusión en la sociedad tan necesaria para poder dar
respuesta mediante soluciones innovadoras que se realizan en la materia de Economía y
Emprendimiento y la competencia 8 de la materia de sociales que promueve proyectos
cooperativos teniendo como base la Unión Europea.

•
Educación en Valores Cívicos y Éticos: las competencias de la materia tienen
una perspectiva enfocada al desarrollo de valores y actitudes respetuosas con el entorno. Es por
ello que hay una especial relación, tales como la competencia 2 asociada a la cultura de la paz;
la competencia 7 que hace hincapié a la sostenibilidad del planeta, o la competencia 6 que
describe la lucha contra la desigualdad y la injusticia.

•
Biología y Geología: las competencias específicas de la materia trabajan temas
sobre sostenibilidad como la conservación con responsabilidad de todas de las formas de vida y
el planeta (CE7) y la adopción de hábitos de comportamiento en la actividad cotidiana
responsables con el entorno (CE10)

La competencia 4 tiene especial relación con las Matemáticas y la Física y Química,
debido a la necesidad de las mismas para el cálculo de aspectos técnicos y financieros.

•
Matemáticas: algunas de las competencias matemáticas que son necesarias
tratan de resolver problemas relacionados con situaciones diversas del ámbito social (CE1),
construir modelos matemáticos-funcionales con el objetivo de interpretar problemas relevantes
(CE3) e interpretar mensajes orales y escritos complejos de manera formal, empleando el
lenguaje matemático (CE6)

•
Física y Química: desde la materia se trabaja la resolución de problemas
científicos a partir de trabajos de investigación abordables en el ámbito experimental (CE1),
analizar fenómenos naturales (CE5) y la utilización de representaciones gráficas (CE7).

La competencia 7 está asociada a la creación de prototipos, muy útil en la materia de
Tecnología y Digitalización.

•
Tecnología y Digitalización: competencias como la gestión de los recursos
disponibles (CE2), el uso responsable y sostenible de objetos y materiales (CE4) o el uso de la
tecnología al desarrollo personal, social y profesional (CE7) ayudarán a adquirir la competencia
específica de la materia de Economía y Emprendimiento.

3.3. Relaciones o conexiones con las competencias clave.

La competencia específica CE1 tiene conexión con la competencia personal, social y de
aprender a aprender (CPSAA), con la competencia emprendedora (CE) y con la competencia en
conciencia y expresión culturales (CCEC), pues al analizar las fortalezas y debilidades, tanto
propias como de los demás, reflexionando sobre las aptitudes y gestionando las emociones,
implica que el alumnado desarrolla estrategias de autoconocimiento y resiliencia, a la vez que
aprende a expresar sus sentimientos y emociones de manera creativa y abierta. Al mismo tiempo
esta competencia tiene conexión con la competencia ciudadana (CC) pues le ayuda a
comprender su propia identidad y a respetar las normas.

La competencia específica CE2 tiene conexión con la competencia en comunicación
lingüística (CCL), con la competencia plurilingüe (CP), con la competencia personal, social y de
aprender a aprender (CPSAA), con la competencia ciudadana (CC) y con la competencia
emprendedora (CE), pues al utilizar estrategias de conformación de equipos, comunicación ágil
y habilidades sociales, el alumnado ha de expresarse correctamente de forma oral y escrita con
coherencia y corrección según los contextos sociales y esa comunicación se realiza en las
diferentes lenguas del currículo. Por otra parte, la configuración de grupos de trabajo eficaces
para desarrollar soluciones emprendedoras hace que refuerce el espíritu constructivo en la
interacción con los demás, al tiempo que se trabaja la competencia emprendedora con la
creación de ideas y soluciones valiosas.

La CE3, que implica elaborar ideas y soluciones sencillas, innovadoras y sostenibles, se
relaciona con la competencia matemática y competencia en ciencia, tecnología e ingeniería
(STEM) y con la competencia emprendedora pues implican el desarrollo de proyectos que den
soluciones a diferentes necesidades o problemas locales o globales, hecho que a su vez la
relaciona con la competencia ciudadana (CC) y con la competencia en conciencia y expresión
culturales (CCEC).

La competencia específica 4 se relaciona directamente con la competencia
emprendedora (CE), con la competencia matemática y competencia en ciencia, tecnología e
ingeniería (STEM) así como con la competencia digital pues son indispensables para reunir los
recursos necesarios en el proceso de desarrollo de la empresa y para identificar las fuentes
financieras necesarias para la obtención de dichos recursos.

La competencia en comunicación lingüística (CCL), la competencia plurilingüe (CP) y la
competencia digital (CD) están directamente relacionadas con la CE5 pues son necesarias a la
hora de exponer ideas y soluciones creativas. Igualmente, la competencia emprendedora (CE),
la competencia personal, social y de aprender a aprender (CPSAA) así como la competencia
ciudadana (CC) están relacionadas con la CE5, pues favorecen la identificación de
oportunidades sociales y diversidad social.

La competencia específica 6 que analiza aspectos básicos de economía y fianzas
desarrollando ideas que den soluciones está directamente vinculada con la competencia
ciudadana (CC) y con la competencia emprendedora (CE) pues desarrolla una visión global
desde una perspectiva de empatía, equidad y espíritu constructivo al mismo tiempo que presenta
ideas innovadoras, éticas y sostenibles para crear valor en la sociedad.

|  | CCL | CP | STEM | CD | CPSAA | CC | CE |
| --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 |  |  |  |  | X | X | X |
| CE2 | X | X |  |  | X | X | X |
| CE3 |  |  | X |  |  | X | X |
| CE4 |  |  | X | X |  |  | X |
| CE5 | X | X |  | X | X | X | X |
| CE6 |  |  |  |  |  | X | X |
| CE7 |  |  | X | X | X |  | X |

Por último, la CE7 se relaciona con la competencia matemática y competencia en
ciencia, tecnología e ingeniería (STEM), con la competencia digital (CD), con la competencia
personal, social y de aprender a aprender (CPSAA) y la competencia ciudadana (CC), pues al
construir de manera cooperativa, autónoma y ágil nuevos prototipos y al evaluar los resultados
de forma ética, crítica y sostenible el alumnado desarrolla estas competencias claves. Además,
la CE7 también está vinculada con la competencia emprendedora (CE) al potenciar la utilización
de destrezas que favorecen el trabajo colaborativo y en equipo para reunir y optimizar los
recursos necesarios que lleven a la acción la experiencia emprendedora de valor.

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

•
CCL. Competencia en comunicación lingüística

•
CP. Competencia plurilingüe

•
STEM. Competencia matemática y competencia en ciencia y tecnología

•
CD. Competencia digital

•
CPSAA. Competencia personal, social y de aprender a aprender

•
CC. Competencia ciudadana

•
CE. Competencia emprendedora

•
CCEC. Competencia en conciencia y expresión culturales

4. Saberes básicos del área de Economía y Emprendimiento

4.1. Introducción

La materia de Economía y Emprendimiento aporta conceptos económicos y
empresariales necesarios para que el alumnado tenga una visión global que le permita realizar
análisis críticos y fundamentados a partir del estudio de casos sobre la realidad económica,
valorar la importancia de generar ideas y diseñar prototipos para desarrollar un proyecto
empresarial y los efectos que éste provoca en los distintos ámbitos de la vida. Además, permite
aprovechar estos aprendizajes para generar una actitud proactiva y comprometida con la
sociedad y para lograr un mayor bienestar tanto colectivo como individual a partir de ideas
innovadoras y responsables con su entorno.

Los saberes básicos que contribuyen a adquirir las competencias específicas se
organizan en tres bloques. El primero se vincula a conocimientos básicos relacionados con el
problema de la escasez, el funcionamiento del mercado, el entorno macroeconómico y financiero,
así como los principales objetivos de la economía actual. El segundo bloque de saberes se
relaciona con el emprendimiento y el conocimiento de las personas emprendedoras e incluye
aquellas habilidades y competencias que son características de las personas con iniciativa y
sentido emprendedor y de sus finanzas. El tercer bloque recoge los conocimientos necesarios
para realizar un proyecto emprendedor, la importancia de la toma de decisiones, de establecer
una visión y misión del proyecto, la organización de la empresa y el diseño de prototipos, así
como el valor del trabajo en equipo teniendo siempre presente las novedades que existen en
este campo como consecuencia de la revolución tecnológica y digital.

4.2. Bloque de saberes

BLOQUE 1 ECONOMÍA (CE3, CE5, CE6, CE7)

GRUPO DE SABERES 1.1 EL PROBLEMA BÁSICO DE LA ECONOMÍA

•
La importancia de la Economía. Economía Normativa y Positiva. Microeconomía,
Macroeconomía

•
El problema económico: la escasez de recursos y la necesidad de elegir.

•
El comportamiento de las personas en las decisiones económicas.

•
Los agentes económicos y el flujo circular de la renta.

GRUPO DE SABERES 1.2 FUNCIONAMIENTO DEL MERCADO

•
El entorno económico-empresarial.

•
El funcionamiento de los mercados.

•
El mercado y las oportunidades de negocio: análisis del entorno general o
macroentorno; estrategias de análisis del entorno específico o microentorno.

GRUPO DE SABERES 1.3 PRINCIPALES OBJETIVOS DE LA ECONOMÍA ACTUAL

•
Producción y crecimiento sostenible. Empleo y control de precios. Indicadores

•
Sensibilidad ante desigualdades económicas y distribución de la renta. El papel
del Estado.

•
Estrategias de revisión de los procesos de integración económica y
globalización.

•
La economía colaborativa. La huella ecológica y la economía circular.

•
La economía social y solidaria. Los Objetivos de Desarrollo Sostenible (ODS) y
el desarrollo local.

BLOQUE 2 EMPRENDIMIENTO (CE1, CE2, CE4, CE5)

GRUPO DE SABERES 2.1 LA FIGURA DE LA PERSONA EMPRENDEDORA

•
El Perfil de la persona emprendedora. Técnicas de diagnóstico de debilidades y
fortalezas.

•
Creatividad, ideas y soluciones. La innovación ágil.

•
Comunicación, motivación y liderazgo. Habilidades sociales.

•
Gestión de emociones. Estrategias de gestión de la incertidumbre y toma de
decisiones en contextos cambiantes. El error y la validación como oportunidades para aprender.

•
Estrategias de exploración del entorno. Búsqueda y gestión de la información.

•
Perseverancia, iniciativa y flexibilidad en el análisis de toma de decisiones.

GRUPO DE SABERES 2.2 FINANZAS DE LA PERSONA EMPRENDEDORA

•
El sistema financiero. Control y gestión del dinero. Fuentes y control de ingresos
y gastos.

•
Recursos financieros a corto y largo plazo y su relación con el bienestar
financiero.

•
El endeudamiento. Fuentes de financiación y captación de recursos financieros.

•
La gestión del riesgo financiero.

BLOQUE 3 EL PROYECTO EMPRENDEDOR (CE1, CE2, CE3, CE4, CE5, CE6, CE7)

GRUPO DE SABERES 3.1 DECISIONES PARA LLEVAR A CABO EL PROYECTO
EMPRENDEDOR

•
La decisión empresarial como fuente de transformación social. Recursos para
llevar a cabo un proyecto emprendedor.

•
Misión, visión y valores de la empresa o entidad. La empresa y su
responsabilidad social.

•
Emprendimiento en los sectores productivos desde una perspectiva de género.

•
Las funciones y la organización de la empresa. Los equipos en las empresas y
organizaciones: estrategias de formación y funcionamiento de equipos de trabajo.

GRUPO
DE
SABERES
3.2
PLAN
DE
REALIZACIÓN
DEL
PROYECTO
EMPRENDEDOR

•
Planificación, gestión y ejecución de un proyecto emprendedor.

•
Métodos de análisis de la competencia.

•
El prototipo del proyecto emprendedor: herramientas de desarrollo, presentación,
difusión y validación.

•
El usuario como consumidor y destinatario final del prototipo. Derechos y
obligaciones de los consumidores.

•
Derechos sobre el prototipo: la propiedad intelectual e industrial.

5. Situaciones de aprendizaje

Las situaciones de aprendizaje deben estar conectadas con los “Principales retos del
siglo XXI” y con los objetivos de la etapa de la Educación Secundaras Obligatoria (ESO). La
capacidad de actuación del alumnado al enfrentarse a una situación de aprendizaje requiere
movilizar todo tipo de saberes implicados en las competencias específicas: conceptos,
procedimientos, actitudes y valores.

La materia de Economía y Emprendimiento contribuye a formar personas críticas y
responsables ante los problemas actuales relativos al medio ambiente, degradación del planeta
y exceso de consumo, para ser conscientes de la importancia de sus acciones y su repercusión
negativa en el bien común. Al mismo tiempo, la materia contribuye a dar respuesta a problemas

del entorno próximo poniendo de manifiesto su compromiso en el ámbito local y global, valorando
las competencias, cualidades y hábitos que debe tener una persona emprendedora consciente
de los retos del siglo XXI.

Para ello, es necesario hacer reflexionar al alumnado ante situaciones de inequidad y
exclusión que generen un sentimiento de empatía y justicia social desde una perspectiva
colectiva, una resolución pacífica de los conflictos con soluciones creativas que tengan como
premisa la cooperación. Igualmente, el alumnado debe reflexionar sobre la importancia del
emprendimiento en el desarrollo económico y la creación de valor, el análisis de nuevos modelos
de negocio más sostenibles con el entorno.

Algunos criterios para diseñar situaciones de aprendizaje desde esta perspectiva serían
los siguientes:

•
Estar relacionadas con actividades del ámbito local y próximo al alumnado que
establezca relaciones los Objetivos de Desarrollo Sostenible que incorporan los desafíos
globales a los que nos enfrentamos día a día, tales como la desigualdad, medio ambiente,
empleo, escasez, propiedad intelectual, permitiendo descubrir el funcionamiento de la economía
y la actividad empresarial.

•
Establecer relaciones con otras materias para adquirir una visión integral de la
economía y asumir responsabilidades y compromisos, desde una perspectiva interdisciplinar.

•
Diseñarse para incentivar la reflexión, promover la competencia clave de
aprender a aprender, y desarrollar un enfoque crítico, con la finalidad de conseguir actitudes
sensibles, comportamientos responsables y proactivos que permitan aprovechar las
oportunidades sociales y económicas.

•
Estimular el fomento de la lectura y la escritura a través de diferentes canales
que les permitan ser ciudadanos críticos y respetuosos ante diferentes argumentos y opiniones,
así como remarcar la necesidad de potenciar las habilidades comunicativas necesarias a la hora
de emprender un proyecto personal.

•
Permitir que sean abordadas tanto de manera individual como grupal,
incorporando un enfoque inclusivo, coeducativo, dando visibilidad a la relevancia del papel de
las mujeres en la actividad empresarial, y con el uso de técnicas de trabajo tanto cooperativo
como colaborativo, a través de actividades dialógicas, de debate, de explicación de resultado de
tareas.

•
Conectar los contenidos con experiencias y sentimientos personales del
alumnado que han tenido lugar en otros contextos, movilizando la capacidad de argumentación
mediante el lenguaje verbal y no verbal.

•
Potenciar los talentos individuales utilizando herramientas que posibiliten el
estímulo de la creatividad, la participación activa del alumnado, para afrontar los problemas
desde diferentes perspectivas según su diversidad personal y cultural.

•
Incluir la aceptación y el manejo de la incertidumbre tratada desde el aula y que
dé respuesta a cuestiones que le servirán para enfocar su futuro de trabajo o estudios e incluso
la posibilidad de, a partir de una iniciativa diseñada en el aula, poder trasladarlas fuera de la
misma.

•
Es necesario que impulsen un buen uso de las nuevas tecnologías en el aula,
aprendiendo nuevos programas, aplicaciones y herramientas informáticas para fomentar la
alfabetización digital y audiovisual del alumnado y la gamificación en el aula para incrementar su
motivación, autonomía y el abanico de recursos necesarios para el correcto análisis de la
disciplina.

•
Son actividades inclusivas y que utilizan los principios del Diseño Universal de
Aprendizaje.

6. Criterios de evaluación.

1. Competencia específica 1. Diseñar un proyecto personal que genere valor para la
sociedad, analizando las fortalezas y debilidades propias y gestionando de forma
eficaz las emociones.

1.
Realizar una planificación y organización de las diferentes tareas
necesarias para llevar a cabo un proyecto personal, resolviendo posibles dificultades con
creatividad y mostrando esfuerzo y tenacidad.

2.
Utilizar estrategias de análisis de las fortalezas y debilidades
personales, comparándolas con las cualidades propias de las personas emprendedoras.

3.
Gestionar de forma eficaz las emociones y destrezas personales,
promoviendo y desarrollando actitudes creativas.

4.
Analizar los resultados alcanzados con conciencia del esfuerzo personal
aplicado y los logros obtenidos, realizando propuestas de mejora sobre el propio trabajo.

2. Competencia específica 2. Utilizar estrategias de conformación de equipos y
mostrar habilidades sociales de empatía, respeto y liderazgo en las dinámicas
de trabajo en distintos contextos, analizando el valor de cooperar con otras
personas.

1.
Constituir equipos de trabajo basados en principios de equidad,
coeducación e igualdad entre mujeres y hombres, utilizando estrategias que faciliten la
identificación y optimización de los recursos humanos necesarios que conduzcan a la
consecución del reto propuesto.

2.
Mostrar habilidades sociales, de motivación, liderazgo y de cooperación
e innovación ágil en distintos contextos de trabajo en equipo, utilizando diferentes estrategias
comunicativas.

3.
Respetar las aportaciones de los demás en las distintas dinámicas de
trabajo y fases del proceso llevado a cabo, asumiendo las decisiones tomadas de forma colectiva.

4.
Asumir con confianza la incertidumbre, las dificultades y los errores que
pueden surgir en sus propios procesos de aprendizaje.

3. Competencia específica 3. Identificar necesidades de las personas a nivel local
y global y proponer soluciones sencillas, innovadoras y sostenibles para
satisfacerlas, con sentido ético y solidario, analizando sus puntos fuertes y
débiles y su posible impacto en el entorno económico.

1.
Identificar en el entorno más próximo las ideas innovadoras que dan
respuesta a necesidades locales y globales, promoviendo el desarrollo sostenible.

2.
Comprobar que las ideas de negocio propuestas responden de forma
innovadora y sostenible a las necesidades detectadas, describiendo sus ventajas e
inconvenientes, y analizar el impacto que pueden generar en el entorno económico.

3.
Aplicar metodologías ágiles que faciliten la superación de retos
económicos planteados y la obtención de soluciones a las necesidades detectadas, con sentido
ético y solidario.

4. Competencia específica 4. Identificar los recursos necesarios en el proceso de
desarrollo de la idea o solución creativa propuesta y las posibles fuentes
financieras necesarias para la obtención de dichos recursos y aplicarlas a su
proyecto emprendedor.

5.
Identificar los recursos materiales, inmateriales y digitales necesarios en
el proceso de ideación creativa, analizando la perspectiva sostenible.

6.
Seleccionar algunas fuentes financieras básicas, valorando el horizonte
temporal y el riesgo que implican en el proyecto.

7.
Argumentar la necesidad del control del presupuesto personal como
herramienta esencial de la viabilidad del proyecto, reflexionando sobre el riesgo del
endeudamiento y sus consecuencias en el proceso de emprendimiento

5. Competencia específica 5. Presentar y exponer ideas y soluciones creativas que
transmitan mensajes convincentes adecuados al contexto y a los objetivos de
cada situación, utilizando estrategias comunicativas eficaces, respetuosas e
inclusivas.

1.
Validar las ideas y soluciones presentadas mediante mensajes
convincentes y adecuados al contexto y objetivos concretos, utilizando estrategias comunicativas
ágiles adaptadas a cada situación comunicativa.

2.
Presentar y exponer, con claridad y coherencia, las ideas y soluciones
creativas, valorando la importancia de mantener una comunicación eficaz y respetuosa a lo largo
de todo el proceso llevado a cabo.

3.
Utilizar correctamente la terminología económica y financiera adaptada
al nivel educativo en actividades orales y escritas del ámbito personal, académico, social o
profesional, en las distintas lenguas del currículo, utilizando un lenguaje no discriminatorio.

6. Competencia específica 6. Analizar aspectos básicos de la economía y las
finanzas, valorando críticamente el problema de la escasez de recursos, la
necesidad de elegir, así como los principales objetivos de la economía actual,
desarrollando ideas que den soluciones eficaces, equitativas y sostenibles.

1.
Identificar el problema económico de la escasez de recursos y la
necesidad de elegir, tomando conciencia de las consecuencias del mismo en la sociedad.

2.
Identificar los efectos del desempleo, la desigualdad de la renta, la
economía sumergida y la inflación en algunos contextos y situaciones reales, describiendo
alguna medida correctora para cada uno de ellos.

3.
Describir las características de la economía colaborativa, circular y
social, valorando el impacto que tienen en diferentes entornos.

4.
Interpretar algunas actividades económicas de la vida cotidiana desde
el punto de vista financiero.

7. Competencia específica 7. Diseñar y analizar de manera cooperativa y ágil
prototipos innovadores y sostenibles, a través de estrategias eficaces de diseño,
validando sus resultados de forma ética, crítica y sostenible.

1.
Diseñar un prototipo final innovador y sostenible, evaluando de manera
crítica y ética su aportación al entorno.

2.
Analizar de manera crítica el proceso de diseño de los prototipos
creados, estableciendo comparaciones entre la efectividad, viabilidad y adecuación lograda en
los procesos y los resultados obtenidos.

3.
Utilizar estrategias eficaces de diseño, seleccionando aquellas que
faciliten la ejecución del prototipo final de manera ágil y cooperativa.
