# CULTURA CLÁSICA

> Fuente: Secundaria.pdf, páginas 1086-1099 (versión en castellano).

CULTURA CLÁSICA

1. Presentación

La presencia de la materia de Cultura Clásica como optativa de oferta obligatoria en tercero de
Educación Secundaria está plenamente justificada por el hecho de constituir uno de los pilares básicos de la
cultura y ciencia europeas modernas.

Al establecer la relación entre el pasado y presente se favorece en el alumnado el desarrollo de una
visión crítica de su entorno desde una perspectiva lingüística, histórica, política, social, cultural, arqueológica
y literaria. Así mismo, se fomenta el estudio de la Cultura Clásica desde la perspectiva del momento histórico
en que se desarrolló sin emitir juicios de valor basados en la situación actual.

No podemos comprender y reflexionar sobre la actualidad sin remontarnos al mundo grecorromano,
base fundamental de numerosos aspectos de nuestra civilización: la lengua, la vida cotidiana, la política, la
ciencia, el calendario y las festividades, la ingeniería, el derecho, la filosofía, entre otros. Su análisis y
comprensión aporta al alumnado la capacidad para valorar y respetar el patrimonio cultural y arqueológico
desde una posición sostenible y comprometida.

El estudio de la materia de Cultura Clásica en la Educación Secundaria Obligatoria ayuda a potenciar
las competencias del alumnado, desde las tres dimensiones que estas incluyen, conceptuales, instrumentales
y actitudinales, pues contribuye a afrontar una serie de desafíos que conectan la antigüedad clásica con
nuestros días. Así pues, este aprendizaje les capacita para comprender los múltiples vínculos que siguen
existiendo entre la cultura grecorromana y nuestra realidad actual. Además, promueve su desarrollo personal
ante el mundo que le rodea, reforzando su habilidad para enfrentarse a la incertidumbre de la sociedad del
siglo XXI.

|  | ayuda a potenciar |
| --- | --- |
| las competencias del alumnado, desde las tres dimensiones que estas incluyen, conceptuales, instrumentales |  |
| y actitudinales, pues contribuye |  |

Igualmente, fomenta todo aquello que requiere una actitud democrática a la hora de resolver
pacíficamente los conflictos y de poner siempre por encima de otras consideraciones el bien común, haciendo
hincapié en la capacidad de negociación y comunicación inherente a toda sociedad democrática y solidaria.

A su vez, la Cultura Clásica impulsa en el alumnado la adquisición de un juicio crítico al situarlo frente
a aspectos del mundo antiguo que la evolución cultural de la humanidad intenta superar, como son la
esclavitud o la condición de la mujer. Este acercamiento crítico incorpora también, por lo tanto, una reflexión
ética que pone de manifiesto la necesidad de combatir desigualdades y discriminaciones, visibilizando el papel
de las mujeres y los referentes femeninos en todos los campos del saber y explicando la condición de la mujer
desde otras perspectivas.

El alumnado también adquiere en el proceso de indagación, tanto individual como en equipo, unas
destrezas básicas en el manejo de las nuevas tecnologías valorando sus riesgos y beneficios, además de
desarrollar sus capacidades de aprender a aprender y distinguir la información primordial de la secundaria.

En la materia de Cultura Clásica se tendrá presente la diversidad del alumnado teniendo en cuenta
sus diferentes ritmos y formas de aprendizaje, propiciando la capacidad de aprender individualmente e
impulsando el trabajo colaborativo. El estudio de la materia promueve el hábito de lectura, así como una
correcta comprensión y expresión oral y escrita, sin olvidar la competencia digital y la comunicación
audiovisual, propios de la sociedad actual. Por otra parte, el currículum de Cultura Clásica contribuye al
desarrollo personal y social del alumnado al reforzar la autoestima, la autonomía, la reflexión y la
responsabilidad.

Se trabajará de manera transversal temas tan importantes como la igualdad de género, incluyendo
en todos los ámbitos sociales, políticos, culturales y de conocimiento la presencia femenina, la educación para
la salud, el consumo responsable y la sostenibilidad al estudiar aspectos de la vida cotidiana del mundo clásico
como, por ejemplo, la alimentación, la mujer, el deporte o la higiene.

La materia de Cultura Clásica mejora el conocimiento y manejo de las lenguas oficiales de la
Comunidad Valenciana y de otras lenguas extranjeras y permite la consolidación del repertorio lingüístico del
alumnado a través de la reflexión sobre el funcionamiento de las lenguas clásicas y su evolución.

El estudio de esta materia despertará en el alumnado la curiosidad por ampliar el conocimiento en
otros ámbitos al percibir la vinculación con otras disciplinas.

Se propone por tanto un enfoque didáctico “activo” para esta materia. El alumnado es el centro del
proceso de enseñanza y aprendizaje, por lo que conviene partir de sus propios intereses para acercar la
materia al contexto actual, basándose en situaciones reales y cotidianas para relacionarlas con las del mundo
antiguo.

La estrategia metodológica se basa en la exploración, búsqueda, descubrimiento e investigación del
propio alumnado, relacionando su presente con el pasado grecorromano por medio de talleres, proyectos de
investigación, visitas, itinerarios y dramatizaciones breves haciendo uso de las posibilidades que nos ofrecen
las nuevas tecnologías.

La figura del profesorado adquiere un papel fundamental como inspirador y mediador de diferentes
situaciones de aprendizaje que implican el desarrollo de las competencias y la atención a los desafíos del
siglo XXI. Eso supone que el profesorado desempeña también un papel activo en el proceso de aprendizaje
del alumnado.

Tras la aproximación al mundo clásico en la etapa de Primaria, la materia de Cultura Clásica en la
Educación Secundaria Obligatoria proporciona una mirada más profunda al mundo grecorromano en
cuestiones culturales, de vida cotidiana, artísticas y científicas.

Todo ello contribuye a que el alumnado tenga una toma de contacto con el mundo clásico que se
podrá ampliar en la materia optativa de Latín de esta misma etapa, o posteriormente en otras etapas y
materias según sus propios intereses y orientación académica.

A continuación, se formulan y se describen cada una de las competencias específicas y se establecen
las conexiones entre ellas, con las competencias específicas de otras materias, con las competencias clave
y con los desafíos del siglo XXI.

|  | Estos saberes constituyen los aprendizajes básicos, actitudes y procedimientos |
| --- | --- |
| imprescindibles que el alumnado debe adquirir, articular y movilizar para asegurar la consecución y desarrollo |  |
| de las competencias específicas. |  |

El primero, Marco geográfico de Grecia y Roma, ubica el origen de la civilización europea actual y
permite tener una perspectiva de su evolución.

El segundo, Historia y evolución sociopolítica, pone el acento en el origen de muchos de los sistemas
políticos actuales y en sus semejanzas y diferencias con la actualidad.

El tercero, Vida cotidiana, integra todos los aspectos de la vida diaria en la época clásica
comparándolos con la actualidad, incidiendo en temas transversales como la situación de mujer, la educación
de la infancia, el trabajo, la alimentación y la higiene.

El cuarto, Mitología y religión, recoge las creencias del mundo antiguo que de una manera u otra han
influido en las manifestaciones artísticas y culturales de toda índole a lo largo de los últimos siglos. Muchos
de estos elementos son ya referentes o modelos en la actualidad cuyo origen es preciso conocer para
entender su significado.

El quinto, Arte y Ciencia, trata sobre los aspectos relacionados con el urbanismo y sus edificios más
representativos. Asimismo, pone el foco en la importancia de los avances científicos del mundo clásico en su
vertiente teórica y práctica como medio para afrontar y resolver los desafíos a los que se enfrenta una
sociedad en desarrollo. También se pone de manifiesto la genialidad del arte griego en todas sus vertientes
y la forma en la que Roma supo adaptarlo a sus necesidades y a su vez crear modelos originales inspirados
en las creaciones helénicas.

El sexto, Lengua y Literatura, incide en la importancia decisiva del latín como lengua materna de las
lenguas oficiales de la Comunidad Valenciana y su estrecha relación con otras lenguas del estado, de la Unión
Europea y del resto del mundo. Su conocimiento es una herramienta fundamental para el completo desarrollo
de la competencia lingüística y mejora de manera clara la plurilingüe por medio del conocimiento etimológico
de las palabras. De la misma manera, la lectura de los clásicos más importantes de esta época es fundamental
por su trascendencia para la historia de la literatura universal y del mundo cultural occidental en general.

Las situaciones de aprendizaje recomendadas para el buen desarrollo competencial de la materia se
entienden como el contexto adecuado que propicia el desarrollo de las distintas competencias. Aunque los
saberes básicos están organizados en distintos bloques, en las situaciones de aprendizaje se trabajan
interrelacionados por medio de tareas significativas, relevantes y, en lo posible, interdisciplinares.

Por último, se establecen los criterios de evaluación que permiten valorar el progreso del alumnado
en el proceso de adquisición y desarrollo de las competencias específicas. Estos criterios se han diseñado
para poner de relieve la conexión de los saberes básicos con sus paralelismos del mundo actual de manera
razonada y crítica. Por medio de estos criterios se busca asegurar que el alumnado haya obtenido la
perspectiva de cómo hemos ido constituyendo nuestra vida cotidiana, nuestra ciudadanía, nuestro acervo
cultural y científico y el fundamento de nuestra comunicación a lo largo de la historia hasta el momento actual.

2. Competencias específicas

2.1. Competencia específica 1

Reconocer y valorar la pervivencia de las características de la vida social griega y romana en el
desarrollo de nuestra actividad cotidiana y en nuestras raíces comunes con otros países de nuestro entorno.

2.1.1. Descripción de la competencia

Con esta competencia específica se pretende que el alumnado identifique y aprecie que nuestra
cultura y nuestro día a día participan de los usos y costumbres de la vida cotidiana en la antigüedad clásica
grecorromana.

El conocimiento de la pervivencia de la vida cotidiana clásica en la sociedad actual implica el
desarrollo de un análisis crítico del presente y del pasado que permite al alumnado reconocer aquella huella
que sigue vigente y beneficia a nuestra sociedad, y rechazar las prácticas de discriminación que ya no tienen
cabida en nuestros días. No obstante, es importante no juzgar con los ojos del presente algunos aspectos del
pasado que hoy en día son considerados poco respetuosos y superados por la evolución de la civilización y
los derechos humanos.

|  | Con esta competencia se descubre la importancia de la pervivencia cultural (situación de la mujer, |
| --- | --- |
| clases sociales, hábitos de higiene, alimentación, deporte…) como elemento de unión y cohesión entre |  |
| pueblos de distinto origen, promocionando en el alumnado la capacidad de valorar la diversidad cultural como |  |
| una riqueza legada por nuestro pasado clásico común y la necesidad de promover la inclusión frente a las |  |
| situaciones de discriminación anteriores. |  |

Asimismo, favorece el desarrollo de su espíritu crítico y ético, el respeto a las diferencias culturales y
la convivencia ciudadana, además de promover unos hábitos saludables en higiene, deporte y alimentación
que tienen ya su origen en el mundo clásico.

2.2. Competencia específica 2

Relacionar los acontecimientos más relevantes de la historia griega y romana con la configuración
sociopolítica de la Europa del siglo XXI y del mundo actual a partir de fuentes históricas, teniendo en cuenta
los límites geográficos y las características específicas del mundo clásico.

2.2.1. Descripción de la competencia

Gracias a la adquisición y desarrollo de esta competencia, el alumnado será capaz de entender la
influencia que la historia grecorromana ha ejercido en la Europa actual, descubriendo que muchos de los
diferentes modelos de organización política y territorial tienen su origen en el pasado. Para ello, se utilizarán
instrumentos variados (mapas geopolíticos, textos, gráficos) en diferentes formatos que permitan la
descripción, el análisis y comparación de la situación anterior y de la actual.

Por otra parte, se estudian los aspectos sociales y económicos del pasado grecorromano poniéndolos
en relación con la situación actual y los desafíos del siglo XXI, con especial hincapié en temas como la
igualdad entre hombres y mujeres, el desarrollo sostenible, la situación de la emigración y las situaciones
laborales justas.

Esta competencia trabaja de manera gradual los cambios sociopolíticos a través de la utilización
crítica y comparada de información multimodal, líneas de tiempo, mapas conceptuales o debates para hallar
similitudes y diferencias con la realidad sociopolítica contemporánea, incidiendo en aspectos relacionados
con el reto de la igualdad y la inclusión.

Todo ello se relaciona con los espacios geográficos en los que se produjo el desarrollo de las culturas
y sociedades griega y romana, para así comprender de una manera coherente la continuidad histórica y
cultural de estos pueblos en nuestros días y en nuestro entorno.

Al mismo tiempo, el alumnado conocerá los elementos definitorios del medio mediterráneo como
elemento unificador y tomará conciencia de la importancia del Mare Mediterraneum o Nostrum como eje
central de las conexiones políticas, culturales y económicas y del valor de las comunicaciones para el pleno
desarrollo de las sociedades de la zona.

Su estudio potencia el respeto, la necesidad de una convivencia pacífica y la cooperación en una
sociedad cambiante y multicultural, además de fomentar el espíritu de ciudadanía europea, desarrollar la
capacidad de diálogo y la confianza en el conocimiento como punto de partida para la resolución pacífica de
conflictos y despertar el interés por conocer distintas culturas.

2.3.  Competencia específica 3

Identificar los rasgos y valorar la importancia y la huella de la lengua griega y latina en los idiomas
que el alumnado utiliza y estudia, a través del aprendizaje del alfabeto, la etimología, los helenismos y
latinismos, la composición y derivación.

2.3.1. Descripción de la competencia

Con esta competencia el alumnado reconoce el origen de los idiomas que usa y estudia, aprende a
identificar y emplear los helenismos y latinismos, amplía su vocabulario y mejora su ortografía por medio del
análisis y uso de las raíces grecolatinas que conforman las palabras, constatando así los nexos lingüísticos
de unión con los países europeos y favoreciendo su conciencia de ciudadanía europea. A su vez, puede
descubrir que alguno de los idiomas que estudia no tiene su origen en las lenguas romances, pero tienen una
importante influencia de las mismas.

Con ello se promueve una reflexión sobre la utilidad del latín y el griego para adquirir lenguas
extranjeras, además de mejorar la lectura comprensiva, la expresión oral y escrita al ampliar su vocabulario
mediante la deducción los significados de términos técnicos o científicos gracias al conocimiento de su raíz
clásica.

Esta competencia se trabaja mediante una visión diacrónica centrada en la evolución de las lenguas
clásicas y actuales comparándolas por familias léxicas o por agrupaciones temáticas, lo que favorece el
desarrollo de habilidades lingüísticas a través de la inferencia del significado de las palabras de léxico común
o científico.

De esta manera el alumnado comprueba que la mayoría del acervo lingüístico de los idiomas que usa
y estudia tiene su origen en las lenguas que hablaron los antiguos griegos y romanos, que son una seña de
identidad del pasado que le ayuda a conocer y comprender su presente, valorando la diversidad lingüística,
dialectal y cultural inherente a los retos del siglo XXI.

2.4. Competencia específica 4

Localizar y relacionar la presencia del mundo clásico en el patrimonio histórico de Europa, de la
Península Ibérica y de la Comunidad Valenciana y contribuir a su conservación y respeto.

2.4.1. Descripción de la competencia

Mediante esta competencia el alumnado aprende a reconocer la presencia grecorromana e identificar
el patrimonio clásico de la Comunidad Valenciana y de la Península Ibérica como parte de su historia.

Es importante experimentar el paso de lo estudiado en las aulas a la realidad: a los centros de
interpretación, yacimientos y espacios musealizados, que muestran realmente cómo son y fueron las
diferentes manifestaciones culturales del mundo griego y romano.

La localización geográfica de estos espacios en la geografía de la Comunidad Valenciana y del
territorio peninsular permite analizar los diferentes niveles de influencia que la cultura grecorromana ha tenido
en nuestro país.

A su vez, ello contribuye a despertar la preocupación por la necesidad de conservación, explotación
y exposición de los mismos y de la importancia de las herramientas digitales (entornos virtuales, en 3D,
maquetación y diseño gráfico y de estructuras) para favorecer la mejor comprensión del mundo clásico.

El estudio y el contacto directo con esos elementos patrimoniales en museos, yacimientos
arqueológicos o excavaciones constituyen un ejercicio de análisis y reflexión para entender su entorno
histórico y patrimonial de una manera más crítica y precisa.

Con esta competencia el alumnado adquiere el necesario respeto a las manifestaciones de nuestro
pasado para poder entender nuestro presente y tomarlo como referencia para soluciones futuras.

2.5.  Competencia específica 5

Desde una perspectiva inclusiva, investigar, identificar y explicar los referentes culturales, tanto
masculinos como femeninos, de la época clásica en el desarrollo de la ciencia y en las diversas
manifestaciones artísticas actuales.

2.5.1. Descripción de la competencia

Con esta competencia el alumnado es capaz de redescubrir y argumentar la relación entre las
producciones artísticas actuales de diferente tipología (literatura, escultura, arquitectura, pintura, cine,
publicidad, música, …) y las fuentes clásicas que las inspiran. De esta manera, el conocimiento adquirido en

la materia de Cultura Clásica impulsa su desarrollo y habilidades personales y pone de manifiesto la
importancia del conocimiento del pasado para la mejor comprensión del mundo actual.

Conviene subrayar de manera especial la importancia que la mitología grecorromana tiene de manera
transversal en las manifestaciones culturales y científicas contemporáneas (astronomía, medicina, música,
química, botánica, psiquiatría, física) y en la vida cotidiana (calendario, lenguaje, literatura, publicidad)

Con esta competencia se potencia en el alumnado el aprendizaje holístico e interdisciplinar, pues no
sólo se trabajan los referentes de la cultura clásica en las manifestaciones científicas y artísticas actuales,
sino que aprende y es capaz de integrar diferentes conocimientos para obtener un saber que le ayuda a
solucionar problemas y a obtener respuestas, proporcionando herramientas de reflexión e inferencia. De este
modo, se fomenta en el alumnado el pensamiento crítico, reflexivo y creativo que le permite emitir juicios
elaborados y argumentados. Al mismo tiempo, se potencia el uso ético y responsable de las nuevas
tecnologías y la cultura digital.

Esta competencia también permite mayor libertad en la expresión e iniciativa personal del alumnado
que, por medio de esa búsqueda e investigación en diferentes campos relacionados con sus propios intereses,
gustos o aficiones, puede ir encontrando nexos de unión con el mundo escolar y reforzar de esa manera el
lazo que permita concebir la cultura clásica como un elemento importante en el desarrollo de su evolución
personal.

3. Conexiones de las competencias específicas entre sí, con las de otras materias y con las
competencias clave

3.1. Relaciones o conexiones entre las competencias específicas de la materia

Las competencias específicas de la materia de Cultura Clásica están totalmente vinculadas entre sí,
ya que todas ellas proporcionan al alumnado capacidades, conocimientos y herramientas para valorar e
interpretar la herencia que la lengua y cultura clásicas han dejado en la Europa y en el mundo del siglo XXI
en el sistema sociopolítico, en las lenguas que se hablan actualmente, en las producciones artísticas, en la
conformación geopolítica, en los referentes culturales actuales y en el patrimonio histórico.

3.2. Relaciones o conexiones con las competencias específicas de las otras materias de la
etapa

La CE 3 de Cultura Clásica conecta directamente con las materias del ámbito lingüístico como son
las propias lenguas cooficiales de la Comunidad Valenciana (castellano y valenciano) y sus literaturas, las
lenguas extranjeras (inglés, francés, alemán o italiano), puesto que el léxico o las estructuras gramaticales
tienen su origen directamente en el latín y el griego. Además, al ser la lengua castellana o valenciana el
vehículo de aprendizaje, transmisor de cultura y conocimientos, también se trabajan la expresión y
comprensión oral y escrita, lectura e interacción por lo que conecta con el resto de competencias específicas
de estas áreas lingüísticas.

También con las materias del ámbito humanístico (Geografía e Historia o Valores Éticos), pues en
todas ellas se reflexiona sobre el devenir histórico y político. Su vinculación se encuentra en los aspectos
sociales y políticos de la sociedad grecorromana que han pervivido hasta nuestros días, además de los
numerosos restos patrimoniales. En concreto, las competencias CE 1, CE 2 y CE 4 de la materia de Cultura
Clásica están conectadas con la mayoría de las competencias específicas del área de Geografía e Historia y
de Valores Éticos por su carácter transversal y complementario.

A su vez, con el ámbito científico, pues su léxico presenta a menudo un origen griego y romano y el
pensamiento científico tiene sus raíces en Grecia y Roma.

Y con el ámbito de la Educación Plástica, Visual y Audiovisual, puesto que numerosas producciones
artísticas actuales se inspiran en el mundo clásico. El alumnado de Cultura Clásica puede elaborar propuestas
creativas utilizando los formatos, materiales y discursos propios de la contemporaneidad artística e incluso
crear producciones artísticas colectivas, así como crear escenas de teatro basadas en los clásicos, construir
maquetas de edificios y de ciudades, y realizar performances y todo tipo de creaciones audiovisuales.

De la misma manera conecta con la materia de Tecnología y digitalización puesto que un alumno del
siglo XXI debe hacer uso responsable y ético de las nuevas tecnologías, saber seleccionar las fuentes fiables
y poder generar contenido multimodal.

3.3. Relaciones o conexiones con las competencias clave

Competencias específicas de la materia que mantienen relaciones especialmente significativas y
relevantes con las competencias clave:

En primer lugar, la CE1 se relaciona con las competencias clave CCL, CD, CPSAA, CE y CCEC, en
la medida en que reconocer y valorar la pervivencia de la vida social griega y romana en el desarrollo de
nuestra actividad cotidiana estimula la curiosidad, la comunicación, el trabajo en equipo, la búsqueda y
selección de las fuentes fiables y de las estrategias de aprendizaje del alumnado, haciéndole consciente de
esta herencia cultural tan presente en muchas facetas de nuestra vida y ayudándole así a entender mejor el
mundo en el que vive y su relación con el pasado.

En segundo lugar, la CE2 está conectada con las competencias clave CCL, CMCT, CD, CPSAA, CC
y CE debido a  que relacionar los acontecimientos más relevantes de la historia griega y romana con la
configuración sociopolítica de la Europa del siglo XXI impulsa no sólo la adquisición de un vocabulario
específico, sino también de una ciudadanía plena y consciente, así como la capacidad de percibir las
identidades culturales y nacionales como un proceso dinámico y cambiante en un contexto de globalización.

En tercer lugar, la CE3 se vincula con las competencias clave CCL, CP, CMCT, CD, CPSAA, CC y
CE a través de una mejora de la ortografía, el vocabulario y la semántica de las diferentes lenguas que estudia
el alumnado en esta etapa gracias a su contacto con las lenguas clásicas. Además, impulsa el respeto hacia
otras lenguas herederas de una misma fuente. Por otra parte, el conocimiento de los étimos griegos y latinos
es esencial para la correcta comprensión de los saberes matemáticos, científicos y tecnológicos.

En cuarto lugar, la CE4 se relaciona con las competencias clave CD, CPSAA, CC, CE y CCEC en la
medida en que el descubrimiento del patrimonio clásico a lo largo de la historia permite identificar y poner en
valor restos arqueológicos, otros tipos de monumentos y vestigios culturales a través del uso de herramientas
digitales que ayudan a descubrir la identidad cultural que ha aportado el mundo grecorromano.

En quinto lugar, la CE5 se asocia a las competencias clave CD, CPSAA, CC, CE y CCEC, puesto que
la identificación de los referentes culturales de la época clásica en el desarrollo de la ciencia y en las diversas
manifestaciones artísticas actuales proporciona al alumnado los conocimientos y las destrezas
necesarias  para relacionar los referentes clásicos con los contemporáneos, potenciando su capacidad para
establecer vínculos en nuevas manifestaciones que requieren una reflexión crítica acerca de los propios
procesos de aprendizaje. A su vez, impulsa el respeto y empatía hacia otras manifestaciones y herencias
culturales.

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

CCL: competencia en comunicación lingüística

CP: competencia plurilingüe

CMCT: competencia matemática, ciencia y tecnológica

CD: competencia digital

CPSAA: competencia personal, social y de aprender a aprender

CC: competencia ciudadana

CE: competencia emprendedora

CCEC: competencia en conciencia y expresión cultural

El cuadro adjunto muestra la existencia de una relación especialmente significativa y relevante entre
las cinco competencias específicas de la materia de Cultura Clásica y algunas competencias clave incluidas
en el perfil de salida del alumnado al finalizar la educación básica. En todos los casos, esta relación opera en
las dos direcciones. Por una parte, la adquisición y desarrollo de las competencias específicas señaladas
contribuye a la incorporación de las competencias clave con las que aparecen estrechamente vinculadas; por
otra parte, estas competencias clave juegan un papel importante en la adquisición y desarrollo de las
competencias específicas señaladas.

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 | X |  |  | X | X |  | X | X |
| CE2 | X |  | X | X | X | X | X |  |
| CE3 | X | X | X | X | X | X | X |  |
| CE4 |  |  |  | X | X | X | X | X |
| CE5 |  |  |  | X | X | X | X | X |

4.  Saberes básicos

4.1. Introducción

De acuerdo con la lógica inherente a un enfoque competencial, los saberes básicos de la materia de
Cultura Clásica en tercero de Educación Secundaria identifican los contenidos que el alumnado debe
aprender, articular y movilizar para desplegar las actuaciones establecidas en las competencias específicas.

Todos los bloques ofrecen la posibilidad de establecer una relación entre el pasado grecolatino y el
mundo actual, lo que permite tratar los aspectos más importantes relacionados con la herencia clásica, los
desafíos del siglo XXI y los objetivos de desarrollo sostenible desde una perspectiva diacrónica.

El criterio disciplinar utilizado para la organización y distribución de los bloques atiende a la división
temática de la materia, asumiendo que es necesario un marco de espacio y tiempo, geográfico e histórico,
desde el cual se desarrollen de manera conjunta los otros bloques: vida cotidiana, mitología y religión, arte y
ciencia y lengua y literatura. El orden de los bloques no tiene un carácter jerárquico.

El profesorado adaptará al perfil de su alumnado estos bloques de contenido.

4.2. Bloque 1. MARCO GEOGRÁFICO DE GRECIA Y ROMA.

|  | CE 2 y CE 4 |  |
| --- | --- | --- |
| • Marcos geográficos de las civilizaciones griega y romana en el momento de su apogeo cultural: principales ciudades y regiones y accidentes geográficos más significativos. |  |  |
| • El Mare Nostrum como punto de unión entre los pueblos. |  |  |

•
El mapa en diferentes formatos, analógico o digital, como instrumento de conocimiento histórico.

•
El cosmopolitismo en la antigüedad y la globalización actual.

•
Actitud positiva de superación en el proceso de aprendizaje.

•
Conciencia de ciudadanía global del alumnado.

•
Fuentes escritas históricas y literarias sobre la geografía del mundo antiguo.

4.3. Bloque 2. HISTORIA Y EVOLUCIÓN SOCIOPOLÍTICA

|  | HISTORIA. CE 2 y CE 3 |  |
| --- | --- | --- |
| • Grecia: etapas y hechos históricos más importantes de la época clásica al helenismo. Mujeres y hombres que hicieron historia |  |  |
| • Roma: etapas y hechos históricos más importantes de la República al Imperio. La romanización. Mujeres y hombres que hicieron historia. |  |  |
| • Estrategias para la búsqueda sencilla, selección y manejo de fuentes históricas y literarias tanto en bibliotecas como en internet. |  |  |

|  | EVOLUCIÓN SOCIOPOLÍTICA. CE 2 y CE 3 |  |
| --- | --- | --- |
| • Principales formas de gobierno y organización social. |  |  |
| • Aportación de Grecia y Roma en nuestro sistema político democrático y en las instituciones actuales. |  |  |
| • Importancia de la argumentación o debate razonado con apoyo de información veraz y contrastada que potencian la convivencia democrática, la resolución pacífica de conflictos y el espíritu crítico. |  |  |

4.4. Bloque 3. VIDA COTIDIANA

|  | CE 1 y CE 3 |  |
| --- | --- | --- |
| • La familia: roles de sus miembros; situación de la mujer, sin olvidar aquellas mujeres que han transgredido los convencionalismos y los roles establecidos. |  |  |
| • La educación de niños y niñas. Los juegos. |  |  |
| • Indumentaria e higiene. |  |  |
| • La alimentación en la antigüedad. |  |  |
| • El calendario y la jornada diaria. |  |  |
| • Analogías y diferencias entre aspectos de la vida cotidiana grecorromana y los actuales. |  |  |
| • Importancia de la contextualización de algunos aspectos de la vida cotidiana que formaban parte de la civilización griega y romana |  |  |
| • Actividades de creación propia, individuales o en grupo, sobre el legado de la vida cotidiana, haciendo uso de fuentes de información fiables y de las nuevas tecnologías. |  |  |

4.5. Bloque 4. MITOLOGÍA Y RELIGIÓN

|  | MITOLOGÍA. CE 1, CE 3 y CE 5 |  |
| --- | --- | --- |
| • Divinidades del panteón griego y romana. |  |  |
| • Principales héroes y heroínas en sus mitos y leyendas y sus características. |  |  |
| • Influencia de la mitología clásica en otras mitologías y en manifestaciones artísticas y literarias a lo largo de la historia. |  |  |
| • Uso de procedimientos de búsqueda, selección y análisis de la información, obtenida tanto de fuentes tradicionales griegas y romanas como actuales. |  |  |

|  | RELIGIÓN. CE 1, CE 3 y CE 5 |  |
| --- | --- | --- |
| • Principales características de la religión grecolatina. |  |  |
| • Manifestaciones religiosas de la Grecia Clásica: juegos olímpicos. |  |  |
| • Huellas de las festividades religiosas clásicas en la actualidad. |  |  |
| • Actitud de respeto hacia diferentes creencias religiosas. |  |  |

4.6. Bloque 5.  ARTE Y CIENCIA

|  | ARTE. CE 3, CE 4 y CE 5 |  |
| --- | --- | --- |
| • Museos, espacios arqueológicos o recreaciones vinculadas con el mundo clásico y su aportación para la formación personal y ciudadana. |  |  |
| • Principales producciones artísticas grecorromanas de autoría tanto masculina como femenina: escultura, pintura, cerámica y mosaico. |  |  |
| • Influencia de la cultura griega en la civilización romana. |  |  |

CIÈNCIA. CE 3, CE 4 i CE 5

●
La planificació urbana a Grècia i Roma: tipologia dels edificis i infraestructures.

●
Llegat de les obres públiques i l'urbanisme a les ciutats actuals.

●
Descobriments i aportacions científiques, tant d’homes com de dones, del món antic.

●
Aportació de la civilització grega en el pas del mite al logos.

●
Respecte i curiositat (lliure de prejudicis) pels avanços científics com a mitjà per a millorar el
benestar i la sostenibilitat.

4.7. Bloque 6. LENGUA Y LITERATURA

|  | LENGUA. CE 3 |  |
| --- | --- | --- |
| • Alfabetos griego y latino. |  |  |
| • Lenguas romances y no romances. |  |  |
| • Introducción al significado etimológico de las palabras. |  |  |
| • Principales helenismos y latinismos en el lenguaje común y el científico-técnico. |  |  |
| • Interés por el conocimiento de la etimología de las palabras como instrumento para una buena comunicación y expresión. |  |  |
| • Importancia del latín y del griego en la evolución de las lenguas que forman parte del repertorio lingüístico del alumnado. |  |  |
| • Respeto por las diferentes lenguas del mundo y por las diferencias culturales de sus hablantes. |  |  |
| • Estrategias para la formación de nuevas palabras o para la deducción de su significado a través de los componentes. |  |  |

LITERATURA. CE 3 I CE 5

●
 Principals gèneres literaris: Èpica, lírica, teatre, epistolografia i oratòria

●
Autors i autores i les seues obres més representatives.

●
Interés per la lectura de textos literaris com a font de coneixement del món clàssic.

●
Lectura de textos literaris seleccionats, també d’autoria femenina, relacionats amb el món antic.

●
 Reinterpretació i creació pròpia dels textos en diferents formats.

●
Semblances i diferències entre els principals gèneres literaris del món clàssic i els de la literatura
actual.

5.  Situaciones de aprendizaje para el conjunto de las competencias de la materia.

Las situaciones de aprendizaje de Cultura Clásica ponen en relación las competencias específicas
de la asignatura con los desafíos del s. XXI y las competencias clave, vinculando la realidad cotidiana del
alumnado con los referentes clásicos.

Las experiencias de aprendizaje deben potenciar la posibilidad de disfrutar aprendiendo; para ello, se
presentarán actividades, talleres, juegos y retos didácticos con los que el alumnado pueda encontrar la
motivación para continuar en su proceso de aprendizaje al hacerle partícipe del mismo.

El acercamiento didáctico y como experiencia personal a estos espacios se realizará en colaboración
con las instituciones responsables de la conservación y defensa del patrimonio. Con ello se pretende dar
importancia a la actividad de las diferentes administraciones y visibilizar para el alumnado el trabajo de todas
las personas e instituciones en la conservación y acceso a estos espacios.

El punto de partida debe ser la propuesta de actividades que surjan de la cotidianeidad del alumnado
y que estén relacionadas con su entorno más cercano. Posteriormente se podrán plantear contextos más

lejanos, de manera que el discente pueda trasladar sus conocimientos a otras situaciones. A partir de ahí, el
alumnado, desarrollando su capacidad de reflexión sobre los conocimientos adquiridos, será capaz de
proponer actividades similares.

Para el estudio del bloque de la lengua griega y latina se potenciará el  método inductivo-contextual,
en el que el alumnado descubra el significado de palabras, étimos, latinismos o expresiones gracias al uso de
ilustraciones, de familias léxicas, de juegos y del contexto.

En la didáctica de la materia de Cultura Clásica se emplearán, junto a las estrategias comunicativas,
el análisis de las fuentes de información en diferentes formatos (escritas, visuales o audiovisuales), y la
experiencia vivencial de manera individual o en grupo, mediante talleres didácticos, creando conciencia de la
importancia del conocimiento en su desarrollo personal.

Se fomentará el uso de metodologías que se adapten al ritmo de aprendizaje propio de cada discente,
para así incentivar el esfuerzo, la actitud investigadora, la capacidad de argumentación y el trabajo en equipo.

Se intentará promover el hábito de la lectura y escritura a través de la selección de textos adaptados
a la edad sobre temas relacionados con la Cultura Clásica que pueden ser de autores clásicos grecorromanos
o actuales (como novela histórica, cómics, artículos de opinión, entre otros), para que el alumnado adquiera
las destrezas necesarias para una buena comprensión y expresión.

Los objetivos de desarrollo sostenible deben estar reflejados de manera transversal en todos los
contenidos de la materia y etapa, de manera que despierten en el alumnado un fuerte compromiso ciudadano
en el ámbito local y global, como por ejemplo al presentar los fundamentos del sistema democrático y de la
noción de libertad del individuo en el mundo grecorromano.

El alumnado como protagonista de su propio aprendizaje establece conclusiones y relaciones entre
pasado y presente, de manera que puede desarrollar opiniones personales respetuosas sobre el modo de
vida en otros tiempos y culturas.

Por otra parte, la rápida evolución en la sociedad actual genera la necesidad de educar en
competencias para afrontar el futuro y saber gestionar la incertidumbre que conlleva todo cambio; de ahí que
los principios de movimiento, complejidad y adaptación se revelen como nuevos motores que tratar en
nuestras aulas y en nuestra materia, tomando como ejemplo los retos a los que el mundo griego y romano
tuvo que enfrentarse a lo largo de su devenir histórico.

Se debe tener presente en todo momento la conexión directa de la Cultura Clásica con otras materias
como, por ejemplo, las Ciencias Sociales y las lingüísticas para trabajar interdisciplinariamente los contenidos
y competencias susceptibles de ser conectados.

6.   Criterios de evaluación

6.1 Competencia específica 1. Criterios de evaluación.

CE 1. Reconocer y valorar la pervivencia de las características de la vida social griega y romana en
el desarrollo de nuestra actividad cotidiana y en nuestras raíces comunes con otros países de nuestro entorno.

•
Identificar y explicar las semejanzas y diferencias entre la actualidad y la vida cotidiana griega y
romana en algunos temas cercanos y de especial relevancia para el alumnado, contrastándolos con
los que son saludables y sostenibles en su entorno.

•
Reconocer las desigualdades sociales en la antigüedad, dando visibilidad a aquellos colectivos que
han sido silenciados, con especial cuidado a la presencia femenina.
•
Elaborar y presentar contenidos propios en forma de esquemas, redacciones, tablas comparativas u
otro tipo de formato mediante estrategias de búsqueda, análisis crítico, selección y tratamiento de
información de fuentes primarias y secundarias.
•
Mostrar actitudes no discriminatorias ante la diversidad social y multicultural para promover la
igualdad.
•
Formular opiniones y valoraciones respetuosas y argumentadas hacia otras culturas y formas de vida
tomando como referencia el respeto a los derechos humanos, interviniendo en favor de la integración,
la igualdad de género, la colaboración social y la cohesión en el entorno.

| • Elaborar y presentar contenidos propios en forma de esquemas, redacciones, tablas comparativas u |  |
| --- | --- |
|  | otro tipo de formato mediante estrategias de búsqueda, análisis crítico, selección y tratamiento de |
|  | información de fuentes primarias y secundarias. |

| • Formular opiniones y valoraciones respetuosas y argumentadas hacia otras culturas y formas de vida |  |
| --- | --- |
|  | tomando como referencia el respeto a los derechos humanos, interviniendo en favor de la integración, |
|  | la igualdad de género, la colaboración social y la cohesión en el entorno. |

6.2 Competencia específica 2. Criterios de evaluación.

CE 2. Relacionar los acontecimientos más relevantes de la historia griega y romana con la configuración
sociopolítica de la Europa del siglo XXI y del mundo actual a partir de fuentes históricas, teniendo en cuenta
los límites geográficos y las características específicas del mundo clásico.

•
Explicar la relación de los elementos más significativos de la historia de Grecia y Roma con aspectos
destacados de la situación sociopolítica europea actual.
•
Establecer las semejanzas y diferencias del marco geográfico y político del mundo clásico con la
situación europea actual utilizando tanto fuentes clásicas como actuales.
•
Investigar y aportar argumentos sobre la importancia socioeconómica y cultural del medio marítimo
en el desarrollo de las civilizaciones griega y romana.
•
Expresar opiniones fundamentadas sobre la importancia de la multiculturalidad para el desarrollo de
la sociedad y llegar a conclusiones a partir del debate y puesta en común.
•
Valorar el proceso de creación de formas de gobierno que llevaron a cabo Grecia y Roma y
compararlo con su evolución en la actualidad.
•
Mostrar una disposición favorable a participar y comprometerse con las instituciones democráticas
respetando los diferentes puntos de vista y haciendo hincapié en la igualdad real, especialmente de
las mujeres.

6.3 Competencia específica 3. Criterios de evaluación.

CE 3. Identificar los rasgos y valorar la importancia y la huella de la lengua griega y latina en los idiomas que
el alumnado utiliza y estudia, a través del aprendizaje del alfabeto, la etimología, los helenismos y latinismos,
la composición y derivación.

•
Identificar la relevancia de los alfabetos griego y latino en las manifestaciones culturales y lingüísticas
del mundo occidental.
•
Descubrir la pervivencia de los étimos grecolatinos en las lenguas romances peninsulares, europeas
y otras lenguas que estudie el alumnado.
•
Buscar y clasificar familias léxicas de palabras específicas a partir de su raíz griega o latina en su
lengua materna.
•
Hacer uso adecuado en su contexto de los helenismos y latinismos más comunes.
•
Deducir el significado de algunos tecnicismos aplicando los principales fundamentos de la derivación
y composición con prefijos griegos y latinos.
•
Mostrar interés por el conocimiento de otras lenguas extranjeras como medio de enriquecimiento
personal y profesional.

6.4 Competencia específica 4. Criterios de evaluación.

CE 4. Localizar y relacionar la presencia del mundo clásico en el patrimonio histórico de Europa, de la
Península Ibérica y de la Comunidad Valenciana y contribuir a su conservación y respeto.

•
Localizar la presencia de referentes patrimoniales arqueológicos, arquitectónicos y artísticos griegos
y romanos en su entorno más cercano y en la Península Ibérica.
•
Identificar, analizar y valorar las contribuciones científicas más importantes del mundo clásico.
•
Realizar actividades que pongan de manifiesto la necesidad de la conservación y conocimiento de
las manifestaciones culturales y los valores cívicos de nuestro pasado.
•
Contribuir al respeto por las expresiones culturales y los valores cívicos de nuestro pasado como un
elemento significativo de nuestra identidad.
•
Ilustrar con ejemplos de la cultura clásica o con clara influencia de esta la importancia y el valor del
conocimiento científico y las manifestaciones artísticas como medio de evolución personal, social y
cultural

6.5 Competencia específica 5. Criterios de evaluación.

CE 5. Desde una perspectiva inclusiva, investigar, identificar y explicar los referentes culturales, tanto
masculinos como femeninos, de la época clásica en el desarrollo de la ciencia y en las diversas
manifestaciones artísticas actuales.

•
Reconocer y analizar la presencia de los referentes clásicos estudiados en el aula (arquitectónicos,
literarios, escultóricos) en las producciones artísticas más significativas de diferentes momentos de
la historia.
•
Investigar y localizar nuevas manifestaciones de los referentes clásicos en ámbitos cercanos a los
intereses del alumnado como publicidad, juegos de internet, películas, música y cómics.
•
Identificar los referentes del mundo grecolatino que funcionan como modelos de personajes,
situaciones, actividades o comportamientos en el mundo actual.
•
Crear y editar producciones propias (presentaciones, vídeos, relatos, dramatizaciones, juegos) que
tengan como eje central algunos de los referentes clásicos más relevantes de la mitología en
diferentes manifestaciones artísticas.
•
Argumentar con ejemplos la importancia de la tradición clásica en las manifestaciones culturales
posteriores.
•
Investigar la pervivencia de la ciencia en la sociedad actual.
