# BIOLOGÍA Y GEOLOGÍA

> Fuente: Secundaria.pdf, páginas 635-667 (versión en castellano).

BIOLOGÍA Y GEOLOGÍA

1. Presentación

Las materias de Biología y Geología de la educación secundaria obligatoria buscan contribuir a los
conocimientos necesarios para comprender procesos tan significativos en la actualidad como el cambio
climático o las distintas crisis ambientales, así como sus consecuencias para la población y el compromiso
con los Objetivos de Desarrollo Sostenible de la Agenda 2030 de Naciones Unidas.

Por otro lado, aportan explicaciones que contribuyen al conocimiento del propio cuerpo y sus cambios
a lo largo del desarrollo, tan significativos en esta etapa madurativa en que se encuentra el alumnado,
avanzando en la asunción de la importancia de los hábitos saludables para la mejora en el rendimiento del
organismo y la prevención de enfermedades.

En lo que respecta al desarrollo de las competencias clave, dado que el trabajo científico es un
proceso colaborativo, la materia contribuye a fomentar la tolerancia, solidaridad y cooperación. Por otro lado,
como requiere de la comunicación de resultados, y en esta comunicación se emplean diferentes herramientas
digitales, también se contribuye a la mejora de las competencias lingüísticas y digitales. Con este
planteamiento, la propuesta de saberes básicos que se plantea para promover la adquisición y el desarrollo
de las once competencias específicas se estructura en cinco bloques que suponen, por un lado, una
continuación de aquéllos que se trataron en el área de Conocimiento del Medio Natural y Social en la
educación primaria, como la metodología de la ciencia, el cuerpo humano y los hábitos saludables o la
sostenibilidad; y por otro, la incorporación de nuevos saberes que permitirán profundizar en el conocimiento
de determinados aspectos más específicos, como el estudio de la tierra y de los seres vivos. A ello habrá que
añadir otros bloques de contenidos, como la evolución o la genética, que se tratarán en 4ª curso de la
educación secundaria obligatoria, en el que la materia de Biología y Geología es optativa y, por tanto, no será
cursada por todo el alumnado.

A continuación, se describen los cinco bloques de saberes básicos que se propone trabajar a lo largo
de la ESO:

• Bloque 1: Metodología de la ciencia. Pretende aproximar al alumnado al pensamiento y el trabajo
científico, incluyendo las herramientas de trabajo que se utilizan, tanto en el laboratorio como en el campo, y
las particularidades de la comunicación de resultados y las discusiones que se producen a raíz de ellas.

• Bloque 2: Cuerpo humano y hábitos saludables. Da continuidad a los saberes trabajados durante
la etapa de educación primaria, profundizando en el conocimiento del cuerpo humano y su funcionamiento y
aportando explicaciones a los cambios que sufre el cuerpo humano a lo largo de sus diferentes etapas,
especialmente significativos durante la adolescencia. Incluye, además, una actitud de respeto en cuanto a las
opciones de manifestaciones relacionadas con la sexualidad y una actitud de prevención frente a posibles
enfermedades de transmisión sexual asociada al conocimiento de los métodos relacionados con la misma.

• Bloque 3: Los seres vivos. Aporta una visión de la biodiversidad y la importancia de su
mantenimiento, las distintas formas en que se manifiesta la vida y las características básicas de los cinco
reinos de seres vivos. Dada la gran cantidad de formas de vida y la imposibilidad de abordarlas todas en este
nivel, no parece necesario detallar los grupos menores, evitando asimismo la utilización de especies tipo que
pueden dar una impresión equivocada de la biodiversidad y conducen a una concepción excesivamente
sesgada y simple de la misma.

• Bloque 4: La Tierra. Sitúa nuestro planeta en el Sistema Solar y el Universo y aproxima al
alumnado a la comprensión de la dinámica que experimenta, manifestada mediante fenómenos de carácter
interno o externo y más o menos catastrófico o, por el contrario, inapreciables a la escala humana de tiempo.
Todo ello facilita además la percepción de las distintas escalas, tanto temporales como espaciales, que
facilitan el descubrimiento de las distintas concepciones espacio-temporales con las que trabaja la ciencia.

• Bloque 5: Sostenibilidad. Se concibe como de carácter global e interdisciplinar, por lo que se
entiende que debería trabajarse en todas las materias de la etapa. La aportación concreta de la Biología y
Geología a dicho bloque incluirá la comprensión de la Tierra como un sistema integral en el que nuestra
especie ha generado una interacción global que está afectando a sus procesos, generando unas
consecuencias que pueden resultar catastróficas si no se toman medidas con carácter urgente para paliarlas.
El cambio climático, el agotamiento de recursos, la contaminación, y otros procesos similares se relacionan
de forma muy estrecha con los saberes que se imparten en estas materias, si bien, como hemos indicado, su
prevención y consecuencias asociadas implican a la práctica totalidad de las áreas y materias del currículo.

Los saberes incluidos en estos bloques deben trabajarse de manera competencial para que su
adquisición vaya siempre ligada al desarrollo de las competencias específicas de la materia que, a su vez,
contribuye al perfeccionamiento de las competencias clave y de las competencias específicas de otras
materias de la etapa. En otras palabras, los saberes básicos son el medio para promover la adquisición y el
desarrollo de las competencias específicas, pero también los conocimientos mínimos de ciencias biológicas
y geológicas que el alumnado debe adquirir.

Los criterios de evaluación son indicadores que permiten medir el nivel de desarrollo de las
competencias y están conectados de forma flexible con los saberes con el fin de proporcionar una visión
objetiva de los aprendizajes del alumnado.

Las competencias y saberes deben trabajarse en forma de situaciones de aprendizaje o actividades
con un objetivo claro, conectadas con la realidad y que inviten al alumnado a la reflexión y la colaboración.
Con tal fin se recomienda el trabajo interdisciplinar, que favorecerá una asimilación más profunda de esta
materia, al extender sus raíces hacia otras ramas del conocimiento con las que se vincula.

En conclusión, en las materias de Biología y Geología se trabajan saberes de las ciencias geológicas
y de la vida como vía para la adquisición y desarrollo de las competencias específicas y de las competencias
clave, con el fin último de una plena integración ciudadana del alumnado a nivel profesional, social y
emocional.

2. Competencias especificas

2.1.    Competencia específica 1

Resolver problemas científicos abordables en el ámbito escolar a partir de trabajos de investigación
de carácter experimental.

2.1.1    Descripción de la competencia 1

Las experiencias prácticas realizadas en el ámbito escolar que requieren un trabajo experimental
implican hacer operaciones destinadas a descubrir, comprobar o demostrar determinados fenómenos o
principios científicos. Es por esto que detrás de cada diseño de un experimento debe haber una finalidad que
dirija el trabajo del alumnado hacia la comprensión de los fenómenos o principios que se ponen de manifiesto.

Estas experiencias se convierten en pequeñas investigaciones cuando van acompañadas de un
aprendizaje por descubrimiento cuyo objetivo es enseñar ciencia haciendo ciencia. Así, mediante el diseño
de estas pequeñas investigaciones, el alumnado podrá buscar soluciones a los problemas de tipo científico
que se le planteen. De esta forma, se consigue el desarrollo de habilidades para la investigación y se ponen
en juego las características y valores del trabajo científico. Este modelo de prácticas educativas, basado en
la indagación o aprendizaje por descubrimiento, puede oscilar entre un modelo muy guiado y pautado por el
docente, en el que el alumnado decide poco o nada, hasta otro donde el alumno o la alumna no decide la
pregunta investigable pero sí el experimento, o totalmente abiertas y centradas en el alumnado, en función
del grado de desarrollo cognitivo y habilidades que se requieran. Evidentemente el grado de intervención del

profesorado dependerá del tipo de contenido trabajado y del grado de competencia del alumnado adquirido
en experiencias anteriores en este tipo de prácticas indagativas. Cuanto mayor es la autonomía del alumnado
y su implicación en el diseño de todos los pasos necesarios en la investigación, mayor es su destreza y la
adquisición de los procedimientos propios de la ciencia, lo que conocemos genéricamente como método
científico: observar hechos, formular preguntas investigables, diseñar experimentos, recopilar datos, razonar
y revisar las pruebas obtenidas a la luz de lo que ya se conoce, extraer y comunicar conclusiones, discutir los
resultados y formular modelos explicativos.

Esta competencia implica no sólo la adquisición de habilidades instrumentales o trabajo manipulativo,
sino también las capacidades de razonamiento, como la argumentación y la modelización.

Hay que señalar que las actividades experimentales pueden ser indagativas o no, ya que no siempre
que hacemos experimentos hacemos ciencia y ésta utiliza otros instrumentos, al margen de la
experimentación, en su quehacer diario. No obstante, en numerosas ocasiones es necesario recurrir a
experimentación práctica de tipo demostrativo para ilustrar ejemplos o adquirir destrezas en el manejo de
instrumentos científicos, sin realizar preguntas investigables ni hipótesis que contrastar, lo que requiere menor
maduración del alumnado en esta destreza.

Las diferencias de grado en el desarrollo de esta competencia específica se manifiestan a través de
la distinta complejidad de las investigaciones planteadas, tanto en el problema a abordar, como en el
planteamiento del experimento o en la comunicación de los resultados, y en función de los saberes básicos
asociados al nivel.

Al final del primer curso, el alumnado debe haber adquirido las destrezas básicas implicadas en el
uso de los materiales y herramientas propias de un laboratorio, así como ser capaz de realizar prácticas
demostrativas y pequeñas investigaciones guiadas en las que se exige identificar el problema y las variables
que intervienen, emitir hipótesis, realizar diseños experimentales, obtener resultados y saber comunicarlos.
En este nivel, los problemas planteados son más sencillos y los resultados se presentan generalmente
mediante informes descriptivos y observaciones cualitativas (dibujos y esquemas).

Al acabar el tercer curso, el alumnado debe ser capaz de relacionar las variables de manera
cuantitativa o cualitativa, comunicar el proceso con precisión, sacar conclusiones y hacer predicciones en
distintas condiciones. Los informes de los resultados deben ser interpretativos de los fenómenos estudiados.

2.2.    Competencia específica 2

Analizar situaciones problemáticas reales utilizando la lógica científica y explorando las posibles
consecuencias de las soluciones propuestas para afrontarlas.

2.2.1. Descripción de la competencia 2

Esta competencia hace referencia al análisis de un problema o caso real al que es necesario dar una
solución o adoptar decisiones para poder minimizar sus efectos. Todo ello desde el punto de vista científico.

Así, implica la movilización de conocimientos para cuestionar la situación, buscar y profundizar en la
información, recopilar datos y opiniones para el análisis de la situación, argumentar las ideas y aceptar puntos
de vista diferentes al propio, proponer una intervención y comunicar las conclusiones obtenidas. Su
adquisición y desarrollo permitirá al alumnado hacer frente a problemas como, por ejemplo, el deterioro de
los alimentos, la aparición de los síntomas de una enfermedad, los efectos de una gran tormenta, o el cambio
climático, de una forma objetiva e informada, así como proponer acciones que puedan mitigar sus efectos o
adaptarse a las consecuencias.

El grado en el desarrollo de esta competencia específica viene de la adecuación de la solución
planteada, la complejidad del problema a resolver, los conocimientos que se movilizan para resolverla, la
cercanía del contexto en que se desarrolla y el grado de abstracción que requiere.

Al acabar el primer curso, el alumnado debe ser capaz de proponer soluciones ante situaciones
problemáticas reales, para resolverlas o mejorarlas, que sean coherentes con la lógica científica.

Al acabar el tercer curso, el alumnado debe ser capaz de construir explicaciones ante situaciones
problemáticas reales que relacionen los hechos y conceptos indicando sus limitaciones, así como de proponer
soluciones creativas y relevantes en las que utilicen conocimientos de otras materias, predecir los resultados
y relacionarlas con otras situaciones con características similares.

Las reflexiones aportadas en la descripción de la competencia específica anterior son igualmente
válidas para ésta, que también es compartida con la materia de Física y Química.

2.3.     Competencia específica 3

Utilizar el conocimiento científico como instrumento del pensamiento crítico, interpretando y
comunicando mensajes científicos, desarrollando argumentaciones y accediendo a fuentes fiables, para
distinguir la información contrastada de los bulos y opiniones.

2.3.1. Descripción de la competencia 3

El desarrollo del pensamiento crítico entendido como “pensamiento reflexivo y razonable que orienta
la decisión sobre qué hacer o qué creer” es una demanda de la sociedad actual. Este pensamiento crítico se
encuentra fuertemente vinculado con la capacidad de aprender a aprender y el aprendizaje permanente. Para
ello, el alumnado deberá ser capaz de distinguir las fuentes fiables de aquellas que no lo son. La reiterada
presencia en el mundo actual de bulos basados en fuentes poco fiables y en opiniones carentes de una base
científica, así como el avance de las pseudociencias, hacen imprescindible el desarrollo, por parte de la
ciudadanía, de una competencia que le permita distinguir entre informaciones contrastadas y valoraciones sin
ningún fundamento.

Desarrollar esta competencia implica la capacidad de reunir datos de una forma que permita utilizarlos
para acotar los problemas y realizar una descripción precisa de los mismos, debatir, argumentar y defender
posturas, contrastar opiniones y redactar informes. Esto exige aplicar un código común, propio de la
comunidad científica: el uso de un lenguaje preciso, de información en formato numérico y gráfico, de citación
de fuentes fiables o de revisión por pares antes de ser publicados los resultados.

La utilización del lenguaje científico ya sea para leer textos o para producirlos, implica el conocimiento
de las reglas de ese lenguaje, además del vocabulario técnico específico, y la adquisición de las destrezas
propias de la argumentación, como el razonamiento lógico, el cuestionamiento de las propias creencias, y la
contrastación de los hechos o hipótesis.

Por otro lado, la comunicación desempeña un papel esencial en la construcción del conocimiento
científico que se va desarrollando en la sociedad.

El grado en el desarrollo de esta competencia específica viene dado por la complejidad de los
conocimientos que implica identificar los rasgos propios de la ciencia en un discurso para validar el mismo en
base a su adecuación a las teorías y modelos científicos.

Al acabar el primer curso, el alumnado debe ser capaz de identificar los elementos característicos del
discurso científico y tener un criterio propio para distinguir la información fiable de las opiniones personales o

faltas de fiabilidad, así como de interpretar textos científicos sencillos, elaborar informes de las experiencias
realizadas y exponerlos de manera oral.

Al finalizar el tercer curso, el alumnado debe ser capaz de argumentar y defender una opinión propia
en torno a cuestiones investigables utilizando los elementos principales del pensamiento crítico: construir una
argumentación a partir de análisis de datos que dé base a una opción o desmienta a otra.

Nuevamente, las reflexiones aportadas en la descripción de las dos competencias anteriores son
igualmente válidas para ésta, que es también común y compartida con la materia de Física y Química.

2.4.    Competencia específica 4

Justificar la validez del modelo científico como producto dinámico que se va revisando y
reconstruyendo bajo la influencia del contexto social e histórico, atendiendo a la importancia de la ciencia en
el avance de las sociedades, así como a los riesgos de un uso inadecuado o interesado de los conocimientos
científicos y a sus limitaciones.

2.4.1. Descripción de la competencia 4

Esta competencia alude al hecho de que el conocimiento es un producto en continua revisión, con
influencias del pensamiento de la época. En ese sentido, las explicaciones científicas que son modelos válidos
en un entorno social y momento dado sufren cambios en función del conocimiento existente, mejorando su
capacidad de explicar la realidad. La ciencia debe entenderse y apreciarse no como un saber acabado, sino
como la descripción más razonable y adecuada a los conocimientos en cada momento histórico.

Igualmente importante en esta competencia es el conocimiento de la forma en que se gestaron las
ideas científicas y las circunstancias en las que se produjeron los descubrimientos, lo que aporta una
perspectiva sobre la ciencia que permite comprender el avance en el pensamiento humano y las
circunstancias que lo envuelven, favoreciendo o frenando dicho avance. Ciertamente, la ciencia se caracteriza
por una continua revisión de sus propuestas, asociada a nuevos descubrimientos o al progreso tecnológico
que permiten obtener datos más precisos. El conocimiento de la época en la cual se realizaron los
descubrimientos proporciona una visión más realista de la ciencia, como un trabajo de equipos y en continua
revisión, lejos de una concepción asociada a la genialidad de individuos aislados de su entorno. Esto es
aplicable a todas las teorías y modelos científicos, como por ejemplo las teorías sobre el origen del Universo,
la Tierra y el Sistema Solar, los procesos geológicos generadores del relieve, las teorías de la herencia, la
aparición de la vida, la tectónica de placas, las teorías sobre la evolución o la aparición y propagación de
enfermedades.

El desarrollo de esta competencia conlleva una actitud crítica acerca del alcance y las limitaciones de
la ciencia, en la que, al contrario de lo que sucede en las pseudociencias o las creencias, no existen certezas
entendidas como verdades absolutas e incuestionables.

Un aspecto relevante de la epistemología de las ciencias es el papel jugado por las controversias
científicas. La discusión y el análisis de controversias científicas son fundamentales para alcanzar una
adecuada alfabetización científica, ya que permiten transmitir una imagen de la ciencia más adecuada,
mostrando características básicas de la misma, como la incertidumbre, el carácter tentativo, la subjetividad,
la existencia de múltiples perspectivas, el rol del financiamiento, los intereses políticos y su relación con el
entorno social.

El grado en el desarrollo competencial de esta competencia específica depende de la dificultad para
comprender los modelos estudiados y los nuevos descubrimientos o avances en las técnicas que impulsan
los avances de la ciencia, y de las relaciones con otros conocimientos de otras áreas que influyen en la ciencia
en un momento histórico dado.

En el transcurso del primer curso, el alumnado avanzará en el conocimiento de las relaciones entre
ciencia y sociedad y, al finalizarlo, deberá ser capaz de aportar ejemplos de utilización positiva y negativa del
conocimiento científico como muestra del carácter neutral de la ciencia y de su utilización en función de
intereses concretos, en muchas ocasiones nobles, pero perversos en otras. También serán capaces de
aportar ejemplos de cambios sufridos por las teorías científicas con el tiempo.

Al finalizar el tercer curso, el alumnado será capaz de situar en contexto las teorías científicas teniendo
en cuenta la época en que fueron planteadas y aportar algunos datos sobre las causas de los avances que
supusieron y su relación con el contexto histórico y social. Han de valorar las explicaciones científicas
aceptadas como la mejor explicación posible con los datos disponibles en un momento dado.

2.5.    Competencia específica 5

Adoptar hábitos de vida saludable basados en el conocimiento del funcionamiento del propio cuerpo,
y de los peligros del uso y abuso de determinadas prácticas y del consumo de algunas sustancias.

2.5.1. Descripción de la competencia 5

La adquisición de esta competencia requiere la comprensión del funcionamiento del cuerpo humano
como un sistema en equilibrio, en el que el todo es mayor que la suma de sus partes. Incorpora la comprensión
del concepto de ser vivo y de sus niveles de organización e interrelación entre los principales aparatos y
sistemas funcionales (digestivo, respiratorio, excretor, circulatorio, locomotor, nervioso, endocrino y
reproductor) del cuerpo humano.

Requiere que el alumnado pueda valorar la importancia de mantener una alimentación saludable y
un ejercicio físico adecuado, siendo consciente de la influencia sobre su salud y actuando de modo
responsable. La alimentación debe cubrir las necesidades energéticas y nutritivas necesarias en cada período
de la vida dependiendo de las situaciones diferenciales y personales.

Las desigualdades también generan una brecha nutricional, tanto entre las clases más desfavorecidas
como entre los diferentes países con distintos niveles de vida. Los casos de malnutrición y desnutrición están
ligados a problemas sociales y económicos, además de estar sujetos a modas y tendencias a las que los
adolescentes son muy propensos y que pueden acabar desembocando en trastornos graves como la anorexia
y la bulimia.

Los conocimientos adquiridos también tienen que permitir adoptar medidas de cuidado del propio
cuerpo para evitar contraer infecciones, lesiones musculares, ser conscientes del propio estrés y alcanzar un
equilibrio emocional.

Es importante destacar los efectos tóxicos que provocan determinadas sustancias nocivas (drogas y
medicamentos) en el sistema nervioso, relacionándolas con procesos degenerativos y alteraciones cognitivas,
así como con el deterioro de determinadas funciones cerebrales. También el uso inadecuado de las
tecnologías digitales de la información y la comunicación produce consecuencias negativas sobre la salud, la
vida social, familiar, escolar o laboral, dificultando las relaciones sociales. En este sentido, es particularmente
importante prevenir determinadas actuaciones que interfieren en el funcionamiento del centro escolar y que
pueden afectar gravemente a la convivencia, como es el caso del ciberbulling y otras prácticas similares.

Por último, conocer la causa y origen de determinadas enfermedades puede ayudar a prevenir el
consumo de sustancias como el tabaco y el alcohol, que crean adicciones y afectan a diferentes sistemas del
cuerpo humano.

La competencia debe estar adquirida al finalizar el primer curso de secundaria, siendo el alumnado
capaz de adoptar los hábitos saludables y las medidas preventivas teniendo en cuenta las alteraciones a nivel

orgánico y celular producidas por los malos hábitos, el consumo de sustancias tóxicas y dañinas, o la
alimentación no saludable. En este caso, el objetivo sería evitar que el alumnado se iniciara en dichos malos
hábitos.

En cuanto al tercer curso, si bien no se trabajará en esta materia, sí se tratará en otras, como
Educación Física, Valores Éticos, y Tutoría, en las que se abordarán aspectos de esta competencia
relacionados de nuevo con los hábitos de vida saludables y con las relaciones interpersonales, destacando la
importancia del papel alumnado como agente activo de la prevención de dichas prácticas y de las actitudes
que atentan contra la dignidad de las personas.

2.6.     Competencia específica 6

Identificar y aceptar la sexualidad personal, y respetar la variedad de identidades de género y de
orientaciones sexuales existentes, en base al conocimiento del cuerpo humano y del propio cuerpo.

2.6.1. Descripción de la competencia 6

La adquisición de esta competencia abarca tres ámbitos diferentes y relacionados entre sí: el científico
(conocimiento del funcionamiento del propio cuerpo), el emocional (desarrollo psicológico y maduración
personal), el social y el axiológico (respeto y aceptación de las diferencias individuales).

Desde el área de la Biología se imparten los conocimientos necesarios para entender el
funcionamiento del propio cuerpo, formación de gametos, cambios corporales, regulación hormonal, ciclo
ovárico y menstrual, desarrollo embrionario, parto, así como los aspectos básicos de las enfermedades de
transmisión sexual y métodos anticonceptivos. Pero este conocimiento científico, aunque necesario, no es
suficiente para el desarrollo y la maduración personal.

Resulta imprescindible abordar las implicaciones emocionales de las relaciones interpersonales
desde la óptica de la realización personal, diferenciando la sexualidad humana de la reproducción, y las
relaciones sexuales deseadas de las no deseadas. Incluye la capacidad de reconocer, comprender y hablar
sobre la discriminación y la violencia y saber cómo y dónde buscar apoyo, asesoramiento e información fáctica
sobre una variedad de cuestiones sobre relaciones y sexualidad.

En el entorno social el alumnado interactúa con mensajes complejos y a menudo contradictorios sobre
género, relaciones y sexualidad que darán forma a su vida cotidiana y futuros imaginados. Estos mensajes
provienen de la publicidad, los libros, la música, las redes sociales, la televisión y los medios de comunicación
en general, de miembros de la familia, los compañeros y la comunidad. Esto genera en ocasiones la asunción
de conceptos erróneos por parte de la infancia y la juventud. A menudo, estas concepciones erróneas no son
detectadas por los adultos, lo que lleva a una mala interpretación de los comportamientos de la juventud.

El alumnado debe comprender cómo se pueden formar y mantener diferentes tipos de relaciones
seguras, consensuadas, saludables y satisfactorias. Un aspecto fundamental de este aprendizaje es
reconocer y comprender la diversidad de relaciones en todo el mundo y durante el curso de la vida. El objetivo
no es otro que acompañar a los adolescentes y jóvenes en su proceso de crecimiento, desarrollo y aprendizaje
personales, y empoderarlos para la autodeterminación de su propia identidad, de forma libre, sana y sin
imposiciones externas basadas en estereotipos y prejuicios.

El alumnado debe desarrollar una comprensión adecuada del sexo (determinado genéticamente), el
género (identidad y expresión personal, independiente del sexo con el que se nace) y la orientación sexual.
Esto implica conocer cómo la biología, la sociedad y la cultura moldean nuestro sentido de identidad y nuestras
relaciones con los demás. Es fundamental para este aprendizaje reconocer la diversidad de género e
identidad sexual, expresión, comportamiento y representación, incluida la diversidad LGTBIQ+, y cómo la

comprensión social y cultural del sexo, el género y la sexualidad han cambiado con el tiempo y continúa
evolucionando.

Descubrir la identidad sexual propia, diferenciando sexo biológico de género y orientación sexual,
respetar las diferencias individuales, y actuar de modo responsable y asertivo exige desarrollar habilidades
de toma de decisiones desde la libertad individual, pero mediante la adecuada reflexión, asunción de los
riesgos y medidas preventivas adecuadas.

Al final del primer curso, el alumnado habrá adquirido un conocimiento del funcionamiento del propio
cuerpo que le permita tomar decisiones de forma responsable y asertiva en relación con su identidad sexual,
respetando todas las opciones.

Considerando la evolución previsible en cuanto al desarrollo y madurez, tanto física como mental, que
se produce durante la etapa de secundaria, al finalizar el tercer curso el alumnado habrá avanzado en el
control de sus emociones y de las relaciones personales que se intensifican durante este período. Además,
deberá de ser capaz de argumentar en torno a las cuestiones sobre la adopción de medidas preventivas y
contrastar informaciones y puntos de vista alternativos relacionados con la sexualidad y reproducción humana,
justificando sus argumentos mediante el recurso al conocimiento científico adquirido.

2.7.   Competencia específica 7

Actuar con responsabilidad participando activamente en la conservación de todas las formas de vida
y del planeta en base al conocimiento de los sistemas biológicos y geológicos.

2.7.1. Descripción de la competencia 7

Al finalizar la educación básica se espera que el alumnado diferencie los seres vivos de la materia
inerte en base a las propiedades que definen la vida: las funciones de los seres vivos, su composición y
organización interna, basada en grados de complejidad creciente, y las relaciones entre ellos interpretando
los ciclos de la materia y las pirámides tróficas.

Es importante conocer los criterios de clasificación que determinan las categorías taxonómicas y los
principales grupos de los seres vivos (los cinco reinos y los grandes grupos), destacando las adaptaciones de
la vida a las condiciones cambiantes del planeta que han llevado a los expertos a establecer los grandes
grupos de seres vivos.

Esta visión global de la vida y los ecosistemas ha de facilitar la percepción de una ecodependencia
de todos los seres vivos, y de interdependencia con los ciclos geológicos, adquiriendo hábitos de cuidado del
planeta y sus formas de vida, así como del suelo fértil.

La acción del ser humano sobre el planeta puede ahora percibirse desde el conocimiento de la
dinámica de la tierra. El cambio climático, la contaminación, el agotamiento de recursos y la pérdida de la
biodiversidad adquieren un carácter más globalizador al relacionar los fenómenos geológicos externos con la
vida en la tierra.

Esta competencia debe facilitar el conocimiento basado en la observación y la experimentación con
seres vivos para reconocer su estructura y funcionamiento.

Al acabar el primer curso, el alumnado será capaz de responder a cuestiones relacionadas con las
causas de los fenómenos que se producen en nuestro planeta y prever algunas posibles consecuencias de
estos a partir de datos obtenidos mediante métodos fiables conocidos, valorando la importancia del papel de
la ciencia en esas previsiones.

Al final del tercer curso, el alumnado será capaz, además, de proponer soluciones para paliar dichas
consecuencias o para prevenir los fenómenos responsables de las mismas.

2.8.    Competencia específica 8

Utilizar el conocimiento geológico básico sobre el funcionamiento del planeta Tierra como sistema,
con el fin de analizar su impacto sobre las poblaciones y proponer y valorar actuaciones de previsión e
intervención.

2.8.1. Descripción de la competencia 8

Las manifestaciones de la dinámica del planeta han generado y continuarán haciéndolo situaciones
inesperadas y en muchas ocasiones trágicas para numerosas poblaciones humanas. La comprensión de los
procesos que originan esas manifestaciones permitirá que el alumnado asuma la necesidad de tomar
precauciones y de valorar las actuaciones que los seres humanos realizan en algunas zonas especialmente
sensibles, a la vez que propone actuaciones de intervención y prevención llevándolo a actuar como agente
de transformación. Todo ello facilitará la aproximación al concepto de ciencia y de las diversas formas de
aproximación al conocimiento científico. El conocimiento de los modelos del planeta Tierra permite
comprender las causas que originan los fenómenos que observamos, tanto de tipo destructivo como
constructivo, del relieve y que se manifiestan de modo puntual, y en ocasiones catastrófico, o gradualmente.

Al acabar el primer curso, el alumnado será capaz de reconocer que un sistema es algo más que una
agrupación de elementos, identificar las relaciones entre los componentes o conceptos y las variables
relevantes del modelo teórico que corresponde al fenómeno estudiado, y comunicarlo con la terminología
científica adecuada.

Al acabar el tercer curso, será capaz de interpretar los fenómenos o hechos de una manera más
global, analizando los cambios que se producen cuando se modifican las condiciones o se realiza una posible
intervención, y prediciendo la evolución del sistema mediante un razonamiento lógico y unos argumentos que
utilizan la terminología y el lenguaje simbólico propio de la ciencia. También podrá explicar la dinámica de
construcción-destrucción del relieve terrestre y asociarla con los cambios que observamos en nuestro planeta.

2.9.    Competencia específica 9

Analizar e interpretar los principales hitos de la historia del planeta Tierra y los principales procesos
evolutivos de los sistemas naturales, atendiendo a las magnitudes del tiempo geológico implicadas.

2.9.1. Descripción de la competencia 9

El aprendizaje de las nociones temporales y de los sucesos que acontecen en escalas de tiempo muy
diferentes permite explicar, situar e interpretar datos del pasado que rigen la evolución del planeta. Algunos
aspectos que suceden en escalas temporales muy diferentes son las que afectan al origen y evolución
geológica de la Tierra, los procesos geológicos externos, el modelado del relieve, el ciclo de las rocas o la
evolución del universo. Por otro lado, es importante asociar el paso del tiempo con la aparición de formas de
vida que han ido sobreviviendo por selección natural a las condiciones cambiantes, desarrollando numerosas
estructuras corporales y adaptaciones características, propias de cada grupo de seres vivos. Esto facilita la
comprensión de la magnitud del tiempo geológico por parte del alumnado, lo que le permitirá asociarlo con
los procesos de evolución de los seres vivos, así como de los sucesivos episodios catastróficos que cambiaron
radicalmente el aspecto del planeta, acabando con un porcentaje importante de la biodiversidad, en algún
caso de más del 90%.

Otras escalas temporales relacionadas con las anteriores son los ciclos de la materia, la dinámica de
los ecosistemas o los procesos en equilibrio sobre los que la actuación del ser humano produce alteraciones

(como extinciones de seres vivos o cambio climático). Las duraciones temporales de los ciclos vitales
minimizan aún más estas escalas completando una visión global del tiempo y su relación con la naturaleza.

Junto con la competencia anterior, ésta permitirá adquirir una visión de conjunto del planeta que
habitamos, su dinámica, su historia y los fenómenos que han conducido al actual aspecto del planeta y la
diversidad de los seres vivos, además de contribuir a la percepción global del mundo en su conjunto.

Se sugiere la utilización de herramientas digitales como, por ejemplo, las líneas del tiempo para
representar procesos a escala planetaria o ciclos de vida de seres vivos, y de aplicaciones digitales para
estudiar la biodiversidad de la vida.

Al final del primer curso, el alumnado será capaz de apreciar la magnitud del tiempo geológico en
comparación con el histórico, y ambos con la duración de la vida de un individuo, distinguiendo las diferentes
escalas en que ocurren los fenómenos geológicos, históricos y personales.

Al finalizar el tercer curso, el alumnado será capaz de asociar el origen de la biodiversidad y la
necesidad de una gran cantidad de tiempo para su desarrollo con la magnitud del tiempo geológico y las
teorías que explican el mecanismo principal que originó dicha biodiversidad (selección natural) y los cambios
geológicos (tectónica de placas).

2.10. Competencia específica 10

Adoptar hábitos de comportamiento en la actividad cotidiana responsables con el entorno, aplicando
criterios científicos y evitando o minimizando el impacto medioambiental.

2.10.1. Descripción de la competencia 10

La ecoresponsabilidad comienza por la aplicación de los principios de sostenibilidad en el entorno
más próximo de la persona. La problemática generada por la actuación del ser humano sobre su entorno ha
alcanzado un nivel tal de gravedad que, partiendo de pequeños impactos de tipo local, ha llegado a generar
una incidencia a nivel planetario que se manifiesta en fenómenos tan globales como la emergencia climática
que nos amenaza en la actualidad. Por otro lado, incluye la percepción de que a los problemas globales se
les puede dar solución tomando las medidas adecuadas a nivel personal y local, como en el caso del
adelgazamiento de la capa de ozono. Mediante la adquisición y desarrollo de esta competencia, el alumnado
debe ser capaz de adoptar comportamientos en su vida diaria que demuestren su compromiso con la
conservación de las condiciones de vida del planeta y el conocimiento del impacto que sus actuaciones tienen
sobre todo lo que le rodea. La reducción del consumo energético y de recursos como el agua potable, la
disminución de los residuos y de la utilización de elementos que los generarán o, caso de tener que recurrir a
ellos, su reutilización y, en última instancia, su posterior reciclaje, deben ser las metas para una ciudadanía
responsable. Por otro lado, el consumo de productos de proximidad, la reducción del consumo de carnes y
alimentos procesados, la compra de productos con menos cantidad de envases no retornables y otros
comportamientos responsables similares, además de los beneficios asociados a las propias acciones, pueden
favorecer cambios en los sistemas de producción y, por extensión, en las políticas de las administraciones.

Al finalizar el primer curso, el alumnado será capaz de interpretar datos técnicos en torno a los
problemas que origina la acción humana sobre su entorno y su manifestación más preocupante en el momento
presente: la emergencia climática. También será capaz de describir las consecuencias para las poblaciones
humanas de procesos como la destrucción de biodiversidad, la desertización y, asociada a ella, la migración
climática.

En cuanto al consumo, el alumnado será capaz de aportar pruebas respecto a qué hábitos son más
saludables y cuáles generan menor cantidad de residuos o generan residuos susceptibles de ser reciclados,
argumentando en base a estas pruebas y actuando en consecuencia a nivel individual.

Al finalizar el tercer curso, será capaz de identificar y analizar, de manera global y con conocimientos
técnicos, los problemas que afectan a nuestro planeta generados por la actividad humana de una manera
directa o indirecta, sus causas y las posibles actuaciones que se puedan emprender para mitigarlos o
adaptarse a ellos.

Además, el alumnado habrá adquirido hábitos responsables de consumo, reduciendo su huella de
carbono, con un menor consumo energético y menor generación de residuos, participando además
activamente en la difusión de estas prácticas en su entorno más cercano y aportando pruebas en torno a su
idoneidad.

2.11. Competencia específica 11

Proponer soluciones realistas basadas en el conocimiento científico ante problemas de naturaleza
ecosocial a nivel local y global, argumentar su idoneidad y actuar en consecuencia.

2.11.1. Descripción de la competencia 11

El alumnado será capaz, al terminar esta etapa, de actuar como agente de transformación,
argumentando sus propuestas de mejora y/o de adaptación a la situación, tanto en el ámbito local como en el
global, y de dirigirse a las instancias que puedan llevar a cabo esas transformaciones o que puedan facilitarlas.
Todo ello deberá estar basado en datos objetivos aplicando un punto de vista científico, con capacidad para
realizar pruebas experimentales de comprobación y búsqueda de información contrastada, trabajando en
equipo, aplicando siempre criterios éticos de igualdad y no discriminación. Para ello, deberá poseer un amplio
conocimiento no solo de los problemas ambientales y sus consecuencias sobre la naturaleza, sino también
de los problemas sociales que se generan y que implican, al mismo tiempo, la desestabilización de las
sociedades que los sufren. Se deberá, por tanto, aplicar un criterio de tipo ecosocial a la hora de profundizar
en las causas, la concreción y las soluciones a los problemas ambientales, ya que no se pueden abordar los
problemas sin un profundo conocimiento de los mismos y distinguiendo las opiniones personales de los
hechos contrastados científicamente.

Al finalizar el primer curso, el alumnado deberá ser capaz de diagnosticar problemas presentes en su
entorno cercano y proponer medidas para afrontarlo, acudiendo, con ayuda del profesorado, a las instancias
adecuadas para aportar dichas propuestas.

Al finalizar el tercer curso, el alumnado deberá ser capaz de aportar propuestas, tanto a nivel local
como global, para afrontar, mitigar o adaptarse a los problemas generados por la acción humana de forma
autónoma, conociendo las vías establecidas para realizar dichas aportaciones y las fuentes en las que
consultar la información.

3. Conexiones de las competencias específicas entre sí, con las competencias de otras áreas/materias
y con las competencias clave (para el conjunto de las competencias del área/materia)

3.1.    Relaciones o conexiones con las otras CE de la materia

La CE 1 está ligada a las dos competencias específicas siguientes (CE 2 y CE 3) que abarcan la
metodología de la ciencia y no puede desarrollarse de forma independiente de ellas. La adquisición y el uso
de conocimientos específicos da respuestas y soluciones a los problemas científicos. Las leyes, los principios
y los conceptos científicos se utilizan para definir un problema y formularlo en términos que se aproximen a
una respuesta o solución. Esta competencia no puede desarrollarse sin el dominio de las estrategias de
comunicación. Por otro lado, en la medida en que se aplicará para facilitar la comprensión de los fenómenos
de nuestro entorno, se relaciona con el resto de las competencias específicas de la materia, al constituir el
instrumento que facilitará dicha comprensión.

La CE 2 está ligada a la CE 1 de esta misma materia y no puede desarrollarse de forma independiente
de ella. La adquisición y el uso de conocimientos específicos permite dar respuestas a situaciones reales. Las
leyes, los principios y los conceptos científicos se utilizan para definir un problema y formularlo en términos
que se aproximen a una respuesta o solución. Del mismo modo, esta competencia no puede desarrollarse sin
el dominio de las estrategias de argumentación y comunicación propios de la ciencia a los que remite la CE
3.

La CE3 no puede desarrollarse independientemente de las dos anteriores. Se enriquece con la mejor
comprensión de los procesos al resolver problemas aplicando el razonamiento científico, o al emitir hipótesis
y comunicar los resultados de una investigación, pero en ambos casos la comunicación de los resultados o
conclusiones, o la argumentación realizada, se llevan a cabo mediante un tipo de discurso argumentativo y
un lenguaje propios de la ciencia, que implican la utilización del lenguaje matemático y la comprensión de las
leyes de la ciencia.

La CE 4 se relaciona con las tres anteriores por suponer un avance en la comprensión de cómo
funciona la ciencia y su incidencia en la vida de las personas, aportando a dicha comprensión la relación con
la sociedad en la que se encuentran las personas que desarrollan las teorías.

La relación de las cuatro competencias anteriores con el resto de las competencias específicas se
basa en la naturaleza del sistema de trabajo propio de la ciencia. Con sus limitaciones asociadas a la
dependencia de los principios aplicados en los distintos descubrimientos que se van produciendo y el carácter
dinámico que ello le infiere, el trabajo científico constituye un buen sistema de interpretación de la realidad
que facilita la previsión de acontecimientos y, por tanto, las actuaciones que facilitan la vida a los seres
humanos y permiten prever las consecuencias de sus actos. Por tanto, estas competencias deben impregnar
todos los niveles educativos y todas las áreas y materias del currículo, no solo las del ámbito científico y
tecnológico.

En cuanto a su relación con el resto de competencias específicas de Biología y Geología, por su
carácter transversal, las cuatro primeras competencias específicas afectan a todos los aspectos de la ciencia,
facilitando los avances en campos como el conocimiento del funcionamiento del organismo y la adquisición
de buenos hábitos (CE 5), los avances en la comprensión del funcionamiento de los sistemas del planeta (CE
7, CE 8 y CE 9) y las acciones humanas sobre el planeta, sus consecuencias y las medidas para paliarlas o
adaptarse a ellas (CE 10 y CE 11).

Por lo que respecta a la CE5, esta competencia y la CE 6 (relativa a temas de sexualidad) están muy
relacionadas, ya que la segunda requiere del conocimiento del funcionamiento del propio cuerpo y de la toma
de conciencia de la necesidad de su cuidado. También con la CE 7 (biodiversidad), al relacionar el ser humano
con el concepto de ser vivo como sistema integrado. Por lo demás, no son indiferentes las consecuencias
derivadas de una alimentación no sostenible sobre el medio ambiente (CE 10).

la CE 6 se nutre de la anterior, ya que requiere de la comprensión de la anatomía y fisiología del
cuerpo humano como sistema complejo y de la toma de conciencia de la necesidad de su cuidado, aunque
tiene elementos propios y diferenciales relacionados con la sexualidad y los numerosos aspectos emocionales
y sociales que requieren su desarrollo independiente.

Las CE 7, 8 y 9 apelan al conocimiento de nuestro planeta y los sistemas que contiene, incluyendo él
mismo como sistema.  Los puntos de coincidencia y las estrechas conexiones existentes entre estas tres
competencias aconsejan examinar sus relaciones con otras competencias específicas de manera conjunta,
en lugar de hacerlo para cada una de ellas por separado.

La comprensión de los sistemas biológicos y geológicos relacionan la CE 8 con la CE 9, pero el
concepto de sistema debe estar presente en la interpretación de la naturaleza, considerando que un sistema
es algo más que la suma de sus partes. El conocimiento del funcionamiento del cuerpo humano o los

ecosistemas requieren también esa concepción de sistema, lo que ligaría las CE 7, CE 8 y CE 9 con las CE
4, CE 10 y CE 11, asociando así los efectos sobre el medio ambiente con las consecuencias sobre la salud
humana. Dicha comprensión también se relaciona con las cuatro primeras CE, pues requiere una capacidad
de análisis de problemas de la vida cotidiana. Además, implica valorar la incidencia de las acciones humanas
sobre el mantenimiento de la biodiversidad y la pérdida de ésta y sobre la alteración de los equilibrios naturales
como generadora de enfermedades en los seres humanos (CE10 y CE11).

La indiscutible incidencia del ser humano sobre el planeta debe ser tenida en cuenta a la hora de
formar a la ciudadanía. Si bien se concibe la infancia y la juventud como los ciudadanos del futuro, lo cierto
es que ya lo son en el presente y deben conocer las consecuencias que la actividad de su especie está
teniendo, sus causas últimas y las posibles respuestas que se pueden proponer como medidas de prevención,
compensación o adaptación. En este sentido, el alumnado debe no solo conocer los problemas, sino ser
capaz de aportar ideas para afrontarlos. Por esa razón, las CE 10 y CE 11 se encuentran imbricadas y
contribuyen a un planteamiento de la problemática que debe ser de tipo ecosocial, manteniendo relaciones
compartidas con las competencias clave y con otras competencias específicas, al igual que ocurría con las
del bloque anterior.

Las CE 10 y CE11 se relacionan, de una forma muy destacada, con la CE 5 sobre hábitos saludables,
debido a la causalidad confirmada de las alteraciones del medio en numerosas afecciones o agravamiento de
enfermedades en seres humanos. También tienen una especial conexión con la CE 7 sobre biodiversidad y
la importancia de su conservación. Por otra parte, en la medida en que el desarrollo de la CE 10 y la CE 11
implica la aplicación de criterios objetivos basados en evidencias, ambas se relacionarán también con las
cuatro primeras competencias específicas.

3.2.    Relaciones o conexiones con las CE de otras materias de la etapa

La ciencia aporta explicaciones a los fenómenos y la sociedad utilizará dichas explicaciones para el
desarrollo de aplicaciones y la toma de decisiones. En este sentido, el conocimiento sobre dichas decisiones
permitirá reflexionar en torno a su idoneidad. Las competencias en el ámbito humanístico resultan así
esenciales para el desarrollo de esta competencia específica.

Para el correcto conocimiento del funcionamiento del organismo y los criterios que nos permitan
argumentar en cuanto a la idoneidad de unos hábitos u otros, es fundamental que se desarrollen
competencias ligadas al tratamiento de datos y a las leyes físicas y químicas. Así, el conocimiento de los
procesos que se desarrollan en nuestro organismo y que justifican la toma de decisiones en cuanto a nuestra
salud debe incluir la comprensión de las reacciones químicas que se producen en nuestro cuerpo y las leyes
de la física que limitan determinadas acciones por parte de nuestro aparato locomotor.

Los problemas asociados a una alimentación inadecuada incluyen los casos en los que dicha
alimentación no es decisión de la persona, sino que resulta impuesta por unas sociedades injustas,
insolidarias y hegemónicas. La correcta comprensión de estas circunstancias viene asociada al desarrollo de
las competencias del ámbito humanístico.

La sexualidad es una de las expresiones más importante en el ser humano y su relación con las
relaciones afectivas es también estudiada a través de las características y procesos físico-químicos del
organismo humano. Además, se puede aprovechar esta competencia para estudiar cuestiones relacionadas
con el género y la presencia de hombres y mujeres en los distintos ámbitos de la ciencia, así como el
comportamiento del mundo de la ciencia con la diversidad sexual y de género, en comparación con otros
ámbitos de la vida. Se puede aprovechar también para valorar cómo responden los distintos ámbitos de la
ciencia ante los retos actuales de la sociedad.

Así, el carácter transversal de la CE 6 se manifiesta en su clara relación con la interacción entre los
humanos y el respeto a todas las opciones de orientación sexual. En este sentido, cualquiera de las formas

de afrontar la realidad debe estar asociada a ese respeto, que no es posible sin un conocimiento de la
existencia de esas posibilidades. Desde cualquiera de los ámbitos se puede estudiar esta diversidad, tanto
en el momento presente como desde un punto de vista histórico, así como la forma en que las distintas
culturas la abordan o la han abordado y las manifestaciones que tanto desde la literatura como desde el arte
se han generado.

La comprensión del funcionamiento de los sistemas biológicos y geológicos (CE 7, CE 8 y CE9)
requiere la utilización de los recursos matemáticos. Por otro lado, la adquisición y desarrollo de las
competencias relacionadas con la Física y la Química incrementará también dicha comprensión, ya que, para
avanzar en el conocimiento de los sistemas y su funcionamiento, es necesaria la utilización de conceptos de
física y química que aportan explicaciones a los fenómenos que observamos y nos permiten prever
comportamientos y obrar en consecuencia.

Los sistemas no son exclusivos del ámbito científico. Se dan en cualquier ámbito y la comprensión
de su origen, funcionamiento y relaciones entre sus componentes en uno de los ámbitos facilitará la de otros
sistemas, aproximando al alumnado a una mejor comprensión de su entorno.

También las CE 10 y CE 11 tienen profundas conexiones con las ciencias sociales, habida cuenta de
las implicaciones que para las poblaciones humanas tienen los impactos sobre la naturaleza de nuestras
acciones y las consecuencias que a su vez se derivan sobre las propias poblaciones que habitan las zonas
que reciben el impacto y que en muchas ocasiones no son las que lo han generado. Pero también hay posibles
lugares de encuentro con otras materias que pueden contribuir a la concienciación en los problemas y la
difusión de las ideas a la vez que desarrollan sus competencias, como es el caso del ámbito artístico
expresivo, el ámbito tecnológico y digital o el ámbito lingüístico.  El desarrollo de estas dos competencias
requiere no solo un proceso de sensibilización, sino el acceso a datos objetivos que permitan el conocimiento
en profundidad de los problemas y el desarrollo del pensamiento crítico asociado. Esto no es posible sin el
desarrollo de competencias ligadas a conocimientos técnicos y de procesos operativos que facilitan las áreas
del ámbito STEM. Además, el conocimiento de datos y procesos no aporta, por sí solo, una visión de conjunto
de las situaciones. Es necesario, además, el acceso a informaciones asociadas a las consecuencias de
nuestras acciones ligadas a fenómenos sociales y éticos, entornos naturales próximos, riqueza paisajística,
entornos urbanos, expresión artística y relaciones sociales que constituyen el foco de otras materias,
especialmente del humanístico y social, y de la materia de Valores cívicos y éticos, así como una buena
comprensión de los textos y un buen desarrollo de la capacidad de comunicación que permita que el mensaje
emitido sea comprendido por los receptores asociada al desarrollo y adquisición de las competencias
específicas del ámbito lingüístico.

3.3. Relaciones o conexiones con las competencias clave

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 |  |  | X | X | X |  |  |  |
| CE2 |  |  | X | X | X | X |  |  |
| CE3 | X | X | X |  |  |  |  |  |
| CE4 |  |  | X |  |  | X |  | X |
| CE5 |  |  | X |  | X | X |  |  |
| CE6 |  |  | X |  | X | X |  |  |
| CE7 |  |  | X |  | X | X | X | X |
| CE8 |  |  | X |  | X | X |  | X |
| CE9 |  |  | X |  | X | X |  |  |
| CE10 |  |  | X |  | X | X | X |  |

| CE11 | X |  | X |  |  | X | X |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

•
CCL: competencia en comunicación lingüística
•
CP: competencia plurilingüe
•
CMCT: competencia matemática, ciencia y tecnológica
•
CD: competencia digital
•
CPSAA: competencia personal, social y de aprender a aprender
•
CC: competencia ciudadana
•
CE: competencia emprendedora
•
CCEC: competencia en consciencia y expresión cultural

A continuación, se exponen algunas consideraciones respecto a la relación de las competencias
específicas con las competencias clave.

Es evidente, por la naturaleza de la materia, la relación de todas las competencias específicas con la
competencia matemática y la competencia en ciencia, tecnología e ingeniería.  Es por ello que, si bien se
señalan estas conexiones en el cuadro, se prescinde de unos comentarios que resultarían sin duda obvios

Resolver problemas científicos a partir de investigaciones (CE 1), requiere movilizar todos los
conocimientos y habilidades adquiridos propios de la ciencia, así como las herramientas digitales
(competencia digital) para tratar, procesar y comunicar la información. El propio proceso experimental también
requiere de un trabajo colaborativo, distribuyendo tareas, y de la revisión de los resultados y conocimientos
previos (competencia personal, social y de aprender a aprender).

Esta competencia no puede desarrollarse sin el dominio de las estrategias de comunicación, lo que
moviliza la competencia en comunicación lingüística.

En lo que concierne al análisis de situaciones problemáticas reales utilizando la lógica científica y
explorando las posibles consecuencias de las soluciones propuestas para afrontarlas (CE 2), implica proponer
soluciones y comprobar el resultado de éstas, lo que fuerza a aprender de los errores y a revisar los
conocimientos propios, desarrollando la competencia personal, social y de aprender a aprender. Cuando
implica soluciones a problemas globales, ha de tener en cuenta multitud de factores sociales, y contribuir al
bienestar común desde el respeto a las diferencias y a la diversidad, conectando de este modo con la
competencia ciudadana. También potencia la competencia digital, ya que requiere de la búsqueda avanzada
de información, el tratamiento adecuado de la misma y la comunicación a través de plataformas virtuales y
herramientas informáticas.

La competencia específica referida al uso del conocimiento científico como instrumento del
pensamiento crítico y el desarrollo de la capacidad argumentativa (CE 3) aborda la dimensión comunicativa
de la ciencia, por lo que está estrechamente relacionada con la competencia en comunicación lingüística y la
competencia plurilingüe. Estas relaciones son especialmente destacables en la medida en que estamos en
una comunidad autónoma con lengua propia y la consulta de bibliografía científica requiere a menudo el
conocimiento de otras lenguas como el inglés.

Respecto a la justificación de la validez del modelo científico como producto dinámico (CE 4), se basa
en la naturaleza del sistema de trabajo propio de la ciencia. Con sus limitaciones asociadas a la dependencia
de los principios aplicados en los distintos descubrimientos que se van produciendo y el carácter dinámico
que ello le infiere, el trabajo científico constituye un buen sistema de interpretación de la realidad que facilita
la previsión de acontecimientos y, por tanto, las actuaciones que facilitan la vida a los seres humanos y
permiten prever las consecuencias de sus actos. Por tanto, esta percepción de las limitaciones de la ciencia

y su carácter dinámico debe impregnar todos los niveles educativos y todas las áreas y materias del currículo,
no solo las del ámbito científico y tecnológico. Ello supone plantearse problemas éticos en cuanto a los riesgos
inadecuados del uso del conocimiento científico en la sociedad (competencia ciudadana). En la comprensión
de los modelos científicos se recurre al contexto social, a los hechos y a las relaciones ciencia-tecnología–
sociedad, que hacen que estos modelos adquieran sentido en un momento histórico dado. Su desarrollo
requiere conocer y respetar el patrimonio cultural y artístico en otras épocas que ayudan a comprender la
visión historicista de la ciencia, lo que las vincula con la competencia clave en conciencia y expresión
culturales.

La toma de decisiones respecto a la salud del propio cuerpo (CE 5) implica que el alumnado debe
conocer y practicar hábitos de vida saludable a nivel físico y mental y conocer los riesgos que comporta no
tenerlos en cuenta (competencia personal, social y de aprender a aprender). También la aceptación de las
diferencias culturales en modos de vida, y la valoración y actuación responsable ante las conductas de riesgo
o en la trasmisión de enfermedades infecciosas ayuda a la resolución de conflictos de forma pacífica y
constructiva, contribuyendo al bienestar común (competencia ciudadana).

Por otra parte, la competencia específica referida a la sexualidad personal y el respeto a la variedad
de identidades de género y de orientaciones sexuales (CE 6) afecta directamente a la interacción entre las
personas e implica el respeto a todas las opciones de orientación sexual, lo que la vincula claramente con la
competencia ciudadana y la competencia personal, social y de aprender a aprender.

Las CE 7, 8 y 9 apelan al conocimiento de nuestro planeta y los sistemas que contiene, incluyendo el
mismo como sistema. En ellas se intercalan las implicaciones sociales de las acciones propias que afectan al
resto de la sociedad, en aspectos globales como la pérdida de la biodiversidad, el cambio climático, o la
necesidad de enfrentarse al reto de alcanzar un equilibrio sostenible, con las relaciones sistémicas de
interdependencia, ecodependencia e interconexión entre actuaciones locales y globales, tan imbricadas en la
visión de conjunto del sistema Tierra. Al mismo tiempo, se valora el patrimonio que la naturaleza nos ha
proporcionado en cuanto a recursos geológicos, de ecosistemas, de riqueza paisajística y valores culturales
asociados (competencia ciudadana y competencia personal, social y de aprender a aprender). En cuanto a la
asunción de la importancia del mantenimiento de la biodiversidad asociada al territorio, se vinculan con la
competencia en conciencia y expresión culturales. Por último, actuar con responsabilidad participando
activamente en la conservación de todas las formas de vida y del planeta permitirá el desarrollo de la
competencia emprendedora.

Las CE 10 y 11 se encuentran imbricadas y contribuyen a un planteamiento de la problemática de
tipo ecosocial. Existe una relación especial entre la CE10 y la competencia personal, social y de aprender a
aprender, ya que los problemas ambientales requieren una implicación y un conocimiento de los problemas
asociados a las alteraciones del medio ambiente. Otra conexión destacada en este caso es la competencia
ciudadana, dado el nivel de compromiso con la sociedad que se requiere para abordar los problemas
ambientales y tomar decisiones adecuadas y realistas para resolverlos asumiendo los valores asociados a
los Objetivos de Desarrollo Sostenible relacionados con las alteraciones de la naturaleza y con otros
problemas como, por ejemplo, la pobreza o la falta de vivienda y recursos, asociados a su vez a situaciones
de injusticia social. Por su parte, proponer soluciones realistas y adoptar hábitos responsables está
estrechamente relacionado con la competencia emprendedora.

4. Saberes básicos (para el conjunto de las competencias de la materia)

4.1.    Introducción

Como se indicó al principio de este documento, la selección de los contenidos básicos recogidos en
los bloques que se muestran a continuación viene justificada por la necesidad de los mismos para la

adquisición y desarrollo de las CE que, a su vez, contribuyen a la adquisición y desarrollo de las competencias
clave y, en definitiva, a alcanzar el perfil de salida del alumnado al finalizar la educación básica. Entendemos
que los cinco bloques propuestos resultan imprescindibles para la comprensión del mundo que nos rodea por
cualquier ciudadano o ciudadana, aportando todos aquellos aspectos de la Biología y la Geología que resultan
fundamentales para ello. Asimismo, cada uno de los cinco bloques se trabaja, con diferente nivel de
profundidad en el primer y el tercer curso de la educación secundaria. Dichos bloques, serían los básicos para
la comprensión de la naturaleza, incluyendo el papel del ser humano como parte de la misma y su incidencia
en los procesos naturales.

Habida cuenta de que en la Comunidad Valenciana todo el alumnado cursará la materia de Biología
y Geología en los cursos 1º y 3º de la ESO, los saberes básicos seleccionados por ser necesarios para
alcanzar el nivel de desarrollo competencial esperado al final de la educación obligatoria se distribuyen, con
fines orientativos, entre estos dos cursos. Los saberes básicos se presentan organizados en bloques
vinculados a grupos de competencias específicas estrechamente relacionadas entre sí (ver el apartado 3.1)
y cuya adquisición y desarrollo exige el aprendizaje, articulación y movilización de contenidos igualmente
interrelacionados.

4.2.
Bloque 1: METODOLOGÍA DE LA CIENCIA (CE 1, CE 2, CE 3 y CE 4)

Para desarrollar las competencias relacionadas con la metodología de la ciencia resulta
imprescindible adquirir unos conocimientos básicos sobre el fundamento del trabajo científico, así como unas
determinadas destrezas en el manejo del instrumental y en la realización de las prácticas, en el tratamiento
de los datos y en la comunicación de los resultados. Los saberes básicos que integran estas cuatro
competencias están interrelacionados entre sí conformando un bloque que no se identifica con unos
contenidos curriculares concretos. Más bien se trata de saberes que afectan al resto de los saberes, y que se
incorporan a la práctica educativa mediante su aplicación en cada uno de los temas tratados y en todos los
niveles. En el cuadro se indica el curso (1º, 3º) en el que propone trabajarlos o el nivel de profundidad con el
que propone hacerlo.

| Saberes básicos | CURSO |  |
| --- | --- | --- |
|  | 1º | 3º |
| Contribución de las grandes científicas y científicos en el desarrollo de las ciencias biológicas y geológicas | x | x |
| Estrategias de utilización de herramientas digitales para la búsqueda de la información, la colaboración y la comunicación de procesos, resultados e ideas en diferentes formatos (infografía, presentación, póster, informe, gráfico...) | x | x |
| Lenguaje científico y vocabulario específico de la materia de estudio en la comprensión de informaciones y datos, la comunicación de las propias ideas, la discusión razonada y la argumentación sobre problemas de carácter científico | x | x |
| Procedimientos experimentales en laboratorio: control de variables, toma (error en la medida) y representación de los datos (tablas y gráficos), análisis e interpretación de los mismos | x | x |
| Pautas del trabajo científico en la planificación y ejecución de un proyecto de investigación en equipo: identificación de preguntas y planteamiento de problemas que puedan responderse, formulación de hipótesis, contrastación y puesta a prueba a través de la experimentación, y comunicación de resultados | x | x |
| Procedimientos y métodos de observación de hechos o fenómenos naturales desde el prisma del naturalista inquieto: capacidad de incorporar las observaciones a los conocimientos adquiridos y cuestionamiento de lo evidente | x | x |

| Instrumentos, herramientas y técnicas propias del laboratorio de biología. Normas de seguridad en el laboratorio | x | x |
| --- | --- | --- |

Las herramientas digitales utilizadas pueden ser las mismas en los dos cursos, pero trabajadas de
forma más pautada o guiada en primero y de forma más autónoma en el tercero. En el tercer curso el
alumnado puede ser más autónomo para elegir la herramienta más adecuada para comunicar sus resultados
dependiendo de la tarea desarrollada. Esto mismo sucede en el resto de los saberes de este bloque.

4.3.
Bloque 2: CUERPO HUMANO Y HÁBITOS SALUDABLES (CE 5 y CE 6)

Este bloque, relacionado con el conocimiento del propio cuerpo y los hábitos saludables, se encuentra
más próximo que otros a la experiencia del alumnado y además trata de aspectos fundamentales para la
salud y el bienestar del individuo. La comprensión de los contenidos resulta accesible al alumnado de niveles
iniciales de secundaria. Es por ello que se propone trabajar los contenidos de este bloque en el primer curso,
con un planteamiento centrado en un conocimiento del propio cuerpo y el reconocimiento de la diversidad
humana, dejando para cursos posteriores, ya en la educación postobligatoria, la profundización en aspectos
más técnicos en cuanto a la estructura y funcionamiento del organismo.

| Saberes básicos | CURSO |  |
| --- | --- | --- |
|  | 1º | 3º |
| Niveles de organización de la materia viva y organización general del cuerpo humano (célula, tejido, órgano, aparatos o sistemas) Concepto de ser pluricelular | x |  |
| La salud y la enfermedad. Enfermedades infecciosas y no infecciosas. Higiene y prevención | x |  |
| Sistema inmunitario. Vacunas. Los trasplantes y la donación de células, sangre y órganos | x |  |
| La homeostasis y su relación con el mantenimiento de la vida |  | x |
| Necesidades nutricionales: los nutrientes, los alimentos y hábitos alimenticios saludables y sostenibles. Dietas saludables y trastornos de la conducta alimentaria | x |  |
| La función de nutrición. Relación entre los diferentes aparatos digestivo, respiratorio, circulatorio y excretor y visión global de la nutrición en el ser humano | x |  |
| La función de relación: coordinación entre sistema nervioso, sistema endocrino y aparato locomotor. Prevención de lesiones | x |  |
| Las sustancias adictivas: el tabaco, el alcohol y otras drogas. Problemas asociados. | x | x |
| Alteraciones más frecuentes, enfermedades asociadas, prevención de las mismas y hábitos de vida saludables en relación a las funciones de nutrición, relación y reproducción | x | x |
| La reproducción humana. Anatomía y fisiología del aparato reproductor. El ciclo menstrual. Fecundación, embarazo y parto. Análisis de los diferentes métodos anticonceptivos y de las técnicas de reproducción asistida | x | x |
| Prevención de las enfermedades de transmisión sexual | x | x |
| Cambios físicos y psíquicos en la adolescencia | x | x |
| Relaciones y sexualidad: derechos e igualdad; sexo, género y sexualidad; salud y bienestar sexual; violencia y prevención de amenazas de género en la sociedad digital | x | x |

Los saberes de este bloque se presentan organizados en dos grupos reflejados en dos tablas
diferentes. Los del primer grupo, correspondiente a la tabla superior, se trabajan, en su mayoría, solo en el
primer curso y sientan las bases para profundizar en el tercer curso diferentes aspectos de los mismos
contenidos. Así, los hábitos saludables en funciones de nutrición y relación pueden reforzarse en tercer curso,
a la par que también se tratan desde otras materias como, por ejemplo, en Educación Física. En cuanto a los
saberes relacionados con sexualidad y reproducción, el diferente grado de madurez a lo largo de la etapa
obliga a retomar desde otra óptica los mismos conceptos. En el primer curso se abordará como conocimiento
del propio cuerpo, mientras que en tercer curso se profundizará en el conocimiento de las relaciones
interpersonales.

4.4.
Bloque 3: LOS SERES VIVOS (CE 7)

Los saberes de este bloque se organizan en torno a grandes conceptos globales relacionados con el
conocimiento de los seres vivos (ser vivo como sistema, ecosistema, ciclo vital, teoría celular, clasificación
general de los seres vivos, adaptaciones…). No es necesario profundizar en las categorías taxonómicas
menores. Sí lo es entender el proceso general jerárquico de clasificación y las adaptaciones como
consecuencia de la selección natural. No parece necesario entrar en detalles sobre los tipos de invertebrados
más allá de destacar su importancia en los ecosistemas y de estudiar ejemplares concretos para entender su
organización corporal básica.

| Saberes básicos | CURSO |  |
| --- | --- | --- |
|  | 1º | 3º |
| El ser vivo como sistema: propiedades y diferencias con la materia inerte. Funciones de nutrición, relación y reproducción de los seres vivos | x |  |
| Teoría celular. En primer curso concepto de célula y teoría celular, y en tercer curso principales tipos celulares (célula procariota, eucariota animal y vegetal) y sus diferencias básicas | x | x |
| Nutrición autótrofa y heterótrofa | x |  |
| Tipos división celular (mitosis y meiosis). Relación con la reproducción sexual y asexual y los ciclos de reproducción de los seres vivos |  | x |
| Niveles de organización de los seres vivos |  | x |
| La clasificación de los seres vivos: criterios de clasificación naturales |  | x |
| Nomenclatura binomial: concepto de especie |  | x |
| Sistema de clasificación taxonómica y jerárquica, categorías más importantes |  | x |
| Dominios y reinos de seres vivos (en primero, breve descripción; en tercero, profundizando en las características) | x | x |
| Principales grupos de seres vivos de cada reino: ejemplos de rasgos característicos de las categorías taxonómicas más relevantes y relación con sus adaptaciones a las condiciones ambientales |  | x |
| Ciclos de la materia, flujos de energía y pirámides tróficas | x |  |
| Concepto de ecosistema | x |  |
| La biodiversidad y la necesidad de su conservación | x |  |
| Ecodependencia de los seres vivos e importancia del mantenimiento de todas las formas de vida para la salud humana | x |  |
| Ciclos biológicos y modos de reproducción de seres vivos (bacterias, hongos, protoctistas, plantas y animales sencillos) |  | x |

| Estrategias de reconocimiento y estudio de especies más comunes de los ecosistemas del entorno (guías, claves dicotómicas, visu, herramientas digitales...) |  | x |
| --- | --- | --- |

4.5.
BLOQUE 4: La Tierra (CE 8 y CE 9)

Este bloque, destinado al estudio del planeta Tierra, su contexto, estructura y dinámica, aborda la
introducción de un concepto fundamental para una adecuada comprensión, no solo del propio planeta, sino
de otros elementos y fenómenos asociados. Nos referimos al concepto de sistema. Este concepto aparece
también en otras áreas, lo que lo convierte en un elemento esencial para la comprensión de la realidad por
parte del alumnado. Vivimos en un planeta en continuo cambio que, a escala de tiempo geológico, ha sufrido
uniones y divisiones continentales, variaciones del nivel del mar, cambios climáticos y apariciones y
extinciones de especies; un planeta en el que ocurren infinidad de fenómenos naturales como terremotos,
erupciones volcánicas o inundaciones. Esta Tierra dinámica es nuestro hogar, de ella extraemos los recursos
que necesitamos y de ella depende nuestra existencia y la del resto de organismos que la habitan. Las
ciencias de la Tierra resultan imprescindibles para dar respuesta a muchos de los retos a los que se enfrenta
la humanidad en el siglo XXI.

El conocimiento de la dinámica y composición de nuestro planeta permite al alumnado comprender
el origen de determinados fenómenos, algunos de ellos de tipo catastrófico, que se producen de manera más
o menos súbita en nuestro entorno. Pero, además, la dinámica de otros sistemas que forman parte de la
Tierra, como la atmósfera o la hidrosfera, es responsable asimismo de ciclos fundamentales para el desarrollo
de la vida y sufren importantes alteraciones debido a las acciones humanas, lo que vincula este bloque con
el siguiente, puesto que la comprensión de esos ciclos facilitará, a su vez, la de dichas interacciones y los
factores causantes, así como de las medidas urgentes a tomar por nuestra especie para preservar la vida tal
como la concebimos.

| Saberes básicos | CURSO |  |
| --- | --- | --- |
|  | 1º | 3º |
| Tipos de procesos geológicos | x |  |
| La Tierra como sistema complejo en el que interaccionan rocas, agua, aire y vida: procesos geológicos externos | x |  |
| Origen de la Tierra y del Sistema Solar | x |  |
| Los materiales de la Tierra: origen y tipos | x |  |
| Relación de objetos y materiales cotidianos con los minerales y rocas utilizados en su fabricación | x |  |
| Estructura básica de la Tierra | x |  |
| Dinámica interna de los materiales terrestres: manifestaciones de la energía interna. En primer curso, se estudiarán los terremotos y volcanes como manifestaciones de la energía interna del planeta y, en el tercer curso, se estudia su distribución y las causas (Tectónica de Placas) | x | x |
| El tiempo en geología: escalas y medida del tiempo | x | x |
| Relaciones entre los cambios en la historia de la Tierra y el origen y la evolución de la vida (acontecimientos que marcan las divisiones temporales) |  | x |
| Recursos geológicos y sostenibilidad | x |  |
| Riesgos geológicos y cambio climático | x | x |

4.6.
Bloque 5: Sostenibilidad (CE 10 y CE 11)

Las competencias relacionadas con este bloque son transversales, por lo que los principios en que
se basan deben estar presentes también en otras materias. La incidencia de las acciones humanas sobre los
ecosistemas, así como los problemas asociados, causa de la actual situación de emergencia climática y las
medidas paliativas y adaptativas que deben tomarse ya en la actualidad o en el futuro constituyen elementos
esenciales que requieren un trabajo multidisciplinar. Así, los saberes básicos propuestos para este bloque,
contribuyen a la adquisición y desarrollo de la práctica totalidad de las competencias de esta materia, así
como a las del resto del ámbito de las ciencias de la naturaleza. La propuesta de ubicación en este bloque se
debe a la necesidad de establecer unos contenidos, asociados a la materia, imprescindibles para una
adecuada comprensión de los problemas y un aporte de herramientas para afrontarlos de una forma crítica,
responsable y realista.

| Saberes básicos | CURSO |  |
| --- | --- | --- |
|  | 1º | 3º |
| Principales problemas medioambientales: contaminación, desertización, cambio climático, pérdida de biodiversidad, agotamiento de recursos, etc... | x |  |
| Los ODS, relaciones entre ellos: el factor ecosocial y consecuencias sociales asociadas a los problemas ambientales | x |  |
| Acciones de protección del medio ambiente o de mitigación de los problemas ambientales | x |  |
| Corresponsabilidad en la protección ambiental. La importancia de las acciones individuales, locales y globales. En primer curso, se debería adquirir el conocimiento sobre posibles acciones, y en tercero debería poder concretarse mediante estudios técnicos más pormenorizados | x | x |
| Medio ambiente y salud. Influencia de los desequilibrios ambientales sobre las enfermedades y el bienestar |  | x |
| La desigualdad dentro de los países y entre ellos. Relación con la salud. La brecha nutricional y el desarrollo de enfermedades |  | x |

Se propone abordar en el primer curso la problemática asociada e la incidencia humana sobre el
medio y las implicaciones sobre las poblaciones humanas, incluyendo las situaciones de injusticia social que
se generan. En el tercer curso se profundizará en la concreción de las consecuencias sobre la salud humana
y el conocimiento de la relación entre las distintas problemáticas.

5. Situaciones de aprendizaje para el conjunto de las competencias del área/materia

Las situaciones de aprendizaje plantearán tareas complejas en las que el alumnado esté obligado a
movilizar y articular una serie de recursos, saberes y habilidades para resolverlas. Han de incorporar
cuestiones que ayuden a la reflexión sobre el propio pensamiento, afrontando los retos del perfil de salida y
facilitando la construcción de los aprendizajes sobre los conocimientos previos.

Entre los criterios que conviene tener en cuenta para diseñar estas situaciones, cabe mencionar las
siguientes:

1. Plantearán un problema, reto o situación en el que la demanda sea clara y explícita. Los retos
pueden ser lo bastante amplios como para implicar a varias materias y requerir de la colaboración de los

compañeros para su resolución. Así, por ejemplo, se puede plantear al alumnado que estudie y proponga
soluciones para reducir el consumo energético o de recursos de la escuela, cómo prevenir o actuar ante un
terremoto o inundación, o cómo abordarían la búsqueda de vida en el espacio exterior. La tarea consistirá en
recabar información en torno al problema y diseñar una propuesta.

2. Contribuirán al desarrollo de una o varias competencias específicas.

3. Integrarán saberes básicos, esto es, para resolver la situación será necesario movilizar y
articular saberes básicos incluidos en los bloques de contenidos.

4. Se adecuarán a la edad y al nivel de desarrollo cognitivo del alumnado. Las situaciones de
aprendizaje propuestas han de ser inclusivas y permitir que todo el alumnado pueda abordarlas y resolverlas.
De esta forma, una propuesta de mejora de la sostenibilidad del centro puede partir del análisis de la situación
medioambiental del mismo, en la que, en función de la madurez del alumnado, se pueden trabajar gráficas
con datos de consumo y facturas reales hasta simples observaciones del estado del patio y la escuela o del
uso de la iluminación natural o artificial, mediante patrullas de ecoauditores con distintos niveles de
complejidad para abordar el mismo aspecto.

5. Serán significativas, relevantes y estimulantes para el alumnado porque tratan temas de su
interés o bien porque el enfoque propuesto es atractivo. En este sentido, las situaciones próximas a su realidad
sobre la toma de decisiones en aspectos de hábitos saludables (alimentación, prevención de usos
inadecuados de las TIC, consumo de sustancias adictivas y tóxicas...), o los debates en torno a supuestas
elecciones relacionadas con la reproducción humana y sexualidad, como la interrupción del embarazo o la
reproducción asistida mediante embriones congelados, plantean situaciones próximas en las que se deben
movilizar conocimientos para justificar y argumentar adecuadamente las decisiones, con respuestas abiertas
e interpretaciones cuestionables.

6. Requerirán un enfoque crítico y reflexivo porque la situación planteada puede incluir una
demanda de posicionamiento una vez resuelta la situación teniendo en cuenta la perspectiva global (desarrollo
sostenible, consumo responsable, salud, higiene, alimentación, igualdad y equidad...). Un ejemplo cercano lo
tenemos en el rápido desarrollo de las vacunas frente a la COVID 19. Otro ejemplo, en esta ocasión con
connotaciones negativas, lo tenemos en el rápido desarrollo de tecnologías, principalmente de tipo
armamentístico, que se produce en tiempos de guerra, siendo utilizadas algunas de ellas con posterioridad
en la construcción de aparatos de uso pacífico, favoreciendo en muchos casos el avance científico, como es
el caso del sonar y el estudio del interior de la Tierra.

7. Favorecerán  la cooperación y el trabajo en equipo desarrollando las competencias
socioemocionales.

8. Conllevarán la resolución creativa de una pregunta o problema al ser las situaciones
planteadas suficientemente abiertas para que no tengan una única respuesta o solución. En este sentido, se
puede plantear, por ejemplo, qué implicaciones tendría la prohibición de la experime ntación con animales en
el desarrollo de la medicina, la eliminación de especies foráneas introducidas hace muchos años en nuestros
ecosistemas, o las propuestas de compaginar las medidas contra el cambio climático con el desarrollo
económico y humano.

9. Implicarán la comunicación y representación de estrategias, procesos y soluciones y la
evaluación pondrá énfasis tanto en el proceso como las soluciones finales. Conviene recordar a este respecto
que la evaluación es una herramienta cuya finalidad no es únicamente calificar, sino también y sobre todo
facilitar una retroalimentación continua del proceso de enseñanza y aprendizaje para ajustar los ritmos,
contenidos y procedimientos didácticos utilizados.

10. Abordarán temas de interés público y relacionados con la sostenibilidad y la convivencia
democrática (participación ciudadana, igualdad de género, trabajo tomando como referencia los Objetivos de
Desarrollo Sostenible y la Agenda 2030 de la Organización de las Naciones Unidas), con análisis de datos,
diagnóstico y propuestas de actuación en base a ello.

11. Movilizarán saberes científicos y de otras materias del currículo estableciendo conexiones
entre ellos y las experiencias adquiridas por el alumnado en diferentes contextos. (Importancia de la
interdisciplinariedad para abordar los problemas). El diseño de actividades experimentales sencillas permite
estudiar tanto las características (modelos organizativos) como los cambios en los seres vivos y ecosistemas
(observaciones en el laboratorio de plantas, seres vivos, ecosistemas, o salidas a la naturaleza o al exterior).

A continuación, y a modo de ilustración, se señalan posibles situaciones de aprendizaje, cada una
para una dimensión diferente del conocimiento de la materia de Biología y Geología.

• Dimensión salud:

Una posibilidad es plantear una situación problemática en la que el alumnado tenga que decidir y
argumentar para tomar una decisión en base a su propio conocimiento y experiencia. Si tomamos el ámbito
de la sexualidad, como cualquier otro de la salud, las conductas de riesgo y los problemas derivados pueden
ser una buena base. Se desarrolla una tarea de debate en pequeños grupos en la que el alumnado tiene un
rol asignado (experto científico, ciudadano, político, …) planteando situaciones imaginadas (la clonación
humana como posibilidad reproductora, la utilización de embriones humanos genéticamente seleccionados
para la reproducción asistida, o la  investigación con embriones) o más reales y cercanas al contexto del
alumnado en las que debe tomar una decisión en torno a una cuestión ética como, por ejemplo, la
reproducción asistida, la decisión de interrumpir o no un embarazo no deseado, la legalización del cambio de
sexo en menores de edad, la identidad sexual, etc... En estos debates se movilizan saberes esenciales (para
argumentar hay que conocer), se busca información y se construyen argumentos.

• Dimensión medio ambiente:

Las situaciones de aprendizaje, en esta dimensión, pueden partir del planteamiento de un problema
ambiental y la búsqueda de soluciones. Esto se relaciona con el planteamiento de este bloque y la
responsabilidad que supone el cuidado de nuestro planeta y la asunción de valores éticos compatibles con el
ejercicio de la equidad, la inclusividad y la explotación sostenible de los recursos. Las acciones que se
propongan como solución podrían partir de problemas locales, situados en el propio centro o las viviendas
particulares, para ir hacia propuestas globales. En este sentido, las situaciones pueden incluir la participación
activa del alumnado en la gobernanza de los centros, el diagnóstico de los mismos y la colaboración con las
instituciones. Esto genera propuestas de mejora que deberían asociarse a una asunción de compromisos.
Asimismo, la creación en los centros de consejos ambientales o de sostenibilidad, de carácter democrático y
en los que el alumnado sea protagonista de los procesos de toma de decisiones, acciones y evaluación,
puede resultar de utilidad en el desarrollo de las competencias específicas propuestas.

Por otro lado, el que este alumnado comparta con representantes de otros centros, de la misma zona
o de otras más o menos lejanas, sus conclusiones, proyectos y expectativas potenciará la interiorización de
los valores y el desarrollo de las competencias.

• Dimensión planeta Tierra y su dinámica

La dinámica que afecta a nuestro planeta y su importancia sobre los cambios que lleva asociados es
fundamental para la comprensión de la responsabilidad del ser humano sobre la conservación del entorno.
La incidencia sobre nuestras vidas de este dinamismo, con fenómenos tan habituales en nuestro planeta
como terremotos, volcanes y fenómenos meteorológicos extremos, puede ayudar a plantear situaciones de
aprendizaje en las que el alumnado desarrolle una percepción real de dicha situación. En cuanto a

composición terrestre, el uso que se da a los distintos materiales y la relación de sus características con dicho
uso facilitarán la comprensión de su naturaleza y aproximará al alumnado a su conocimiento.

6. Criterios de evaluación

6.1. Consideraciones previas:

Considerando el nivel evolutivo del alumnado, existen competencias que deben adquirirse a una edad
más temprana, por lo que los criterios de evaluación correspondientes se establecen para el primero de los
dos cursos en los que se impartirá la materia de Biología y Geología. Así ocurre con las relacionadas con la
salud y el bienestar. Cuando inicia la ESO, el alumnado está experimentando cambios hormonales asociados
a la adolescencia que modifican su cuerpo y su mente, especialmente en aspectos relacionados con el sexo
y las relaciones interpersonales. Por ello, es aconsejable incidir especialmente en esta competencia en este
momento y así prevenir la aparición de posibles problemas asociados a estos aspectos, tales como las
enfermedades de transmisión sexual o los embarazos no deseados.

CE1. Resolver problemas científicos abordables en el ámbito escolar a partir de trabajos de
investigación de carácter experimental.

| 1er curso de la ESO | 3er curso de la ESO |
| --- | --- |
| 1.1 - Aplicar correctamente las normas de seguridad propias del trabajo experimental | 1.1 - Realizar una interpretación adecuada de los hechos observados o los datos disponibles para contrastar hipótesis y extraer conclusiones que le resultan de utilidad en su conocimiento del mundo que le rodea |
| 1.2 - Observar hechos, formular preguntas investigables y emitir hipótesis comprobables científicamente | 1.2 - Elaborar informes de las investigaciones que justifiquen correctamente las conclusiones obtenidas de acuerdo con los resultados obtenidos y en el marco de los modelos o teorías |
| 1.3 - Realizar búsquedas de información y recogida de datos, atendiendo a criterios de validez, calidad y fiabilidad de las fuentes (3er curso) de forma guiada | 1.3 - Argumentar, debatir y razonar sobre el problema investigado y la validez de la experiencia propuesta |
| 1.4 - Diseñar experimentos para comprobar hipótesis y obtener resultados que las validen o refuten siguiendo las pautas del trabajo científico |  |
| 1.5 - Elaborar informes sencillos de las investigaciones realizadas |  |

CE2 -   Analizar situaciones problemáticas reales utilizando la lógica científica y explorando las
posibles consecuencias de las soluciones propuestas para afrontarlas.

| 1er curso de la ESO | 3er curso de la ESO |
| --- | --- |
| 2.1 - Utilizar con acierto las herramientas informáticas necesarias para su trabajo de forma guiada | 2.1 - Utilizar correctamente los términos más habituales asociados a los distintos ámbitos de la ciencia. |
| 2.2 - Analizar críticamente la solución propuesta a un problema sencillo en función de los saberes básicos que se movilizan | 2.2 - Utilizar correctamente las herramientas informáticas necesarias para su trabajo |

| 2.3 - Utilizar el conocimiento científico adquirido para interpretar los fenómenos que ocurren a su alrededor | 2.3 - Analizar críticamente la solución propuesta a un problema complejo en función de los saberes básicos que se movilizan |
| --- | --- |
|  | 2.4 - Elegir la herramienta informática adecuada para presentar los resultados de sus trabajos de forma autónoma |
|  | 2.5 - Construir explicaciones que relacionan los hechos y conceptos indicando sus limitaciones y movilizando conocimientos complejos |

CE3 - Utilizar el conocimiento científico como instrumento del pensamiento crítico, interpretando y
comunicando mensajes científicos, desarrollando argumentaciones y accediendo a fuentes fiables, para
distinguir la información contrastada de los bulos y opiniones.

| 1er curso de la ESO | 3er curso de la ESO |
| --- | --- |
| 3.1 - Identificar hipótesis, pruebas y conclusiones en un discurso para distinguir adecuadamente una opinión de una afirmación basada en pruebas con base científica | 3.1 - Utilizar la adecuación de las afirmaciones o textos a los modelos y conocimientos teóricos como criterio para validar las afirmaciones y distinguirlas de valoraciones personales o faltas de rigor, en función de los saberes básicos movilizados para validarlos |
| 3.2 - Conocer algunas fuentes que se ajusten a los criterios de objetividad, revisión y fiabilidad que caracterizan a la ciencia a las que acudir para recabar información | 3.2 - A partir de observaciones de fenómenos o hechos, construir una argumentación que dé base a una afirmación o que desmienta otra en retos de una dificultad ajustada a los saberes básicos del nivel |
| 3.3 – Comunicarse, de forma oral y escrita, utilizando el lenguaje científico para participar en intercambios o en debates, interpretando o produciendo mensajes científicos de nivel básico | 3.3 - Comunicarse utilizando el lenguaje científico para participar en intercambios o en debates, interpretando y produciendo mensajes científicos, con un rigor medio, adecuado a los saberes básicos propios del nivel |
| 3.4 - Utilizar fuentes de información variada para construir sus argumentaciones (textos escritos, audios, gráficas, infografías, vídeos) con un bajo grado de complejidad | 3.4 - Desarrollar una actitud abierta y receptiva hacia la diversidad de conocimientos, puntos de vista y enfoques |
|  | 3.5 - Utilizar fuentes de información variada para construir sus argumentaciones (textos escritos, audios, gráficas, infografías, vídeos) con un grado de complejidad medio |

CE4 - Justificar la validez del modelo científico como producto dinámico que se va revisando y
reconstruyendo bajo la influencia del contexto social e histórico, atendiendo a la importancia de la ciencia en
el avance de las sociedades, así como a los riesgos de un uso inadecuado o interesado de los conocimientos
científicos y a sus limitaciones.

| 1er curso de la ESO | 3er curso de la ESO |
| --- | --- |
| 4.1 - Aportar ejemplos de utilización positiva y | 4.1 - Argumentar el valor el trabajo de las mujeres |

| negativa del conocimiento científico | científicas y de las distintas culturas a la ciencia |
| --- | --- |
| 4.2 - Utilizar un lenguaje inclusivo en sus trabajos conociendo ejemplos de las aportaciones de las mujeres y de las distintas culturas a la ciencia | 4.2 - Asociar las ideas científicas actualmente descartadas con el contexto histórico en el que predominaron, justificando los modelos teóricos a la luz de los conocimientos disponibles en un momento histórico dado y huyendo de la crítica fácil en función de los conocimientos implicados |
| 4.3 - Aportar ejemplos de cambios sufridos por las teorías científicas con el tiempo | 4.3 - Relacionar los avances tecnológicos con algunos avances científicos que los acompañaron o se asociaron a ellos en función de los saberes básicos implicados |
| 4.4 - Señalar algunos de los avances tecnológicos que han facilitado el desarrollo de la ciencia | 4.4 - Argumentar la validez de las explicaciones y argumentaciones relacionándolas con las pruebas obtenidas y los modelos teóricos en los diferentes momentos de la ciencia, en función de la dificultad de las argumentaciones y modelos asociados a lo contenidos básicos |

CE5. Adoptar hábitos de vida saludable basados en el conocimiento del funcionamiento del propio
cuerpo y de los peligros del uso y abuso de determinadas prácticas y del consumo de algunas sustancias.

| 1er curso de la ESO | 3er curso de la ESO |
| --- | --- |
| 5.1 - Explicar adecuadamente qué requerimientos debe cumplir una dieta sana, equilibrada y sostenible | 5.1 - Explicar los fundamentos de los métodos anticonceptivos, así como la efectividad real de los mismos, en base al conocimiento del funcionamiento del propio cuerpo |
| 5.2 - Realizar una alimentación consumiendo productos sanos y de proximidad | 5.2 - Justificar las respuestas del cuerpo humano a las alteraciones producidas por lesiones o inducidas mediante enfermedades o sustancias, desde la perspectiva del modelo de ser vivo pluricelular de organización compleja, que responde mediante mecanismos de retroalimentación para mantener su homeostasis |
| 5.3 - Explicar las consecuencias que se generan debido a la ignorancia de los hábitos saludables |  |
| 5.4 - Explicar la importancia de las medidas preventivas frente a las infecciones, incluyendo la vacunación. |  |
| 5.5 - Demostrar conocimiento de las medidas preventivas adecuadas a la hora de mantener relaciones sexuales para prevenir enfermedades de transmisión sexual o embarazos no deseados | 5.3 - Explicar el concepto de homeostasis y su relación con el mantenimiento de la vida y la prevención de enfermedades |

CE6. Identificar y aceptar la sexualidad personal, y respetar la variedad de identidades de género y
de orientaciones sexuales existentes, en base al conocimiento del cuerpo humano y del propio cuerpo.

| 1er curso de la ESO | 3er curso de la ESO |
| --- | --- |
| 6.1 - Explicar de forma adecuada las diferencias entre los conceptos de reproducción, sexo, género y orientación sexual | 6.1 - Elegir con total libertad su opción relativa a orientación sexual o género entre todas las posibles |
| 6.2 - Respetar y defender con argumentos todas las posibles opciones de manifestación de la sexualidad | 6.2 - Argumentar en torno a las cuestiones sobre la adopción de medidas preventivas relacionadas con la práctica sexual. |

| 6.3 - Demostrar, en sus relaciones interpersonales, respeto a la hora de decidir los pasos a dar en cada momento y respetar los cambios de opinión que puedan surgir en este sentido |  |
| --- | --- |

CE7. Actuar con responsabilidad participando activamente en la conservación de todas las formas de
vida y del planeta en base al conocimiento de los sistemas biológicos y geológicos.

| 1er curso de la ESO | 3er curso de la ESO |
| --- | --- |
| 7.1 - Respetar todas las formas de vida, siendo capaces de explicar la dependencia del ser humano del resto de seres vivos | 7.1 - Explicar la actual biodiversidad como resultado de un proceso de selección natural, según eventos explicados actualmente por la ciencia |
| 7.2 - Identificar y valorar algunos indicadores de la incidencia de la actividad humana sobre los fenómenos geológicos externos y de estos sobre la vida en la Tierra | 7.2 - Manejar claves dicotómicas para clasificar correctamente distintos seres vivos |
| 7.3 - Prever algunas de las posibles consecuencias de los fenómenos de nuestro planeta a partir de datos obtenidos mediante métodos fiables conocidos, valorando la importancia del papel de la ciencia en dichas previsiones | 7.3 - Proponer soluciones para paliar las consecuencias de la actividad humana sobre el planeta o para prevenir los fenómenos responsables de las mismas |
| 7.4 - Clasificar correctamente, a nivel de reino, distintos organismos en función de sus características más destacables | 7.4 - Reconocer el significado del concepto especie |
|  | 7.5 - Argumentar sobre la necesidad de conservar todas las formas de vida |

CE8. Utilizar el conocimiento geológico básico sobre el funcionamiento del planeta Tierra como
sistema, con el fin de analizar su impacto sobre las poblaciones y proponer y valorar actuaciones de previsión
e intervención.

| 1er curso de la ESO | 3er curso de la ESO |
| --- | --- |
| 8.1 - Explicar los rasgos más generales del relieve como consecuencia de los procesos geológicos | 8.1 - Explicar el funcionamiento de la Tierra y saber aplicar ese conocimiento básico para justificar, desde una visión de conjunto, la distribución de volcanes y terremotos |
| 8.2 - Analizar e identificar algunas de las principales interacciones entre la humanidad y el planeta | 8.2 - Explicar la dinámica de construcción- destrucción del relieve terrestre y asociarla con los cambios que observamos en nuestro planeta |
| 8.3 - Argumentar la necesidad del uso sostenible de los recursos | 8.3 - Explicar los riesgos naturales y sus causas, así como la influencia de la actividad humana en su intensidad |
| 8.4 - Buscar y seleccionar información relevante sobre algunos de los procesos que afectan a la Tierra, formulando preguntas pertinentes sobre ellos y valorando si determinadas evidencias apoyan o no una determinada conclusión | 8.4 - Interpretar los fenómenos o hechos de una manera global, analizando los cambios que se producen cuando se modifican las condiciones o se realiza una intervención |
| 8.5 - Valorar la importancia de los principios | 8.5 - Interpretar los ciclos de materia y los flujos de |

geológicos básicos y los procedimientos más
elementales y usuales de la Geología para la
construcción del conocimiento científico sobre la
Tierra

la energía para valorar la importancia en la dinámica
terrestre y para los seres vivos

| 8.6 - Analizar un fenómeno geológico identificando sus componentes, las relaciones entre ellos y su funcionamiento como sistema no reductible a esos componentes y relaciones por separado | 8.6 - Analizar la estructura y composición de los diferentes materiales terrestres (minerales rocas) y sus principales aplicaciones en el ámbito de la vida cotidiana |
| --- | --- |

CE9.  Analizar e interpretar los principales hitos de la historia del planeta Tierra y los principales
procesos evolutivos de los sistemas naturales, atendiendo a las magnitudes del tiempo geológico implicadas
en ellos.

| 1er curso de la ESO | 3er curso de la ESO |
| --- | --- |
| 9.1 - Apreciar la magnitud del tiempo geológico en comparación con el histórico, y ambos con la duración de la vida de un individuo, distinguiendo las diferentes escalas en que ocurren los fenómenos geológicos, históricos y personales | 9.1 - Explicar el papel determinante de la historia geológica para la evolución de los seres vivos, tanto en su relación con las grandes extinciones, como en el proceso de cambio gradual de la selección natural |
| 9.2 - Reconocer evidencias de los cambios en el registro de la tierra identificándolos y situándolos en un eje cronológico | 9.2 - Relacionar y aplicar la perspectiva temporal sobre los profundos cambios que han afectado a nuestro planeta en el pasado y a los organismos que lo han poblado |
|  | 9.3 - Argumentar y valorar la importancia del conocimiento de los fenómenos naturales del pasado para entender el presente |
|  | 9.4 - Justificar la biodiversidad como resultado del proceso de selección natural |
|  | 9.5 - Justificar los cambios geológicos como resultados de los procesos geológicos externos e internos identificando las causas que los originan (tectónica de placas y agentes geológicos externos) |

CE10. Adoptar hábitos de comportamiento en la actividad cotidiana responsables con el entorno,
aplicando criterios científicos y evitando o minimizando el impacto medioambiental.

| 1er curso de la ESO | 3er curso de la ESO |
| --- | --- |
| 10.1 - Interpretar datos técnicos en torno a los problemas que origina la acción humana sobre su entorno y la emergencia climática | 10.1 - Utilizar su conocimiento sobre el funcionamiento de los ecosistemas para detectar las acciones humanas que los alteran |
| 10.2 - Ser capaz de describir las consecuencias para las poblaciones humanas de procesos como la destrucción de biodiversidad, la desertización y, asociada a ella, la migración climática | 10.2 - Proponer soluciones para paliar las distintas formas de alteración humana de los ecosistemas |
| 10.3 - Adoptar hábitos respetuosos para el medio que generan la menor cantidad de residuos posible o que son susceptibles de ser reciclados | 10.3 - Describir las pautas principales para realizar un consumo sostenible y de proximidad, así como las consecuencias ambientales y sociales que se derivan de no aplicarlas |

| 10.4 - Reducir el consumo de recursos a nivel personal y en sus hábitos diarios |  |
| --- | --- |
| 10.5 - Explicar correctamente los factores más significativos responsables de la situación de emergencia climática que sufre el planeta |  |

CE11. Proponer soluciones realistas basadas en el conocimiento científico ante problemas de
naturaleza ecosocial a nivel local y global, argumentar su idoneidad y actuar en consecuencia.

| 1er curso de la ESO | 3er curso de la ESO |
| --- | --- |
| 11.1 - Diagnosticar problemas presentes en su entorno cercano relacionados con el medio | 11.1 - Proponer y participar en la adopción de medidas locales y globales de mitigación de la crisis climática orientadas a evitar que las temperaturas sigan incrementándose |
| 11.2 - Proponer acciones de concienciación y reivindicativas en relación con los problemas ambientales, utilizando el procedimiento adecuado para ello con ayuda del profesorado | 11.2 – Utilizar las fuentes adecuadas para documentarse en torno a causas y posibles soluciones a los problemas ambientales que les permiten argumentar y defender sus propuestas |
| 11.3 - Asociar situaciones de problemas de tipo social, como la inmigración masiva, a la alteración de los ecosistemas de origen humano, tales como la sobreexplotación de recursos o la desertificación |  |

BIOLOGÍA Y GEOLOGÍA. ADDENDA PARA EL 4º CURSO DE ESO

SABERES BÁSICOS

A. Proyecto científico
•
Formulación de preguntas, hipótesis y conjeturas científicas.
•
Colaboración y comunicación de procesos, resultados o ideas en diferentes formatos (presentación,
gráfica, vídeo, póster, informe...) seleccionando la herramienta más adecuada.
•
Reconocimiento y utilización de fuentes veraces de información científica.
•
Diseño de pequeñas investigaciones justificando el desarrollo de las mismas en base al método
científico para obtener resultados objetivos y fiables en un experimento.
•
Utilización de herramientas, instrumentos y espacios (laboratorio, aulas, entorno...) de forma
adecuada y precisa.
•
Principales modelos como interpretaciones y representaciones de fenómenos y hechos, que abarcan
los conceptos e ideas para explicar los fenómenos naturales (modelo de célula, ser vivo, evolución,
ecosistema...).
•
Métodos de observación de fenómenos, descripción precisa y análisis de resultados.
•
Diferenciación entre correlación y causalidad.
•
Papel de las grandes científicas y científicos en el desarrollo de las ciencias biológicas y geológicas.
•
Teorías y modelos científicos en su contexto histórico: el conocimiento científico como un proceso en
continuo cambio y perfeccionamiento.
•
Búsqueda y selección de información de carácter científico mediante herramientas digitales y otras
fuentes.
•
Interpretación de información de carácter científico y su utilización para formarse una opinión propia,
expresarse con precisión y tomar decisiones sobre problemas científicos abordables en el ámbito
escolar.

B. La célula
•
Teoría celular.
•
Tipos de célula y organización celular.
•
Estructura y composición de la célula eucariótica.
•
Análisis de las fases del ciclo celular.
•
Función biológica de la mitosis, la meiosis y sus fases.
•
Reproducción sexual y asexual.

C. Genética
•
Modelo simplificado de la estructura del ADN y del ARN y relación con su función y síntesis.
•
Dogma central de la biología molecular. Expresión génica y características del código genético y
resolución de problemas relacionados con estas.
•
Relación entre las mutaciones, la replicación del ADN, la evolución y la biodiversidad.
•
Genética Mendeliana: conceptos básicos, leyes de la herencia y teoría cromosómica.
•
Resolución de problemas sencillos de genética con uno o dos caracteres no ligados.
•
Resolución de problemas de herencia del sexo y de herencia de caracteres con relación de
codominancia, dominancia incompleta, alelismo múltiple y ligada al sexo con uno o dos genes.
•
Árboles genealógicos.

•
Genética humana: cariotipo, herencia de caracteres continuos y discontinuos en la especie humana
y principales alteraciones genéticas relacionadas con enfermedades hereditarias en cromosomas
sexuales y no sexuales.
•
Malformaciones congénitas y diagnóstico de enfermedades genéticas.

D. Origen y evolución de la vida
•
Principales teorías sobre el origen de la vida.
•
Pruebas de la evolución
•
Teoría de la selección natural y explicación actual del proceso evolutivo en base a los conocimientos
de la genética y la biología molecular.
•
Ingeniería genética: aplicaciones de las principales técnicas en la agricultura, ganadería, medio
ambiente y salud. OMG, CRISPR.
•
Formación de nuevas especies y aparición de la especie humana.

E. Ecosistemas
•
Factores ambientales y adaptaciones de los seres vivos al medio.
•
Población, comunidad y ecosistema.
•
Materia y energía en los ecosistemas
•
Ciclos biogeoquímicos
•
Relaciones tróficas y productividad de los ecosistemas.
•
Sostenibilidad de los recursos del planeta: principales problemas medioambientales y eco-sociales
(sobreexplotación de recursos, el problema de la energía, la contaminación, los residuos, y la
protección del medio ambiente).
•
Agenda 2030 y ODS de la ONU.
•
Dinámica de los ecosistemas.

F. Geología
•
Principales teorías que explican el origen y evolución del relieve terrestre.
•
Estructura y dinámica de la geosfera y métodos de estudio de éstas.
•
Deformaciones de las rocas: esfuerzos, pliegues y fallas.
•
Explicación de los efectos globales de la dinámica de la geosfera a través de la Tectónica de Placas:
límites de placas y fenómenos geológicos asociados: magmatismo, metamorfismo y procesos
formadores del relieve.
•
Diferenciación entre los procesos geológicos externos e internos y argumentación sobre su relación
con los riesgos naturales.
•
Interpretación de cortes geológicos y trazado de la historia geológica que reflejan aplicando los
principios del estudio de la historia de la Tierra (horizontalidad, superposición, intersección, sucesión
faunística ...).
•
Descripción del origen del Universo y de los componentes del Sistema Solar.
•
Catastrofismo, actualismo y neocatastrofismo.
•
El tiempo geológico: métodos de datación absoluta y relativa.
•
Grandes divisiones del tiempo geológico: principales eventos, eras y períodos. Fauna y flora asociada
a las condiciones del plantea en cada momento de la historia geológica. Interrelaciones entre la vida
y las condiciones y cambios geológicos.
•
Discusión sobre las principales investigaciones en el campo de la astrobiología.

CRITERIOS DE EVALUACIÓN

CE1
•
Aplicar, en un trabajo práctico, la metodología propia de la ciencia para resolver las cuestiones que
se le plantean en el marco de los modelos aprendidos y haciendo predicciones elaboradas.
•
Realizar una interpretación adecuada de los datos y extraer conclusiones que le resultan de utilidad
en su conocimiento del mundo que le rodea, diferenciando variables dependientes e independientes.
•
Predecir el comportamiento de fenómenos en caso de que varíen las condiciones, aplicando los
resultados encontrados para explicar o predecir fenómenos similares.

CE2
•
Utilizar correctamente los términos técnicos adecuados a los distintos ámbitos de la ciencia.
•
Incorporar nuevas herramientas informáticas adecuadas a sus necesidades de trabajo.
•
Predecir cómo se modificaría la situación observada si cambiaran las condiciones del problema.
•
Aplicar las soluciones encontradas a un problema en otros contextos o situaciones próximas.

CE3
•
Desarrollar argumentos frente a afirmaciones de tipo dogmático, distinguiendo la ciencia del
pensamiento mágico o de la mitología en base al conocimiento del funcionamiento de la ciencia.
•
 Contrastar posibles explicaciones de fenómenos, justificando la distinta importancia de las variables
del proceso.
•
Elaborar documentos o productos utilizando diferentes herramientas de presentación y mostrando
diferentes soluciones a un mismo problema.
•
Comunicarse utilizando el lenguaje científico para participar en intercambios o en debates y para
interpretar o producir mensajes científicos.
•
Desarrollar una actitud abierta y receptiva hacia la diversidad de conocimientos, puntos de vista y
enfoques.

CE4
•
Justificar la validez de los modelos científicos en el contexto histórico en que se desarrollaron (origen
de la vida, teoría celular, herencia, evolución, tectónica).
•
Distinguir la controversia científica de la discusión ideológica, destacando su importancia en el avance
de la ciencia.
•
Relacionar los avances en tecnología con los progresos en el conocimiento de la naturaleza.
•
Relacionar los avances en el conocimiento de la genética, la evolución y la dinámica y composición
terrestre con las mejoras en la salud y calidad de vida humanas.

CE5
•
Justificar la toma de decisiones en aspectos relacionados con la sexualidad y hábitos saludables en
base al conocimiento del funcionamiento del propio cuerpo.
•
Contrastar informaciones y puntos de vista alternativos relacionados con la sexualidad y reproducción
humanas, mediante conocimientos científicos profundos y complejos.
•
Relacionarse con el resto de personas de manera libre y saludable respetando todas las opciones y
deseos.

CE6
•
Argumentar adecuadamente la necesidad de conservación de todas las formas de vida en base al
conocimiento de los sistemas biológicos y geológicos.

•
Explicar correctamente los distintos tipos de ciclos biológicos que existen aportando ejemplos de los
mismos.
•
Manejar claves dicotómicas distinguiendo los criterios que muestran parentesco evolutivo entre los
grupos (naturales) de aquellos que no reflejan dicho parentesco.

CE7
•
Explicar los principales fenómenos geológicos a la luz de la Tectónica de Placas.
•
Analizar e identificar algunas de las principales interacciones entre la humanidad y el planeta
relacionando los riesgos naturales que pueden afectarle, su dependencia para la obtención de los
recursos y la necesidad de favorecer un uso sostenible de ellos.
•
Predecir la evolución del sistema mediante un razonamiento lógico y la argumentación utilizando la
terminología y el lenguaje simbólico propio de la ciencia.

CE8
•
Explicar la actual biodiversidad como resultado de un proceso natural a partir de un origen común y
por medio de acumulación de modificaciones surgidas al azar, pero con un mayor o menor éxito
adaptativo.
•
Explicar el papel determinante de la Geología en el conocimiento de la evolución de los seres vivos
por selección natural.
•
Interpretar el presente de nuestro planeta y la vida que lo habita en base a los profundos cambios que
han afectado a nuestro planeta en el pasado y a los organismos que lo han poblado.
•
Explicar el proceso de evolución humana y su relación con los cambios geológicos y ecológicos que
desembocaron en su particular fisonomía.

CE9
•
Explicar las causas de las alteraciones del medio ambiente y su relación con la actividad humana.
•
Explicar las consecuencias para las poblaciones humanas menos favorecidas de fenómenos
asociados a las actividades humanas, como el cambio climático, agotamiento de recursos,
acumulación de residuos, contaminación atmosférica.
•
Relacionar la explotación de recursos de zonas empobrecidas por parte de los países más poderosos
con fenómenos como la migración, las hambrunas o la inestabilidad política y social.
•
Proponer soluciones para paliar las distintas formas de alteración humana de los ecosistemas.

CE10
•
Explicar los significados de los Objetivos de Desarrollo Sostenible de la Agenda 2030 de la ONU y de
algunas de las metas asociadas a los mismos.
•
Proponer acciones a las administraciones conducentes a la consecución de las metas de la agenda
2030.
•
Proponer medidas de prevención y adaptación al cambio climático y a todos los problemas de tipo
ecosocial para favorecer la resiliencia de su entorno y a nivel global.
