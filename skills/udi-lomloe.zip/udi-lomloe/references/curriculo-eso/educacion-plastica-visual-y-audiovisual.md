# EDUCACIÓN PLÁSTICA, VISUAL Y AUDIOVISUAL

> Fuente: Secundaria.pdf, páginas 746-764 (versión en castellano).

EDUCACIÓN PLÁSTICA, VISUAL Y AUDIOVISUAL

1. Presentación

La Educación Plástica, Visual y Audiovisual engloba los saberes de distintos lenguajes
que proporcionan al alumnado la oportunidad de expresar ideas, emociones y sentimientos a
través de creaciones artísticas que constituyen uno de los rasgos fundamentales de la cultura y
del desarrollo de la humanidad.

El lenguaje plástico nos permite moldear y transformar elementos a través de la
experimentación, creando propuestas artísticas nuevas y desarrollando la capacidad de
expresión del ser humano.

Vivimos inmersos en un mundo rodeado de imágenes. El lenguaje visual y audiovisual
posee una gran relevancia social y nunca antes se había mostrado tan necesaria una educación
completa que contribuya a la alfabetización visual. Esta formación proporcionará al alumnado los
recursos y herramientas necesarios para identificar los códigos propios del lenguaje y, así, poder
detectar estereotipos, prejuicios, convencionalismos y mensajes que atenten contra la diversidad
personal y cultural.

Estas herramientas propias de los lenguajes plástico, visual y audiovisual permitirán al
alumnado comunicarse y expresar con criterio  sus ideas y emociones, desarrollando su propia
identidad y contribuyendo a las relaciones intrapersonales e interpersonales. Además, vinculará
a su conocimiento la conciencia del patrimonio cultural y artístico.

Dicha aportación dará al alumnado la oportunidad de conocer numerosos referentes
artísticos y establecer vínculos entre diferentes lenguajes y disciplinas artísticas que
enriquecerán su percepción y sus propias creaciones. Además, contribuirán a su desarrollo
competencial, favoreciendo la eliminación de barreras sociales y desarrollando una actitud crítica
con las posibilidades transformadoras de uno mismo y de la sociedad.

Esta materia ha sido vertebrada teniendo en consideración la etapa anterior de primaria,
con la  pretensión de crear una construcción significativa y progresiva de los saberes, teniendo
en cuenta el desarrollo cognitivo del alumnado. Los criterios de evaluación formulados son
derivados de las competencias específicas que siguen una estructura escalonada adecuada a la
etapa de escolarización y su maduración, con vinculación con los descriptores del perfil de salida.
Además, edifica un pilar básico para abordar saberes futuros relacionados con el resto de las
materias y el ámbito artístico-expresivo.

La materia de Educación Plástica, Visual y Audiovisual, a través de su lenguaje universal
y transversal, facilita el logro y desarrollo de los objetivos generales de etapa, ya que promueve
una actitud abierta y colaborativa, y una continua acción que impulsa la construcción de una
cultura artística sostenible, igualitaria e integradora. Las Competencias Específicas, que se
articulan a partir de la Competencia Clave Conciencia y expresiones culturales, abarcan saberes
contextualizados que incrementan la consciencia del alumnado, habilidades que despiertan sus
talentos e intereses, y actitudes positivas que se promueven a través de la práctica artística.

Los saberes esenciales se vertebran en dos bloques subdivididos en dos subbloques
cada uno:

El bloque 1, Percepción y Análisis, fomenta la experiencia perceptiva a través del estudio
y análisis de la alfabetización visual y audiovisual, y la exploración del patrimonio cultural y
artístico de las diferentes épocas históricas y contextos incluida la contemporaneidad artística,
aportando conocimientos necesarios para el desarrollo integral del alumnado. Este primer bloque
tiene dos subbloques diferenciados: Exploración e interpretación del entorno, que hace
referencia al contacto con el contexto cultural y artístico, y Alfabetización visual y audiovisual, en
el que se abordan los contenidos necesarios para analizar y apreciar dicho entorno.

El bloque 2, Experimentación y creación, fomenta la experiencia creativa. Este bloque
también se divide en dos subbloques: La experiencia artística a través de procesos de producción
artística, experimentando con diversas técnicas, procedimientos, materiales y contextos, y la
experiencia social, que fomenta la participación e interacción social en proyectos artísticos
colectivos.

Esta organización responde a un modelo competencial para un desarrollo personal
integral del alumnado que impulse su crecimiento y maduración y fomente una actitud abierta al
aprendizaje que le acompañe a lo largo de su vida académica así como en otras parcelas
sociales y cotidianas. El carácter práctico y diverso de la materia le confiere una aptitud didáctica
para trabajar temas transversales que dotará al alumnado de capacidades que contribuyan a
enfrentarse, de forma individual o colectiva, a los retos del siglo XXI.

En las distintas propuestas de proyectos artísticos que se generen en el aula se
seleccionarán  los saberes indispensables para adquirir las competencias específicas.

Los criterios de evaluación como elemento curricular prescriptivo garantizan que todo el
alumnado sea evaluado con los mismos parámetros, garantizando la igualdad y la equidad en
este proceso. Estos están redactados en modo competencial para favorecer la evaluación en
estos términos y proporcionan indicadores del grado de consecución y adquisición de las
competencias en los distintos cursos en los que se imparte la asignatura.

La Educación Plástica, Visual y Audiovisual fomentará la creación de situaciones de
aprendizaje que faciliten encuentros entre el alumnado y su contexto de creación y expresión
artística, cuyo objetivo será la estimulación de su identidad artística, y que favorecerán su
autoestima y su crecimiento personal, impulsando el atrevimiento a mirar, indagar y descubrir.
Estas situaciones de aprendizaje serán el medio perfecto para desarrollar proyectos innovadores,
interdisciplinares e internivelares donde se conjuguen conocimientos propios de otras materias
y se facilite, desde una perspectiva inclusiva, el acceso, la participación y el aprendizaje del
alumnado. Estas situaciones se desarrollarán en contextos donde la gestión del error forme parte
del proceso de enseñanza-aprendizaje y, donde, además, se desafiará al alumnado a situaciones
diseñadas para que sean resueltas en términos de sostenibilidad, contribuyendo así a una
formación global y a una educación medioambiental y responsable del alumnado.

2. Competencias específicas.

2.1. Competencia específica 1.

Analizar de manera crítica y argumentada diferentes propuestas artísticas,
contemporáneas y de otras épocas, identificando, a través de distintos canales y contextos,
referencias socioculturales, funcionalidades y elementos de contenido del patrimonio y de la
cultura visual y audiovisual.

2.1.1. Descripción de la competencia 1.

Para garantizar el acceso a la cultura del alumnado de secundaria, se plantea esta
competencia como medio de interacción del alumnado con el patrimonio artístico y la cultura
visual y audiovisual.

El trabajo con referentes contemporáneos permite explorar mensajes propios de este
siglo, cercanos a las inquietudes y pensamientos del presente, favoreciendo su conexión con
elementos propios de otros contextos temporales y geográficos, desde una posición de respeto
a la diversidad.

Supone, además, entender e interpretar las imágenes como portadoras de significados
culturales, a través de los cuales se generan identidades individuales y colectivas. Implica activar
estrategias para reconstruir el significado de las imágenes a partir de su contexto, formulando
hipótesis sobre la intención comunicativa que subyace en las mismas y los valores a los que

contribuyen. Estos procesos de análisis y argumentación requieren posicionamientos críticos
respecto a los prejuicios y estereotipos, desde el respeto a la diversidad personal y cultural.

La identificación de las referencias socioculturales y elementos de contenido de la cultura
visual y audiovisual y del patrimonio local y global proporcionará al alumnado la posibilidad de
relacionar los elementos propios de la cultura local con los de otras culturas para desarrollar una
sensibilidad artística y cultural desde el respeto a la diversidad. Esta competencia permite no
sólo conocer y valorar el patrimonio local a partir del contexto en el que este se ha desarrollado,
sino también abrirse a otras sociedades y culturas, mostrando interés hacia ellas.

Los diferentes canales y contextos son los medios y espacios que el alumnado utilizará
para acceder a la cultura visual y audiovisual y el patrimonio histórico-artístico tanto local como
global.

Se entiende como canales los recursos físicos utilizados para la observación de las
propuestas a través de diferentes medios y formatos. Los contextos se entienden como los
espacios experienciales y de reconocimiento del entorno que pueden ser contextos físicos como
el aula, museos o bien virtuales.

2.º curso

Al finalizar este curso el alumnado habrá indagado acerca de diversas propuestas
artísticas con el objetivo de extraer información a través de distintos canales. Esto le permitirá
desarrollar un criterio propio que le proporcione las herramientas y recursos necesarios para el
disfrute y apreciación de los elementos del patrimonio cultural, incluida la contemporaneidad
artística. Este conocimiento posibilitará el enriquecimiento de sus propias propuestas creativas.

3.º curso

Al finalizar el tercer curso el alumnado sabría identificar y seleccionar los elementos
particulares de las distintas manifestaciones artísticas de carácter local o global desarrolladas en
diferentes contextos geográficos e históricos. Para ello ha de saber distinguir la información
extraída de los diferentes canales y poder así argumentar su propio discurso, desarrollando su
identidad personal.

2.2. Competencia específica 2.

Compartir ideas y opiniones usando la terminología específica del área en la
comunicación de las experiencias de apreciación y creación artística.

2.2.1.  Descripción de la competencia 2.

La integración de los saberes parte de una construcción adecuada del lenguaje, es decir,
para poder constituir un saber necesitamos de recursos lingüísticos para la descripción, el
análisis, la expresión o la formulación de ideas entre otros. Por lo tanto, es imprescindible que el
alumnado conozca la terminología específica del área para poder acercarse y profundizar en la
cultura visual y audiovisual y del patrimonio artístico.

La creación artística va más allá del desarrollo material de una obra ya que la fase de
creación implica necesariamente la argumentación a la hora del desarrollo de una idea y  la
reflexión y el análisis a lo largo de todo el proceso creativo. Es en la expresión de las experiencias
de apreciación y creación donde el alumnado tendrá la oportunidad de poner en marcha esta
serie de acciones que permiten desarrollar el pensamiento propio, crítico y divergente. Esto
último resulta una condición indispensable para que los aprendizajes vinculados a las artes se
conciban como generadores de conocimiento y no solo como impulsores de destrezas.

Se trata pues de que el alumnado utilice de manera consciente y adecuada el lenguaje
específico del área a la hora de explicar conceptos, plantear reflexiones o manifestar opiniones
acerca del proceso creativo y de todos los elementos que lo configuran.

2.º curso

Al finalizar este curso el alumnado habría adquirido un vocabulario específico del área
que le permitirá expresarse de forma apropiada en un proceso de comunicación oral y escrita
que a su vez le permitirá valorar la experiencia de apreciación de los distintos referentes
artísticos. Asimismo, dispondría de los recursos necesarios para contrastar y establecer diálogos
respetuosos con la diversidad creativa.

3.º curso

En este nivel el alumnado debería manejar el lenguaje específico del área con destreza
de forma que pueda valorar y emitir argumentos con espíritu crítico que le permitirá comunicarse
en los procesos de trabajo favoreciendo así el discurso y el debate de manera lógica ante
cualquier experiencia de apreciación y creación.

2.3.
Competencia específica 3.

Comunicar ideas, sentimientos y emociones, experimentando con los elementos del
lenguaje visual y con diferentes técnicas y materiales en la elaboración de prácticas artísticas y
creativas.

2.3.1. Descripción de la competencia 3.

La creación y la posterior transmisión de mensajes e ideas referidas a temáticas de
interés público o de relevancia personal implica el reflejo consciente o inconsciente de aspectos
emocionales y una percepción propia frente al entorno y las situaciones vividas. El acto mismo
de comunicar lleva implícitos una intencionalidad como es el de convertir un producto de
elaboración en objeto de valoración y crítica por parte de un público receptor.

Se considera que el fin último de la competencia específica descrita ha de ser que una
idea o proyecto creativo se materialice en productos concretos con un objetivo claro como es el
comunicativo.

La producción artística en todas sus vertientes implica el uso y experimentación con
materiales y herramientas propias del área o materia, que son múltiples y variados.  La
elaboración de propuestas a partir de la experimentación con diversidad de formatos, incluidos
los propios de la contemporaneidad, permite explorar discursos relacionados con temáticas
actuales y aspectos propios de la sociedad del siglo XXI.

El lenguaje visual es el código empleado para la elaboración, transformación y análisis
de obras plásticas y creativas. Se consideran elementos básicos configurativos y expresivos, con
capacidad comunicativa el punto, la línea, la textura y el color tanto en producciones
bidimensionales como tridimensionales, ya que la capacidad comunicativa aglutina ambas.

Con el uso de la imaginación y del pensamiento, divergente o convergente, y una
intencionalidad clara, se crea una base para el desarrollo de estrategias de interacción,
participación y colaboración. En cada nivel educativo se refuerzan aspectos concretos que
inciden en el conocimiento de una identidad personal propia y, por extensión, en la exploración
del mundo que nos rodea. Se crece compartiendo propuestas creativas y enumerando los pasos
seguidos en la búsqueda de soluciones originales que permitan integrar mejor lo aprendido y
aplicarlo posteriormente en el enfrentamiento a nuevos retos. Se avanza incidiendo en el dominio
de las técnicas y del uso de los recursos disponibles,  en la elaboración de proyectos, y en la
comprensión y el respeto de diferentes propuestas y planteamientos, armonizándolas si cabe
con las propias.

2.º curso

En este nivel el alumnado dispondría de las herramientas necesarias para contribuir al
desarrollo de propuestas artísticas, a través de la experimentación con las diversas técnicas y
materiales, incluidos los propios de la contemporaneidad, que a su vez le proporcionarán

indicadores para la posterior lectura de las citadas producciones artísticas. A lo largo del curso
el propio alumnado será cada vez más exigente tanto en el proceso de comunicación, expresión,
elaboración y creación como en el resultado de sus propias producciones creativas.

3.º curso

En este nivel el alumnado habría consolidado hábitos que le generarán seguridad y
confianza en sí mismo,  potenciando su autonomía a la hora de seleccionar una técnica u otra y
su correcta utilización, así como el uso adecuado y responsable de los materiales, en función de
su propia identidad y discurso a través de los distintos medios de la obra artística creada.

2.4.
Competencia específica 4.

Seleccionar de manera responsable y autónoma recursos digitales aplicados a la
percepción, la investigación y la creación en el desarrollo de propuestas y proyectos artísticos,
desarrollando una identidad y criterio propio en un consumo responsable y sostenible de acuerdo
a la normativa vigente.

2.4.1. Descripción de la competencia 4.

La importancia de adquirir una competencia digital en el área de la Educación Plástica,
Visual y Audiovisual reside en la creciente vinculación, casi permanente, de las tecnologías con
la vida del alumnado, lo que implica que estas adquieran un protagonismo relevante tanto en la
educación formal como informal.

El uso de las TIC en educación se concreta en el marco de referencia del Marco de la
Competencia Digital docente y la competencia digital del profesorado (DigCompEdu) y se aborda
tanto desde la alfabetización (saber identificar, localizar, recuperar, almacenar, organizar y
analizar la información digital, evaluando su finalidad y relevancia) como en la comunicación a la
hora de elaborar productos y producciones creativas.

Los entornos virtuales de aprendizaje, las herramientas TIC, las comunidades y redes
para la difusión de las producciones, requieren de un acercamiento respetuoso, crítico y acorde
con la normativa vigente de licencias de uso, derechos de autoría, protección de datos y
propiedad intelectual. La construcción de una identidad digital respetuosa y sostenible implica,
además de tomar decisiones sobre el correcto uso de las herramientas, desarrollar una
personalidad íntegra que evite la discriminación en las redes y fomente un uso contrastado e
inclusivo de las mismas.

2.º curso

En este nivel el desarrollo de la competencia digital se fundamenta en indagar los
recursos existentes, conociendo y seleccionando los más adecuados tanto en la parte de acceso
a propuestas culturales y artísticas, y la investigación como en la creación de producciones
individuales y colectivas. El conocimiento de la normativa vigente que implica la construcción de
la identidad digital se aplicará a los buenos usos de los recursos tecnológicos.

3.º curso

En este nivel, el alumnado habría adquirido mayor conocimiento respecto a los entornos
virtuales de aprendizaje, realizando selecciones argumentadas de fuentes y usos de recursos
TIC en base a sus necesidades, tanto en la investigación como en la producción de propuestas
creativas. Además, habría consolidado su identidad digital siendo capaz de realizar un consumo
consciente, responsable y sostenible de acuerdo a la normativa vigente.

2.5.
Competencia específica 5.

Crear producciones artísticas colectivas, atendiendo a las diferentes fases del proceso
creativo y aplicando los conocimientos específicos adquiridos.

2.5.1. Descripción de la competencia 5.

La producción visual y audiovisual en diferentes soportes o medios, conlleva una
planificación previa. Las estrategias utilizadas para desarrollar proyectos artísticos colectivos se
apoyan en una adecuada planificación de las fases del trabajo, distribución equitativa de tareas
y asunción de roles entre el alumnado participante en el proyecto, orientado todo ello al logro de
objetivos compartidos.

La reflexión continuada durante el proceso es de suma importancia, así como la
comunicación y el respeto por las aportaciones de las diferentes personas que intervienen en el
mismo. Esta competencia específica es fundamental para el aprendizaje, pues incluye
estrategias de cooperación y socialización entre otras.

2.º curso

Al finalizar este curso el alumnado habría adquirido recursos y desarrollado habilidades
sociales mediante el proceso colectivo de creación de producciones artísticas a través de la
relación de los conocimientos específicos adquiridos anteriormente y durante el proceso creativo.
Además, dispondría de las herramientas que le permitan explicar las distintas fases del proceso
a la comunidad educativa, argumentando y proponiendo mejoras tanto de su aportación como
de la de otros participantes. El alumnado habría desarrollado una actitud crítica en relación al
uso adecuado de los materiales atendiendo a principios de sostenibilidad.

3.º curso

En este nivel el alumnado habría consolidado los conocimientos específicos adquiridos
durante la creación de producciones artísticas colectivas. Estas experiencias artísticas permitirán
al alumnado aplicar con seguridad estos conocimientos para desarrollar sus propias ideas y
comunicarlas a través de medios gráficos o textuales al resto de la comunidad. Por esta vía se
contribuye así a los objetivos del proyecto colectivo que atenderán a los principios de
sostenibilidad siendo una prioridad el consumo responsable y la gestión de los residuos
materiales generados.

3. Conexiones de las competencias específicas entre sí, con las competencias de otras
áreas/materias y con las competencias clave (para el conjunto de las competencias del
área/materia) .

3.1.
Relaciones o conexiones con las otras CE de la materia.

En el proceso de enseñanza aprendizaje del alumnado las distintas competencias
específicas contribuyen de forma integradora al desarrollo competencial. Todas las
competencias específicas del área están relacionadas entre sí. Estas competencias se presentan
organizadas en torno a dos procesos diferenciados, pero complementarios: apreciación y
creación, ambas dimensiones imprescindibles para el desarrollo del alumnado.

Las competencias hacen referencia a la experiencia de apreciación y análisis de obras
culturales visuales y audiovisuales y del patrimonio artístico incluida la contemporaneidad (CE1)
que favorecerá el interés y el desarrollo de la creación en la práctica artística individual o colectiva
del alumnado (CE3) (CE5).  De estas experiencias de apreciación y creación se impulsará la
importancia de la comunicación utilizando un lenguaje correcto y específico del área (CE2) y la
utilización de los medios digitales e informáticos (CE4) que contribuyen en la parte de
investigación y proporcionan herramientas fundamentales para la creación.

3.2.
Relaciones o conexiones con las CE de otras materias de la etapa.

En cuanto al resto de materias, la vinculación con Educación Plástica, Visual y
Audiovisual puede establecerse desde varias perspectivas. El hecho de utilizar referentes
artísticos, tanto del patrimonio cultural como, especialmente, los contemporáneos, puede servir
de nexo de unión de saberes integrados. Por tanto, se pueden detonar secuencias didácticas,

así como vincular contenidos propios con todas las asignaturas tanto de ámbito humanístico
como lingüístico y científico-tecnológico. Los referentes de la cultura visual y artística, que hibrida
saberes y utiliza recursos de experimentación científica, documentación y otros campos de
conocimiento representados en las diferentes materias que se imparten en la educación
secundaria, aportan la visión de las creadoras y creadores trabajando de la mano con
profesionales de sectores diversos, representados en las diferentes áreas de conocimiento.
Especialmente la contemporaneidad, aborda los retos y temáticas del presente, de manera que
aporta una visión metafórica y procedimental especialmente adecuada para las materias de
valores. El lenguaje visual y audiovisual sirve, asimismo, para comunicar efectivamente en
cualquier disciplina, además de ser contenido propio, y junto con la capacidad de representación
gráfica y visual de conceptos, suponen herramientas de investigación, análisis y expresión
aplicables a cualquier disciplina. En este sentido, analítico y expresivo, la importancia del
elemento lingüístico en cualquier proceso de creación vincula las áreas de lenguas con las
artísticas de manera que suponen un enriquecimiento mutuo.

3.3.
Relaciones o conexiones con las competencias clave.

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 | X | X | X |  | X | X |  | X |
| CE2 | X | X |  |  |  |  |  | X |
| CE3 | X |  | X |  |  |  | X | X |
| CE4 | X | X | X | X | X | X |  | X |
| CE5 | X |  | X |  | X | X | X | X |

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

●
CCL: Competencia en comunicación lingüística
●
CP: Competencia plurilingüe
●
CMCT: Competencia matemática y competencia en ciencia y tecnología (STEM,
por sus siglas en inglés).
●
CD: Competencia digital
●
CPSA: Competencia personal, social y de aprender a aprender
●
CC: Competencia ciudadana
●
CE: Competencia emprendedora
●
CCEC: Competencia en conciencia y expresión culturales

La competencia clave en comunicación lingüística se vincula con todas las
Competencias Específicas ya que se desarrolla en cada momento de la práctica en el aula y a
través de todas las propuestas de percepción y análisis;  creación y experimentación. El uso del
lenguaje de manera correcta y adecuada y el empleo de la terminología específica del área son
necesarias en cada momento de la práctica docente de educación plástica, visual y audiovisual
tanto en la experiencia de percibir y analizar como en el proceso de crear y experimentar.

En cuanto a la competencia clave plurilingüe se relaciona con las competencias
específicas ya que el trabajo con referentes artísticos y contenidos culturales y del patrimonio y
la contemporaneidad (CE01) de zonas geográficas diversas, locales o globales y el acceso a la
información en lenguas diferentes (CE4) conlleva respetar la diversidad lingüística y cultural del
entorno. A través de la creación artística individual o colectiva (CE3) (CE5) se fomenta una actitud

positiva en la expresión de juicios y opiniones y se promueve una comunicación sensible a la
diversidad cultural y social (CE2).

La estrecha correspondencia entre procesos compartidos de la ciencia y el arte como la
investigación y la experimentación hacen que la competencia clave matemática y competencia
en ciencia, tecnología e ingeniería se relacionen íntimamente con las competencias específicas
de esta materia. La experiencia de observación, investigación y análisis del patrimonio artístico
y la contemporaneidad (CE1) y la fase de creación y experimentación creativa (CE3) (CE5)
desarrollan los procesos del pensamiento científico. La relación con la tecnología surge del
desarrollo de habilidades en el manejo de herramientas digitales y TIC (CE4) en los procesos
creativos.

La competencia clave digital está vinculada a las competencias específicas ya que los
entornos virtuales de aprendizaje suponen el medio para acercar los contenidos de la cultura
visual, audiovisual, del patrimonio y también de la contemporaneidad (CE1). Esta competencia
está muy asociada al resto de competencias específicas ya que la materia contiene saberes
específicos de la cultura audiovisual (CE4) potenciando habilidades en el uso de herramientas
TIC en el desarrollo de creaciones artísticas tanto individuales como colectivas (CE3) (CE5).

El desarrollo de la competencia clave personal, social y de aprender a aprender en la
práctica artística, (CE3) (CE5) supone la experiencia de enfrentarse a retos y toma de decisiones
individuales y colectivas,  manteniendo una posición de respeto, diálogo y asertividad con los
demás utilizando de forma adecuada el lenguaje (CE2) al igual que en la experimentación con el
uso de los medios multimedia y TIC (CE4). La inmersión al arte y la cultura visual y audiovisual
y del patrimonio incluyendo la contemporaneidad, supone un bagaje cultural para el alumnado
que le proporcionará autonomía y riqueza en su desarrollo personal.

La competencia clave ciudadana contribuye a la aproximación al arte y al patrimonio
cultural y artístico de todas las épocas incluida la contemporánea, la comprensión de los hechos
históricos y sociales más relevantes supone para el alumnado comprender la importancia de la
cultura artística para ser incorporada a  una construcción del ser como individuo y como parte de
la sociedad (CE1). Compartir ideas y opiniones a través de la comunicación oral (CE2) en
contextos de aprendizaje de creación artística, individuales o colectivos, (CE1) (CE3) (CE5) con
propuestas de diferentes temas de relevancia social implica reflexionar acerca de los diferentes
retos del siglo XXI, desde una perspectiva inclusiva, multicultural, igualitaria y sostenible.

El conocimiento de las creaciones artísticas culturales y del patrimonio artístico y
contemporáneo (CE1) contribuyen en el desarrollo de la competencia clave emprendedora ya
que supone despertar la curiosidad y la indagación en la iniciación de proyectos innovadores y
creaciones artísticas sostenibles que favorecen el crecimiento y la autonomía de la identidad
personal. La puesta en marcha de estos proyectos artísticos individuales o colectivos (CE3)
(CE5) conlleva un proceso de socialización que favorece la comunicación (CE1) y la toma de
decisiones durante todo el proceso creativo.

La competencia clave en conciencia y expresión cultural se encuentra inherentemente
relacionada con el resto de competencias clave por su carácter transversal e interseccional. Por
ello, de igual manera está relacionada con las competencias específicas de la materia de
educación plástica visual y audiovisual.

El conocimiento del patrimonio histórico y de la cultura artística contemporánea (CE01)
favorece el desarrollo de esta competencia y a su vez facilita la experimentación a través del
proceso de expresión creativa (CE3) (CE5), atendiendo siempre a indicadores que fomenten el
respeto a la diversidad cultural y el compromiso social.

4. Saberes básicos.

4.1.
Introducción.

La materia de Educación Plástica, Visual y Audiovisual abarca multitud de saberes de
diferentes lenguajes tales como dibujo técnico y artístico, pintura, escultura, cómic, ilustración,
publicidad, fotografía, cine, diseño, decoración, multimedia, arquitectura, ingenierías, entre otros.
Esto implica que a su vez la creación artística desarrolle numerosas capacidades, competencias
y destrezas según se trabaje uno u otro de los lenguajes mencionados.

Las producciones artísticas creadas en el aula se sustentarán sobre una base de saberes
teóricos y prácticos fundamentales para el bagaje del alumnado y además contribuirán a la
identificación y análisis del patrimonio histórico artístico.

Los saberes teóricos se consolidarán con el desarrollo práctico a través de las diferentes
técnicas artísticas empleadas. La destreza en la técnica y el desarrollo de habilidades en las
mismas es esencial para fortalecer la intencionalidad comunicativa en las obras o producciones,
y, además, para la transformación artística de una cosa en otra. La técnica contribuirá a que se
generen propuestas artísticas originales y con calidad estética.

Con el objetivo principal de que se logre alcanzar las competencias específicas de la
materia se ha desarrollado un abanico de saberes esenciales, contenidos mínimos que el
alumnado debe adquirir al finalizar la etapa.  Por su parte, el profesorado podrá ampliarlos con
la finalidad de dar respuesta a las necesidades educativas particulares de su alumnado.

Como ya se ha expuesto, esta materia goza de la dualidad de trabajar con multitud de
contenidos teóricos, por un lado, pero tiene una condición especial de taller por otro al tratarse
de una materia práctica, por lo que los saberes básicos se han desarrollado en dos bloques
diferenciados. Esta clasificación responde a la intención de diversificar por un lado el bloque
conformado de saberes relacionados con la observación,  la mirada y el análisis, que
configurarán una aportación fundamental para el alumnado en cuanto a su desarrollo personal,
y, por otro lado, la parte más práctica y de experimentación del proceso creativo que aportará al
alumnado las destrezas y habilidades necesarias para comunicarse a través de la práctica
artística.

Los saberes básicos están formulados como los contenidos mínimos que el alumnado
debe consolidar al finalizar la etapa. Como la materia de Educación plástica Visual y Audiovisual
estará presente en dos cursos, se ha reflejado a modo orientativo la gradación entre ellos,
realizando una propuesta de los saberes que, con una consecución lógica, se aconseja introducir
en el primer curso para asegurar la adquisición del conjunto de saberes al concluir la etapa.

4.2.
Bloque 1. Percepción y análisis.

|  | B.1.1. Exploración e interpretación del entorno |  | 2.º ESO | 3.º ESO |  |
| --- | --- | --- | --- | --- | --- |
|  | CE1, CE2, CE4 |  |  |  |  |
|  | G1. Patrimonio artístico y cultura visual contemporánea |  |  |  |  |
| Manifestaciones culturales y artísticas a lo largo de la historia, pertenecientes al patrimonio y a la cultura visual y audiovisual en entornos físicos y virtuales |  |  |  |  |  |
| Patrimonio cultural tangible. Mueble: pintura, escultura, artesanía, material audiovisual. Inmueble: monumentos artísticos, sitios históricos, conjuntos arquitectónicos. |  |  | x | x |  |
| Patrimonio cultural intangible. Formas de expresión: manifestaciones plásticas y visuales. |  |  | x | x |  |
| Elementos del lenguaje visual y audiovisual en las manifestaciones culturales y artísticas |  |  |  |  |  |

| Los elementos del lenguaje visual en manifestaciones culturales y artísticas de diferentes épocas y estilos. |  | x | x |  |
| --- | --- | --- | --- | --- |
| Los elementos del lenguaje audiovisual y sus posibilidades expresivas y comunicativas en imágenes fijas y en movimiento. |  | x | x |  |
| Aspectos semiológicos y contextuales de las manifestaciones artísticas. |  |  | x |  |
|  | Contemporaneidad artística |  |  |  |
| Características y cualidades expresivas y comunicativas de los formatos, soportes y materiales de las prácticas artísticas contemporáneas. |  | x | x |  |
| La creación artística como proceso de investigación: conexión con otras áreas de conocimiento. |  |  | x |  |
|  | G2. Actitudes |  |  |  |
| Atención y respeto en la exploración de manifestaciones artísticas plásticas, visuales y audiovisuales en entornos físicos y virtuales. |  | x | x |  |
| Participación y sentido crítico en la exploración de manifestaciones artísticas plásticas, visuales y audiovisuales en entornos físicos y virtuales. |  |  | x |  |
|  | G3. Entornos digitales |  |  |  |
| Entornos virtuales de aprendizaje (EVA) referentes a las artes visuales y audiovisuales. Normativa vigente en relación a la protección de datos, autoría y licencias de uso. |  | x | x |  |
|  | G4. Utilización de la terminología específica para la expresión de la experiencia de |  |  |  |
|  | apreciación |  |  |  |
| Para la expresión de las ideas, emociones y experiencias derivadas de la exploración de propuestas culturales y artísticas, y su descripción formal. |  | x | x |  |
| Para el análisis y argumentación de opiniones acerca de propuestas artísticas visuales y audiovisuales. |  |  | x |  |

|  | B1.2. Alfabetización visual y audiovisual |  | 2.º ESO | 3.º ESO |  |
| --- | --- | --- | --- | --- | --- |
|  | CE1, CE2 |  |  |  |  |
|  | G1. Percepción visual |  |  |  |  |
| Organización del campo visual. Leyes de la percepción visual: semejanza, figura-fondo, proximidad, simetría, continuidad, dirección común, simplicidad, igualdad y cierre. |  |  | x |  |  |

| Aspectos que intervienen en el proceso perceptivo: creencias, conocimientos previos y emociones. | x |  |  |
| --- | --- | --- | --- |
| G2. Comunicación visual y audiovisual |  |  |  |
| El proceso comunicativo: emisor, receptor, mensaje, código, canal, referente y contexto. El mensaje visual y audiovisual. | x |  |  |
| Funciones e intencionalidades de la imagen: estética, informativa, exhortativa, expresiva. | x | x |  |
| Lectura, análisis e interpretación de imágenes fijas y en movimiento. Aspectos formales y conceptuales. Valor denotativo y connotativo. | x | x |  |
| La imagen en el mundo actual: estereotipos, prejuicios y convencionalismos. | x |  |  |
| La imagen en el mundo actual: realidad y ficción. La veracidad del mensaje. Redes sociales. |  | x. |  |
| G3. Elementos configuradores del lenguaje visual y audiovisual |  |  |  |
| Elementos morfológicos: punto, línea, plano, forma, color y textura. | x | x |  |
| Elementos dinámicos: ritmo, tensión, movimiento. Interacción del lenguaje visual con otros lenguajes. |  | x |  |
| Elementos escalares: formato, dimensión, proporción y escala. Relación entre realidad y representación. |  | x |  |
| Sintaxis de la imagen. Esquemas compositivos. |  | x |  |
| Elementos visuales y sonoros del lenguaje audiovisual. Elementos sintácticos. | x |  |  |
| Elementos semánticos del lenguaje audiovisual. |  | x |  |

4.3.
Bloque 2. Experimentación y creación.

| B2.1. La experiencia artística: técnicas y materiales de expresión |  | 2.º ESO | 2.º ESO | 3.º ESO |  |
| --- | --- | --- | --- | --- | --- |
| gráfico-plástica y de creación visual y audiovisual. Ámbitos de |  |  |  |  |  |
| aplicación. |  |  |  |  |  |
| CE1, CE3, CE4 |  |  |  |  |  |
| G1. Expresión gráfico-plástica |  |  |  |  |  |
| Técnicas secas y húmedas. Técnicas mixtas y experimentales. Materiales, soportes y procedimientos. Formatos bidimensionales y tridimensionales. |  | x |  | x |  |

| Cualidades emotivas y expresivas de los medios gráfico-plásticos. Posibilidades comunicativas. |  | x | x |  |
| --- | --- | --- | --- | --- |
| Ámbitos de aplicación y perfiles profesionales. Pintura, dibujo, escultura, ilustración, cómic, artes decorativas, publicidad. Prácticas artísticas contemporáneas y producciones multidisciplinares. |  | x | x |  |
|  | G2. Dibujo geométrico |  |  |  |
| Geometría plana: trazados geométricos básicos. Instrumentos de dibujo técnico. |  | x | x |  |
| Introducción a los sistemas de representación: sistema diédrico, axonométrico y perspectiva cónica. |  |  | x |  |
| Ámbitos de aplicación y perfiles profesionales. Diseño y arquitectura. |  | x | x |  |
| G3. Creación audiovisual |  |  |  |  |
| Producción audiovisual. Preproducción, producción y postproducción. |  |  | x |  |
| Ámbitos de aplicación y perfiles profesionales. Fotografía y cine. Videocreación y formatos multidisciplinares. |  | x | x |  |
| G4. Terminología específica del área |  |  |  |  |
| Vocabulario relativo a procesos de experimentación, creación, difusión y evaluación de producciones creativas. |  | x | x |  |
| G5. Aplicaciones digitales |  |  |  |  |
| Uso de las TIC y experimentación en entornos virtuales de aprendizaje aplicados a la expresión gráfico-plástica. |  | x | x |  |
| Uso de las TIC y experimentación en entornos virtuales de aprendizaje aplicados al dibujo geométrico. |  |  | x |  |
| Uso de las TIC y experimentación en entornos virtuales de aprendizaje aplicados a la creación audiovisual. |  |  | x |  |

| B2.2. La experiencia artística individual y colectiva: procesos de trabajo CE3, CE4, CE5 | 2.º ESO | 3.º ESO |
| --- | --- | --- |
| G1. Las fases del proceso creativo |  |  |

| Generación de ideas: creatividad en la elaboración de ideas y en la toma de decisiones. | x | x |
| --- | --- | --- |
| Investigación: búsqueda y análisis de referentes. |  | x |
| Creación: diseño y producción de la propuesta. Distribución de tareas: roles en el desarrollo de un proyecto artístico colectivo. Funciones y cometidos. | x | x |
| Evaluación: resultados en relación a los objetivos iniciales del proyecto. Análisis y propuestas de mejora. |  | x |
| Documentación gráfica de procesos. Portafolios de evidencias del proceso creativo. Estrategias de pensamiento visual. | x | x |
| G2. Actitudes |  |  |
| Esfuerzo, fuerza de voluntad. Capacidad de concentración. Resiliencia, superación de obstáculos y fracasos. | x | x |
| Respeto por la diversidad de ideas y producciones. Utilización de un vocabulario inclusivo básico. | x | x |
| Tenacidad y constancia en la realización y consecución de las distintas tareas. | x | x |
| Consenso, respeto y empatía con la aportaciones de las compañeras y compañeros en el proceso de trabajo colectivo. | x | x |
| Cooperación y responsabilidad en la parte individual para contribuir a un objetivo común y a la cohesión del grupo. | x | x |
| Cuidado de espacios y materiales de trabajo. Sostenibilidad y gestión de residuos. | x | x |

5. Situaciones de aprendizaje para el conjunto de las competencias de la materia

A continuación, se presentan algunos principios relevantes que deberían tenerse en
cuenta a la hora de diseñar situaciones de aprendizaje para la práctica docente de Educación
Plástica, Visual y Audiovisual. Las situaciones de aprendizaje ponen en relación las
competencias específicas de la asignatura con procedimientos y contextos de aprendizaje
deseables.

El aprendizaje de los saberes básicos propios de la materia debería establecerse en
forma de andamiaje que afiance contenidos adquiridos en cursos previos incorporándolos de
forma natural en propuestas nuevas, evitando repetir conceptos año tras año.

Teniendo en cuenta que las situaciones de aprendizaje han de conectarse con los
desafíos del siglo XXI, en el contexto de la materia de Educación Plástica, Visual y Audiovisual
se deben relacionar y justificar los referentes que se utilizan en base a su conexión con ejes y
temáticas de trascendencia social vinculadas a los retos del presente, como son: el consumo
responsable, la resolución pacífica de los conflictos, la valoración de la diversidad personal y
cultural, el respeto al medioambiente y la gestión de residuos, la vida saludable, etc.

Además, han de tener en cuenta la diversidad personal y cultural incluyendo en los
relatos de aula los microrrelatos, es decir aquellos de colectivos minorizados como la perspectiva
multicultural, de género, etc. Esto se plantea como una oportunidad para ampliar referentes y

explorar los matices que proporciona introducir multiplicidad de miradas y respuestas a retos que
son comunes.

Por otro lado, para contribuir a la sostenibilidad, y en conexión con los ODS, se
recomienda la incorporación de materiales sostenibles y reciclados en el aula. En este sentido
se trataría no solo de utilizarlos sino de reflexionar en torno a su uso, consumo y al significado
que proporcionan en las creaciones de aula.

Para poder integrar las experiencias personales del alumnado podemos detonar los
procesos de aprendizaje partiendo de situaciones cotidianas y de vivencias compartidas,
estableciendo los vínculos pertinentes con los saberes básicos y las competencias específicas
del área.

Incorporar referentes de la cultura visual y audiovisual: imágenes de redes sociales,
publicidad, personajes famosos que sean un referente etc, garantiza la conexión con intereses y
con aprendizajes que el alumnado ya posee pero que no vincula con los aprendizajes del aula.
Permite desdibujar el límite entre el centro educativo como único espacio educador y el exterior
como fuente de experiencias desvinculadas del centro.

Por otro lado, partir de la cultura local para poco a poco ir incorporando otras formas
culturales es una manera de garantizar el desarrollo de una identidad cultural cada vez más rica
en conexiones y de valores de tolerancia y respeto.

Para contemplar otros contextos educativos que ayuden a dar sentido al aprendizaje en
el lugar de su realización, podemos utilizar espacios del centro educativo más allá del aula de
referencia (patio, pasillos etc) para así fomentar el sentimiento de pertenencia en el alumnado,
intentando que se sienta parte de un colectivo y reforzar así su autoestima. También podemos
explorar las posibilidades del contexto más cercano (barrio, pueblo, ciudad) y establecer relación
con los agentes culturales del entorno. En este sentido podemos propiciar la participación de
creadores y creadoras en el centro (mediante programas de residencias artísticas o invitación a
profesionales vinculados al mundo de la creación).

Contar en los centros educativos con la figura de un/a coordinador/a cultural, que
favorezca la participación del alumnado del centro en actividades culturales y artísticas del
entorno puede ser una manera de afianzar la presencia de la cultura y de las propuestas
culturales del entorno en los centros.

El aula de Educación Plástica, Visual y Audiovisual no debería ser un lugar
exclusivamente para “hacer” sino también para pensar, conectar, relacionar, estudiar, debatir, en
definitiva para estimular la reflexión y el pensamiento crítico y divergente. Las propuestas de aula
deben ser abiertas, de respuesta múltiple, y no suponer necesariamente la uniformidad de los
productos finales, en el caso de que los haya, para favorecer la inclusión y la heterogeneidad
ocasionadas por las diferentes personalidades, inquietudes, contextos y vivencias del alumnado.

Fomentar los procesos de investigación en los que se reflexione en torno a las ideas y
referentes socioculturales que el alumnado va adquiriendo es imprescindible para crear
propuestas que vayan más allá de la manualidad y se conformen como experiencias pedagógicas
significativas. La alfabetización visual implica educar la mirada, y para ello tenemos que instaurar
la pedagogía de la sospecha en relación a las imágenes que nos rodean y preguntarnos
constantemente acerca de sus posibles significados. La gestión crítica de la búsqueda y
selección de la información en los procesos de aprendizaje es fundamental para que el alumnado
comprenda que las imágenes que consume diariamente están cargadas de significados y de
intencionalidades.

El desarrollo del pensamiento crítico y divergente permite enfrentarse a otras situaciones
de manera creativa por lo que los procesos de reflexión inherentes a la práctica artística en el
contexto del aula garantizan aprendizajes transferibles a otras situaciones en su día a día o a
otras áreas de conocimiento.

Las situaciones de aprendizaje han de incluir necesariamente elementos emocionales
por la capacidad que tienen para interferir y determinar los procesos de aprendizaje. En ese
sentido el cuidado de los espacios de trabajo, el uso respetuoso de los mismos, de manera que
los sientan como espacios propios puede ayudar a crear experiencias más conectadas con el
alumnado y sus necesidades afectivas.

Se debe garantizar el acceso al aprendizaje del conjunto del alumnado aplicando los
principios del Diseño Universal y la Accesibilidad para el Aprendizaje (DUA-A), atendiendo las
dimensiones física, cognitiva, sensorial y emocional.

Es recomendable justificar de manera asertiva las opiniones relativas al trabajo del
alumnado, fomentando el refuerzo positivo y la adecuación de las apreciaciones a los objetivos
de la propuesta y no a valoraciones personales desvinculadas de esta.

El respeto por los tiempos de trabajo y sus distintos ritmos, supone aceptar la
incertidumbre como parte ineludible del aprendizaje. Para ello, los tiempos de trabajo amplios
favorecen el diseño de secuencias didácticas que permiten explorar todas las fases del proceso
creativo y valorar el error como una oportunidad para aprender.

Es importante tener en cuenta que en la etapa de secundaria la educación plástica ha
de centrarse en el desarrollo de hábitos de percepción, de experimentación y participación,
además del desarrollo de destrezas manuales o técnicas, y por tanto las consideraciones que
planteemos no deberían evaluar estas últimas en exclusiva. Además, debemos emplear un
lenguaje inclusivo e igualitario que integre la diversidad inherente a los grupos con los que
trabajamos y facilitar momentos para compartir ideas y opiniones de manera asertiva.

Debemos incentivar hábitos de constancia y autoexigencia, y el placer por la consecución
de objetivos reales. Es importante que el alumnado se vea capaz de terminar los procesos y
tomar consciencia del propio aprendizaje fomentando la reflexión, por lo que debemos programar
tareas viables, flexibles y adaptadas a sus capacidades.

Para fomentar otras formas de representación se recomienda la utilización de estrategias
de pensamiento visual en la conceptualización de contenidos curriculares, así como en la
organización y planificación de proyectos o registro de evidencias en procesos de aprendizaje.

El desarrollo de proyectos artísticos colectivos (ver CE06) fomenta la participación y el
diálogo implicando al alumnado en procesos de trabajo que requieren cooperación. Se debe
potenciar la llegada a acuerdos por medios dialogados fomentando la cultura democrática y el
lenguaje oral en la expresión de opiniones, posicionamientos y emociones, y la recepción de
ideas ajenas.

6. Criterios de evaluación

6.1.
Competencia específica 1.

Analizar de manera crítica y argumentada diferentes propuestas artísticas,
contemporáneas y de otras épocas, identificando, a través de distintos canales y contextos,
referencias socioculturales, funcionalidades y elementos de contenido del patrimonio y de la
cultura visual y audiovisual.

| 2.º ESO | 3.ºESO |
| --- | --- |
| C1.1 Buscar información, a través de diferentes canales y contextos, acerca de propuestas artísticas diversas desarrollando el criterio propio a partir de su análisis. | C1.1 Investigar acerca de diferentes propuestas artísticas, a través de distintos canales, contextualizándolas y teniendo en cuenta sus funcionalidades. |

| C1.2 Examinar propuestas artísticas del entorno patrimonial y de la cultura visual y audiovisual, a través de recursos y agentes culturales del entorno, encontrando elementos de contenido esenciales. | C1.2 Identificar elementos de contenido esenciales y funcionalidades en la apreciación y análisis de referentes artísticos, a través de recursos y agentes culturales del entorno, incluyendo canales y medios tecnológicos. |
| --- | --- |
| C1.3 Identificar los mensajes de diferentes creaciones artísticas clasificando los elementos que intervienen en la comunicación. | C1.3 Interpretar los mensajes de diferentes creaciones artísticas, identificando los elementos que intervienen en la comunicación y extrayendo conclusiones para su aplicación en propuestas creativas propias. |
| C1.4 Apreciar la diversidad de propuestas en manifestaciones culturales y artísticas de diferentes contextos geográficos e históricos. | C1.4 Valorar con respeto y sentido crítico las manifestaciones culturales y artísticas en entornos diversos, desarrollando el criterio propio y argumentando en la construcción de la opinión personal. |
| C1.5 Relacionar los referentes y elementos de la contemporaneidad artística con los desafíos y retos del presente, apreciando su aportación a la transformación social. | C1.5 Identificar los desafíos del presente a través del trabajo y mensajes de la creación contemporánea, valorando su contribución a la sociedad actual y adoptando un posicionamiento razonado, crítico y constructivo. |

6.2.
Competencia específica 2.

CE2. Compartir ideas y opiniones usando la terminología específica del área en la
comunicación de la experiencia de apreciación y creación artística.

| 2.º ESO | 3.ºESO |
| --- | --- |
| C2.1 Emplear vocabulario específico del área de manera correcta para valorar la experiencia de apreciación de diferentes referentes artísticos. | C2.1 Valorar de manera argumentada diferentes obras e imágenes, en la experiencia de apreciación, utilizando el vocabulario específico del área. |
| C2.2 Incorporar terminología específica del área en el proceso de comunicación oral y escrita de la experiencia de creación. | C2.2 Comunicar, de manera oral y escrita, la experiencia de creación elaborando un discurso coherente que describa los procesos de trabajo utilizando terminología propia del área |
| C2.3 Compartir información extraída de diversas | C2.3 Argumentar con criterio y respeto en diferentes |

| fuentes de forma contrastada y establecer discursos y debates con asertividad. | momentos de discurso y debate vinculados a la experiencia de apreciación y creación. |
| --- | --- |

6.3.
Competencia específica 3.

Comunicar ideas, sentimientos y emociones, experimentando con los elementos del
lenguaje visual y con diferentes técnicas y materiales en la elaboración de prácticas artísticas y
creativas.

| 2.º ESO | 3.º ESO |
| --- | --- |
| C3.1 Experimentar con diversidad de técnicas y materiales adecuándose a los objetivos planteados en cada una de las propuestas, incluyendo posibilidades no convencionales. | C3.1 Seleccionar las técnicas más adecuadas en función del objetivo planteado en cada propuesta creativa, incluyendo materiales no convencionales. |
| C3.2 Emplear las posibilidades comunicativas y expresivas de los formatos y materiales de la contemporaneidad artística en la elaboración de propuestas creativas sencillas. | C3.2 Seleccionar diferentes formatos y materiales propios de las manifestaciones artísticas contemporáneas con finalidad comunicativa en la elaboración de propuestas creativas. |
| C3.3 Idear propuestas artísticas en las que las técnicas y materiales seleccionados estén al servicio del mensaje que se pretende transmitir. | C3.3 Crear propuestas artísticas, relacionando las potencialidades expresivas de los diferentes elementos que las conforman con la finalidad comunicativa que se pretende transmitir. |
| C3.4 Demostrar hábitos de constancia y autoexigencia tanto en el proceso como en el resultado final. | C3.4 Consolidar hábitos de constancia y autoexigencia tanto en el proceso como en el resultado final |
| C3.5 Incorporar los referentes y elementos de la contemporaneidad artística como estímulo en propuestas creativas propias. | C3.5 Emplear los referentes y elementos de la contemporaneidad artística seleccionando los más adecuados a la finalidad comunicativa. |

6.4.
Competencia específica 4.

Seleccionar de manera responsable y autónoma recursos digitales aplicados a la
percepción, la investigación y la creación en el desarrollo de propuestas y proyectos artísticos,
desarrollando una identidad y criterio propio en un consumo responsable y sostenible de acuerdo
a la normativa vigente.

| 2.º ESO | 3.ºESO |
| --- | --- |

| C4.1 Buscar información y recursos aplicados a las artes plásticas, visuales y audiovisuales, en diferentes entornos digitales. | C4.1 Seleccionar información y recursos aplicados a las artes plásticas, visuales y audiovisuales, en diferentes entornos digitales. |
| --- | --- |
| CE4.2. Probar diferentes recursos digitales en la percepción, experimentación y creación de las diferentes propuestas y producciones. | CE4.2. Emplear diferentes recursos digitales para la percepción, experimentación y creación, seleccionando los más adecuados para los objetivos de las diferentes propuestas y producciones. |
| C4.3 Conocer la normativa vigente de protección de datos y autoría, aplicándola de manera responsable en la creción y difusión de contenidos. | C4.3 Aplicar buenas conductas para un consumo digital responsable y sostenible, respetando las licencias de uso y las normas vigentes de protección de datos y autoría. |

6.5.
Competencia específica 5.

Crear producciones artísticas colectivas, atendiendo a las diferentes fases del proceso
creativo y aplicando los conocimientos específicos adquiridos.

| 2.º ESO | 3.ºESO |
| --- | --- |
| C5.1 Participar activamente en la planificación de producciones artísticas multidisciplinares, adecuando las decisiones adoptadas a los objetivos del proyecto y teniendo en cuenta la perspectiva inclusiva. | C5.1 Diseñar producciones artísticas multidisciplinares, planificando las fases del proceso de trabajo, adecuando las decisiones adoptadas a los objetivos del proyecto, teniendo en cuenta la perspectiva inclusiva. |
| C5.2 Crear producciones artísticas colectivas experimentando con diferentes posibilidades expresivas y comunicativas, explorando las conexiones con otras materias. | C5.2 Analizar el objetivo comunicativo de las propuestas artísticas colectivas, experimentando con diferentes técnicas, materiales y formatos y estableciendo conexiones con conocimientos de otras materias. |
| C5.3 Asumir diferentes roles en el proceso de planificación, creación y difusión de la producción artística colectiva, con actitud respetuosa e inclusiva. | C5.3 Relacionar los roles asumidos durante el proceso de planificación, creación y difusión de la producción artística colectiva, con los diferentes ámbitos de aplicación profesional. |

| C5.4 Explicar a la comunidad los procesos de trabajo de manera textual, gráfica y/o audiovisual, aportando valoraciones críticas acerca del proceso y resultado. | C5.4 Reflexionar sobre los procesos de trabajo, utilizando registros textuales, gráficos y/o audiovisuales, evaluando cada fase, proponiendo mejoras y exponiendo las conclusiones a la comunidad. |
| --- | --- |
| C5.5 Difundir las producciones artísticas colectivas realizadas utilizando diferentes medios y canales. | C5.5 Planificar la promoción de las producciones artísticas colectivas realizadas, explorando y evaluando diferentes vías de difusión. |
