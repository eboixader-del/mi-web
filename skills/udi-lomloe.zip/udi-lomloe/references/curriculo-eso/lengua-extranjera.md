# LENGUA EXTRANJERA

> Fuente: Secundaria.pdf, páginas 953-972 (versión en castellano).

LENGUA EXTRANJERA

1. Presentación

La comunicación en distintas lenguas en la sociedad actual, caracterizada por la globalización, el
plurilingüismo y la interculturalidad, exige una educación y formación más adaptada a las demandas que esta
sociedad requiere para el desarrollo de personas independientes, activos y comprometidos con la realidad
contemporánea. En ese sentido, la lengua extranjera, en consonancia con las directrices marcadas por el
Consejo de Europa a través del Marco Común Europeo de Referencia para las Lenguas, contribuye al
desarrollo competencial que permitirá al alumnado afrontar los retos del siglo XXI como personas integradas
en la sociedad y profesionales del futuro, en un mundo interconectado, global y cambiante, donde la
internacionalización, la movilidad y el descubrimiento de otras culturas estén presentes. La materia de Lengua
Extranjera en la etapa de Educación Secundaria Obligatoria tiene como objetivo principal la adquisición de la
competencia comunicativa apropiada en la lengua extranjera, de modo que permita al alumnado comprender,
expresarse, interactuar y mediar en dicha lengua con eficacia, así como el enriquecimiento y la expansión de
su conciencia intercultural.

En este currículo las dos dimensiones básicas del plurilingüismo están presentes: la dimensión
comunicativa y la dimensión intercultural. Es por ello que las competencias específicas de la materia se
vinculan con las competencias clave del perfil de salida de esta etapa, así como con los retos del siglo XXI.
La Lengua Extranjera está directamente relacionada con el desarrollo de las competencias clave de
comunicación lingüística y plurilingüe, puesto que supone incorporar mecanismos y estrategias para el
procesamiento y transmisión de la información, integrando saberes y conocimientos del propio repertorio
lingüístico como su lengua materna, las lenguas oficiales y el resto de lenguas extranjeras, para así
trasladarlos al aprendizaje de otras lenguas y culturas. Asimismo, fomenta el desarrollo del resto de
competencias clave puesto que supone moverse en entornos de aprendizaje analógicos y digitales
(competencia digital), inferir y deducir información para la construcción de significados (competencia en
ciencia, tecnología, ingeniería y matemáticas), así como reflexionar sobre su propio proceso de aprendizaje
(competencia personal, social y aprender a aprender) y apreciar, valorar la expresión artística, cultural y
literaria de forma empática y respetuosa (competencia en conciencia y expresión cultural). Esta materia, a
través de los saberes de sus competencias específicas, contribuye de manera clara a que el alumnado pueda
afrontar retos del siglo XXI como son el reconocimiento y respeto por la diversidad lingüística y cultural, la
gestión de situaciones interculturales de convivencia democrática, la resolución dialogada de conflictos o el
establecimiento de vínculos personales y sociales basados en el respeto y la igualdad de derechos.

La materia de Lengua Extranjera, en el desarrollo de las competencias específicas de comprensión,
expresión, interacción y mediación, fomenta que el alumnado pueda adquirir los elementos básicos de la
cultura en sus aspectos humanísticos, y contribuye al desarrollo y a la consolidación de hábitos de estudio y
de trabajo, como preparación a su incorporación a estudios posteriores y a su inserción laboral. Al mismo
tiempo, promueve el desarrollo de valores como el respeto a los derechos y a las libertades individuales, la
igualdad efectiva, el esfuerzo y la responsabilidad individual, así como el aprendizaje a lo largo de la vida con
la adquisición de hábitos de trabajo y conocimientos en el ámbito lingüístico. Cabe enfatizar la importancia
que en esta materia tienen las herramientas digitales para reforzar el aprendizaje, la enseñanza y la
evaluación de idiomas. Por ello, el desarrollo del pensamiento crítico, la alfabetización digital y el uso
adecuado, seguro, ético y responsable de la tecnología suponen un elemento de aprendizaje muy relevante
en esta materia.

Asimismo, las estrategias y saberes propios de otras materias de esta etapa fomentan el desarrollo
de una actitud responsable hacia el medioambiente, el consumo, los hábitos de vida saludable, la inclusión o
la aceptación de la incertidumbre, por lo que el trabajo conjunto a través de ámbitos o proyectos que
incorporen dos o más materias junto con la lengua extranjera son fundamentales.

Para el aprendizaje de la lengua extranjera y el desarrollo de su dimensión comunicativa e
intercultural, cabe adoptar un enfoque comunicativo, en el que destaque el aprendizaje orientado a la acción,
teniendo como referente el Marco Común Europeo de Referencia para las Lenguas y el Marco Común
Europeo de Referencia de las Lenguas: Aprendizaje, enseñanza, evaluación (MCER). Volumen
complementario. Este enfoque considera que los usuarios de una lengua, así como el alumnado que la
aprende, son agentes sociales, es decir, son miembros de una sociedad que lleva a cabo una serie de tareas,
no sólo relacionadas con la lengua, en unas circunstancias y un entorno específicos. Por ello, metodologías
comunicativas como el aprendizaje basado en tareas o el Tratamiento Integrado de Lenguas (TIL) y
Tratamiento Integrado de Lenguas y Contenido (TILC), resultan apropiadas para el desarrollo competencial
del currículo en esta materia, así como el uso de otras metodologías eclécticas que sigan un enfoque
comunicativo.

La materia de Lengua Extranjera presenta una continuidad en las competencias específicas respecto
a Educación Primaria, ya que supone una progresión respecto a los saberes adquiridos a lo largo de esta
etapa, y que se desarrollarán a partir del repertorio lingüístico y de las experiencias previas del alumnado. Por
tanto, implica una ampliación y una profundización de las competencias específicas de comprensión,
expresión, interacción y mediación, así como la extensión en cuanto a los ámbitos de las situaciones
comunicativas, los géneros textuales y la utilización de soportes digitales en relación con los trabajados en
Educación Primaria. Asimismo, la progresión de una a otra etapa conlleva ahondar en la reflexión del
funcionamiento y contraste de distintas lenguas de su repertorio lingüístico, así como la incorporación de
diversas lenguas en las actividades de mediación lingüística para el desarrollo de su conciencia plurilingüe y
pluricultural. De igual modo, el trabajo con el resto de las materias de la etapa en que se involucren aspectos
como el fomento del espíritu crítico y científico o el emprendimiento social y empresarial, promueve que el
alumnado siente las bases para su orientación educativa y profesional posterior. En ese sentido, el
conocimiento y la habilidad de comunicarse en una o más lenguas extranjeras resulta esencial.

En primer lugar, cabe destacar que tanto el enfoque, como la nivelación y descripción de los diferentes
elementos del currículo de Lengua Extranjera se basan en el planteamiento establecido por el Consejo de
Europa en el Marco Común Europeo de Referencia para las Lenguas. Este marco, así como el volumen
complementario, que incorpora nuevos descriptores, sobre todo para la competencia específica de mediación
lingüística, resulta clave para determinar el nivel de competencia del alumnado, así como para apoyar su
proceso de aprendizaje adecuado a sus circunstancias, necesidades e intereses.

El currículo de Lengua Extranjera está estructurado a partir de siete competencias específicas, que
constituyen el punto de partida para el aprendizaje del idioma. Estas competencias son multilingüismo e
interculturalidad, comprensión oral, comprensión escrita, expresión oral, expresión escrita, interacción oral y
escrita, mediación oral y escrita. Para cada una de ellas se presenta una definición y una breve descripción,
donde se ofrece información más detallada sobre sus ingredientes –actuaciones y capacidades asociadas,
situaciones en las que se despliega y saberes que moviliza–, así como una breve explicación de sus
conexiones con el resto de las competencias específicas de la materia, con las competencias específicas de
otras materias y con las competencias clave del perfil de salida del alumnado al final de la etapa.

Para el conjunto de las competencias de la materia de Lengua Extranjera se establecen saberes
básicos divididos en tres grandes bloques para los cursos de la Educación Secundaria Obligatoria: Lengua y
uso, Estrategias comunicativas, y Cultura y sociedad. El bloque de Lengua y uso abarca el conjunto necesario
de saberes para el desarrollo de actividades comunicativas de comprensión, expresión, interacción y
mediación; el bloque de Estrategias comunicativas incorpora aquellas destrezas necesarias para llevar a cabo
los distintos procesos implicados en el desarrollo de las competencias en distintas situaciones y contextos
comunicativos; el bloque de Cultura y sociedad incluye conocimientos relativos a aspectos culturales (y
transversales) de las culturas y sociedades vehiculadas en la lengua extranjera. Se espera que el alumnado
sea capaz de poner en funcionamiento todos los saberes básicos de las situaciones comunicativas asociadas
a los ámbitos personal, social, educativo y profesional, y a partir de textos sobre temas cotidianos, de
relevancia personal o de interés público próximos a la experiencia del alumnado y que incluyan retos y
desafíos del siglo XXI.

En consonancia con el enfoque orientado a la acción que plantea el Marco Común Europeo de
Referencia para las Lenguas, el carácter competencial de este currículo invita al profesorado a crear tareas
interdisciplinares, contextualizadas, significativas y relevantes, similares a aquellas en las que el alumnado se
encontrará en la vida real. Por ello, cabe desarrollar situaciones de aprendizaje donde se considere al
alumnado como agente social progresivamente autónomo, y gradualmente responsable de su propio proceso
de aprendizaje. Esto implica tener en cuenta sus repertorios lingüísticos, intereses y circunstancias
específicas, con el fin de sentar las bases para el aprendizaje a lo largo de toda la vida. Las situaciones de
aprendizaje en lengua extranjera deben promover la inclusión de diversas lenguas de su repertorio lingüístico
para determinadas tareas, por ejemplo, dentro de la competencia de mediación lingüística, para que el
alumnado aproveche los saberes básicos de las distintas materias lingüísticas y así promover el contraste y
la reflexión entre lenguas. Asimismo, se deben favorecer aquellas situaciones de aprendizaje donde se
incluyan materias tanto lingüísticas como no lingüísticas, siguiendo por ejemplo la metodología TIL-TILC, para
fomentar el trabajo en ámbitos.

Los criterios de evaluación de la materia establecen el nivel de consecución de las competencias
específicas que se espera al final del segundo curso de la etapa y al final de esta. En su formulación se incluye
la actuación que el alumnado debe realizar, los saberes que ello implica y la situación o contexto en el que se
espera que los movilice. En su nivelación se ha tomado como referencia los descriptores del Marco Común
Europeo de Referencia para las Lenguas, adaptados a la madurez y desarrollo psicoevolutivo propio de la
etapa de Educación Secundaria Obligatoria.

2. Competencias especificas

2.1.    Competencia específica 1

Multilingüismo e interculturalidad

Analizar y usar los repertorios lingüísticos de distintas lenguas, reflexionando sobre su funcionamiento
y tomando conciencia de los propios conocimientos, valorando la diversidad lingüística y cultural a partir de la
lengua extranjera.

2.1.1.
Descripción de la competencia 1

El uso y reflexión sobre el funcionamiento del repertorio lingüístico están vinculados al enfoque
plurilingüe de la adquisición de lenguas, puesto que las experiencias del alumnado sobre las lenguas que
conoce sirven para el aprendizaje y mejora de las nuevas, así como para desarrollar su repertorio lingüístico
plurilingüe y su sensibilización cultural. Precisamente el fomento de la conciencia intercultural favorece el
entendimiento con los demás, y sirve para que el alumnado actúe de forma empática y respetuosa en
situaciones interculturales, evitando la distorsión estereotipada y la discriminación hacia lo diferente.

Esta competencia específica parte del enfoque intercultural en el que el concepto de intercomprensión
lingüística y cultural entre dos o más lenguas resulta clave puesto que implica apoyarse en la lengua materna
para acceder a una lengua extranjera. En este sentido, en el proceso de enseñanza-aprendizaje de una
lengua extranjera, el alumnado realiza constantes comparaciones entre las estructuras de su repertorio
lingüístico por medio transferencias que contribuyen a la adquisición de la competencia comunicativa. Por
tanto, se debe partir de conocimientos previos de otras lenguas para aprender una nueva, y considerar estos
conocimientos como recursos potenciales en lugar de obstáculos.

En el proceso de aprendizaje de las lenguas se establece una comparación continua entre los
aspectos culturales de las lenguas, explorando similitudes y diferencias que es necesario evidenciar para la
construcción de la competencia plurilingüe e intercultural. El alumnado no sólo tiene un perfil lingüístico propio,
sino también un perfil cultural, y ambos se pueden solapar en mayor o menor medida (por ejemplo, un alumno
o una alumna puede ser competente en una lengua y desconocer la cultura de las comunidades que la hablan
y viceversa). Por tanto, es conveniente la incorporación de aspectos tanto lingüísticos como culturales en el
aula de lenguas extranjeras para consolidar estos perfiles.

En Educación Secundaria Obligatoria se espera que el alumnado profundice en la reflexión sobre las
lenguas que conoce y establezca sus propias relaciones, analizando semejanzas y diferencias entre la lengua

extranjera y las lenguas de su repertorio lingüístico, con el fin de ampliar sus conocimientos y estrategias
comunicativas para responder a situaciones lingüísticas diversas.

Asimismo, en esta etapa se debe promover la valoración crítica y adecuación a la diversidad, tanto
lingüística como cultural, para propiciar que el alumnado adquiera estrategias que le permitan establecer
relaciones con personas de otras culturas, abriéndose a nuevas experiencias, ideas y sociedades, lo cual
repercutirá en su formación como ciudadano que debe afrontar los desafíos del siglo XXI.

Al término del segundo curso de la ESO, el alumnado debería comparar y contrastar similitudes y
diferencias entre distintas lenguas mediante la reflexión sobre su funcionamiento de manera progresivamente
autónoma, y aceptar la diversidad lingüística y cultural propia de países donde se habla la lengua extranjera.
Al final de la etapa, tendría que realizar procesos de autoevaluación y coevaluación de las estrategias más
eficaces para superar sus dificultades y progresar en su propio aprendizaje a través del contraste de códigos,
a la vez que debería aplicar estrategias para explicar y apreciar la diversidad lingüística.

2.2.
Competencia específica 2

Comprensión oral

Interpretar textos orales, breves y sencillos, sobre temas predecibles y no predecibles del ámbito
personal, social, educativo y profesional, utilizando los conocimientos adecuados sobre los géneros textuales
y las estrategias de comprensión y de escucha activa.

2.2.1    Descripción de la competencia 2

El alumnado debe comprender textos orales y multimodales en lengua estándar con una progresiva
complejidad entre la obtención de la información literal y específica, hasta llegar a la información explícita e
implícita. El trabajo de comprensión se centrará en géneros textuales específicos como: conversaciones,
entrevistas, anuncios, biografías, noticias, canciones, poemas, artículos de opinión, podcast, vídeo,
conferencias, etc. Muchos de estos textos, adaptados o auténticos, pertenecen a los ámbitos de las relaciones
interpersonales, los medios de comunicación social, el ámbito educativo y textos literarios.

Es necesario que el alumnado seleccione, de forma autónoma, las estrategias más adecuadas de
comprensión (reconocer, anticipar, inferir, retener, interpretar y seleccionar) y aplique técnicas de escucha
activa (formular preguntas para conectar con las ideas de los otros, mostrar empatía, o no hacer juicios de
valor).

Asimismo, debe ser capaz de reconocer y discriminar los elementos lingüísticos de textos breves y
sencillos, e integrarlos en estructuras más amplias de significado por medio de una constante
retroalimentación y establecimiento de hipótesis que permitan analizar el contexto comunicativo. Además,
para construir el significado global, resulta clave comprender la organización de la información por medio de
la selección de ideas principales, la identificación de los detalles relevantes y las ideas secundarias.

De forma paralela, es esencial la anticipación e interpretación de la información implícita y el análisis
de la explícita, a partir de las cuales se realizan inferencias que permiten la identificación del sentido del texto,
la intención comunicativa subyacente del mensaje y, en definitiva, la comprensión del significado global del
texto. En este sentido, la estrategia de retener frases e ideas durante un periodo de tiempo para interpretarlas
posteriormente y mantenerlas en la memoria a largo plazo resultará básica para completar la comprensión de
una forma eficiente.

Es importante hacer énfasis en la interpretación de los elementos gráficos y audiovisuales, así como
en la identificación del género discursivo y la inferencia del significado de palabras y expresiones de uso poco
frecuente.

Durante el proceso de comprensión es importante centrar la atención en los saberes lingüísticos,
paralingüísticos (gestos, ritmo en el discurso, dicción y entonación), así como extralingüísticos (entorno sonoro
y signos visuales) que permitirán optimizar los diferentes niveles del mismo. Para el éxito de este proceso es
recomendable que el alumnado oyente adopte una actitud activa, que muestre curiosidad, que sea objetivo

con el discurso, así como que comprenda el mensaje y la forma de ver las cosas des del punto de vista de la
persona emisora con la finalidad de poder interpretar el texto escuchado.

Además de dichas estrategias, la búsqueda de información en textos orales y multimodales, en
soportes tanto analógicos como digitales, resulta clave en la consolidación de los procesos de comprensión,
pues permite contrastar de forma crítica la fiabilidad de las fuentes y validar la información.

Finalmente, la comprensión necesita contextos dialógicos, que favorezcan la construcción de un
saber conjunto, que formen al alumnado en la identificación y rechazo de prejuicios y estereotipos de cualquier
tipo y promuevan la adquisición de valores para la equidad e igualdad, así como el respeto hacia las
diferencias étnico-culturales.

Al término del segundo curso de la ESO, el alumnado debería ser capaz de analizar el tema principal,
las ideas secundarias y detalles relevantes por medio de los significados implícitos que el alumnado puede
deducir a partir de la información extralingüística (gestos, sonidos e imágenes presentes en el texto oral o
multimodal). Al finalizar la etapa, además de aplicar las estrategias anteriores, tendría que ser capaz de emitir
valoraciones personales de textos orales y multimodales incluyendo estructuras lingüísticas y vocabulario de
uso común.

2.3.
Competencia específica 3

Comprensión escrita

Interpretar información explícita e implícita expresada en textos escritos y multimodales breves y
sencillos que incluyen estructuras y vocabulario de uso frecuente, sobre temas predecibles y no predecibles
de ámbito personal, social, educativo y profesional, mediante estrategias que permitan desarrollar su
repertorio lingüístico.

2.3.1. Descripción de la competencia 3

En la comprensión de textos escritos y multimodales, redactados en lengua estándar, se debe
localizar o recuperar la información específica predecible y no predecible por medio de una interacción
constante con el texto que implica realizar preguntas y anticipaciones para la comprensión de los significados.
Esta interacción compleja utiliza procesos cognitivos como establecer hipótesis, anticipar e identificar las ideas
principales y sus detalles, seleccionar la información específica y realizar las inferencias necesarias. Se debe
tener presente la importancia de la transferencia lingüística y el uso de todas aquellas estrategias adquiridas
en el aprendizaje de la L1.

Los niveles que interactúan para una óptima comprensión conllevan comprender la idea principal y el
sentido general del texto, así como un nivel más específico que permita identificar las ideas importantes, los
detalles y las ideas secundarias.

Entre los diferentes niveles, se pueden enumerar la comprensión literal, que permite extraer datos
explícitos; la inferencial, que permite interpretar y comprender información implícita; y la analítica, que permite
establecer comparaciones entre ideas principales y secundarias con la finalidad de establecer reflexiones o
conclusiones.

El aprendizaje de los diferentes niveles y estrategias debe adquirirse de manera gradual y autónoma
en la identificación de léxico, de estructuras lingüísticas y de expresiones de uso poco frecuente de textos en
formato impreso y digital escritos en un registro formal, informal o neutro. Muchos de estos textos, adaptados
o auténticos, pertenecen a los ámbitos personal, social, educativo y profesional.

El alumnado debe reconocer la organización textual y distinguir aquellos elementos discursivos y
lingüísticos que permitan identificar la tipología textual: relación entre tiempos verbales y conectores para un
texto narrativo, o los ordinales-cardinales para un texto instructivo. De forma paralela, se debe identificar e
inferir el significado del léxico y de las estructuras de uso frecuente y poco frecuente, reconocer los símbolos
ortográficos y de puntuación, y aplicar las reglas de decodificación entre sonido-grafía. Junto a ello, se debe
analizar e interpretar la información de tipo gráfico (iconos, imágenes…) y tipográfico (títulos, subtítulos,
exclamaciones, tipos de letra…) para completar la comprensión de un texto en formato analógico o digital.

En este proceso, desde el punto de vista plurilingüe, el profesorado debe ayudar a construir en el
alumnado una actitud crítica hacia los aspectos socioculturales y sociolingüísticos, así como los aspectos de
diversidad cultural que se dan en los textos presentes en la realidad del aula y en los medios de comunicación.

Además, la adquisición de la comprensión lectora afronta retos derivados de las nuevas formas de
distribución e interacción con la información. En este contexto se debe aprender a aplicar estrategias de
lectura crítica de información durante los procesos de búsqueda, selección y almacenaje de información
procedente de textos multimodales.

Al término de 2.º curso de la ESO, el alumnado debería ser capaz de comprender textos escritos y
multimodales en los que se identifica la función comunicativa, el tema principal y las ideas secundarias a partir
de la información extralingüística (soportes visuales, sonidos presentes en el texto multimodal, etc.) y sus
conocimientos previos. Al finalizar la etapa, además, tendría que comprender e inferir expresiones idiomáticas
de uso común y debería ser capaz de comparar la información con diferentes fuentes documentales con la
finalidad de hacer su propia valoración.

2.4.
Competencia específica 4

Expresión oral

Producir textos orales, de manera autónoma y fluida, aplicando estrategias de planificación,
producción y compensación, para expresar mensajes sencillos del ámbito personal, social, educativo y
profesional, mediante estrategias que permitan desarrollar su repertorio lingüístico.

2.4.1       Descripción de la competencia 4

La expresión oral implica expresar de forma estructurada y comprensible informaciones,
conocimientos, sentimientos y opiniones, adaptándose al registro adecuado en función del tipo de texto y
situación comunicativa.

Las estrategias de planificación, compensación y corrección que se ponen en funcionamiento en el
proceso de producción son múltiples, y abarcan desde realizar un esquema previo a la producción, a buscar
fórmulas para expresar ideas utilizando un repertorio lingüístico limitado, con la ayuda de elementos verbales
y no verbales, hasta el uso de repeticiones y aclaraciones.

La fase de planificación supone la preparación de esquemas o guiones que recojan las ideas más
importantes que se quieran transmitir en cada situación, utilizando un repertorio limitado de frases y
expresiones, así como de estructuras sencillas, según las necesidades concretas de las situaciones
comunicativas.

En la fase de producción oral el uso de saberes lingüísticos, paralingüísticos (gestos, ritmo en el
discurso, dicción y entonación), así como extralingüísticos (entorno sonoro y signos visuales) es necesario
para realizar una producción comprensible.

Durante la producción oral del mensaje pueden utilizarse estrategias de compensación como puede
ser el uso de repeticiones, aclaraciones o autocorrecciones, o recurrir a elementos lingüísticos como
sinónimos o paráfrasis y a elementos no lingüísticos como gestos, o señalar objetos, con el fin de poder llevar
a cabo la expresión oral de forma eficaz.

Al término del segundo curso de la ESO, el alumno debería producir textos orales breves y sencillos.
Al final de la etapa, tendría que ser capaz de producir, de forma autónoma, textos de diferentes tipologías
como descripciones, exposiciones, narraciones e instrucciones, entre otros, debería seleccionar el léxico
apropiado y utilizar el registro adecuado a la situación comunicativa. Además, tendría que hacer un uso
correcto y adecuado de los elementos morfosintácticos, fonéticos y fonológicos para conseguir una
comunicación eficaz, fluida y contextualizada.

2.5.
Competencia específica 5

Expresión escrita

Producir textos escritos y multimodales comprensibles y estructurados, de forma autónoma, para
expresar mensajes sencillos del ámbito personal, social, educativo y profesional, aplicando estrategias de
planificación, textualización y revisión, mediante estrategias que permitan desarrollar su repertorio lingüístico.

2.5.1.      Descripción de la competencia 5

La expresión escrita implica poner en práctica multitud de operaciones cognitivas previas, simultáneas
y posteriores a la realización del discurso, como son la planificación, la textualización y la revisión de mensajes
que traten de temas cotidianos de interés personal del ámbito personal, social, educativo y profesional.

La planificación ayuda a identificar los elementos de la situación comunicativa, como son la finalidad
comunicativa, el contexto, el destinatario, la estructura y el grado de formalidad que requiere el tipo de texto
elegido. Se necesita un trabajo previo para generar, seleccionar, organizar ideas y activar los elementos
lingüísticos necesarios para la posterior producción escrita.

Es conveniente partir de situaciones comunicativas experimentadas por el alumnado, ya que en la
producción de textos escritos interactúan conocimientos acerca del tema sobre el cual se desea escribir y
saberes lingüísticos y discursivos que hacen referencia al texto.

La textualización implica la utilización del vocabulario, las expresiones y las estructuras del repertorio
lingüístico adquirido que se adecúen a la situación comunicativa y al propósito comunicativo. El proceso de
escritura supone también la organización de las oraciones con conectores para producir un texto cohesionado
y también el ajuste del texto a las características de diferentes géneros textuales.

Finalmente, la fase de revisión del texto es necesaria para detectar posibles errores, poder
subsanarlos y así mejorar el resultado final. Además, el tratamiento del error supone una oportunidad de
aprendizaje que fomenta la capacidad de aprender a aprender.

Al término del segundo curso de la ESO, se espera que el alumnado adquiera las herramientas
necesarias para producir textos breves y estructurados a partir de modelos, mediante oraciones simples
enlazadas por conectores básicos. Al final de la etapa debería ser capaz de producir, de manera autónoma,
textos escritos y multimodales coherentes y cohesionados de distintos géneros textuales.

2.6.       Competencia específica 6

Interacción oral y escrita

Interactuar de manera oral, escrita y multimodal mediante intercambios sencillos de información, de
forma síncrona y asíncrona, mostrando autonomía e iniciativa, para responder a necesidades comunicativas
relacionadas con el ámbito personal, social, educativo y profesional, mediante estrategias que permitan
desarrollar su repertorio lingüístico.

2.6.1.        Descripción de la competencia 6

La interacción abarca la comprensión, la expresión, así como la construcción de un discurso conjunto,
que utilizará los repertorios plurilingües y pluriculturales del alumnado. La interacción es mucho más que la
suma de estas dos competencias, ya que se utilizan estrategias colaborativas como tomar el turno de palabra,
cooperar y pedir aclaraciones.

Esta competencia conlleva el trabajo en grupo además de la colaboración y la predisposición a
establecer diálogo con otros usuarios de la lengua. Por tanto, el alumnado debe ser capaz de llegar a un
entendimiento, llevar a cabo negociaciones de manera empática, asertiva y respetuosa hacia la diversidad,
así como ser correcto en las formas.

En la Educación Secundaria Obligatoria el alumnado debe entender, seleccionar, analizar y expresar
información paulatinamente más elaborada que en la etapa anterior, sobre temas cotidianos y de interés
personal, público, social, educativo y profesional, en textos orales, escritos y multimodales de distintos

géneros dialogados. Así pues, de manera autónoma, tiene que interaccionar con el profesorado, con el resto
de alumnado u otros usuarios o usuarias de la lengua extranjera en las funciones interpersonales,
colaborativas y transaccionales que se lleven a cabo.

Además, debe identificar y saber utilizar el registro adecuado a la situación comunicativa
(adecuación), organizar las ideas con claridad (coherencia), enlazar los enunciados en secuencias textuales
cohesionadas (cohesión) y respetar las normas gramaticales y ortográficas (corrección). Todo ello mientras
se incrementa de manera paulatina tanto la capacidad de utilizar las palabras y estructuras precisas en los
textos orales, escritos y multimodales, como la consciencia de la calidad y creatividad de la propia expresión.

En la interacción se debe identificar, seleccionar y utilizar elementos como la cortesía lingüística y la
etiqueta digital, los elementos verbales y no verbales de la comunicación y expresiones tanto predecibles
como no predecibles. Estrategias como el uso de la repetición, mantener un ritmo adecuado, tomar la palabra,
cooperar y pedir aclaraciones, son esenciales en esta competencia. Asimismo, la escucha activa será
fundamental puesto que contribuye a la convivencia, a la cooperación, a la tolerancia y a la comunicación
eficaz.

Al término del segundo curso de la ESO, el alumnado debería interactuar en conversaciones simples,
sobre temas predecibles, de manera progresivamente autónoma, mostrando interés, respeto y empatía por
los interlocutores. Al final de esta etapa, el alumnado tendría que interactuar en conversaciones de manera
autónoma y espontánea, mostrando interés, respeto y empatía por los interlocutores.

2.7.
Competencia específica 7

Mediación oral y escrita

Mediar entre interlocutores aplicando estrategias de adaptación, simplificación y reformulación del
lenguaje para procesar y transmitir información más elaborada, en situaciones comunicativas de ámbito
personal, social, educativo y profesional.

2.7.1.      Descripción de la competencia 7

La mediación es la actividad del lenguaje que consiste en explicar y facilitar la comprensión de
mensajes o textos orales, escritos y multimodales, utilizando estrategias como la reformulación, la adaptación
o la simplificación de la lengua, en consonancia con el objetivo, la situación y los interlocutores o destinatarios
de la comunicación.

El alumnado actúa como agente social encargado de crear puentes, de ayudar a construir y de
trasvasar significados, de manera que se facilite la comprensión y expresión de mensajes, y también la
transmisión de información general y específica de manera autónoma, tanto en su propia lengua (mediación
intralingüística) como entre otras lenguas o variedades lingüísticas (mediación interlingüística).

La mediación lingüística trata desafíos como la resolución de conflictos de manera dialogada, el uso
de repertorios lingüísticos personales entre distintas lenguas o la valoración de la diversidad personal y
cultural de la lengua extranjera, puesto que supone el uso de estrategias y conocimientos para superar
barreras lingüísticas y culturales de forma cooperativa, negociar significados y llegar a un entendimiento de
manera empática y creativa.

En Educación Secundaria la mediación está orientada a procesar y reformular información e ideas de
textos orales, escritos y multimodales, sobre asuntos cotidianos, de interés personal y público, y utiliza tanto
medios convencionales como virtuales y se apoya de soporte visual. Son también estrategias específicas de
la mediación la simplificación, la adaptación y la transformación del lenguaje, recurrir a la lengua materna o al
uso de gestos, la repetición o las aclaraciones, y todo ello llevado a cabo de manera autónoma, responsable
y constructiva.

La mediación en esta etapa incluye actividades como resumir, explicar datos, parafrasear, tomar
notas, interpretar, traducir textos, así como participar en tareas colaborativas para facilitar la interacción y el
entendimiento pluricultural en entornos cooperativos de intercambios de información, adaptados a su nivel, y
combinando su repertorio lingüístico (L2-L2, L2-L1, L1-L2).

En ese sentido resulta fundamental conocer, reflexionar y contrastar tanto los elementos lingüísticos
y discursivos entre códigos (fonética, gramática, sintaxis, vocabulario o tipología textual), como
extralingüísticos (lenguaje corporal, signos visuales, pausas, ritmo y entonación), para la comprensión y
posterior reformulación del mensaje.

Al término del segundo curso de la ESO, la mediación se debería realizar combinando el repertorio
lingüístico del alumnado y comunicando, describiendo y explicando conceptos a un tercero, pudiendo para
ello apoyarse en soportes analógicos o digitales, e incorporar elementos lingüísticos y culturales en textos
orales, escritos y multimodales de los ámbitos personal, social y educativo. Al finalizar la etapa, el alumnado
tendría que ser capaz de parafrasear y reformular en la L2 las comunicaciones, descripciones o explicaciones,
sin tener siempre que recurrir a apoyos, e incorporar elementos lingüísticos y culturales de los ámbitos
personal, social, educativo y profesional.

3. Conexiones de las competencias específicas entre sí, con las competencias de otras materias y con
las competencias clave

3.1. Relaciones o conexiones con las otras CE de la materia

Las competencias específicas del área de lenguas extranjeras se conectan y complementan entre sí,
todas y cada una de ellas son necesarias para que el resto se puedan manifestar. Por ejemplo, para poder
transmitir mensajes orales y escritos en el proceso de comunicación se precisa de la comprensión previa.
Asimismo, sin comprensión no se puede dar ni la interacción ni la mediación, ya que ambas exigen responder
adecuadamente a una situación comunicativa. Además, la competencia multilingüe e intercultural es
transversal a todas ellas puesto que supone reflexionar sobre el uso de las lenguas para detectar similitudes
y diferencias, tanto lingüísticas como culturales. Por tanto, todas ellas están relacionadas en mayor o menor
medida. Las conexiones más destacables entre las diferentes competencias del área de lengua extranjera
son las siguientes:

La comprensión oral (CE2) y escrita (CE3) son componentes fundamentales en la adquisición del
resto de competencias específicas, ya que sin una correcta asimilación no es posible expresar, interactuar,
mediar con otras personas y aplicar conocimientos de ámbito multilingüe e intercultural. De esta manera, su
papel resulta clave en la adquisición de las competencias específicas de expresión oral (CE4) y escrita (CE5)
en tanto que permiten una correcta producción. En este sentido, facilitan la identificación del objetivo de la
situación comunicativa, la organización textual o la selección de las ideas principales y secundarias con la
finalidad de que el usuario exprese textos orales y escritos con coherencia y corrección adecuados al registro
y a las necesidades comunicativas de cada momento.

La competencia multilingüe e intercultural (CE1) facilita la comprensión del significado de mensajes y
textos, así como la detección de similitudes y diferencias lingüísticas y culturales para aplicar los
conocimientos a distintos contextos formales e informales. Asimismo, aspectos como el ritmo, la entonación
o el lenguaje no verbal pueden ser comunes o diferir entre las lenguas, por lo que su conocimiento resulta
clave para el desarrollo de la competencia de expresión oral.

Todo acto de interacción oral y escrita (CE6) requiere procesos de comprensión y expresión para
adaptarse a las necesidades comunicativas del contexto y poder interaccionar con el fin de resolver los retos
comunicativos planteados en cada momento. Junto a ello, resulta imprescindible identificar los aspectos
culturales divergentes entre lenguas y culturas para poder establecer una comunicación fluida y respetuosa
con sus usos y costumbres; estos aspectos se relacionan con la competencia multilingüe e intercultural (CE1).

Además, la interacción requiere mediar entre interlocutores en muchas ocasiones, ya que se
construye un discurso conjunto entre emisor y receptor, por lo que la relación con la competencia específica
de mediación oral y escrita (CE7) es evidente. Cualquier actividad de mediación exige una continua
comprensión para poder adaptar y reformular los significados durante la interacción con la finalidad de facilitar
la comunicación. Es importante tener en consideración que las actividades de esta competencia específica
resultan clave tanto para la reflexión como para la valoración de la diversidad lingüística y cultural, puesto que
mediar implica crear puentes para solucionar problemas de entendimiento, muchas veces promovidos por

diferencias, no sólo lingüísticas, sino también culturales entre lenguas y culturas diversas, estableciendo así
una conexión clara con la competencia multilingüe e intercultural (CE1). Dichas estrategias son transferibles
entre lenguas, y pueden contribuir al desarrollo de la competencia mediadora donde la negociación de
significados, llegar a acuerdos y transmitir información a terceros es fundamental.

3.2. Relaciones o conexiones con las CE de otras materias de la etapa

La competencia específica de multilingüismo e interculturalidad (CE1) tiene relación con el resto de
las materias del currículum, en particular, presenta una estrecha correlación con el resto de materias
lingüísticas, puesto que esta competencia implica el análisis y contraste entre elementos comunes y diferentes
del repertorio lingüístico del alumnado. Además, la vertiente intercultural se vincula a materias tanto
lingüísticas como no lingüísticas, ya que los elementos culturales están presentes tanto en los ámbitos
lingüísticos, los científicos, como en los artísticos.

Las competencias específicas de comprensión oral (CE2) y escrita (CE3) se vinculan al resto de
materias curriculares y resultan un elemento fundamental para la adquisición del resto de competencias,
puesto que sin comprensión no puede haber aprendizaje. Asimismo, las competencias específicas de
expresión oral (CE4) y escrita (CE5) son elementos clave tanto en las materias lingüísticas como no
lingüísticas, ya que la identificación del objetivo de la situación comunicativa, la organización textual, la
selección de las ideas principales y secundarias garantiza que el alumnado se exprese con la coherencia y
corrección adecuadas al registro y a las necesidades comunicativas de cada momento.

Por lo que respecta a las competencias de interacción (CE6) y mediación (CE7), ambas tienen
relación con el resto de las materias lingüísticas y no lingüísticas. En el caso de la interacción, esta
competencia conlleva comprender, expresar y comunicarse en diferentes situaciones comunicativas, en las
que se fomentan estrategias de transmisión de la información de manera personal, cooperativa y respetuosa,
así como aquellas que desarrollan elementos pragmáticos como la cortesía lingüística o la etiqueta digital.

En cuanto a la competencia específica de mediación, cabría señalar que todo acto de mediación exige
la comprensión previa para poder adaptar, reformular significados, explicar conceptos o crear puentes entre
distintos interlocutores. Es por ello que esta competencia se relaciona de manera muy estrecha con materias
no lingüísticas que conlleven explicar conceptos o trasladar información en distintos códigos, no
necesariamente lingüísticos, por ejemplo, explicar un problema matemático, trasladar los datos que aparecen
en un gráfico o indicar los pasos que se deben realizar en un sistema informático.

3.3. Relaciones o conexiones con las competencias clave

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 Multilingüismo e interculturalidad | X | X |  | X | X | X |  | X |
| CE2 Comprensión oral | X | X |  | X | X | X |  | X |
| CE3 Comprensión escrita | X | X |  | X | X | X |  | X |
| CE4 Expresión oral | X | X |  | X | X | X |  | X |
| CE5 Expresión escrita | X | X |  | X | X | X |  | X |
| CE6 Interacción oral y escrita | X | X | X | X | X | X | X | X |
| CE7 Mediación oral y | X | X | X | X | X | X | X | X |

| escrita |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

•
CCL: Competencia en comunicación lingüística
•
CP: Competencia plurilingüe
•
CMCT: Competencia matemática, ciencia y tecnológica
•
CD: Competencia digital
•
CPSAA: Competencia personal, social y de aprender a aprender
•
CC: Competencia ciudadana
•
CE: Competencia emprendedora
•
CCEC: Competencia en consciencia y expresión cultural

4. Saberes básicos

4.1.      Introducción

Los saberes básicos de la materia de Lengua Extranjera son compartidos por el conjunto de las
competencias específicas, ya que su aprendizaje, articulación y movilización son necesarios para conseguir
tanto el desarrollo de la competencia comunicativa como la conciencia plurilingüe e intercultural del alumnado.

Para la selección de los saberes básicos se ha tenido en cuenta la necesidad de incorporar contenidos
que engloben conocimientos, destrezas y actitudes, que sirvan de guía al profesorado en el diseño de
situaciones de aprendizaje en las que el alumnado resuelva situaciones comunicativas cotidianas típicas de
su entorno, ya sea del ámbito personal, social, educativo o profesional. Asimismo, estos saberes aparecen
de manera recurrente a lo largo de los cursos de la Educación Secundaria Obligatoria, de forma más básica
en el primer curso y gradualmente más elaborada y ampliada en los sucesivos cursos, promoviendo así el
establecimiento de conexiones y relaciones con los conocimientos previos.

La organización de los saberes se ha realizado atendiendo a la necesidad de relacionar el conjunto
de las competencias específicas de la materia con los conocimientos, y con las destrezas necesarias para
aplicarlos en diferentes situaciones comunicativas. La integración de los saberes en las situaciones de uso
lingüístico supone también la atención a los valores y a las actitudes que fomentan la conciencia plurilingüe e
intercultural del alumnado. En cambio, su disposición no denota una jerarquía, ni sugiere un trabajo separado
de los contenidos de cada apartado, sino al contrario; los diferentes saberes básicos de los distintos bloques
se deben combinar entre sí en el diseño de las situaciones de aprendizaje.

Los saberes básicos de la materia de Lengua Extranjera se dividen en tres grandes bloques, que se
deben desarrollar a lo largo de los cuatro cursos de la Educación Secundaria Obligatoria. El primer bloque,
Lengua y uso, integra los saberes propiamente lingüísticos de la lengua extranjera (fonética y fonología,
ortografía, gramática, vocabulario, funciones comunicativas y géneros textuales); el segundo bloque,
Estrategias comunicativas, incorpora las destrezas y habilidades necesarias para desenvolverse en las
situaciones comunicativas, así como reflexionar sobre el uso de los distintos saberes de su repertorio
lingüístico y analizar el propio proceso de aprendizaje; el tercer bloque, Cultura y sociedad, aúna los
conocimientos relativos a aspectos culturales (y transversales) de las culturas y sociedades vehiculadas en
la lengua extranjera, y su valoración como oportunidad de crecimiento y de relación con los demás.

4.2.      Bloque 1: Lengua y uso

| Lengua y uso. Transversal a todas las CE | 1.er Ciclo (cursos 1.º y 2.º) | 2.º ciclo (cursos 3.º y 4.º) |
| --- | --- | --- |
| Funciones comunicativas |  |  |

| • Funciones comunicativas básicas adecuadas al ámbito y al contexto comunicativo: saludos, despedidas y presentaciones; descripción de personas, objetos y lugares; situar eventos en el tiempo; situar objetos, personas y lugares en el espacio; petición e intercambio de información sobre cuestiones cotidianas; instrucciones y órdenes; ofrecer, aceptar y rechazar ayuda, proposiciones o sugerencias; expresar parcialmente el gusto o el interés y emociones básicas; narración de acontecimientos pasados, descripción de situaciones presentes, y expresión de sucesos futuros; expresar la opinión y la posibilidad. • Funciones comunicativas de uso común adecuadas al ámbito y al contexto comunicativo: saludos, despedidas y presentaciones; descripción y caracterización de personas, objetos, lugares, fenómenos y acontecimientos; situar eventos en el tiempo; situar objetos, personas y lugares en el espacio; petición e intercambio de información sobre cuestiones cotidianas; instrucciones y órdenes; ofrecer, aceptar y rechazar ayuda, proposiciones o sugerencias; expresar parcialmente el gusto o el interés y emociones; narración de acontecimientos pasados, descripción de situaciones presentes, y expresión de sucesos futuros; expresar la opinión y la posibilidad; argumentaciones sencillas; realizar hipótesis y suposiciones; expresar la posibilidad, la incertidumbre y la duda; reformular y resumir. • Principios del funcionamiento de las lenguas en lo referente al léxico, a las reglas gramaticales y a las variedades lingüísticas. • Comparación y contraste de los principios del funcionamiento de las lenguas en lo referente al léxico, a las reglas gramaticales y a las variedades lingüísticas. • Unidades lingüísticas de uso común y significados asociados a dichas unidades tales como expresión de la entidad y sus propiedades, cantidad y calidad, espacio y relaciones espaciales, tiempo y relaciones temporales, afirmación, negación, interrogación y exclamación, y relaciones lógicas básicas. | X X X | X X X |
| --- | --- | --- |
| Modelos contextuales y géneros discursivos |  |  |
| • Modelos contextuales y géneros discursivos de uso común en la comprensión, producción y coproducción de textos orales, escritos y multimodales, breves y sencillos, literarios y no literarios: características y reconocimiento del contexto (participantes y situación), expectativas generadas por el contexto; organización y estructuración según el género, la función textual y la estructura. | X | X |

Expresiones y léxico

| • Léxico de uso común y de interés para el alumnado, relativo a identificación personal, relaciones interpersonales, lugares y entornos cercanos, ocio y tiempo libre, vida cotidiana, salud y actividad física, vivienda y hogar, clima y entorno natural, tecnologías de la información y la comunicación. • Léxico de uso común y de interés para el alumnado, relativo a identificación personal, relaciones interpersonales, lugares y entornos, ocio y tiempo libre, salud y actividad física, vida cotidiana, vivienda y hogar, clima y entorno natural, tecnologías de la información y la comunicación, sistema escolar y formación. • Expresiones y léxico de uso común para comprender enunciados sobre la comunicación, la lengua, el aprendizaje y las herramientas de comunicación y aprendizaje (metalenguaje). • Expresiones y léxico específico de uso común para intercambiar ideas sobre la comunicación, la lengua, el aprendizaje y las herramientas de comunicación y aprendizaje (metalenguaje). | X X | X X |
| --- | --- | --- |
| Patrones sonoros, acentuales y rítmicos |  |  |
| • Patrones sonoros, acentuales, rítmicos y de entonación básicos y de uso común, intenciones comunicativas y significados asociados a dichos patrones. | X | X |
| Convenciones ortográficas |  |  |
| • Convenciones ortográficas básicas e intenciones comunicativas y significados asociados a los formatos, patrones y elementos gráficos. | X | X |
| Reflexión sobre la lengua |  |  |
| • Consciencia sobre las similitudes formales y diferencias de significados entre lenguas (préstamos, cognados, falsos amigos). • Reflexión sobre similitudes formales y diferencias de significados (préstamos, cognados, falsos amigos, etc.) y su aplicación en diferentes contextos comunicativos. | X | X |

4.3.      Bloque 2: Estrategias comunicativas

| Estrategias comunicativas. Transversal a todas las CE | 1.er Ciclo (cursos 1.º y 2.º) | 2.º ciclo (cursos 3.º y 4.º) |
| --- | --- | --- |
| Estrategias de comprensión y producción |  |  |
| • Estrategias de uso común para la planificación, ejecución, control y reparación de la comprensión, la producción y la coproducción de textos orales, escritos y multimodales. | X |  |

• Convenciones
y
estrategias
conversacionales de uso común, en formato síncrono o
asíncrono, para iniciar, mantener y terminar la
comunicación, tomar y ceder la palabra, pedir y dar
aclaraciones y explicaciones, reformular, comparar y
contrastar, resumir, colaborar, debatir.

X

| Estrategias conversacionales |  |  |
| --- | --- | --- |
| • Estrategias y técnicas para responder eficazmente a una necesidad comunicativa básica y concreta de forma comprensible, a pesar de las limitaciones derivadas del nivel de competencia en la lengua extranjera y en las lenguas familiares. • Estrategias y técnicas para responder eficazmente y con niveles crecientes de fluidez, adecuación y corrección a una necesidad comunicativa concreta de forma comprensible, a pesar de las limitaciones derivadas del nivel de competencia en la lengua extranjera y en las lenguas familiares. • Estrategias de uso común para identificar, organizar, retener, recuperar y utilizar creativamente unidades lingüísticas (léxico, morfosintaxis, patrones sonoros, etc.) a partir de la comparación de las lenguas y variedades que conforman el repertorio lingüístico personal. | X X | X X |
| Intercambios interculturales y mediación |  |  |
| • Interés e iniciativa en la realización de intercambios comunicativos a través de diferentes medios con hablantes o estudiantes de la lengua extranjera. • Estrategias para resolver conflictos interculturales en contextos personales, sociales y educativos. • Aplicación de las estrategias que permitan resolver conflictos interculturales en contextos personales, sociales, educativos y profesionales. • Conocimientos, destrezas y actitudes que permitan detectar y colaborar en actividades de mediación en situaciones cotidianas sencillas. | X X X | X X X |
| Estrategias de autoevaluación y coevaluación |  |  |
| • Autoconfianza. El error como instrumento de mejora y propuesta de reparación. • Autoconfianza e iniciativa. El error como parte integrante del proceso de aprendizaje. • Estrategias y herramientas de uso común de autoevaluación y coevaluación, analógicas y digitales, individuales y cooperativas. | X X | X X |
| Tratamiento de la información |  |  |
| • Recursos para el aprendizaje y estrategias básicas de búsqueda de información: diccionarios, libros de consulta, bibliotecas, recursos digitales e informáticos. • Identificación de la autoría de las fuentes | X X | X |

consultadas y los contenidos utilizados.

X

X

• Respeto a la propiedad intelectual y a los
derechos de autor sobre las fuentes consultadas y
contenidos utilizados.

X

• Herramientas analógicas y digitales de uso
común para la comprensión, producción y coproducción
oral, escrita y multimodal; y plataformas virtuales de
interacción y colaboración educativa (aulas virtuales,
videoconferencias,
herramientas
digitales
colaborativas) para el aprendizaje, la comunicación y el
desarrollo de proyectos con las personas hablantes y
estudiantes de la lengua extranjera.

4.4.         Bloque 3: Cultura y sociedad

| Cultura y sociedad. Transversal a todas las CE | 1.er Ciclo (cursos 1.º y 2.º) | 2.º ciclo (cursos 3.º y 4.º) |
| --- | --- | --- |
| Aspectos socioculturales y sociolingüísticos |  |  |
| • Aspectos socioculturales y sociolingüísticos de uso común relativos a la vida cotidiana, las condiciones de vida y las relaciones interpersonales; convenciones sociales básicas; lenguaje no verbal, cortesía lingüística y etiqueta digital; cultura, costumbres y valores propios de países donde se habla la lengua extranjera. • Valoración crítica de las diferencias en la comunicación no verbal entre las distintas lenguas y culturas. • Reconocimiento de la necesidad de adaptar el propio repertorio comunicativo al contexto social y cultural en el cual se desarrolla la comunicación. • Adaptación del propio repertorio comunicativo al contexto social y cultural en el cual se desarrolla la comunicación. • Estrategias básicas para entender y apreciar la diversidad lingüística, cultural y artística, atendiendo a valores ecosociales y democráticos. | X X X X | X X X X |
| Diversidad lingüística e intercultural |  |  |
| • Reconocimiento de las diferencias y la diversidad plurilingüe e intercultural. • Respeto y valoración crítica de las diferencias y de la diversidad plurilingüe e intercultural. • Diferencias entre lengua y sociedad, variedades lingüísticas, diferentes registros (estándar, informal y formal). • Estereotipos de otras culturas donde se habla la lengua extranjera. • Estereotipos de otras culturas donde se habla la lengua extranjera en contraste con los propios. | X X | X X X |
| Lengua extranjera como medio de comunicación |  |  |

• Patrones culturales de uso común propios de
la lengua extranjera.

X

X

• La
lengua
extranjera
como
medio
de
comunicación interpersonal e internacional, fuente de
información, y como herramienta para el enriquecimiento
personal.

X

X

• La
lengua
extranjera
como
medio
de
comunicación interpersonal e internacional, fuente de
información, y como herramienta de participación social
y de enriquecimiento personal.

5.
Situaciones de aprendizaje

El diseño de contextos de aprendizaje depende del tercer nivel de concreción curricular, ya que los
centros, a través de su proyecto educativo y los responsables y las responsables de las áreas y departamentos
didácticos, son los que deben planificar las situaciones de enseñanza y aprendizaje. Estas situaciones deben
tener en cuenta los usos lingüísticos en los distintos entornos físicos y virtuales, puesto que la lengua
extranjera no sólo se adquiere dentro del aula, sino que las distintas experiencias fuera de ella complementan
el proceso de aprendizaje (por ejemplo, participación en intercambios, preparación de certificaciones oficiales,
acceso a contenido en lengua original en plataformas digitales). Por tanto, cabe considerar las diferentes
esferas de la vida en las que se proyectan las competencias clave, y en particular, la competencia en
comunicación lingüística y plurilingüe.

Asimismo, la concreción curricular de las lenguas debe ir necesariamente ligada al proyecto lingüístico
del centro, que marcará, por un lado, las situaciones de aprendizaje que requieran la integración de diversas
lenguas del currículum; por otro lado, indicará en qué lengua se imparten determinadas áreas o materias para
la planificación de situaciones de aprendizaje interdisciplinares, que permitan la coordinación de áreas y
materias lingüísticas con determinadas áreas no lingüísticas.

De manera general, las situaciones de aprendizaje en el área de lenguas extranjeras deberían
fomentar su uso en contextos lo más reales posible. Además, los usos lingüísticos en estas situaciones deben
ir acompañados de una reflexión sobre las estructuras comunicativas implicadas, así como las estrategias
utilizadas y las actitudes asociadas a estas situaciones, para promover así, no sólo la competencia
comunicativa y la conciencia plurilingüe e intercultural, sino también la autonomía del alumnado en su proceso
de aprendizaje.

Las situaciones de aprendizaje en la materia de Lengua Extranjera deberían presentar las siguientes
características:

El aprendizaje debe basarse en la acción, teniendo en cuenta las situaciones comunicativas que se
dan en la vida real para el diseño de tareas comunicativas, donde el rol del profesorado sea de facilitador y el
del alumnado un agente social activo.

Las tareas comunicativas han de basarse en situaciones y contextos reales del entorno personal,
social, académico y profesional que supongan un reto, que integren las diferentes competencias específicas,
y que promuevan la oralidad, en un entorno de aprendizaje significativo.

Las situaciones de aprendizaje, en general, deben incorporar los siguientes elementos:

•
Plantear situaciones relacionadas con la actualidad.
•
Suponer un desafío o reto, tomando como referencia los desafíos del siglo XXI (exigencia).
•
Incorporar diferentes niveles de dificultad (inclusión) mediante la programación multinivel, así como
variedad en su naturaleza.
•
Presentar la posibilidad de personalizarlas (personalización).
•
Tener un enfoque interdisciplinar, así como plurilingüe e intercultural.

•
Incorporar diversas fases que incluyan recepción, interacción, mediación y (co)producción, junto con
una fase de reflexión final.
•
Implicar la cooperación del alumnado a través de la mediación de conceptos y/o la comunicación y la
negociación de significados.
•
Promover la gestión de las emociones: clima de confianza, empatía, adaptación, resolución de
problemas, autoreflexión, autonomía, motivaciones y valores.
•
Utilizar formatos y herramientas analógicas y digitales (tanto en el ámbito educativo como en el
personal, social y profesional).

Para el diseño de las situaciones en Lengua Extranjera se debe adoptar un enfoque comunicativo, a
través de metodologías diversas, que permitan al alumnado conseguir un cierto grado de autonomía en el uso
de la lengua extranjera como medio de comunicación.

En ese sentido, el enfoque orientado a la acción recomendado por el MCER insiste en la creación de
tareas que reproduzcan situaciones auténticas de la vida real, que tengan alguna utilidad, que incluyan el
componente social y en las que la interacción tenga un papel destacado. Para ello, el alumnado debe ser
consciente de la finalidad y naturaleza de la tarea, lo que su compleción conlleva según tareas lingüísticas y
no lingüísticas, así como sus fortalezas y debilidades, es decir, su nivel actual de conocimientos, sus carencias
y qué procedimientos necesita para poder llevar a cabo la tarea con éxito.

6.
Criterios de evaluación

CE1 Multilingüismo e interculturalidad

| 2.º ESO (1.er ciclo) | 4.º ESO (2.º ciclo) |
| --- | --- |
| 1.1. Contrastar las similitudes y diferencias entre distintas lenguas, de manera progresivamente autónoma, sobre aspectos básicos de su funcionamiento. | 1.1. Contrastar e inferir las similitudes y diferencias entre distintas lenguas, de manera autónoma, sobre aspectos básicos de su funcionamiento. |
| 1.2. Utilizar y diferenciar, de forma progresivamente autónoma, los conocimientos y estrategias que forman su repertorio lingüístico, con apoyo de otros participantes y de soportes analógicos y digitales. | 1.2. Utilizar y diferenciar, de forma autónoma, los conocimientos y estrategias que forman su repertorio lingüístico con apoyo de otros participantes y de soportes analógicos y digitales. |
| 1.3. Diferenciar y valorar, de forma progresivamente autónoma, la diversidad lingüística y cultural propia de países donde se habla la lengua extranjera como fuente de enriquecimiento personal, mostrando interés por comprender elementos culturales y lingüísticos del ámbito personal, social y educativo. | 1.3. Analizar y valorar, de forma autónoma, la diversidad lingüística y cultural propia de países donde se habla la lengua extranjera como fuente de enriquecimiento personal, mostrando interés por comprender elementos culturales y lingüísticos del ámbito personal, social, educativo y profesional. |
| 1.4. Mostrar respeto por las diferencias lingüísticas y culturales de la lengua extranjera, identificando prejuicios y estereotipos, y reconociendo la pluralidad lingüística como fuente de riqueza cultural. | 1.4. Mostrar respeto por las diferencias lingüísticas y culturales de las variedades de la lengua extranjera, valorando prejuicios y estereotipos, y reconociendo la pluralidad lingüística como fuente de riqueza cultural. |

CE2 Comprensión oral

| 2.º ESO (1.er ciclo) | 4.º ESO (2.º ciclo) |
| --- | --- |
| 2.1. Escuchar de forma activa e interpretar, de manera progresivamente | 2.1. Escuchar de forma activa e interpretar, de manera autónoma, textos orales y |

| autónoma, textos orales y multimodales breves y sencillos, sobre temas predecibles y no predecibles, del ámbito personal, social, educativo y profesional, así como textos literarios adecuados a su nivel. | multimodales, sobre temas predecibles y no predecibles, del ámbito personal, social, educativo y profesional, así como textos literarios adecuados a su nivel. |
| --- | --- |
| 2.2. Analizar la función comunicativa, el tema principal, las ideas secundarias y detalles relevantes de textos orales y multimodales a partir de los significados explícitos e implícitos presentes en la información de carácter lingüístico y extralingüístico, por medio de inferencias y sus conocimientos previos. | 2.2. Analizar y comparar los elementos formales y de contenido, los significados explícitos e implícitos, en textos orales y multimodales, así como la información lingüística y extralingüística, utilizando estrategias de comprensión oral adecuadas al texto con la finalidad de valorar la información. |
| 2.3. Inferir el significado de vocabulario y el uso de estructuras frecuentes, así como expresiones básicas de uso común del ámbito personal, social, educativo y profesional | 2.3. Inferir el significado de vocabulario y el uso de estructuras frecuentes y poco frecuentes, así como expresiones idiomáticas de uso común del ámbito personal, social, educativo y profesional. |

CE3 Comprensión escrita

| 2.º ESO (1.er ciclo) | 4.º ESO (2.º ciclo) |
| --- | --- |
| 3.1. Leer e interpretar, de manera progresivamente autónoma, textos escritos y multimodales breves y sencillos, sobre temas predecibles y no predecibles del ámbito personal, social, educativo y profesional, y elegir aquellos que se adecuen a sus gustos e intereses. | 3.1. Leer e interpretar, de manera autónoma, textos escritos y multimodales breves y sencillos, sobre temas predecibles y no predecibles del ámbito personal, social, educativo y profesional, y elegir aquellos que se adecuen a sus gustos e intereses. |
| 3.2. Identificar, de forma progresivamente autónoma, la función comunicativa, el tema principal, las ideas secundarias de textos escritos y multimodales, así como sus significados explícitos e implícitos de carácter lingüístico y su relación con la información de carácter extralingüístico. | 3.2. Identificar, de forma autónoma, la función comunicativa, el tema principal, las ideas secundarias de textos escritos y multimodales, así como sus significados explícitos e implícitos de carácter lingüístico y su relación con la información de carácter extralingüístico. |
| 3.3. Inferir el significado de vocabulario y el uso de estructuras frecuentes, así como expresiones básicas de uso común del ámbito personal, social, educativo y profesional en textos escritos y multimodales. | 3.3. Inferir el significado de vocabulario y el uso de estructuras frecuentes, así como expresiones idiomáticas de uso común del ámbito personal, social, educativo y profesional, en textos escritos y multimodales. |
| 3.4. Localizar, seleccionar y contrastar la información en medios digitales, de forma progresivamente autónoma, de diferentes textos multimodales del ámbito, personal, social, educativo y profesional. | 3.4. Localizar, seleccionar y contrastar la información en medios digitales, de forma autónoma, diferentes textos multimodales del ámbito, personal, social, educativo y profesional a partir de la información de diferentes fuentes. |

CE4 Expresión oral

| 2.º ESO (1.er ciclo) | 4.º ESO (2.º ciclo) |
| --- | --- |
| 4.1. Producir diferentes tipos de textos orales breves, con una pronunciación, ritmo y entonación adecuados, de forma | 4.1. Producir diferentes tipos de textos orales, con una pronunciación, ritmo y entonación adecuados, de forma autónoma, utilizando un |

| progresivamente autónoma, utilizando un registro informal y formal, así como un repertorio de expresiones, léxico y estructuras de uso frecuente en situaciones del ámbito personal, social, educativo y profesional. | registro informal y formal, y también seleccionar expresiones, léxico y estructuras variadas, en situaciones del ámbito personal, social, educativo y profesional. |
| --- | --- |
| 4.2. Utilizar estrategias de planificación, producción, compensación y revisión, como el uso de palabras o frases sencillas de las diferentes lenguas de su repertorio lingüístico o el uso del contexto verbal y no verbal. | 4.2. Utilizar estrategias de planificación, producción, compensación y revisión, de manera autónoma, como el uso de paráfrasis para suplir carencias de vocabulario y estructuras, el uso de elementos léxicos aproximados o la adaptación del mensaje a situaciones nuevas. |

CE5 Expresión escrita

| 2.º ESO (1.er ciclo) | 4.º ESO (2.º ciclo) |
| --- | --- |
| 5.1. Producir textos escritos y multimodales breves, coherentes y cohesionados, de forma progresivamente autónoma, en soportes analógicos y digitales, utilizando tanto el registro formal como informal según la tipología textual y la situación comunicativa, sobre temas del ámbito personal, educativo, social y profesional. | 5.1. Producir textos escritos y multimodales coherentes y cohesionados, de forma autónoma, en soportes analógicos y digitales, utilizando tanto el registro formal como informal según la tipología textual y la situación comunicativa, sobre temas del ámbito personal, educativo, social y profesional. |
| 5.2. Aplicar estrategias de revisión de textos, de forma progresivamente autónoma, a partir de modelos de los textos escritos. | 5.2. Aplicar estrategias de revisión de textos, de forma autónoma, proponiendo alternativas de respuesta. |

CE6 Interacción oral y escrita

| 2.º ESO (1.er ciclo) | 4.º ESO (2.º ciclo) |
| --- | --- |
| 6.1. Participar en conversaciones simples, sobre temas predecibles, en contextos analógicos y digitales, utilizando guiones como apoyo. | 6.1. Participar en conversaciones de manera autónoma y espontánea, en contextos analógicos y digitales. |
| 6.2. Utilizar la cortesía lingüística, la etiqueta digital, el lenguaje no verbal y estrategias para indicar que no se ha entendido el mensaje y solicitar repetición. | 6.2. Utilizar la cortesía lingüística, la etiqueta digital, el lenguaje no verbal y estrategias para indicar que no se ha entendido el mensaje, para solicitar repetición y mostrar que entiende y sigue la conversación. |
| 6.3. Interactuar mostrando interés, respeto y empatía hacia los interlocutores en contextos pluriculturales, cotidianos, informales, como dar y pedir la palabra, cooperar y pedir aclaraciones. | 6.3. Interactuar mostrando interés, respeto y empatía hacia los interlocutores en contextos pluriculturales, cotidianos, formales e informales, como dar y pedir la palabra, cooperar y pedir aclaraciones de forma autónoma y espontánea. |

CE7 Mediación oral y escrita

| 2.º ESO (1.er ciclo) | 4.º ESO (2.º ciclo) |
| --- | --- |
| 7.1. Mostrar interés por participar en la solución de problemas de incomprensión y entendimiento, sobre asuntos diversos del ámbito personal, social y educativo. | 7.1. Mostrar interés por participar en la solución de problemas de incomprensión, sobre asuntos diversos del ámbito personal, social, educativo y profesional. |

| 7.2. Comprender, comunicar y describir textos en diferentes soportes, o explicar conceptos, de forma oral o escrita, combinando su repertorio lingüístico (L2-L2, L1-L2, L2-L1), que incluyan vocabulario, expresiones y estructuras frecuentes, de forma progresivamente autónoma. | 7.2. Comprender, comunicar, describir y parafrasear textos en diferentes soportes, o explicar conceptos, de forma oral o escrita, combinando su repertorio lingüístico (L2-L2, L1-L2, L2-L1), que incluyan vocabulario, expresiones y estructuras frecuentes y poco frecuentes, de forma autónoma. |
| --- | --- |
| 7.3. Seleccionar y aplicar, de forma progresivamente autónoma, estrategias de simplificación y adaptación de la lengua, que faciliten la comprensión y expresión oral y escrita de la información en distintas lenguas (L2-L2, L1-L2, L2-L1), adecuadas a las situaciones comunicativas, con apoyo puntual de soportes analógicos o digitales, en función de las necesidades de cada momento. | 7.3. Seleccionar y aplicar, de forma autónoma, estrategias de simplificación, adaptación y reformulación de la lengua, que faciliten la comprensión y expresión oral y escrita de la información en distintas lenguas (L2-L2, L1- L2, L2-L1), adecuadas a las intenciones comunicativas, las características contextuales y la tipología textual, usando recursos y apoyos analógicos o digitales, en función de las necesidades de cada momento. |
