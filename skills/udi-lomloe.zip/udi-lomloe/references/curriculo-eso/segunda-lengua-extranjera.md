# SEGUNDA LENGUA EXTRANJERA

> Fuente: Secundaria.pdf, páginas 1166-1187 (versión en castellano).

SEGUNDA LENGUA EXTRANJERA

1. Presentación

La comunicación en distintas lenguas en la sociedad actual, caracterizada por la globalización,
el plurilingüismo y la interculturalidad, exige una educación y formación más adaptadas a las demandas
que esta sociedad requiere para el desarrollo de personas independientes, activas y comprometidas
con la realidad contemporánea. En ese sentido, la lengua extranjera, en consonancia con las directrices
marcadas por el Consejo de Europa a través del Marco Común Europeo de Referencia para las
Lenguas, contribuye al desarrollo competencial que permitirá al alumnado afrontar los retos del siglo
XXI como personas integradas en la sociedad y profesionales del futuro, en un mundo interconectado,
global y cambiante, donde la internacionalización, la movilidad y el descubrimiento de otras culturas
estén presentes. Así, el objetivo del aprendizaje de lenguas en la actualidad no debe ser el dominio de
una, dos o más lenguas consideradas de forma aislada, sino el enriquecimiento del repertorio
lingüístico individual y el desarrollo del perfil plurilingüe e intercultural compuesto por distintos niveles
de competencia en distintas lenguas que van cambiando en función de los intereses y necesidades de
cada momento. Esta es precisamente la finalidad de incluir el aprendizaje de una segunda lengua
extranjera en la etapa de la Educación Secundaria Obligatoria. .

En este currículo, las dos dimensiones básicas del plurilingüismo están presentes: la dimensión
comunicativa y la dimensión intercultural. Es por ello por lo que las competencias específicas de la
materia se vinculan con las competencias clave del perfil de salida de esta etapa, así como los retos
del siglo XXI. La Segunda Lengua Extranjera está directamente relacionada con el desarrollo de las
competencias clave de comunicación lingüística y plurilingüe, puesto que supone incorporar
mecanismos y estrategias para el procesamiento y transmisión de la información, integrando saberes
y conocimientos del repertorio lingüístico propio como la lengua materna, las lenguas oficiales y el resto
de lenguas extranjeras, para así trasladarlos al aprendizaje de otras lenguas y culturas. Asimismo,
fomenta el desarrollo del resto de competencias clave puesto que supone moverse en entornos de
aprendizaje analógicos y digitales (competencia digital), inferir y deducir información para la
construcción de significados (competencia matemática y en ciencia, tecnología e ingeniería), así como
reflexionar sobre su proceso de aprendizaje (competencia personal, social y aprender a aprender) y
apreciar, valorar la expresión artística, cultural y literaria de forma empática y respetuosa (competencia
en conciencia y expresión cultural). Esta materia, a través de los saberes de sus competencias
específicas, contribuye de manera clara a que el alumnado pueda afrontar retos del siglo XXI como
son el reconocimiento y respeto por la diversidad lingüística y cultural, la gestión de situaciones
interculturales de convivencia democrática, la resolución dialogada de los conflictos o el
establecimiento de vínculos personales y sociales basados en el respeto y la igualdad de derechos.

Hay que resaltar que la segunda lengua extranjera puede ser una lengua románica (en el caso
del francés o italiano) o una lengua germánica (en el caso del alemán). En ambas situaciones, el
alumnado tiene la ventaja de no partir de cero en el aprendizaje de dichas segundas lenguas pues ya
ha adquirido las bases y destrezas propias del castellano, el valenciano y una primera lengua
extranjera.

La materia de Segunda Lengua Extranjera, en el desarrollo de las competencias específicas
de comprensión, expresión, interacción y mediación, fomenta que el alumnado pueda continuar con la
adquisición de los elementos básicos de la cultura en sus aspectos humanísticos, adquisición que ya
inició con la Primera Lengua Extranjera, y amplía su contribución al desarrollo y consolidación de
hábitos de estudio y de trabajo, como preparación a su incorporación a estudios posteriores y su
inserción laboral. Al mismo tiempo, promueve el desarrollo de valores como el respeto a los derechos

y libertades individuales, la igualdad efectiva, el esfuerzo y responsabilidad individual, así como el
aprendizaje a lo largo de la vida con la adquisición de hábitos de trabajo y conocimientos en el ámbito
lingüístico. Hay que destacar la importancia de las herramientas digitales para reforzar el aprendizaje,
la enseñanza y la evaluación de idiomas. Por ello, el desarrollo del pensamiento crítico, la
alfabetización digital y el uso adecuado, seguro, ético y responsable de la tecnología suponen un
elemento de aprendizaje muy relevante en esta materia.

Para el aprendizaje de la segunda lengua extranjera y el desarrollo de su dimensión
comunicativa e intercultural, cabe adoptar un enfoque comunicativo, en el que destaque el aprendizaje
orientado a la acción, teniendo como referente el Marco Común Europeo de Referencia para las
Lenguas y su volumen complementario. Este enfoque considera que los usuarios de una lengua, así
como el alumnado que la aprende, son agentes sociales, es decir, son miembros de una sociedad que
lleva a cabo una serie de tareas, no sólo relacionadas con la lengua, en un entorno y circunstancias
específicos. Por ello, metodologías comunicativas como el aprendizaje basado en tareas o el
Tratamiento Integrado de Lenguas (TIL) y Tratamiento Integrado de Lenguas y Contenido (TILC),
resultan apropiadas para el desarrollo competencial del currículo en esta materia, así como el uso de
otras metodologías eclécticas que sigan un enfoque comunicativo.

La materia de Segunda Lengua Extranjera presenta una continuidad en las competencias
específicas respecto a Educación Primaria, ya que supone una progresión respecto a los saberes
adquiridos a lo largo de esta etapa, y que se desarrollarán partiendo del repertorio lingüístico y de las
experiencias previas del alumnado. Por tanto, implica una ampliación y profundización de las
competencias específicas de comprensión, expresión, interacción y mediación, así como la extensión
en cuanto a los ámbitos de las situaciones comunicativas, los géneros textuales y la utilización de
soportes digitales en relación con los trabajados en Educación Primaria en la Primera Lengua
Extranjera. Asimismo, la progresión de una a otra etapa conlleva ahondar en la reflexión del
funcionamiento y el contraste de distintas lenguas de su repertorio lingüístico, así como la incorporación
de diversas lenguas en las actividades de mediación lingüística que contribuyen al desarrollo de su
conciencia plurilingüe y pluricultural.

La Segunda Lengua Extranjera en la etapa de la Educación Secundaria Obligatoria es una
materia de opción ofertada en cuarto curso. Sin embargo, el alumnado que la estudia puede haber
iniciado el contacto con ella con anterioridad, puesto que se incluye entre las materias optativas de
oferta obligada de primero a tercero en esta etapa, o, incluso antes, durante la Educación Primaria.
Por ello, el currículo para la materia de Segunda Lengua Extranjera debe ser lo suficientemente flexible
como para ajustarse a la diversidad de niveles que puede presentar el alumnado que tiene la
posibilidad de iniciar y de finalizar su aprendizaje en cualquiera de los cursos de la etapa.

En la definición de los criterios de evaluación se detalla también el grado de adquisición de
cada perfil para dos perfiles de salida en concreto: un perfil 1, que correspondería al alumnado que
solo ha cursado la materia durante dos cursos de la Educación Secundaria Obligatoria, ya sean
consecutivos o no, y un perfil 2 para aquel que ha cursado la materia de Segunda Lengua Extranjera
desde primero hasta cuarto. En la formulación de estos criterios, que establecen el nivel de
consecución de las competencias específicas que se espera por parte del alumnado, se incluye la
actuación que este debe realizar, los saberes que ello implica y la situación o contexto en el que se
espera que los movilice.

El currículo de Segunda Lengua Extranjera está estructurado a partir de siete competencias
específicas, que constituyen el punto de partida para el aprendizaje del idioma. Estas competencias
son: multilingüismo e interculturalidad, comprensión oral, comprensión escrita, expresión oral,
expresión escrita, interacción oral y escrita, y mediación oral y escrita. Para cada una de ellas se
presenta una definición y una breve descripción, donde se ofrece información más detallada sobre sus
ingredientes —actuaciones y capacidades asociadas, situaciones en las que se despliega y saberes

que moviliza—, así como una breve explicación de sus conexiones con el resto de competencias
específicas de la materia, con las competencias específicas de otras materias y con las competencias
clave del perfil de salida del alumnado al final de la etapa.

Para el conjunto de competencias de la materia de Segunda Lengua Extranjera se establecen
saberes básicos divididos en tres grandes bloques: Lengua y uso, Estrategias comunicativas y Cultura
y sociedad. El bloque de Lengua y uso abarca el conjunto necesario de saberes para el desarrollo de
actividades comunicativas de comprensión, expresión, interacción y mediación; el bloque de
Estrategias comunicativas incorpora aquellas destrezas necesarias para llevar a cabo los distintos
procesos implicados en el desarrollo de las competencias en distintas situaciones y contextos
comunicativos; el bloque de Cultura y sociedad incluye conocimientos relativos a aspectos culturales
(y transversales) de las culturas y sociedades vehiculadas en la lengua extranjera. Se espera que el
alumnado sea capaz de poner en funcionamiento todos los saberes básicos de las situaciones
comunicativas relativas a los ámbitos personal, social y educativo, y a partir de textos sobre temas
cotidianos, de relevancia personal o de interés público, y que incorporen retos y desafíos del siglo XXI,
sin perder nunca de vista que dichas competencias y saberes diferirán en función de los perfiles 1 o 2
mencionados anteriormente

En consonancia con el enfoque orientado a la acción que plantea el Marco Común Europeo
de Referencia para las Lenguas, el carácter competencial de este currículo invita al profesorado a crear
tareas interdisciplinares, contextualizadas, significativas y relevantes, similares a aquellas en las que
el alumnado se encontrará en la vida real. Por ello, cabe desarrollar situaciones de aprendizaje donde
se considere al alumnado como agente social progresivamente autónomo, y gradualmente
responsable de su proceso de aprendizaje. Esto implica tener en cuenta sus repertorios lingüísticos,
intereses y circunstancias específicas, con el fin de sentar las bases para el aprendizaje a lo largo de
toda la vida. Las situaciones de aprendizaje en lengua extranjera deben promover la inclusión de
diversas lenguas de su repertorio lingüístico para determinadas tareas, por ejemplo, dentro de la
competencia de mediación lingüística, para que el alumnado aproveche los saberes básicos de las
distintas materias lingüísticas y así promover el contraste y la reflexión entre lenguas. Asimismo, se
deben favorecer aquellas situaciones de aprendizaje donde se incluyan materias tanto lingüísticas
como no lingüísticas, siguiendo por ejemplo la metodología TIL-TILC.

En la definición de los criterios de evaluación se detalla también el grado de adquisición de
cada perfil. En la formulación de estos criterios, que establecen el nivel de consecución de las
competencias específicas que se espera por parte del alumnado, se incluye la actuación que este debe
realizar, los saberes que ello implica y la situación o el contexto en el que se espera que los movilice.

2. Competencias especificas

2.1. Competencia específica 1. Multilingüismo e interculturalidad

Reconocer y usar sus repertorios lingüísticos, y comparar su funcionamiento, identificando la
diversidad lingüística y cultural a partir de la lengua extranjera.

2.1.1. Descripción de la competencia específica 1

El uso y reflexión sobre el funcionamiento del repertorio lingüístico están vinculados con el
enfoque plurilingüe de la adquisición de lenguas, puesto que las experiencias del alumnado sobre las
lenguas que conoce sirven para el aprendizaje y mejora de las nuevas, así como para desarrollar su
repertorio lingüístico plurilingüe y su sensibilización cultural. Precisamente, el fomento de la conciencia
intercultural favorece el entendimiento con los demás, y sirve para que el alumnado actúe de forma

empática y respetuosa en situaciones interculturales, de manera que se evita la distorsión
estereotipada y la discriminación hacia lo diferente.

Esta competencia específica parte del enfoque intercultural en el que el concepto de
intercomprensión lingüística y cultural entre dos o más lenguas resulta clave, puesto que implica
apoyarse en la lengua materna y en la primera lengua extranjera para acceder a una segunda lengua
extranjera. En este sentido, en el proceso de enseñanza-aprendizaje de una segunda lengua
extranjera, el alumnado realiza constantes comparaciones entre las estructuras de su repertorio
lingüístico por medio de transferencias que contribuyen a la adquisición de la competencia
comunicativa. Por tanto, se debe partir de conocimientos previos de otras lenguas para aprender una
nueva, y considerar estos conocimientos como recursos potenciales en lugar de obstáculos.

En el proceso de aprendizaje de las lenguas se establece una comparación continua entre los
aspectos culturales de los idiomas y se exploran similitudes y diferencias que es necesario evidenciar
para la construcción de la competencia plurilingüe e intercultural. El alumnado no sólo tiene un perfil
lingüístico propio, sino también un perfil cultural, y ambos se pueden solapar en mayor o menor medida
(por ejemplo, un alumno puede ser competente en una lengua y desconocer la cultura de las
comunidades que la hablan y viceversa). Por tanto, es conveniente la incorporación de aspectos tanto
lingüísticos como culturales en el aula de lenguas extranjeras para consolidar estos perfiles.

En Educación Secundaria Obligatoria el nivel de contraste entre la segunda lengua extranjera,
la primera lengua extranjera y el valenciano y el castellano, debe realizarse de forma guiada y pautada,
incidiendo, no solo en las diferencias y semejanzas ortográficas, de pronunciación y léxicas, sino
también en los aspectos culturales. Por ejemplo, recurrir a cognados o palabras similares en las
distintas lenguas promueve la adquisición de la segunda lengua extranjera.

De igual modo, el aprendizaje de la segunda lengua extranjera implica la introducción de
elementos culturales propios de los países donde esta se habla. A través de la identificación de estos
elementos y de su contraste con los de la propia cultura, se estimula entre el alumnado el aprecio por
la diversidad lingüística y cultural. A través de la incorporación y posterior análisis de elementos
culturales se desarrolla la conciencia plurilingüe e intercultural del alumnado, lo que propicia el
establecimiento de relaciones con personas de otras culturas. Todo ello permite que el alumnado se
abra a nuevas experiencias e ideas y se distancie de discriminaciones y de estereotipos para construir
una cultura compartida y una ciudadanía comprometida con los valores democráticos.

Para el perfil de salida 1 (alumnado que sólo ha cursado la materia de Segunda Lengua
Extranjera durante dos cursos, ya sean consecutivos o no), el alumnado debería ser capaz de discernir
las diferencias de pronunciación entre la segunda lengua extranjera y el valenciano y castellano, así
como de reconocer aspectos culturales similares y distintos a los propios de los ámbitos personal y
social, como puedan ser hábitos y rutinas relativas a comidas, tradiciones y festividades. Además,
también debería ser capaz de comparar similitudes y diferencias entre las distintas lenguas relativas a
aspectos ortográficos y léxicos, y ampliar las situaciones culturales dentro de los contextos personal,
social y educativo.

En el caso del perfil de salida 2 (alumnado que ha cursado la materia de Segunda Lengua
Extranjera desde primero hasta cuarto de Educación Secundaria), el alumnado debería ser capaz,
además, de contrastar las similitudes y diferencias entre las distintas lenguas, así como de reflexionar
sobre su funcionamiento de manera autónoma y de aceptar la diversidad lingüística y cultural propia
de países donde se habla la segunda lengua extranjera.

2.2. Competencia específica 2.  Comprensión oral

Interpretar la información de textos orales y multimodales, breves y sencillos, de manera
guiada, sobre diferentes temas predecibles de los ámbitos personal, social y educativo, a través de la
escucha activa y la aplicación de estrategias para la comprensión oral.

2.2.1. Descripción de la competencia específica 2

En función de los conocimientos previos del tema, el alumnado debe comprender el sentido
general y la información específica predecible en textos breves y sencillos para satisfacer necesidades
comunicativas relacionadas con las prioridades inmediatas.

Durante el proceso, es necesario que al alumnado seleccione, con la guía ocasional docente,
las estrategias más adecuadas de comprensión (reconocer, anticipar, inferir, retener, interpretar y
seleccionar) con la finalidad de facilitar la comprensión de la información expresada en textos y
enunciados breves y sencillos.

Cabe considerar que, al igual que el resto de las competencias, durante el proceso de
comprensión se activan saberes del sistema lingüístico como la adecuación, la coherencia, la cohesión,
la fonética, el reconocimiento de elementos gramaticales, aspectos que resultarán clave en la
comprensión de los diferentes tipos de textos.

Sin embargo, la comprensión oral implica mucho más que entender el código. Elementos como
el lenguaje no verbal, las imágenes o gráficos que puedan aparecer en el texto oral, la entonación y el
ritmo en el discurso, o la carga emotiva del mensaje actúan como elementos de apoyo igualmente
importantes, tanto a la hora de comprobar la hipótesis inicial acerca del sentido global del texto, como
para plantear hipótesis alternativas si fuera necesario.

Además de dichas estrategias, la búsqueda de información de textos orales y multimodales,
en soportes tanto analógicos como digitales, resulta clave en la consolidación de los procesos de
comprensión, pues permite contrastar y validar la información desde un punto de vista crítico.

Los procesos de comprensión requieren contextos dialógicos, que favorezcan la construcción
de un saber conjunto y que formen al alumnado en la identificación y rechazo de prejuicios y
estereotipos de cualquier tipo, la adquisición de valores para la equidad e igualdad efectiva entre
mujeres y hombres, así como el respeto hacia las diferencias étnico-culturales.

Para el perfil de salida 1, el alumnado debería reconocer e interpretar textos orales y
multimodales sencillos con la guía ocasional docente, y completar la idea principal del texto a partir de
imágenes, gestos o sonidos que acompañan al mismo. Además, al haber incorporado las estrategias
de comprensión a partir de la primera lengua, debería ser capaz de discernir entre ideas principales y
secundarias, así como de comprender la función comunicativa, el tema principal y las ideas
secundarias por medio de anticipaciones realizadas a partir de la información extralingüística (gestos,
sonidos e imágenes presentes en el texto oral o multimodal) y de sus conocimientos previos.

Para el perfil de salida 2, además, el alumnado debería ser capaz de analizar el tema principal,
las ideas secundarias y los detalles relevantes por medio de los significados implícitos que puede
deducir de la información extralingüística. Debería ser capaz, asimismo, de emitir valoraciones
personales de textos orales y multimodales incluyendo estructuras lingüísticas y vocabulario de uso
común.

2.3. Competencia específica 3.  Comprensión escrita

Interpretar la información expresada por medio de textos escritos y multimodales breves y
sencillos, de manera guiada, sobre diferentes temas predecibles de ámbito personal, social y
educativo.

2.3.1. Descripción de la competencia específica 3

La comprensión lectora supone un diálogo entre el lector o el texto, en que se realizan
preguntas y anticipaciones para la comprensión de significados. Esta interacción compleja incluye
procesos cognitivos tales como establecer hipótesis, anticipar e identificar las ideas principales y sus
detalles, seleccionar la información específica y realizar las inferencias necesarias. Para ello, se debe
tener presente la importancia de la transferencia lingüística y todas aquellas estrategias adquiridas en
el aprendizaje de la lengua materna y de la primera lengua extranjera, puesto que estas contribuyen a
desarrollar la comprensión escrita y multimodal en la segunda lengua extranjera.

La aplicación de estrategias de comprensión debe permitir al alumnado identificar, con ayuda
ocasional docente, la función comunicativa y el sentido general del texto, así como la selección de las
ideas principales y secundarias de textos con estructuras simples, que contengan léxico de uso
frecuente, al mismo tiempo que se identifican símbolos ortográficos y se decodifica la correspondencia
entre sonido-grafía.

La adquisición de la comprensión lectora afronta nuevos retos derivados de las nuevas formas
de distribución e interacción con la información, la cual llega a nuestro alumnado mediante textos
multimodales. Para ello, la búsqueda y selección de información en soportes analógicos y digitales
promueve la capacidad de lectura crítica, así como el análisis e interpretación de información gráfica
como iconos e imágenes; tipográfica, como títulos, subtítulos o tipos de letra; y contextual, como
elementos extralingüísticos para la correcta interpretación del objetivo comunicativo.

Finalmente, es importante enfatizar que los procesos de comprensión requieren contextos
dialógicos que favorezcan la construcción de un saber conjunto y que estimulen la identificación de
prejuicios y estereotipos de cualquier tipo, así como aquellos que promuevan valores de respeto,
tolerancia e interés hacia la diferencias y similitudes étnico-culturales.

Para el perfil de salida 1, el alumnado debería ser capaz de comprender textos breves y
sencillos por medio de la aplicación guiada de estrategias de comprensión que le permiten completar
la idea principal a partir de soportes visuales, así como sonidos o imágenes en el caso de los textos
multimodales. Además, al haber incorporado en la etapa anterior textos literarios dentro de su
repertorio, debería comenzar a aplicar estrategias de comprensión escrita e identificar el tema principal,
la función comunicativa y las ideas secundarias en textos escritos y multimodales relacionando la
información extralingüística con sus conocimientos previos.

Para el perfil de salida 2, el alumnado debería ser capaz de comprender textos escritos y
multimodales más extensos en los que debería identificar la función comunicativa, el tema principal y
las ideas secundarias a partir de la información y de sus conocimientos previos.

2.4. Competencia específica 4.  Expresión oral

Producir de manera guiada textos orales y multimodales comprensibles y estructurados, para
expresar mensajes breves y sencillos del ámbito personal, social y educativo, aplicando estrategias de
planificación y compensación.

2.4.1.  Descripción de la competencia específica 4

La expresión oral implica producir, de forma estructurada y comprensible, mensajes,
conocimientos, sentimientos y opiniones, a partir de modelos, adaptándose al registro adecuado en
función del tipo de texto y a la situación comunicativa, a través de estrategias de planificación y
compensación.

Esta competencia supone la exposición de textos breves y sencillos, previamente planificados
y ensayados, sobre temas cotidianos y de relevancia personal, expresados con claridad y creatividad.
La expresión oral en diversos formatos y soportes puede incluir en esta etapa la exposición de una
pequeña descripción o anécdota sencilla, que exprese hechos y sentimientos cotidianos. Por ejemplo,
un modelo de expresión oral en esta etapa sería realizar una descripción sobre sí mismo o su lugar de
residencia, mediante el uso de herramientas analógicas y digitales, así como la búsqueda guiada de
información en internet.

Para el desarrollo de esta competencia específica se aplican tanto recursos lingüísticos,
sociolingüísticos y pragmáticos básicos, como aquellos no lingüísticos; por ejemplo, el lenguaje no
verbal o el contacto visual, además de diversos recursos como imágenes, sonidos o iconos en su
formato multimodal.

Durante el proceso de producción oral es necesario que el alumnado seleccione, de manera
guiada, estrategias específicas de planificación, como lograr recordar y ensayar un conjunto de frases
adecuadas a su repertorio a través de la repetición, y estrategias de compensación como puedan ser
aclaraciones, o recurrir a la gestualidad.

Para el perfil de salida 1, el alumnado debería ser capaz de producir diferentes tipos de textos
orales breves, apoyándose en diferentes soportes, contando con la ayuda ocasional docente y con la
incorporación de estrategias de planificación y producción.

Para el perfil de salida 2, el alumnado debería ser capaz de producir de forma autónoma textos
orales breves de diferentes tipologías, como descripciones, narraciones o explicaciones,
seleccionando el léxico apropiado, además de hacer un uso correcto y adecuado de los elementos
morfosintácticos, fonéticos y fonológicos que contribuyen a conseguir un comunicación eficaz y
contextualizada.

2.5. Competencia específica 5.  Expresión escrita

Producir, de forma guiada, textos escritos y multimodales, comprensibles y estructurados, para
expresar mensajes breves y sencillos del ámbito personal, social y educativo, mediante la aplicación
de estrategias de planificación, textualización y revisión.

2.5.1. Descripción de la competencia específica 5

La expresión escrita consiste en la transmisión, de forma estructurada y comprensible, de
mensajes, conocimientos, sentimientos y opiniones, a partir de diferentes modelos de textos
adecuados a la situación comunicativa, a través de estrategias de planificación, textualización y
revisión.

En esta etapa, la planificación implica seleccionar y organizar ideas, de manera guiada, en
función del repertorio lingüístico, así como identificar los elementos de la situación comunicativa y su
finalidad.

La textualización supone producir textos sencillos, breves, coherentes y adecuados a
situaciones comunicativas conocidas, adaptando los modelos proporcionados y aplicando los
elementos lingüísticos pertinentes. En esta etapa, el alumnado debe producir textos relativos a la vida
cotidiana y escolar, como puedan ser mensajes cortos, narraciones breves o descripciones guiadas,
utilizando léxico de uso frecuente y frases unidas por conectores sencillos, y agrupando las ideas de
manera coherente. Asimismo, se utilizan modelos para reescribirlos, a partir de la sustitución de la
información clave, como datos o detalles específicos.

Finalmente, la revisión del texto es necesaria para detectar posibles errores, poder subsanarlos
y así mejorar la producción. Además, esta estrategia resulta fundamental en el tratamiento del error
como oportunidad de aprendizaje para la mejora no solo de esta competencia, sino también de su
repertorio lingüístico.

Puesto que la expresión escrita es un primer acercamiento a las producciones formales e
informales en segunda lengua extranjera, se recurrirá a modelos que guíen el proceso de producción,
con la ayuda de herramientas y soportes analógicos y digitales.

Para el perfil de salida 1, el alumnado debería ser capaz de realizar producciones de diferentes
tipos de textos breves y consolidar las estrategias de revisión, con la ayuda ocasional docente.

Para el perfil de salida 2, se espera que el alumnado adquiera las herramientas necesarias
para producir textos breves y estructurados, a partir de modelos, mediante oraciones simples
enlazadas por conectores básicos

2.6. Competencia específica 6. Interacción oral y escrita

Interactuar de manera oral, escrita y multimodal a través de textos sencillos, breves y guiados,
de forma síncrona y asíncrona, para responder a necesidades comunicativas relacionadas con el
ámbito personal, social y educativo.

2.6.1. Descripción de la competencia 6

La interacción abarca la comprensión y la expresión, así como la construcción de un discurso
conjunto, que utilizará los repertorios plurilingües y pluriculturales del alumnado. La interacción es
mucho más que la suma de las competencias de comprensión y expresión, ya que se utilizan
estrategias colaborativas, como tomar el turno de palabra, cooperar y pedir aclaraciones.

En esta etapa el alumnado debe entender y expresar información breve y sencilla, sobre temas
cotidianos y de interés personal, en textos escritos, orales y multimodales de los géneros dialogados
más frecuentes. Así pues, de manera guiada, interactuará con el profesorado, con los compañeros y
compañeras u otros usuarios de la segunda lengua extranjera, utilizando funciones interpersonales,
colaborativas y transaccionales, a partir de los modelos facilitados.

Esta competencia promueve el trabajo en grupo, la colaboración y la predisposición a
establecer diálogo con otros. Este proceso implica ser capaz de llegar a un entendimiento y llevar a
cabo negociaciones de manera empática, asertiva, correcta en las formas y respetuosa hacia la
diversidad. En este sentido, el alumnado debe manejar situaciones comunicativas, tanto en soportes
analógicos como digitales, a través de la etiqueta digital y utilizando elementos verbales y no verbales.

Paralelamente, para ser competente en interacción oral, escrita y multimodal también es
necesario utilizar el registro adecuado (adecuación), organizar las ideas con claridad (coherencia) y
respetar las normas gramaticales y ortográficas (corrección). Todo ello, mientras se incrementa de
manera paulatina, reflexiva y guiada, la capacidad de utilizar las palabras y estructuras precisas en los
textos orales, escritos y multimodales.

En la interacción oral son esenciales estrategias como el uso de la repetición, el ritmo pausado
y guiado, tomar la palabra, cooperar y pedir aclaraciones. Junto a ello, la escucha activa es
fundamental porque contribuye a la convivencia, la cooperación, la tolerancia y la comunicación eficaz.
Además, en la interacción entran en juego la cortesía lingüística y la etiqueta digital, así como los
elementos verbales y no verbales de la comunicación.

Para el perfil de salida 1, el alumnado debería interactuar de manera oral, escrita y multimodal
en conversaciones breves y sencillas sobre temas cotidianos y predecibles, utilizando estrategias

elementales y ampliadas propias del lenguaje oral y escrito, y mostrando empatía por los interlocutores.
También debería ser capaz de utilizar recursos como la cortesía lingüística, la etiqueta digital, la
repetición, el ritmo pausado o el lenguaje no verbal.

Para el perfil de salida 2, el alumnado debería interactuar en conversaciones simples, sobre
temas predecibles, de manera autónoma, mostrando interés, respeto y empatía por los interlocutores.

2.7. Competencia específica 7. Mediación oral y escrita

Mediar entre interlocutores utilizando estrategias de adaptación y simplificación del lenguaje,
para procesar y transmitir información básica y sencilla en situaciones comunicativas predecibles de
ámbito personal, social y educativo.

2.7.1. Descripción de la competencia 7

La mediación es la actividad del lenguaje consistente en explicar y facilitar la comprensión de
mensajes o textos orales, escritos y multimodales. En este proceso se utilizan estrategias como la
reformulación, la adaptación o la simplificación del lenguaje, en consonancia con el objetivo, la
situación y los destinatarios de la comunicación.

En la mediación, el alumnado se reconoce como agente social encargado de crear puentes,
ayudando a construir y trasvasar significados, facilitando la comprensión y expresión de mensajes, y
transmitiendo información sencilla de manera guiada, tanto en la propia lengua (mediación
intralingüística) como entre otras lenguas (mediación interlingüística).

La mediación lingüística engloba desafíos como la resolución de conflictos de manera
dialogada, el uso de repertorios lingüísticos personales entre distintas lenguas o la valoración de la
diversidad personal y cultural de la lengua extranjera. En este sentido, implica el uso de estrategias y
conocimientos para superar barreras lingüísticas y culturales de forma cooperativa, negociar
significados y llegar a un entendimiento de manera empática y creativa.

En este caso, la mediación está orientada a comprender y transmitir información e ideas de
textos orales, escritos y multimodales breves y predecibles, sobre asuntos cotidianos y de relevancia
personal, guiados y preparados de antemano. Se utilizan tanto medios analógicos como digitales, con
apoyo visual, así como estrategias de simplificación, adaptación y transformación del lenguaje, y se
recurre a la lengua materna o al uso de gestos, repeticiones o aclaraciones.

La mediación incluye actividades como resumir, explicar datos, parafrasear o traducir textos,
así como participar en tareas colaborativas para facilitar la interacción y el entendimiento pluricultural
en entornos cooperativos, combinando el repertorio lingüístico del alumnado.

En ese sentido resulta fundamental conocer, reflexionar y contrastar los elementos lingüísticos
y discursivos entre lenguas (fonética, gramática, sintaxis, vocabulario o tipología textual), así como los
extralingüísticos (lenguaje corporal, signos visuales, pausas, ritmo y entonación), para la comprensión
y posterior reformulación del mensaje.

Para el perfil de salida 1, la mediación interlingüística se desarrolla de forma oral y escrita,
alternando la comprensión y la transmisión del mensaje de la segunda lengua extranjera a la lengua
materna y viceversa, utilizando estrategias lingüísticas (sinónimos o circunloquios muy elementales),
y extralingüísticas.

Para el perfil de salida 2, la mediación se realiza combinando el repertorio lingüístico del
alumnado, comunicando, describiendo y explicando conceptos a un tercero, pudiendo para ello
apoyarse en soportes analógicos o digitales, e incorporar elementos lingüísticos y culturales en textos
orales, escritos y multimodales de los ámbitos personal, social y educativo.

3. Conexiones de las competencias específicas entre sí, con las competencias de otras materias
y con las competencias clave

3.1. Relaciones o conexiones con las otras CE de la materia de l’etapa

Las competencias específicas del área de lenguas extranjeras se conectan y complementan
entre sí; todas y cada una de ellas son necesarias para que el resto se puedan manifestar. Por ejemplo,
para poder transmitir mensajes orales y escritos en el proceso de comunicación se precisa de la
comprensión previa. Asimismo, sin comprensión no se puede dar ni la interacción ni la mediación, ya
que ambas exigen responder adecuadamente a una situación comunicativa. Además, la competencia
multilingüe e intercultural es transversal a todas ellas, puesto que supone reflexionar sobre el uso de
las lenguas para detectar similitudes y diferencias, tanto lingüísticas como culturales. Por tanto, todas
ellas están relacionadas en mayor o menor medida. Las conexiones más destacables entre las
diferentes competencias del área de Segunda Lengua Extranjera son las siguientes:

La comprensión oral (CE2) y escrita (CE3) son componentes fundamentales en la adquisición
del resto de competencias específicas, ya que sin una correcta asimilación no es posible expresar,
interactuar, mediar con otras personas y aplicar conocimientos de ámbito multilingüe e intercultural. De
esta manera, su papel resulta clave en la adquisición de las competencias específicas de expresión
oral (CE4) y escrita (CE5) en tanto que permiten una correcta producción. En este sentido, facilitan la
identificación del objetivo de la situación comunicativa, la organización textual o la selección de las
ideas principales y secundarias con la finalidad de que el usuario exprese textos orales y escritos con
coherencia y corrección adecuados al registro y a las necesidades comunicativas de cada momento.

La competencia multilingüe e intercultural (CE1) facilita la comprensión del significado de
mensajes y textos, así como la detección de similitudes y diferencias lingüísticas y culturales para
aplicar los conocimientos a distintos contextos formales e informales. Asimismo, aspectos como el
ritmo, la entonación o el lenguaje no verbal pueden ser comunes o diferir entre las lenguas, por lo que
su conocimiento resulta clave para el desarrollo de la competencia de expresión oral.

Todo acto de interacción oral y escrita (CE6) requiere procesos de comprensión y expresión
para adaptarse a las necesidades comunicativas del contexto y poder interaccionar con el fin de
resolver los retos comunicativos planteados en cada momento. Junto a ello, resulta imprescindible
identificar los aspectos culturales divergentes entre lenguas y culturas para poder establecer una
comunicación fluida y respetuosa con sus usos y costumbres; estos aspectos se relacionan con la
competencia multilingüe e intercultural (CE1).

Además, la interacción requiere mediar entre interlocutores en muchas ocasiones, ya que se
construye un discurso conjunto entre emisor y receptor, por lo que la relación con la competencia
específica de mediación oral y escrita (CE7) es evidente. Cualquier actividad de mediación exige una
continua comprensión para poder adaptar y reformular los significados durante la interacción con la
finalidad de facilitar la comunicación. Es importante tener en consideración que las actividades de esta
competencia específica resultan clave, tanto para la reflexión como para la valoración de la diversidad
lingüística y cultural, puesto que mediar implica crear puentes para solucionar problemas de
entendimiento, muchas veces promovidos por diferencias, no sólo lingüísticas, sino también culturales
entre lenguas y culturas diversas, de manera que se establece una conexión clara con la competencia
multilingüe e intercultural (CE1). Dichas estrategias son transferibles entre lenguas y pueden contribuir
al desarrollo de la competencia mediadora, en la que negociar los significados, llegar a acuerdos y
transmitir información a terceros es fundamental.

3.2. Relaciones o conexiones con las competencias clave

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 Multilingüismo e interculturalidad | X | X |  | X | X | X |  | X |
| CE2 Comprensión oral | X | X |  | X | X | X |  | X |
| CE3 Comprensión escrita | X | X |  | X | X | X |  | X |
| CE4 Expresión oral | X | X |  | X | X | X |  | X |
| CE5 Expresión escrita | X | X |  | X | X | X |  | X |
| CE6 Interacción oral y escrita | X | X | X | X | X | X | X | X |
| CE7 Mediación oral y escrita | X | X | X | X | X | X | X | X |

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

1. CCL: Competencia en comunicación lingüística
2. CP: Competencia plurilingüe
3. CMCT: Competencia matemática y en ciencia, tecnología e ingeniería
4. CD: Competencia digital
5. CPSAA: Competencia personal, social y de aprender a aprender
6. CC: Competencia ciudadana
7. CE: Competencia emprendedora
8. CCEC: Competencia en consciencia y expresión cultural

4. Saberes básicos
1. Introducción

Los saberes básicos de la materia de Segunda Lengua Extranjera son compartidos por el
conjunto de las competencias específicas, ya que su aprendizaje, articulación y movilización son
necesarios para conseguir tanto el desarrollo de la competencia comunicativa como la conciencia
plurilingüe e intercultural del alumnado.

Para la selección de los saberes básicos se ha tenido en cuenta la necesidad de incorporar
contenidos que engloben conocimientos, destrezas y actitudes, que sirvan de guía al profesorado en
el diseño de situaciones de aprendizaje en las que el alumnado resuelva situaciones comunicativas
cotidianas típicas de su entorno, ya sea del ámbito personal, social o educativo.

La organización de los saberes se ha realizado atendiendo a la necesidad de relacionar el
conjunto de las competencias específicas de la materia con los conocimientos, y con las destrezas
necesarias para aplicarlos en diferentes situaciones comunicativas. La integración de los saberes en
las situaciones de uso lingüístico supone también la atención a los valores y a las actitudes que

fomentan la conciencia plurilingüe e intercultural del alumnado. En cambio, su disposición no denota
una jerarquía, ni sugiere un trabajo separado de los contenidos de cada apartado, sino al contrario: los
diferentes saberes básicos de los distintos bloques se deben combinar entre sí en el diseño de las
situaciones de aprendizaje.

Los saberes básicos del área de Segunda Lengua Extranjera se dividen en tres grandes
bloques, que se deben desarrollar a lo largo de la Educación Secundaria Obligatoria y teniendo en
cuenta los dos posibles perfiles de salida, perfil 1 y 2. El primer bloque, Lengua y uso, integra los
saberes propiamente lingüísticos de la segunda lengua extranjera (fonética y fonología, ortografía,
gramática, vocabulario, funciones comunicativas y géneros textuales); el segundo bloque, Estrategias
comunicativas, incorpora las destrezas y habilidades necesarias para desenvolverse en las situaciones
comunicativas, así como reflexionar sobre el uso de los distintos saberes de su repertorio lingüístico y
analizar el propio proceso de aprendizaje; el tercer bloque, Cultura y sociedad, aúna los conocimientos
relativos a aspectos culturales (y transversales) de las culturas y sociedades vehiculadas en la lengua
extranjera y su valoración como oportunidad de crecimiento y de relación con los demás.

El nivel de especialización de estos saberes básicos ha de respetar la diversidad del alumnado.
Asimismo, dado que la segunda lengua extranjera será la cuarta lengua del alumnado, este estará en
disposición de aprender con más facilidad y de adquirir un nivel aceptable en menor tiempo, tal y como
enuncia la teoría de la competencia subyacente común, según la cual dos o más lenguas usadas por
una persona, aunque difieran en la superficie, funcionan a través del mismo sistema cognitivo central.

2. Bloque 1: Lengua y uso

| Lengua y uso. Transversal a todas las CE | Perfil 1 | Perfil 2 |
| --- | --- | --- |
| Funciones comunicativas |  |  |
| • Funciones comunicativas básicas adecuadas al ámbito y al contexto comunicativo: saludos, despedidas y presentaciones; descripción de personas, objetos y lugares; situar eventos en el tiempo; petición e intercambio de información sobre cuestiones cotidianas; rutinas; indicaciones e instrucciones; expresión de la pertenencia y la cantidad. • Funciones comunicativas básicas adecuadas al ámbito y al contexto comunicativo: saludos, despedidas y presentaciones; descripción de personas, objetos y lugares; situar eventos en el tiempo; situar objetos, personas y lugares en el espacio; petición e intercambio de información sobre cuestiones cotidianas; instrucciones y órdenes; ofrecer, aceptar y rechazar ayuda, proposiciones o sugerencias; expresar parcialmente el gusto o el interés y emociones básicas; narración de acontecimientos pasados, descripción de situaciones presentes, y expresión de sucesos futuros; expresar la opinión y la posibilidad. • Unidades lingüísticas básicas y significados asociados a dichas unidades, tales como expresión de la entidad y sus propiedades, cantidad y número, el espacio y las relaciones | X X | X |

| espaciales, el tiempo, la afirmación, la negación, la interrogación y la exclamación, relaciones lógicas elementales. • Unidades lingüísticas de uso común y significados asociados a dichas unidades tales como expresión de la entidad y sus propiedades, cantidad y calidad, el espacio y las relaciones espaciales, el tiempo y las relaciones temporales, la afirmación, la negación, la interrogación y la exclamación, relaciones lógicas básicas. • Principios del funcionamiento de las lenguas en lo referente al léxico, reglas gramaticales y variedades lingüísticas. |  | X X |
| --- | --- | --- |
| Modelos contextuales y géneros discursivos |  |  |
| • Modelos contextuales y géneros discursivos básicos en la comprensión, producción y coproducción de textos orales, escritos y multimodales, breves y sencillos, literarios y no literarios: características y reconocimiento del contexto, organización y estructuración según la estructura interna. • Modelos contextuales y géneros discursivos de uso común en la comprensión, producción y coproducción de textos orales, escritos y multimodales, breves y sencillos, literarios y no literarios: características y reconocimiento del contexto (participantes y situación), expectativas generadas por el contexto; organización y estructuración según el género, la función textual y la estructura. | X | X |
| Expresiones y léxico |  |  |
| • Léxico básico y de interés para el alumnado, relativo a identificación personal, relaciones interpersonales próximas, lugares y entornos cercanos, ocio y tiempo libre, vida cotidiana. • Léxico de uso común y de interés para el alumnado, relativo a identificación personal, relaciones interpersonales, lugares y entornos cercanos, ocio y tiempo libre, vida cotidiana, salud y actividad física, vivienda y hogar, clima y entorno natural, tecnologías de la información y la comunicación. • Léxico y expresiones de uso común para comprender enunciados sobre la comunicación, la lengua, el aprendizaje y las herramientas de comunicación y aprendizaje (metalenguaje). | X X | X X |
| Patrones sonoros, acentuales y rítmicos |  |  |
| • Patrones sonoros, acentuales, rítmicos y de entonación básicos, y funciones comunicativas generales asociadas a dichos patrones. | X | X |
| Convenciones ortográficas |  |  |
| • Convenciones ortográficas básicas y significados asociados a los formatos y elementos gráficos. • Convenciones ortográficas básicas y significados e intenciones comunicativas asociados a los formatos, patrones y elementos gráficos. | X | X |

| Reflexión sobre la lengua |  |  |
| --- | --- | --- |
| • Consciencia sobre las similitudes formales y diferencias de significados entre lenguas (préstamos, cognados, falsos amigos). | X | X |

3. Bloque 2: Estrategias comunicativas

| Estrategias comunicativas. Transversal a todas las CE | Perfil 1 | Perfil 2 |
| --- | --- | --- |
| Estrategias de comprensión y producción |  |  |
| • Estrategias básicas para la comprensión y la producción de textos orales, escritos y multimodales breves, sencillos y contextualizados. • Estrategias de uso común para la planificación, ejecución, control y reparación de la comprensión, la producción y la coproducción de textos orales, escritos y multimodales. | X | X |
| Estrategias conversacionales |  |  |
| • Convenciones y estrategias conversacionales básicas de uso común, en formato síncrono o asíncrono, para iniciar, mantener y terminar la comunicación, tomar y ceder la palabra, preguntar y responder, pedir y dar indicaciones, pedir y dar aclaraciones y explicaciones, comparar y contrastar, colaborar. • Interés y valoración positiva por establecer contactos y comunicarse a través de diferentes medios con hablantes o estudiantes de la lengua extranjera. • Interés e iniciativa en la realización de intercambios comunicativos a través de diferentes medios con hablantes o estudiantes de la segunda lengua extranjera. • Estrategias y técnicas para responder eficazmente a una necesidad comunicativa básica y concreta de forma comprensible, a pesar de las limitaciones derivadas del nivel de competencia en la segunda lengua extranjera y en las lenguas familiares. | X X | X X |
| Estrategias de mediación |  |  |
| • Conocimientos, destrezas y actitudes elementales que permiten iniciarse en actividades de mediación en situaciones cotidianas básicas. • Estrategias para resolver conflictos interculturales en contextos personales, sociales y educativos. • Conocimientos, destrezas y actitudes que permitan detectar y colaborar en actividades de mediación en situaciones cotidianas sencillas. | X | X X |
| Estrategias de transferencia entre lenguas |  |  |

| • Estrategias básicas de uso común para identificar, organizar, retener, recuperar y utilizar unidades lingüísticas (léxico, morfosintaxis, patrones sonoros) a partir de la comparación de las lenguas y variedades que conforman el repertorio lingüístico personal. • Estrategias y técnicas de compensación de las carencias comunicativas para responder eficazmente a una necesidad concreta. | X X | X |
| --- | --- | --- |
| Reflexión sobre el aprendizaje y tratamiento del error |  |  |
| • Autoconfianza y reflexión sobre el aprendizaje. El error como instrumento de mejora y propuesta de evaluación. • Autoconfianza e iniciativa. El error como parte integrante del proceso de aprendizaje. | X | X |
| Estrategias de autoevaluación y coevaluación |  |  |
| • Estrategias y herramientas básicas de uso común de autoevaluación y coevaluación, analógicas y digitales, individuales y cooperativas. | X | X |
| Herramientas analógicas y digitales |  |  |
| • Herramientas analógicas y digitales básicas de uso común para la comprensión, producción y coproducción oral, escrita y multimodal; y plataformas virtuales de interacción y colaboración educativa (aulas virtuales, videoconferencias, herramientas digitales colaborativas) para el aprendizaje, la comunicación y el desarrollo de proyectos con hablantes o estudiantes de la segunda lengua extranjera. • Recursos para el aprendizaje y estrategias elementales de búsqueda guiada de información en medios analógicos y digitales. • Recursos para el aprendizaje y estrategias básicas de búsqueda de información: diccionarios, libros de consulta, bibliotecas, recursos digitales e informáticos. • Identificación de la autoría de las fuentes consultadas y los contenidos utilizados. | X X | X X X |

4. Bloque 3:  Cultura y sociedad

| Cultura y sociedad. Transversal a todas las CE | Perfil 1 | Perfil 2 |
| --- | --- | --- |
| Aspectos socioculturales y sociolingüísticos |  |  |
| • Aspectos socioculturales y sociolingüísticos básicos y habituales relativos a las costumbres, la vida cotidiana y las | X |  |

| relaciones interpersonales, convenciones sociales básicas de uso común, lenguaje no verbal, cortesía lingüística y etiqueta digital propias de países donde se habla la segunda lengua extranjera. • Aspectos socioculturales y sociolingüísticos de uso común relativos a la vida cotidiana, las condiciones de vida y las relaciones interpersonales; convenciones sociales básicas; lenguaje no verbal, cortesía lingüística y etiqueta digital; cultura, costumbres y valores propios de países donde se habla la segunda lengua extranjera. • Reconocimiento de la necesidad de adaptar el repertorio comunicativo propio al contexto social y cultural en el cual se desarrolla la comunicación. |  | X X |
| --- | --- | --- |
| Diversidad lingüística e intercultural |  |  |
| • Estrategias básicas de uso común para apreciar la diversidad lingüística, cultural y artística, atendiendo a valores ecosociales y democráticos. • Estrategias básicas para entender y apreciar la diversidad lingüística, cultural y artística, atendiendo a valores ecosociales y democráticos • Diferencias en la comunicación no verbal entre las distintas lenguas y culturas. • Diferencias y diversidad plurilingüe e intercultural. • Estereotipos de otras culturas donde se habla la segunda lengua extranjera. • Reconocimiento de los diferentes contextos sociales y culturales en los que desarrolla la comunicación | X X X X | X X X X |
| Lengua extranjera como medio de comunicación |  |  |
| • La segunda lengua extranjera como medio de comunicación y relación con personas de otros países, como forma de acceder a nueva información y como medio para conocer culturas y modos de vida diferentes. • La segunda lengua extranjera como medio de comunicación interpersonal e internacional, fuente de información, y como herramienta de participación social y de enriquecimiento personal. • Patrones culturales de uso común propios de la segunda lengua extranjera. | X | X X |

5. Situaciones de aprendizaje

El diseño de contextos de aprendizaje depende del tercer nivel de concreción curricular,
ya que los centros, a través de su proyecto educativo y las personas responsables de las áreas y
departamentos didácticos, son los que deben planificar las situaciones de enseñanza y aprendizaje.
No obstante, en este apartado se presentan algunos principios y criterios que pueden ayudar a su
diseño.

Estas situaciones deben tener en cuenta los usos lingüísticos en los distintos entornos físicos
y virtuales, puesto que la segunda lengua extranjera no sólo se adquiere dentro del aula, sino que las
distintas experiencias fuera de ella complementan el proceso de aprendizaje (por ejemplo, participación
en intercambios, preparación de certificaciones oficiales o acceso a contenido en lengua original en
plataformas digitales). Por tanto, es conveniente considerar las diferentes esferas de la vida en las que
se proyectan las competencias clave con las propias experiencias del alumnado, como el uso
responsable de los entornos digitales, las relaciones personales y sociales, hábitos de consumo,
deporte y vida saludable o la valoración de la diversidad personal y cultural.

Asimismo, la concreción curricular de las lenguas debe ir necesariamente ligada al proyecto
lingüístico del centro, que marcará, por un lado, las situaciones de aprendizaje que requieran la
integración de diversas lenguas del currículum, y por otro lado, indicará en qué lengua se imparten
determinadas áreas o materias para la planificación de situaciones de aprendizaje interdisciplinares
que permitan la coordinación de áreas y materias lingüísticas con determinadas áreas no lingüísticas.

De manera general, las situaciones de aprendizaje en el área de lenguas extranjeras deberían
fomentar su uso en contextos lo más reales posible. Además, los usos lingüísticos en estas situaciones
deben ir acompañados de una reflexión sobre las estructuras comunicativas implicadas y sobre las
estrategias utilizadas y las actitudes asociadas a estas situaciones para promover así, no sólo la
competencia comunicativa y la conciencia plurilingüe e intercultural, sino también la autonomía del
alumnado en su proceso de aprendizaje.

Para el diseño de las situaciones en lengua extranjera se debe adoptar un enfoque
comunicativo, a través de metodologías diversas, que permitan al alumnado conseguir un cierto grado
de autonomía en el uso de la segunda lengua extranjera como medio de comunicación.

En ese sentido, el enfoque orientado a la acción recomendado por el MCER insiste en la
creación de tareas que reproduzcan situaciones auténticas de la vida real, que tengan alguna utilidad,
que incluyan el componente social y en las que la interacción tenga un papel destacado. Para ello, el
alumnado debe ser consciente de la finalidad y naturaleza de la tarea, lo que su compleción conlleva
según tareas lingüísticas y no lingüísticas. También debe ser consciente de sus fortalezas y de sus
debilidades, es decir, de su nivel actual de conocimientos, de sus carencias y de qué procedimientos
necesita para poder llevar a cabo la tarea con éxito.

Las situaciones de aprendizaje en la materia de Segunda Lengua Extranjera deberían
presentar las siguientes características y elementos:

a.
El aprendizaje debe basarse en la acción, teniendo en cuenta las situaciones
comunicativas que se dan en la vida real para el diseño de tareas comunicativas, donde el rol del
profesorado sea de facilitador y el del alumnado un agente social activo.

b.
Las tareas comunicativas han de basarse en situaciones y contextos reales del entorno
personal, social y académico que supongan un reto, y que integren las diferentes competencias
específicas, promoviendo la oralidad, en un entorno de aprendizaje significativo. Por ejemplo, escuchar
un mensaje oral o leer un texto escrito puede ser el inicio de una secuencia didáctica que ponga en
marcha otras destrezas como interactuar o mediar. Por tanto, deben incorporar diversas fases que
incluyan recepción, interacción, mediación y (co-) producción, junto con una fase de reflexión final.

c.
Plantear situaciones relacionadas con la actualidad mediante el uso de la
personalización para que resulten significativas y próximas a las vivencias y a los conocimientos
previos del alumnado.

d.
Deben suponer un desafío o reto para el alumnado, tomando como referencia los
desafíos del siglo XXI, en tanto que impliquen un grado de exigencia ante el cual plantear vías de
solución.

e.
Incorporar diferentes niveles de dificultad (inclusión) mediante la programación
multinivel, así como variedad en su naturaleza. Como marco general de las situaciones de aprendizaje,
con el objetivo de atender a la diversidad de intereses y necesidades del alumnado, se podrán
incorporar los principios del diseño universal, que nos asegurarán que no existan barreras que impidan
la accesibilidad física, cognitiva, sensorial y emocional para garantizar su participación y aprendizaje.

f.
Tener un enfoque interdisciplinar, así como plurilingüe e intercultural.
g.
Implicar la cooperación del alumnado a través de la mediación de conceptos o la
comunicación y la negociación de significados.

h.
Promover la gestión de las emociones: clima de confianza, empatía, adaptación,
resolución de problemas, auto reflexión, autonomía, motivaciones y valores.

i.
Utilizar formatos y herramientas analógicas y digitales, tanto en el ámbito educativo
como en el personal y social.

6. Criterios de evaluación

Competencia específica 1. Multilingüismo e interculturalidad

Reconocer y usar sus repertorios lingüísticos y comparar su funcionamiento, identificando la
diversidad lingüística y cultural a partir de la lengua extranjera.

| Perfil 1 | Perfil 2 |
| --- | --- |
| 6.1.1. Contrastar las similitudes y diferencias entre distintas lenguas, identificando, de manera progresivamente autónoma, los aspectos básicos de su funcionamiento. | 6.1.1. Comparar las diferencias y similitudes entre distintas lenguas y reflexionar, de manera autónoma, sobre los aspectos básicos de su funcionamiento. |
| 6.1.2. Utilizar y diferenciar, de forma progresivamente autónoma, los conocimientos y estrategias que forman su repertorio lingüístico, con apoyo de otros participantes y de soportes analógicos y digitales. | 6.1.2. Utilizar y diferenciar, de forma autónoma, los conocimientos y estrategias que forman su repertorio lingüístico, con apoyo de otros participantes y de soportes analógicos y digitales. |
| 6.1.3. Identificar aspectos socioculturales de la segunda lengua extranjera, comparando, con la ayuda ocasional docente, los elementos distintivos de la misma con los de su cultura propia. | 6.1.3. Identificar aspectos socioculturales de la segunda lengua extranjera, comparando, de manera autónoma, los elementos distintivos de la misma con los de su cultura. |
| 6.1.4. Mostrar interés y respeto por las diferencias lingüísticas y culturales de la segunda lengua extranjera, valorando, con la ayuda ocasional docente, prejuicios y estereotipos. | 6.1.4. Comparar la diversidad lingüística y cultural propia de países donde se habla la segunda lengua extranjera mostrando interés por comprender elementos culturales y lingüísticos del ámbito personal, social y educativo. |

Competencia específica 2. Comprensión oral

Interpretar la información de textos orales y multimodales, breves y sencillos, de manera
guiada, sobre diferentes temas predecibles de ámbito personal, social y educativo, a través de la
escucha activa y la aplicación de estrategias para la comprensión oral.

| Perfil 1 | Perfil 2 |
| --- | --- |
| 6.2.1. Escuchar de forma activa e interpretar, con la guía ocasional docente, textos orales y multimodales, breves y sencillos, sobre temas predecibles de ámbito cotidiano, de interés personal, social y educativo, así como textos literarios adecuados a su nivel. | 6.2.1. Escuchar de forma activa e interpretar, de manera autónoma, textos orales y multimodales breves y sencillos, sobre temas predecibles y no predecibles, del ámbito personal, social y educativo, así como textos literarios adecuados a su nivel. |
| 6.2.2. Identificar la función comunicativa, el tema principal y las ideas secundarias de textos orales y multimodales a partir de los significados explícitos presentes en la información de carácter lingüístico, anticipando el significado por medio de la información de carácter extralingüístico (gestos, entonación, ritmo del discurso, dicción, entorno sonoro, signos visuales, emotividad del mensaje). | 6.2.2. Analizar la función comunicativa, el tema principal, las ideas secundarias y detalles relevantes de textos orales y multimodales a partir de los significados explícitos e implícitos presentes en la información de carácter lingüístico y extralingüístico, por medio de inferencias y sus conocimientos previos. |
| 6.2.3. Interpretar el vocabulario y el uso de estructuras frecuentes, así como aplicar estrategias para reconocer vocabulario poco frecuente de los ámbitos personal, social y educativo. | 6.2.3. Inferir el significado de vocabulario y el uso de estructuras frecuentes, así como expresiones básicas de uso común de los ámbitos personal, social y educativo. |

Competencia específica 3. Comprensión escrita

Interpretar la información expresada por medio de textos escritos y multimodales, breves y
sencillos, de manera guiada, sobre diferentes temas predecibles de ámbito personal, social y
educativo, mediante estrategias que permitan desarrollar la comprensión escrita.

| Perfil 1 | Perfil 2 |
| --- | --- |
| 6.3.1. Interpretar, con la guía ocasional docente, textos escritos y multimodales, breves y sencillos, sobre temas predecibles de ámbito personal, social y educativo próximo, así como textos literarios adecuados a su nivel y expresados de forma comprensible y clara. | 6.3.1. Interpretar textos escritos y multimodales breves y sencillos, sobre temas predecibles y no predecibles del ámbito personal, social y educativo, eligiendo aquellos que se adecuen a sus gustos e intereses. |
| 6.3.2. Identificar la función comunicativa, el tema principal y las ideas secundarias de textos | 6.3.2. Identificar el tema principal, las ideas secundarias de textos escritos y multimodales, |

| escritos y multimodales, seleccionando y utilizando, con la guía ocasional docente, las estrategias de comprensión escrita, a partir de los significados explícitos de carácter lingüístico, y anticipando el significado por medio de la información de carácter extralingüístico (imágenes, iconos, disposición de la información, títulos, exclamaciones, tipos de letra) y sus conocimientos previos. | así como sus significados explícitos e implícitos de carácter lingüístico y su relación con la información de carácter extralingüístico. |
| --- | --- |
| 6.3.3. Interpretar el vocabulario y el uso de estructuras frecuentes, y anticipar el significado del vocabulario poco frecuente del ámbito personal, social y educativo próximo en textos escritos y multimodales. | 6.3.3. Interpretar el significado de vocabulario y de expresiones básicas de uso común del ámbito personal, social y educativo e identificar el uso de estructuras frecuentes, en textos escritos y multimodales. |
| 6.3.4. Localizar y seleccionar información en medios digitales, con la guía ocasional docente, a partir de diferentes tipos de textos multimodales sencillos del ámbito personal, social y educativo. | 6.3.4. Localizar, seleccionar y contrastar la información en medios digitales de diferentes textos multimodales del ámbito, personal, social y educativo. |

Competencia específica 4. Expresión oral

Producir de manera guiada textos orales y multimodales comprensibles y estructurados, para
expresar mensajes breves y sencillos del ámbito personal, social y educativo, aplicando estrategias de
planificación y compensación.

| Perfil 1 | Perfil 2 |
| --- | --- |
| 6.4.1. Producir diferentes tipos de textos orales y multimodales breves, con una pronunciación, ritmo y entonación adecuados, a partir de modelos, con la guía ocasional docente, utilizando un repertorio de expresiones, léxico y estructuras básicas en situaciones del ámbito personal, social y educativo. | 6.4.1. Producir y expresar oralmente, con cierta fluidez y corrección, textos claros, coherentes y bien organizados, con una pronunciación, ritmo y entonación adecuados, utilizando un repertorio de expresiones, léxico y estructuras de uso frecuente en situaciones del ámbito personal, social y educativo con el fin de informar, exponer, describir, narrar y argumentar. |
| 6.4.2. Utilizar estrategias básicas, con la guía ocasional docente, de planificación, producción y compensación, para producir monólogos breves. | 6.4.2. Utilizar estrategias de planificación, producción, compensación y revisión, como el uso de palabras o frases sencillas de las diferentes lenguas de su repertorio lingüístico o el uso del contexto verbal y no verbal. |
| 6.4.3. Mostrar control sobre un repertorio muy limitado de estructuras sintácticas comunes. | 6.4.3. Mostrar un buen control, sobre un repertorio limitado de estructuras sintácticas comunes, y seleccionar los elementos adecuados de coherencia y de cohesión textual para organizar el discurso de manera sencilla pero eficaz. |

| 6.4.4. Pronunciar y entonar los enunciados de manera comprensible, con la guía ocasional docente, repitiéndolos tantas veces como sea necesario para hacerlos entendibles. | 6.4.4. Pronunciar y entonar los enunciados de manera clara y comprensible, repitiéndolos tantas veces como sea necesario para hacerlos entendibles. |
| --- | --- |

Competencia específica 5. Expresión escrita

Producir, de forma guiada, textos escritos y multimodales, comprensibles y estructurados, para
expresar mensajes breves y sencillos del ámbito personal, social y educativo, aplicando estrategias de
planificación, textualización y revisión.

| Perfil 1 | Perfil 2 |
| --- | --- |
| 6.5.1. Producir textos escritos y multimodales sencillos y breves de diversos géneros textuales en soportes analógicos y digitales sobre temas del ámbito personal, social y educativo, con la ayuda ocasional docente, utilizando léxico y estructuras de uso frecuente. | 6.5.1. Producir textos escritos y multimodales breves, coherentes y cohesionados en soportes analógicos y digitales, utilizando tanto el registro formal como informal según la tipología textual y la situación comunicativa, sobre temas del ámbito personal, educativo y social. |
| 6.5.2. Mostrar control, sobre un repertorio muy limitado de estructuras sintácticas comunes. | 6.5.2. Mostrar un buen control sobre un repertorio limitado de estructuras sintácticas comunes, y seleccionar los elementos adecuados de coherencia y de cohesión textual para organizar el texto escrito de manera sencilla pero eficaz. |
| 6.5.3. Revisar los textos escritos propios y los de sus compañeros y compañeras, detectando y comentando errores, con la ayuda docente. | 6.5.3. Aplicar estrategias de revisión de textos, de forma autónoma, a partir de modelos de los textos escritos. |

Competencia específica 6. Interacción oral y escrita

Interactuar de manera oral, escrita y multimodal a través de textos sencillos, breves y
guiados, de forma síncrona y asíncrona, para responder a necesidades comunicativas relacionadas
con el ámbito personal, social y educativo.

| Perfil 1 | Perfil 2 |
| --- | --- |
| 6.6.1. Participar en conversaciones, con intercambios de información breves y sencillos, sobre temas cotidianos y de relevancia personal, en contextos analógicos y digitales. | 6.6.1. Participar en conversaciones simples, sobre temas predecibles y del ámbito personal, educativo y social en contextos analógicos y digitales, utilizando guiones |
| 6.6.2 Utilizar la cortesía lingüística, la etiqueta digital, la repetición, el ritmo pausado o el lenguaje no verbal para transmitir el mensaje. | 6.6.2. Utilizar la cortesía lingüística, la etiqueta digital, el lenguaje no verbal y estrategias para |

|  | indicar que no se ha entendido el mensaje y solicitar repetición. |
| --- | --- |
| 6.6.3. Interactuar mostrando empatía y respeto por las diferentes necesidades, ideas y motivaciones de los interlocutores, de forma guiada y en situaciones cotidianas, utilizando estrategias elementales para saludar, despedirse y presentarse; expresar mensajes; y formular y contestar preguntas sencillas e iniciar y terminar la comunicación. | 6.6.3. Interactuar mostrando interés, respeto y empatía hacia los interlocutores en contextos pluriculturales, cotidianos, informales, como dar y pedir la palabra, cooperar y pedir aclaraciones. |

Competencia específica 7. Mediación oral y escrita

Mediar entre interlocutores utilizando estrategias de adaptación y simplificación del lenguaje
para procesar y transmitir información básica y sencilla, en situaciones comunicativas predecibles de
ámbito personal, social y educativo.

| Perfil 1 | Perfil 2 |
| --- | --- |
| 6.7.1. Mostrar interés por participar en la solución de problemas de entendimiento sobre asuntos cotidianos del ámbito personal, social y educativo. | 6.7.1. Mostrar interés por participar en la solución de problemas de entendimiento, sobre asuntos diversos del ámbito personal, social y educativo. |
| 6.7.2. Comprender un mensaje breve y sencillo, y comunicar oralmente o por escrito su información o explicar sus conceptos de la segunda lengua extranjera a su lengua materna o de esta a aquella, incluyendo vocabulario frecuente, de forma guiada, pudiendo recurrir a la ayuda de otros participantes. | 6.7.2. Comprender, comunicar y describir textos en diferentes soportes, o explicar conceptos, de forma oral o escrita, combinando su repertorio lingüístico, que incluyan vocabulario, expresiones y estructuras frecuentes. |
| 6.7.3. Seleccionar y utilizar, de forma guiada, estrategias básicas que faciliten la comprensión y la expresión oral y escrita de información en distintas lenguas (de la segunda lengua extranjera a la lengua materna y al revés), como el lenguaje no verbal, simplificar o adaptar el mensaje, usando, con ayuda, recursos o apoyos analógicos y digitales, para crear puentes en la comunicación. | 6.7.3. Seleccionar y aplicar estrategias de simplificación y adaptación de la lengua, que faciliten la comprensión y expresión oral y escrita de la información en distintas lenguas, adecuadas a las situaciones comunicativas, con apoyo puntual de soportes analógicos o digitales, en función de las necesidades de cada momento. |
