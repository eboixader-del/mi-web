# LATÍN

> Fuente: Secundaria.pdf, páginas 883-894 (versión en castellano).

LATÍN

1. Presentación.

La materia de Latín se presenta como una asignatura optativa para 4º de ESO que tiene
como objetivo primordial la comprensión de aspectos lingüísticos y sociopolíticos del mundo
actual partiendo de la pervivencia de la lengua y cultura latinas.

El Latín en 4º de ESO supone para el alumnado que acaba la Secundaria Obligatoria un
contacto directo con algunos de los elementos fundamentales de nuestra sociedad. A su vez,
sirve de puente para aquel alumnado que vaya a cursar estudios de Bachillerato, no sólo de
humanidades sino también de otras modalidades, pues conocer y valorar la importancia de la
lengua y la cultura latinas en la actualidad contribuye eficazmente al aprendizaje de nuevas
lenguas y al acercamiento razonado a las raíces de nuestra propia realidad cultural.

|  | conocer y valorar la importancia de la |
| --- | --- |
| lengua y la cultura latinas en la actualidad contribuye eficazmente al aprendizaje de nuevas |  |
| lenguas y al acercamiento razonado a las raíces de nuestra propia realidad cultural. |  |

|  | el estudio de la lengua y la cultura latinas |
| --- | --- |
| acerca al alumnado a valores universales del mundo clásico y sirve de punto de partida para |  |
| realizar un análisis crítico y constructivo de algunos aspectos del mismo que no tienen cabida en |  |
| la sociedad del siglo XXI. |  |

Al relacionar el presente con el pasado se incentiva el espíritu crítico y una visión global
más libre de prejuicios. Al mismo tiempo, se fomenta el respeto a la diversidad lingüística y se
activan actitudes de compromiso de preservación y valoración del patrimonio, material e
inmaterial, de la civilización latina desde una posición sostenible y comprometida.

El estudio de esta materia despertará en el alumnado la curiosidad por ampliar el
conocimiento en otros ámbitos al percibir la vinculación con los demás saberes estudiados.

La materia de Latín mejora el conocimiento y manejo de las lenguas oficiales de la
Comunidad Valenciana y de otras lenguas extranjeras y permite la consolidación del repertorio
lingüístico del alumnado a través de la reflexión sobre el funcionamiento de la lengua latina y su
evolución.

El Latín y su estructura gramatical son un instrumento privilegiado para el desarrollo de
las capacidades cognitivas del alumnado, al tiempo que impulsa su facultad de discernir
críticamente las fuentes de información, analógicas o digitales, en el proceso de indagación, tanto
individual como en equipo.

|  | en esta primera aproximación al estudio de la lengua latina resulta |
| --- | --- |
| conveniente un aprendizaje lingüístico gradual y ajustado al tiempo de docencia con |  |
| herramientas que promuevan un aprendizaje activo y lúdico y sitúen al alumnado en el centro de |  |
| su propio proceso de aprendizaje. |  |

El curriculum de Latín de 4º de ESO presenta cada una de las competencias específicas
con su descripción correspondiente, señalando seguidamente las conexiones entre ellas, con las
competencias de otras materias de la ESO y con las competencias clave.

Las competencias específicas están vertebradas en torno a dos aspectos. El primero
tiene que ver con la reflexión sobre la estructura de la lengua latina (fundamentos y técnicas
básicas de traducción) y su léxico, así como con su influencia en las lenguas del repertorio
individual del alumnado, vinculándose de este modo a la mejora de la competencia lingüística y
plurilingüe.  El segundo concierne a la reflexión sobre el legado del mundo romano en la

actualidad, que une el pasado con el presente, potenciando una comprensión crítica de la
sociedad del siglo XXI.

A continuación, se presentan los saberes básicos que el alumnado debe aprender,
articular y movilizar para lograr las competencias específicas de la materia. Estos saberes están
organizados en cuatro bloques que se presentan desde tres perspectivas diferentes: temporal y
espacial (geográfica, histórica y política), patrimonial (cultural y artística) y lingüístico-literaria.

El orden de los bloques no responde a ninguna jerarquía de importancia. Los cuatro
bloques son los siguientes:

El primero, dedicado a los aspectos históricos, geográficos y políticos del mundo romano
y su pervivencia, tiene como objetivo principal contextualizar el origen de la civilización europea
actual y comprender su evolución.

El segundo incluye aspectos culturales y patrimoniales del mundo romano y su
pervivencia, saberes sobre la vida cotidiana comparándolos con la actualidad, la mitología y su
influencia en las manifestaciones artísticas y culturales y, por último, el patrimonio que pone en
valor la herencia material e inmaterial de la cultura latina.

El tercero está dedicado a los rasgos básicos del sistema de la lengua latina y enlaza
directamente con la importancia del latín como origen de las dos lenguas cooficiales de la
Comunidad Valenciana y, al mismo tiempo, como vínculo con otras muchas lenguas de Europa,
lo que permite definirlo como un claro factor de unión entre los pueblos.

El cuarto tiene como foco el Latín y el plurilingüismo, insistiendo en el léxico común, en
la etimología de las palabras, sus formantes y en su uso tanto en materias humanísticas como
científico- técnicas, contribuyendo de este modo a desarrollar la competencia lingüística y
plurilingüe del alumnado, a la vez que favorece la competencia ciudadana a través del aprecio
de la diversidad lingüística y social.

Las situaciones de aprendizaje tienen como finalidad promover la adquisición y
desarrollo de las distintas competencias específicas de la materia, si bien se recomienda
diseñarlas atendiendo a un enfoque interdisciplinar para potenciar de este modo el desarrollo
personal del alumnado.

Por último, se establecen los criterios de evaluación que permiten valorar el progreso del
alumnado en el proceso de adquisición y desarrollo de las competencias específicas. Los criterios
de evaluación permiten comprobar si el alumnado percibe el paralelismo de la lengua y cultura
latinas con el mundo actual, con espíritu crítico y una argumentación razonada. Para ello se
presentan situaciones que permitan valorar su reflexión sobre la relación entre las lenguas y la
interpretación y producción de textos sencillos en latín, así como la lectura y comprensión de
textos ya traducidos o adaptados.

Así mismo, los criterios de evaluación hacen intervenir procedimientos mediante los
cuales se puede discernir el grado de comprensión del presente como un proceso histórico que
encuentra sus fundamentos en la civilización latina.

Todos los criterios de evaluación tienen como finalidad principal constatar que el
alumnado tiene clara conciencia de la importancia del aprendizaje del latín en su formación
personal y académica al poder conectar esta materia con su experiencia personal y con los
conocimientos adquiridos en otras asignaturas no sólo del ámbito lingüístico.

En síntesis, el Latín se presenta como una materia que contribuye a alcanzar el perfil del
alumnado al término de la educación básica, promoviendo la adquisición y desarrollo de las
competencias clave necesarias para enfrentar los retos y desafíos del siglo XXI.

2. Competencias específicas.

2.1. Competencia específica 1.

|  | Reconocer y valorar el papel de la cultura y la lengua latinas en los orígenes de |
| --- | --- |
| Europa, así como su mayor o menor pervivencia y presencia en las lenguas y culturas de los |  |
| países que la conforman en la actualidad. |  |

2.1.1. Descripción de la competencia.

Con esta competencia específica se pretende que el alumnado valore de manera
crítica y constructiva la contribución de la civilización latina como punto de partida de la identidad
europea, percibiendo el legado de la cultura romana como eje de unión de los pueblos europeos
de distinto origen y promocionando la capacidad de valorar la diversidad cultural como una
riqueza heredada de nuestro pasado clásico común y la necesidad de promover la convivencia
ciudadana.

|  | promocionando la capacidad de valorar la diversidad cultural como una |
| --- | --- |
| riqueza heredada de nuestro pasado clásico común y la necesidad de promover la convivencia |  |
| ciudadana. |  |

Asimismo, favorece el desarrollo de su espíritu y análisis crítico, puesto que, para
realizar esa reflexión y comparación entre el presente y el pasado, se activan estrategias de
aprendizaje que potencian la comunicación y el respeto, además de una introspección que ayuda
a discernir aquellos aspectos del mundo romano que benefician a nuestra sociedad de aquellos
que han sido superados y no tienen  cabida en nuestros días, para ello, es conveniente no juzgar
el pasado con los ojos del presente.

Esta competencia capacita al alumnado para la elaboración de juicios y opiniones
personales justificadas sobre aspectos sociales o políticos y proporciona argumentos para
debatir con responsabilidad ante las diferencias de una sociedad globalizada.

2.2. Competencia específica 2.

Identificar los rasgos básicos y valorar la importancia de la lengua latina en los idiomas
que el alumnado utiliza y estudia, a través del aprendizaje del alfabeto, la etimología, los
latinismos, la composición y derivación.

2.2.1. Descripción de la competencia.

Con esta competencia específica se intenta que el alumnado relacione las lenguas que
utiliza y conoce con la lengua latina por medio del análisis lingüístico que caracteriza a ambas.
El estudio etimológico básico, la presencia de latinismos en las lenguas que conoce y la
constatación de los mecanismos de composición y derivación permiten al alumnado entender su
lengua como una evolución diacrónica de la lengua latina.

El conocimiento del origen y evolución del alfabeto latino favorece la comprensión de la
importancia de dicho instrumento como fuente de evolución cultural frente a otros tipos de
alfabetos (silábicos, ideográficos).

El alumnado, a través del análisis del léxico de las lenguas que utiliza, reconoce la base
latina fundamental a partir de la cual construye su discurso, por lo que el estudio de la lengua de
origen resulta enriquecedor para el conocimiento de su propia lengua. Se constatan, así mismo,
expresiones directamente latinas de uso habitual y también especializado, conocidas como
latinismos. Por último, el estudio morfológico de los procedimientos de composición y derivación
refuerza los vínculos descubiertos en los niveles anteriores y mejora la comprensión y uso de las
lenguas que utiliza el alumnado.

2.3. Competencia específica 3.

Traducir, comprender e interpretar textos latinos orales y escritos de dificultad
moderada, utilizando estrategias de acceso al significado.

2.3.1. Descripción de la competencia.

Además de las huellas latinas que el alumnado puede conocer en el estudio de aspectos
relacionados con historia, arqueología, filosofía y arte, el mayor legado del mundo romano es su
lengua y sus textos. La lengua latina es la base de todas las lenguas romances y de una buena

parte de otras lenguas de nuestro entorno; la literatura latina es junto con la griega, el modelo en
el que se inspiran muchas de las obras de la literatura occidental.

Partiendo de los textos, el alumnado se iniciará en el conocimiento de la lengua latina
explorando todos los elementos formales que la constituyen. Para ello se utilizarán textos
originales y adaptados de dificultad gradual a los que el alumnado se aproximará con diversas
estrategias de comprensión: comparación en paralelo de las semejanzas y diferencias de los
diferentes rasgos lingüísticos en las lenguas de uso del alumnado.

El uso de la lengua latina escrita y oral ayudará a que el alumnado consolide un
conocimiento activo y justificado de la lengua latina de acuerdo con la línea que define el Marco
Común Europeo de Referencia para las Lenguas (MCER).

2.4. Competencia específica 4.

Producir enunciados sencillos en lengua latina, orales y escritos, desarrollando estrategias
de acceso al significado.

2.4.1. Descripción de la competencia.

Dentro de las estrategias de desarrollo de las competencias lingüísticas del Marco
Común Europeo de Referencia (MCER) para las Lenguas se encuentra la comunicación,
finalidad fundamental del aprendizaje de una lengua. El alumnado utilizará así de forma activa
todos los elementos que ha ido descubriendo a través de la comprensión e interpretación de los
mismos, lo que supondrá una mayor consolidación de los conocimientos adquiridos con la ayuda
de imágenes, preguntas guiadas y guiones de conversación.

El desarrollo de esta competencia está relacionado de manera muy estrecha con la
interpretación y comprensión de los textos, ya que una y otra se complementan a la hora de
alcanzar la finalidad de la comunicación, entendiendo la lengua como un sistema vivo.

La práctica comunicativa de la lengua permitirá no sólo conseguir un mayor nivel de
competencia lingüística, sino también profundizar en el conocimiento de la lengua, la cultura y la
civilización romana contextualizando adecuadamente las estrategias de aprendizaje.

2.5. Competencia específica 5

Localizar y valorar la presencia del mundo clásico en el patrimonio histórico, arqueológico
y artístico de Europa, de la Península Ibérica y de la Comunidad Valenciana y contribuir a su
conservación y respeto.

2.5.1. Descripción de la competencia.

Mediante la adquisición y desarrollo de esta competencia, el alumnado toma conciencia
de la importancia de la preservación, conservación y respeto del patrimonio romano, tanto
material como inmaterial.

Esta competencia incentiva el compromiso por el entorno patrimonial y potencia la
participación activa para su defensa y cuidado.

Al mismo tiempo, reconocer e identificar la contribución material e inmaterial de la cultura
latina ayuda a comprender y relacionar aspectos de nuestra sociedad que tienen su origen en la
época romana, además de entender nuestro presente y tomarlo como referencia para poder
buscar soluciones en momentos de adversidad como las migraciones, los derechos humanos o
los conflictos bélicos.

El alumnado puede acceder a esos elementos patrimoniales en museos, yacimientos
arqueológicos o excavaciones, y también hacer uso de las herramientas digitales actuales, pues
en ambos casos puede llevarse a cabo un ejercicio de análisis y reflexión para entender su
entorno histórico y patrimonial de una manera crítica y concreta.

3. Conexiones de las competencias específicas entre sí, con las competencias de otras
materias y con las competencias clave

3.1.
Relaciones o conexiones con las otras CE de la materia.

Las competencias específicas de Latín 4º ESO se centran en la adquisición de las competencias
lingüísticas básicas de la lengua latina y en el estudio crítico y la valoración del legado romano
desde distintos puntos de vista (arqueológico, artístico, social). Todas ellas están
interrelacionadas, ya que el aprendizaje de una lengua requiere de las aportaciones culturales
del mundo en el que esta se realiza.

Resulta evidente que las CE1 y CE5 presentan una relación más estrecha entre sí, ya que
ofrecen datos relevantes sobre  la presencia e influencia de Roma  a lo largo de la historia en los
diversos campos de estudio y en la actualidad, tanto a nivel autonómico, como nacional o
europeo.

La CE2 explicita la relación lingüística del latín con las lenguas del repertorio individual del
alumnado y supone un primer acercamiento a la importante aportación de la lengua latina a las
lenguas cooficiales de la Comunidad Valenciana y a aquellas otras que estudia el alumnado. Su
relación con las CE3 y CE4 son claras, ya que señalan de manera inequívoca la estrecha relación
entre el Latín y las lenguas que usa y estudia el alumnado del siglo XXI.

Las CE3 y CE4 se complementan de manera evidente, ya que son dos competencias que se
necesitan mutuamente. Su relación con las CE1, CE2 y CE5 es patente, ya que por medio de
estas se da sentido a los conceptos y términos específicos de la cultura romana y su evolución
e influencia a lo largo de la historia.

3.2.
Relaciones o conexiones con las de otras materias de la etapa.

Las competencias específicas de Latín de 4º ESO están estrechamente relacionadas con las de
otras materias lingüísticas que estudia el alumnado (Lengua Castellana y Literatura; Valenciano:
Lengua y Literatura; y Lengua/s Extranjera/s), ya que la consecución de la CE2, CE3 y CE4 de
Latín facilitará la adquisición de competencias similares en las diversas lenguas. El
establecimiento de redes de conocimiento permitirá al alumnado comprobar la relación e
importancia del Latín para el mejor conocimiento y aprendizaje de las otras lenguas.

Por otro lado, las C1 y C5 están relacionadas con algunas de las competencias que el alumnado
desarrolla en materias como Geografía e Historia, o que ha desarrollado previamente como en
la materia optativa de Cultura Clásica.

3.3.
Relaciones o conexiones con las competencias clave.

Competencias específicas de la materia que mantienen relaciones especialmente significativas
y relevantes con las competencias clave:

En primer lugar, la CE1 contribuye de manera decisiva a la adquisición de la CCL, CPSAA, CCEC
y a la CC, ya que, además de poner de relieve la importancia del legado romano en Europa,
también incide en los valores de la ciudadanía europea y española. Esta competencia activa la
curiosidad, el diálogo argumentado, el trabajo en equipo, la búsqueda y selección de las fuentes
fiables y de las estrategias de aprendizaje del alumnado, haciéndole consciente de esta herencia
cultural tan presente en muchas facetas de nuestra vida y ayudándole así a entender mejor el
mundo en el que vive y su relación con el pasado.

En segundo lugar, la CE2 está conectada con la consecución de la CCL, CMCT, CC y la CP, ya
que pone en relación lenguas actuales que proceden o se han visto influenciadas en gran medida
por la lengua latina, lo que permite que el alumnado aprenda relacionando saberes y conceptos
que desarrollan la CPSAA.  Además, impulsa el respeto hacia la diversidad lingüística. Por otra
parte, el conocimiento de los étimos griegos y latinos es esencial para la correcta comprensión
de los saberes matemáticos, científicos y tecnológicos.

En tercer lugar, las CE3 y CE4 desarrollan de manera clara la CCL, CPSAA y la CP, ya que la
comprensión y producción de textos latinos sencillos promueven en el alumnado la aceptación
del error como motor de aprendizaje, despertando el deseo de aprender como expresión de
superación y desarrollo personal.

En cuarto lugar, la CE5 contribuye a alcanzar las metas planteadas en las competencias CCEC,
CE, CD, CPSAA, CC, ya que permite al alumnado conocer y valorar los restos materiales e
inmateriales del mundo romano en nuestro país, y especialmente en la Comunidad Valenciana,
así como como analizar la importancia de ese pasado en determinadas expresiones artísticas.

Por último, conviene destacar que todas las competencias específicas contribuyen, en mayor o
menor medida, a la adquisición de la CD, ya que el uso de webs, aplicaciones e información
gráfica y textual de carácter digital es clave para que el alumnado adquiera la destreza necesaria
en el manejo y tratamiento de la información de manera veraz y contrastada.

Competencias clave del perfil de salida del alumnado al finalizar la enseñanza básica:

●
CCL: competencia en comunicación lingüística.

●
CP: competencia plurilingüe.

●
CMCT: competencia matemática, ciencia y tecnología.

●
CD: competencia digital.

●
CPSAA: competencia personal, social y de aprender a aprender.

●
CC: competencia ciudadana.

●
CE: competencia emprendedora.

●
CCEC: competencia en conciencia y expresión cultural.

El cuadro adjunto muestra la existencia de una relación especialmente significativa y
relevante entre las cinco competencias específicas de la materia de Latín y algunas
competencias clave incluidas en el perfil de salida del alumnado al finalizar la educación básica.
En todos los casos, esta relación opera en las dos direcciones. Por una parte, la adquisición y
desarrollo de las competencias específicas contribuyen a la consecución de las competencias
clave con las que aparecen estrechamente vinculadas; por otra parte, estas competencias clave
juegan un papel importante en la adquisición y desarrollo de las competencias específicas.

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 | X |  |  | X | X | X |  | X |
| CE2 | X | X | X | X | X | X |  |  |
| CE3 | X | X |  | X | X |  |  |  |
| CE4 | X | X |  | X | X |  |  |  |
| CE5 |  |  |  | X | X | X | X | X |

4. Saberes básicos

4.1. Introducción.

La materia de Latín de 4º ESO supone el primer contacto directo del alumnado con la
lengua latina, madre y origen de las lenguas oficiales de la Comunidad Valenciana.

|  | La lengua se despliega y desarrolla dentro de una sociedad y una cultura con unas |
| --- | --- |
| características concretas que contribuyen a su evolución. Por ello, junto a los saberes |  |
| relacionados con competencias de un marcado carácter lingüístico, se abordan cuestiones |  |
| relacionadas con la historia, la sociedad, la política, el arte y la vida cotidiana romana necesarias |  |
| para comprender el alcance de su influencia en nuestra lengua y cultura. |  |

|  | Los saberes básicos son el conjunto de contenidos que se consideran necesarios para |
| --- | --- |
| la adquisición de las competencias específicas de la materia; su enunciado es amplio y deja |  |
| abierta la posibilidad de desarrollarlo en aquellos aspectos que se consideren más adecuados |  |
| en cada caso. Los bloques son una agrupación temática básica que se aconseja abordar de |  |
| manera combinada en un orden que se deja al criterio de cada docente al no responder a una |  |
| estructura jerárquica. |  |

Los saberes están organizados en cuatro bloques:

|  | 1. Aspectos geográficos, históricos y políticos del mundo romano y su pervivencia. |
| --- | --- |
| Presenta las coordenadas geográficas e históricas y el marco sociopolítico en el que se desarrolla |  |
| la lengua latina, cuyo conocimiento ayuda a comprender nuestro pasado y a tener una clara |  |
| conciencia de las bases históricas de la Comunidad Valenciana, España y la Unión Europea. |  |

|  | 2. Aspectos patrimoniales y culturales del mundo romano y su pervivencia. Se centra en |
| --- | --- |
| los temas relacionados con el legado artístico, cultural y de vida cotidiana que hemos heredado |  |
| y que ejercen influencia en nuestras propias manifestaciones artísticas y el desarrollo de la vida |  |
| diaria del siglo XXI. |  |

|  | 3. Sistema de la lengua latina. Rasgos básicos. Aborda de manera sistemática los |
| --- | --- |
| elementos básicos de la lengua latina, proporcionando un primer acercamiento a la misma. La |  |
| comparación y relación de los elementos de la lengua latina con las del alumnado permitirán la |  |
| consolidación de muchos conceptos lingüísticos y un uso más consciente y adecuado de la |  |
| propia lengua. |  |

|  | 4. El latín y el plurilingüismo. Plantea la relación de la lengua latina con las lenguas del |
| --- | --- |
| repertorio del alumnado, su influencia en el léxico y en locuciones y expresiones latinas de uso |  |
| frecuente |  |

|  | Con el fin de favorecer la adquisición y desarrollo de las competencias específicas, se |
| --- | --- |
| recomienda un desarrollo simultáneo y equilibrado de los cuatro bloques con una metodología |  |
| activa que permita la utilización escrita y oral de la lengua y favorezca el pleno desarrollo de las |  |
| competencias lingüísticas establecidas en el |  |

4.2.
Bloque 1: aspectos históricos, geográficos y políticos del mundo romano y su
pervivencia.

|  | CE 1 y CE 5 |  |
| --- | --- | --- |
| • Principales aspectos geográficos, históricos y políticos del mundo romano relacionados con la comprensión e impulso de la identidad europea. • La romanización: Hispania. • Personajes históricos importantes, hombres y mujeres. • Estrategias y herramientas para relacionar el pasado y el presente a partir de los conocimientos adquiridos. • Técnicas básicas de búsqueda y tratamiento de la información histórica y geográfica mediante las TIC. • Estrategias de investigación aplicadas a la historia y la geografía romanas utilizando fuentes de información fiables y las nuevas tecnologías. |  |  |

4.3.
Bloque 2: aspectos culturales y patrimoniales del mundo romano y su pervivencia.

|  | CE 1 y CE 5 |  |
| --- | --- | --- |

•
  Aspectos fundamentales de la vida cotidiana y cultura romanas y su papel en la
conformación de nuestra identidad como sociedad.

•
Ejemplos relevantes de la influencia de la mitología clásica en manifestaciones
artísticas y literarias a lo largo de la historia.

•
 Principales géneros literarios, obras, autoras y autores latinos: importancia e
influencia en expresiones artísticas posteriores.

•
 Elementos y personajes más destacados, tanto hombres como mujeres, del
patrimonio romano en la Península Ibérica con especial atención a los de la
Comunidad Valenciana.

•
Estrategias de creación propia individuales o grupales sobre el legado de la cultura
romana.

•
Habilidades y herramientas (analógicas y digitales) para relacionar, comentar e
interpretar el pasado y el presente a partir de los conocimientos adquiridos y de la
propia experiencia.

•
 Puesta en valor, compromiso de preservación y disfrute del patrimonio arqueológico
romano como bien social y seña de identidad

4.4.
Bloque 3: sistema de la lengua latina. Rasgos básicos.

|  | CE 2, CE 3 y CE4 |  |
| --- | --- | --- |
| • Tipos de palabras: variables e invariables. • Declinación: conceptos básicos. Sustantivos, pronombres y adjetivos • Conjugación: conceptos básicos. El verbo latino • Los casos y sus usos principales. • La concordancia y el orden de palabras. • La oración: simples y coordinadas. • Producción de textos sencillos en lengua latina. • Estrategias para la traducción, comprensión y utilización escrita y oral de frases sencillas en latín a partir de la comparación de las lenguas del repertorio lingüístico del alumnado. • Habilidades para la lectura comprensiva de textos latinos de dificultad gradual. • Aceptación del error como parte del proceso de aprendizaje. • Recursos analógicos y digitales para la adquisición de lenguas: Portfolio Europeo de las Lenguas (PEL), imágenes, glosarios, diccionarios, etc. |  |  |

4.5.  Bloque 4: el latín y el plurilingüismo.

|  | Transversal a todas las competencias. |  |
| --- | --- | --- |
| • El alfabeto: origen y pronunciación. Huellas del alfabeto latino en las lenguas de uso del alumnado. • Reconocimiento de formantes latinos (lexemas, sufijos y prefijos) en palabras de la lengua de enseñanza. Etimología y latinismos de uso frecuente. • Paralelismo entre lenguas romances y no romances. • Valoración de la importancia del latín para la correcta comprensión y expresión escrita, oral y multimodal en las distintas lenguas de su repertorio lingüístico individual. • Uso de bibliografía y webgrafía (lexicografía, repertorios, glosarios) en el estudio y aprendizaje de la lengua latina como base en la consolidación de otras lenguas extranjeras |  |  |

5. Situaciones de aprendizaje para el conjunto de las competencias de la materia.

Las situaciones de aprendizaje de la materia de Latín de 4º de ESO ponen en relación
las competencias específicas de la asignatura con los desafíos del siglo XXI y las competencias
clave, vinculando la pervivencia de la lengua y la cultura latinas con el presente del alumnado.

Las estrategias de aprendizaje han de favorecer la posibilidad de aprender disfrutando,
de manera que se ofrecerán al alumnado actividades que promuevan su desarrollo personal,
motivación y creatividad con actividades, juegos, talleres y retos didácticos para que participe
activamente de su propio aprendizaje.

Para el estudio del bloque de la cultura latina y su pervivencia se partirá de su legado
mediante actividades que surjan de la cotidianeidad del alumnado y que estén relacionadas con
su entorno más cercano. Así pues, se emplearán, junto a las estrategias comunicativas, el
análisis de las fuentes de información en diferentes formatos (escritas o audiovisuales) y la
experiencia vivencial de manera individual o en grupo, mediante talleres didácticos, creando
conciencia de la importancia del conocimiento en su desarrollo personal y en la comprensión del
pasado evitando juicios de valor basados en el presentismo para potenciar la convivencia
democrática, la resolución pacífica de conflictos y el espíritu crítico.

Así mismo, se promoverá el acercamiento al patrimonio romano conservado, de manera
física o a través del uso de las nuevas tecnologías, para crear en el alumnado una conciencia de
respeto y compromiso ciudadano en el ámbito local y global.

Tomando como modelo los desafíos a los que el mundo romano tuvo que enfrentarse a
lo largo de su devenir histórico, se trabajarán en el aula los principios de movimiento, complejidad
y adaptación de modo que se capacite al alumnado para afrontar el futuro y saber gestionar la
incertidumbre que conlleva todo cambio.

En cuanto al bloque de la lengua latina se potenciará el  método inductivo-contextual,
favoreciendo que el alumnado descubra el significado de palabras, étimos o latinismos gracias
al uso de ilustraciones, de familias léxicas, de juegos y del contexto. A su vez, en lo relativo a la
parte gramatical se intentará relacionar el latín con el repertorio lingüístico del alumnado, de
manera que se descubran las analogías y diferencias entre la lengua hablada en el mundo
romano con las conocidas y empleadas por el discente. Se promoverá el uso de una metodología
activa que favorezca la expresión oral y escrita en latín en el aula.

El Marco Común Europeo de Referencia recomienda en sus competencias lingüísticas
que el aprendizaje de la lengua latina aborde los conceptos de comprensión y expresión tanto
oral como escrita, así como la interpretación, traducción y la retroversión de textos adaptados.

Se considera conveniente el uso de planteamientos didácticos que se adapten al ritmo
de aprendizaje propio de cada estudiante, para así incentivar el esfuerzo, la actitud investigadora,
la capacidad de argumentación y el trabajo en equipo.

Se debe tener presente en todo momento la conexión directa del Latín con otras materias
como, por ejemplo, las lingüísticas y las Ciencias Sociales, para trabajar interdisciplinariamente
las competencias susceptibles de ser conectadas.

El alumnado como protagonista de su propio aprendizaje establece conclusiones y
relaciones entre la lengua latina y el repertorio lingüístico personal, entre el pasado romano y el
presente, de manera que puede desarrollar opiniones personales respetuosas sobre la
diversidad lingüística y el modo de vida en otros tiempos y culturas.

6. Criterios de evaluación

6.1. Competencia específica 1.

|  | Reconocer y valorar el papel de la cultura y la lengua latinas en los orígenes de Europa, |
| --- | --- |
| así como su mayor o menor pervivencia y presencia en las lenguas y culturas de los países que |  |
| la conforman en la actualidad. |  |

•
Identificar los principales acontecimientos políticos, históricos y sociales de la
civilización latina en su contexto histórico y relacionarlos con la situación
sociopolítica europea actual, estableciendo las semejanzas y diferencias con la
ayuda de las fuentes clásicas y actuales.
•
Reconocer elementos de la mitología clásica como fuente de inspiración de
manifestaciones literarias y artísticas a lo largo de la historia.

•
Expresar respetuosamente opiniones argumentadas (multimodales, orales o
escritas) sobre la importancia del latín y de la multiculturalidad para el desarrollo de
la sociedad.
•
Elaborar y presentar contenidos propios en forma de esquemas, redacciones, tablas
comparativas u otro tipo de formato mediante el uso de estrategias de búsqueda, la
selección, el análisis crítico y el tratamiento de información de fuentes primarias y
secundarias.

6.2.
Competencia específica 2.

Identificar los rasgos básicos y valorar la importancia de la lengua latina en los idiomas
que el alumnado utiliza y estudia, a través del aprendizaje del alfabeto, la etimología, los
latinismos, la composición y derivación.

•
Identificar y valorar la relevancia del alfabeto latino en la formación de las lenguas
romances y su influencia en las no romances.

•
Descubrir y sistematizar la pervivencia de los étimos latinos en las lenguas romances
peninsulares, europeas y otras lenguas del repertorio lingüístico del alumnado.

•
Hacer un uso adecuado de los latinismos más comunes en un contexto adecuado.

•
Inferir el significado de algunos tecnicismos aplicando los principales fundamentos de la
derivación y composición con prefijos latinos.

•
Valorar la diversidad lingüística y el interés por la adquisición de otras lenguas
extranjeras como medio de enriquecimiento personal y profesional.

6.3.
Competencia específica 3.

Traducir, comprender e interpretar textos latinos orales y escritos de dificultad moderada,
utilizando estrategias de acceso al significado.

•
Leer y comprender textos sencillos en latín (orales y escritos) siguiendo las normas
básicas de pronunciación, con ayuda de los conocimientos lingüísticos del alumnado.
•
Identificar y analizar los aspectos gramaticales elementales del latín en textos de
dificultad graduada, comparándolos con los del repertorio lingüístico personal.
•
Analizar la formación y función de las palabras en la oración latina: declinación
(sustantivos, adjetivos y pronombres) y conjugación.
•
Interpretar y traducir textos latinos adaptados y de dificultad graduada, haciendo uso de
todos los recursos y estrategias aprendidas.

6.4.
Competencia específica 4.

Producir enunciados sencillos en lengua latina, orales y escritos, desarrollando
estrategias de acceso al significado.

•
Crear frases o textos sencillos, escritos y orales, en latín, utilizando las estructuras y el
léxico aprendidos.

•
Aplicar correctamente la declinación para una expresión correcta de la lengua latina.

•
Utilizar la conjugación verbal para una expresión adecuada de la lengua latina.

•
Valorar la importancia del latín como medio de transmisión de cultura y la comunicación
escrita y oral.

6.5.
Competencia específica 5.

Localizar y valorar la presencia del mundo clásico en el patrimonio histórico, arqueológico
y artístico de Europa, de la Península Ibérica y de la Comunidad Valenciana y contribuir a su
conservación y respeto

•
Argumentar con ejemplos la importancia de la tradición romana en las manifestaciones
culturales posteriores.

•
Localizar y valorar la presencia de referentes patrimoniales arqueológicos,
arquitectónicos y artísticos romanos en su entorno más cercano y en la Península
Ibérica.

•
Realizar actividades orientadas al conocimiento y aprecio de las manifestaciones
culturales y los valores cívicos de nuestro pasado romano.

•
Mostrar respeto por las expresiones culturales y los valores cívicos de nuestro pasado
como un elemento significativo de nuestra identidad.
