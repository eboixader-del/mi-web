# MÚSICA

> Fuente: Secundaria.pdf, páginas 925-952 (versión en castellano).

MÚSICA

1. Presentación.

La música está presente en la vida de las personas desde sus orígenes y nos identifica
como seres individuales, sociales y culturales.

El arte musical es un rasgo identificativo de cualquier sociedad y es parte fundamental
de su cultura, por esta razón, está en la educación desde la niñez. Además, la música es un
medio de expresión de ideas, pensamientos y emociones que contribuye al desarrollo cognitivo,
emocional y psicomotor del ser humano.

Desde el punto de vista educativo, la materia de Música permite lograr los objetivos de
la educación básica, favoreciendo que el alumnado adquiera las competencias que le permitan
desarrollar el sentido de responsabilidad para adoptar hábitos de vida saludable; planificar un
proyecto de vida personal; establecer una actitud activa hacia la protección del medioambiente;
ejercer un juicio crítico, ético y estético respecto al uso de nuevas tecnologías; y hacer suyos los
valores democráticos, participando de forma activa y adoptando una cultura de respeto hacia la
diversidad.

La Música en la Educación Secundaria Obligatoria contribuirá al perfil de salida del
alumnado mediante el trabajo de las capacidades, que le permiten el desarrollo de las
competencias clave en relación con los principales desafíos y retos del siglo XXI. Dentro de las
competencias clave, se promueve el uso del método científico, el espíritu emprendedor, la
iniciativa personal, social y de aprender a aprender, la destreza digital y la competencia
ciudadana, y se fomenta siempre la correcta expresión y corrección oral y escrita. El trabajo de
todas ellas de forma interrelacionada, junto con el fomento de la competencia de conciencia y
expresión culturales, favorece que el alumnado sea competente en materia musical.

Desde los principios educativos actuales, hay que ofrecer una educación de calidad a
toda la ciudadanía bajo el binomio de excelencia y de equidad en todos los niveles del sistema
educativo. La música ha de contribuir a desarrollar las competencias clave para fomentar las
destrezas artísticas y musicales, pues permite la adquisición y el desarrollo de las capacidades
necesarias para obtener un perfil de salida propio de la enseñanza secundaria, donde el
alumnado estará capacitado para percibir y analizar, así como interpretar y crear obras de
diferentes manifestaciones culturales y artísticas desde el respeto a uno mismo, a la salud, a los
hábitos personales y sociales y, sobre todo, fomentando la creatividad como herramienta
fundamental para expresarse y comprender los lenguajes artísticos y musicales desde una
perspectiva coeducativa, inclusiva y siguiendo las directrices del Diseño Universal para el
Aprendizaje (DUA).

El aprendizaje de la música en la Educación Secundaria Obligatoria parte del área de
Educación Artística en la Educación Primaria que, en nuestra comunidad, se desdobla en las
áreas de Música y Danza, por un lado, y Educación Plástica y Visual, por otro. La materia de
Música en Secundaria Obligatoria se podrá ampliar en estudios relacionados con el mundo de
las artes o el Bachillerato.

En el presente documento, se presentan los diferentes apartados que conforman el
currículo de la materia de Música: competencias específicas, conexiones de la materia, saberes
básicos, situaciones de aprendizaje y criterios de evaluación.

En primer lugar, las cinco competencias específicas de la materia de Música definen los
aprendizajes que el alumnado ha de adquirir al finalizar la etapa secundaria. Estas cinco
competencias están relacionadas, en mayor o menor medida, con cada uno de los bloques de

saberes, que seleccionan, a su vez, los contenidos básicos sin los cuales no sería posible su
desarrollo.

En el documento, se incluye un apartado de conexiones que hace referencia a las
relaciones de cada una de estas cinco competencias con el resto de las de la propia materia y
de otras de la etapa y, a su vez, con las competencias clave, que son aquellas que se deben
adquirir para el pleno desarrollo personal, social y profesional del alumnado.

El siguiente apartado, los saberes básicos, son el grupo de conocimientos para el
conjunto de las competencias de la materia o conocimientos que todo el alumnado ha de adquirir
al final de la etapa secundaria. Se ha estructurado el área en dos bloques interrelacionados, que
deben ser trabajados de forma integrada con sus correspondientes subbloques. El primero,
Percepción y análisis, pretende profundizar en los contextos musicales y culturales, así como los
elementos del sonido y la estructura musical que conforman el lenguaje musical. En el segundo
bloque, Interpretación y creación, se aborda el fenómeno musical en su vertiente más vivencial
mediante la improvisación, la interpretación y la creación con el fin de fomentar la expresión
vocal, instrumental y corporal, y la realización de proyectos artísticos y multidisciplinares,
fomentando el uso de las nuevas tecnologías.

En las situaciones de aprendizaje, se presentan un conjunto de principios que orientan
cómo organizar actividades articuladas para que el alumnado pueda conseguir ciertos fines o
propósitos educativos en la materia de Música.

Por último, el apartado referente a los criterios de evaluación establece el grado de
aprendizaje que se espera haya logrado el alumnado en las distintas competencias específicas.
Cada competencia conlleva diferentes criterios de evaluación, en los que se diferencia el nivel
de logro de cada uno de los cursos en los que se imparte.

2. Competencias específicas

2.1.
Competencia específica 1

Analizar propuestas musicales, corporales y multidisciplinares de diferentes épocas y
estilos a través de la percepción activa, relacionando sus elementos estructurales y técnicos, con
sentido crítico y valorando la diversidad cultural que representan.

2.1.1.
Descripción de la competencia 1.

En la formación de una ciudadanía crítica, sensible y respetuosa ante la diversidad
cultural, resulta fundamental la identificación y el análisis de los elementos que configuran las
propuestas musicales, corporales y multidisciplinares a partir de la percepción y apreciación
como impulsores del desarrollo personal. En el proceso de percepción activa, juegan un papel
importante la atención y la memoria. Esta capacidad supone un medio adecuado para reconocer
y relacionar los elementos estructurales y técnicos de propuestas de diferentes autores/as,
épocas y estilos, a través de distintos canales, propiciando el encuentro con diversos contextos
donde se lleva a cabo esta experiencia: contexto físico (aula, auditorios o teatros, entre otros) o
virtual.

El acercamiento a las producciones a partir de sus elementos musicales está presente a
lo largo de la Educación Primaria. En la etapa de secundaria se incidirá en la capacidad de
relacionar dichas propuestas con otras de diferentes culturas, épocas y estilos, incluidos sus
referentes más cercanos geográfica y temporalmente, en estrecha relación con los estilos
musicales escuchados en su cotidianidad.

Para desarrollar un aprendizaje gradual y duradero, el alumnado debe ir relacionando
los saberes y la cultura musical adquirida con las nuevas propuestas. A partir de este aprendizaje
significativo, estará en disposición de realizar conexiones con otras formas culturales mediante
el análisis crítico, oral y escrito, utilizando una correcta terminología musical, con la posibilidad

de basarse en medios visuales o audiovisuales, reconociendo y respetando la diversidad que las
genera.

Este conocimiento proporciona una sólida base para descubrir y valorar las diversas
manifestaciones desde la antigüedad hasta nuestros días, así como las instituciones culturales
que las producen y protegen.

Por otra parte, el papel de la mujer en el contexto histórico y musical favorece un
acercamiento a la perspectiva de género, que permite identificar los mitos, los estereotipos y los
diferentes roles, transmitidos a través de la música y la danza en las distintas profesiones que
en ellas intervienen.

Respecto al aprendizaje adquirido por el alumnado al finalizar el primer curso, partimos
de su capacidad de focalizar la atención, a partir de la cual debería ser capaz de identificar los
elementos estructurales y técnicos referidos a las características fundamentales que definen los
diferentes géneros y estilos en cuanto a la forma, instrumentación, tipos de voces y tipos de
agrupaciones, así como la percepción de elementos en propuestas multidisciplinares. Es
conveniente un acercamiento al contexto cultural más cercano del alumnado para poder
establecer conexión directa con sus propios saberes e intereses con el objetivo de ir,
incorporando propuestas musicales y dancísticas representativas del patrimonio.

Al finalizar el segundo curso, el alumnado debería ser capaz de analizar y relacionar los
elementos estructurales y técnicos de diferentes épocas y culturas, argumentando juicios críticos
a partir de los conocimientos adquiridos con una terminología adecuada, participando en tertulias
y debates, mostrando interés y respeto mediante una actitud atenta, positiva y con respeto ante
la diversidad. Su grado de madurez le debería permitir realizar los procesos de percepción activa
de manera autónoma, individual y grupal, utilizando recursos digitales y TIC.

2.2.
Competencia específica 2

Relacionar los elementos del sonido, sus características y representaciones gráficas, los
instrumentos y la voz a partir del análisis auditivo y visual, con el planteamiento de soluciones a
las agresiones acústicas del entorno.

2.2.1.
Descripción de la competencia 2

El entorno que rodea al alumnado es un espacio que posibilita la percepción, el
reconocimiento y el análisis de diferentes estímulos visuales y sonoros. El planteamiento en la
educación secundaria permite una aproximación más analítica que en etapas anteriores, con el
propósito de poder reconocer y utilizar las cualidades del sonido de forma individual y en su
conjunto. De este modo, a partir de la percepción y análisis de los elementos del sonido referidos
a la altura, duración, intensidad y timbre, el alumnado debería conocer y utilizar, de forma
combinada, su representación gráfica y los elementos básicos que conforman la música con la
generación de un contexto que permita la experimentación y creación sonora.

Para el reconocimiento y análisis de estos elementos, resulta especialmente interesante
el apoyo de representaciones gráficas convencionales y no convencionales: musicogramas o
partituras gráficas, entre otras. También se procederá a la identificación de las voces e
instrumentos en diferentes contextos, como punto de partida para su análisis visual y auditivo, a
una posterior clasificación, así como a la valoración de los instrumentos no convencionales desde
una perspectiva de desarrollo sostenible.

Este proceso de percepción activa de las cualidades del sonido posibilitará la base para
la identificación de posibles agresiones acústicas. Ante un uso indiscriminado del sonido, el
alumnado debería adquirir los hábitos de percepción reflexiva de su entorno sonoro y proponer
alternativas a la contaminación acústica desde un consumo responsable con el fin de conseguir
una vida saludable.

Al finalizar el primer curso, el alumnado debería ser capaz de percibir y analizar, visual y
auditivamente, las cualidades del sonido, así como los elementos sonoros con el apoyo del
lenguaje musical convencional y otros lenguajes artísticos, y describir sus características y
funciones, utilizando una terminología adecuada.

Al finalizar el segundo curso, el alumnado debería ser capaz de percibir, de forma
simultánea, y utilizar, de forma combinada, las cualidades del sonido en relación con diferentes
representaciones gráficas. Al mismo tiempo, debería mostrar su capacidad para argumentar
sobre los procesos de percepción y proponer alternativas a las agresiones acústicas, utilizando
terminología específica.

2.3.
Competencia específica 3.

Construir propuestas musicales basadas en la interpretación, la improvisación y la
experimentación a partir de las posibilidades expresivas y comunicativas del sonido, el cuerpo y
los medios digitales mediante procesos individuales y colectivos.

2.3.1.
Descripción de la competencia 3.

Con esta competencia, se pretende fomentar la expresión musical y dancística, donde
la interpretación de diferentes piezas u obras musicales es el elemento principal en el cual aplicar
los conocimientos técnicos y artísticos adquiridos en el aprendizaje del lenguaje musical.

El sonido, como elemento básico en la producción sonora, será la materia prima para
poder llevar a cabo interpretaciones, improvisaciones y creaciones musicales. Además del
sonido, disponemos del cuerpo como medio para expresar ideas, sentimientos y emociones
debido a su capacidad expresiva y artística.

La interpretación implica construir propuestas musicales con el apoyo de elementos
como el lenguaje musical u otros lenguajes, y de recursos no convencionales para facilitar al
alumnado la expresión y comunicación. La improvisación, por su parte, requiere de un
acompañamiento guiado para favorecer el proceso de experimentación y creación cada vez más
libre.

Estas capacidades deben consolidarse individualmente para que el alumnado pueda
después construir propuestas colectivas, favoreciendo su propia identidad y la identidad de
grupo.

Al finalizar el primer curso, el alumnado debería descubrir diferentes propuestas
musicales y dancísticas, valorando el trabajo individual y grupal, utilizando los elementos del
lenguaje musical y otros elementos para interpretar diferentes propuestas mediante el uso del
sonido y el cuerpo, y valorando también la contribución personal al trabajo en grupo desde el
respeto y la empatía.

Al finalizar el segundo curso, el alumnado debería conocer y experimentar con los
elementos estructurales de la música para poder investigar diferentes propuestas con sentido
crítico, y ser capaz de construir creaciones musicales e interdisciplinares guiadas, de forma
individual y colectiva, progresando en la interpretación musical. Del mismo modo, se debería
profundizar en el control de las emociones y el miedo escénico en las distintas interpretaciones.

2.4.
Competencia específica 4.

Crear proyectos musicales e interdisciplinares mediante el diseño, planificación y
realización de los mismos, experimentando con diferentes roles, desarrollando la capacidad
crítica, con una valoración tanto el proceso como el resultado.

2.4.1.
Descripción de la competencia 4.

La creación de proyectos musicales en el aula a través de los ejes propios de la materia,
así como de otras disciplinas, conlleva iniciar un proceso común de reflexión y de análisis a partir
de un tema propuesto y su posterior diseño y difusión, con la aplicación de herramientas afines
al ámbito artístico para desarrollar tanto el proceso como el posible resultado final, apoyándose
en el uso de recursos de aprendizaje digitales y de las TIC.

La planificación y diseño de las diversas fases, que conducirán a un producto final y su
difusión a través de diversos canales y medios, promueve la toma de decisiones de manera
autónoma y la capacidad crítica por parte del alumnado respecto a su realización. Este proceso
lleva implícito la aplicación de diversos conocimientos adquiridos del lenguaje musical
vehiculados a través de la voz, los instrumentos, la expresión corporal y otros lenguajes
musicales, gráficos o gestuales.

Así mismo, el trabajo en equipo de manera colaborativa y activa, y la asunción de
diferentes roles para la consecución de un objetivo común en forma de proyecto musical e
interdisciplinar son inherentes a esta competencia, con lo que se establece una continuidad a
este respecto con la Educación Primaria.

Los proyectos musicales multidisciplinares establecen una relación más compleja en
cuanto a la organización de su diseño y realización, y precisan de la colaboración entre docentes
de las diversas áreas implicadas y de las necesidades del contexto sociocultural. En este sentido,
será de especial atención el desarrollo y vinculación de elementos relacionados con las Artes
Escénicas.

Por otra parte, esta competencia pretende que el alumnado sea capaz de realizar un
análisis valorativo de las profesiones que intervienen en la realización de proyectos. Durante este
proceso, el alumnado asumirá diversos roles relacionados con las profesiones que pueden
intervenir en éste, como son la producción, la interpretación, la dirección, los técnicos i las
técnicas audiovisuales o los i las guionistas, entre otras, desde una perspectiva igualitaria.

Al finalizar el primer curso, el alumnado debería mostrar evidencias sobre la capacidad
de desarrollo y colaboración en todas las fases del proyecto, y la capacidad para trabajar con
otras disciplinas o ámbitos.

Al finalizar el segundo curso, el alumnado debería ser capaz de establecer un mayor
desarrollo del proyecto, ya que el diseño y la organización del mismo partirá de la creciente
autonomía del propio alumnado y de las aportaciones fruto de la capacidad de diálogo y respeto
ante el grupo. De esta manera, se incide en el trabajo multidisciplinar y en la capacidad del
alumnado para integrar y vertebrar los conocimientos de diversas áreas.

2.5. Competencia específica 5

Aplicar recursos digitales a la escucha, interpretación, investigación, creación y difusión
de producciones musicales, adoptando una actitud responsable y acorde con la normativa
vigente.

2.5.1. Descripción de la competencia 5.

En la sociedad actual, donde la tecnología digital está presente de manera casi
permanente en todos los ámbitos y con una estrecha relación con el tipo de aprendizaje formal
e informal que adquiere el alumnado, toma una especial relevancia el desarrollo de la
competencia digital en materia de música.

Actualmente asistimos a una transformación digital en la que los jóvenes y adolescentes
han cambiado sus hábitos de comunicación y de consumo con el uso de aplicaciones, redes y
plataformas audiovisuales, en las que están presentes diferentes lenguajes y elementos
creativos. Esta transformación implica el uso de estos recursos en los procesos de percepción y
análisis musical, y de interpretación y creación en el ámbito educativo. El alumnado se
desenvuelve en un contexto digital donde se generan espacios de investigación que favorecen
la creación y el tratamiento de contenidos digitales: saber identificar, localizar, recuperar,
almacenar, organizar, analizar y compartir la información digital, y evaluar su finalidad y
relevancia.

En cuanto a seguridad, se tiene que garantizar una enseñanza acorde con los marcos
de referencia de la Competencia Digital Ciudadana y la Competencia Digital Docente, a través
del uso adecuado de aplicaciones, webs y programas de edición de partituras, grabación y
edición de audio.

El alumnado debería desarrollar esta competencia de manera transversal en los
procesos creativos y en la realización de proyectos artísticos, a través de los cuales se puede
generar una propuesta musical, audiovisual o escénica, entre otras, respetando los derechos de
propiedad intelectual y escogiendo las licencias de uso pertinentes.

Respecto al primer curso, el nivel de desarrollo se debería fundamentar en la capacidad
básica de la búsqueda, selección y utilización de recursos digitales musicales aplicados a la
escucha, a la interpretación, a la creación y a la investigación para su posterior uso en la
generación de materiales y en producciones musicales adaptadas al nivel, respetando las
normas de protección de datos, de autoría y las licencias de uso y de difusión.

Al finalizar el segundo curso, el alumnado debería ser capaz de seleccionar, con criterio
propio, recursos digitales musicales aplicados a la escucha, la interpretación, la creación y la
investigación, permitiendo ser implementadas en el diseño y creación de producciones musicales
y favoreciendo el desarrollo de su identidad. Al mismo tiempo, debería aportar elementos de
juicio y criterio personal acordes con los gustos, intereses y preferencias para que, en definitiva,
contribuyan a un uso y consumo musical responsable y sostenible.

3. Conexiones de las competencias específicas entre sí, con las competencias de otras materias
y con las competencias clave.

3.1. Relaciones o conexiones con las otras CE de la materia.

En este apartado presentamos las conexiones más significativas entre las competencias
específicas de la materia de Música.

Entre la competencia CE1 y la CE2, existe una relación significativa en la medida que
hacen referencia a la capacidad de analizar y relacionar los elementos estructurales y técnicos
de diferentes propuestas musicales y los elementos que conforman el lenguaje musical en el
proceso de percepción.

En cuanto a las conexiones de la CE3, la construcción de propuestas musicales implica
el conocimiento y el uso de diferentes elementos del sonido mediante la percepción activa y el
análisis de sus elementos estructurales, por lo tanto, se relaciona directamente con la
competencia CE2.

La competencia CE4 implica, necesariamente, la conexión con las otras, en lo que
respecta a la relación y a la ubicación en el tiempo de propuestas musicales de diferentes épocas
y estilos, y también, el análisis de sus elementos (CE1), el uso de las cualidades del sonido de
forma combinada (CE2), la construcción de propuestas musicales (CE3) y la utilización de
recursos digitales (CE5).

La competencia CE5 está vinculada a procesos relacionados con el resto de las
competencias, en la medida en que se hace uso de la tecnología en el proceso de enseñanza-
aprendizaje mediante la selección y utilización de recursos digitales en los procesos de
percepción y análisis (CE1 y CE2) o de interpretación, de creación, de experimentación sonora
y de su difusión (CE3 y CE4).

3.2. Relaciones o conexiones con las CE de otras materias de la etapa

La materia de Música permite establecer diferentes conexiones con otras materias de la
etapa. Teniendo en cuenta las competencias, los saberes y los criterios de evaluación,
enumeramos y relacionamos las conexiones más relevantes.

La Música se relaciona con la materia de Plástica, Visual y Audiovisual en el uso de los
diferentes recursos audiovisuales para la realización de sonorizaciones, ambientaciones sonoras
y en las diferentes propuestas artísticas. Además, se relaciona en la utilización de lenguajes
gráficos no convencionales, como los musicogramas o partituras gráficas en la interpretación
musical. También cabe destacar las relaciones existentes entre los periodos históricos y los
diferentes estilos artísticos.

En cuanto a las relaciones con la materia de Educación Física, destacamos la expresión
corporal, la danza y el proceso de interpretación y de creación de coreografías.

La materia de Geografía e Historia se relaciona directamente con los saberes del
subbloque Contextos musicales y culturales, pues hacen referencia al estudio de los diferentes
periodos históricos.

En lo referente a la materia de Biología y Geología, destacamos que en ambas se
trabajan aspectos referentes al proceso de percepción y conocimiento del cuerpo como elemento
sonoro y receptor del sonido. También comparten el conocimiento y respeto de nuestro entorno
natural como inspirador de paisajes sonoros y de exploración sonora.

La materia de Matemáticas se relaciona con el estudio del sistema interválico y las
dimensiones matemáticas referidas al ritmo y la duración. Además, comparte el método científico
como método en la elaboración de proyectos.

La materia de Tecnología y Digitalización comparte el estudio de los elementos físicos
del sonido y sus unidades de medida, la construcción de instrumentos en el aula o el uso de
dispositivos electrónicos y herramientas digitales para la grabación, edición y difusión musical.

Y, por último, se destaca la conexión con las materias lingüísticas, que permiten el
trabajo textual del repertorio vocal, así como guiones, cuentos o poemas, entre otros, que pueden
ser utilizados en diversos proyectos musicales y artísticos con el fin de fortalecer la oratoria, la
dicción o el fomento de la lectura. Así mismo, las lenguas serán el medio de expresión oral y
escrita que permitirán una correcta expresión y utilización de una terminología adecuada en el
ámbito musical.

3.3. Relaciones o conexiones con las competencias clave

Conexiones de las competencias específicas de la materia con las competencias clave
del perfil de salida del alumnado al término de la educación básica.

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 | x | x |  |  |  |  |  | x |
| CE2 |  |  |  |  |  | x | x | x |
| CE3 |  |  | x | x | x | x |  | x |
| CE4 | x |  | x |  | x | x | x | x |
| CE5 |  |  |  | x |  |  | x | x |

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica

•
CCL. Competencia en comunicación lingüística

•
CP. Competencia plurilingüe

•
CMCT. Competencia matemática y competencia en ciencia y tecnología

•
CD. Competencia digital

•
CPSAA. Competencia personal, social y de aprender a aprender

•
CC. Competencia ciudadana

•
CE. Competencia emprendedora

•
CCEC. Competencia en conciencia y expresión culturales

El cuadro adjunto anterior muestra la existencia de una relación especialmente
significativa y relevante entre las cinco competencias específicas de esta materia y algunas
competencias clave incluidas en el perfil de salida del alumnado al finalizar la educación básica.
En todos los casos, esta relación opera en las dos direcciones. Por una parte, la adquisición y
desarrollo de las competencias específicas señaladas contribuye a la adquisición y desarrollo de
las competencias clave con las que aparecen estrechamente vinculadas; por otra parte, estas
competencias clave juegan un papel importante en la adquisición y desarrollo de las
competencias específicas señaladas.

•
CE1: en primer lugar, la CE1 se relaciona con las competencias clave CCL, CP y CCEC.
Con la CCL, en la medida en que el alumnado ha de aprender a expresar hechos, conceptos,
pensamientos, opiniones o sentimientos de manera oral y escrita, de forma clara y adecuada
a diferentes contextos, evidenciando una actitud cooperativa y respetuosa. La CP permite
trabajar de forma eficaz la comunicación en una o más lenguas y ampliar su repertorio
lingüístico en terminología musical. En relación a la CCEC, el alumnado ha de analizar los
aspectos esenciales de propuestas de distintas épocas y estilos mediante la percepción
activa, reconociendo y argumentado sobre sus lenguajes y elementos técnicos, y con la
expresión de ideas y opiniones propias.

•
CE2: en segundo lugar, la CE2 está conectada con las competencias clave CC, CE y CCEC
debido a que la CC implica participar en actividades para la toma de decisiones y la
resolución de conflictos con actitud democrática para fomentar el desarrollo sostenible. La
CE se relaciona con buscar, examinar y comparar oportunidades, necesidades y retos que
se deben afrontar con sentido crítico y usar destrezas creativas para proponer soluciones
originales, éticas y sostenibles, tomando conciencia del impacto en el entorno. En relación a
la competencia de CCEC, el alumnado ha de ser capaz de reconocer y analizar el lenguaje

y los elementos técnicos de las diferentes manifestaciones artísticas, favoreciendo el
enriquecimiento cultural.

•
CE3: en tercer lugar, la CE3 se vincula a las competencias clave CTEM, CD, CPSAA, CC y
CCEC, pues a través de la CTEM, el alumnado debe utilizar métodos propios del
razonamiento matemático en la interpretación musical. En la CD, ha de realizar búsquedas
de forma crítica para conocer, crear y difundir contenidos digitales que formen parte de las
diferentes propuestas musicales e interdisciplinares. En cuanto a la CPSAA, el alumnado ha
de expresar y argumentar sus opiniones, participando activamente en el trabajo en grupo,
distribuyendo y aceptando las tareas y responsabilidades para la construcción de propuestas
cooperativas, y planificando objetivos de trabajo individual y grupal. La CC fomenta la
participación en actividades y la resolución de conflictos de forma constructiva y dialogada,
favoreciendo la cohesión social. La construcción de propuestas musicales y dancísticas lleva
consigo el desarrollo de la CE, competencia que desarrolla el proceso creativo de generar
ideas, establecer objetivos y emprender tareas y toma de decisiones. En relación a la
competencia de CCEC, el alumnado ha de conocer el lenguaje para crear productos
artísticos y culturales a través de la interpretación, improvisación y composición mediante
diferentes soportes y técnicas.

•
CE4: en cuarto lugar, la CE4 se relaciona con las competencias clave CL, STEM, CPSAA,
CC, CE, CCEC, pues la CL es necesaria a la hora de implementar un proyecto musical
mediante la participación activa en la elaboración de las diversas fases y en su difusión. Al
mismo tiempo, la CTEM permite plantear y desarrollar proyectos que siguen el proceso de
diseño para realizar los diferentes productos. La CPSAA exige la participación en la
elaboración de un proyecto musical de manera individual y colectiva, comprender la
diversidad de aportaciones para incorporarlas a su propio aprendizaje, respetarlas y aportar
su visión y opinión de manera respetuosa. En cuanto a la relación con la CC, el alumnado,
como partícipe de un proyecto musical o interdisciplinar colectivo, ha de comprender ideas
relativas a la propia identidad y establecer relaciones grupales e interculturales. Así mismo,
ha de valorar hechos relevantes relativos a su entorno y mostrar una actitud democrática
fundamentada en los Derechos Humanos, la diversidad cultural, la igualdad de género y la
cohesión social. La CE evidencia el conocimiento de los diferentes elementos y las fases que
conforman una propuesta musical, y la participación activa en los diferentes proyectos
asumiendo diversos roles. En relación a la competencia de CCEC, el alumnado ha de crear
proyectos artísticos y culturales, expresando ideas, opiniones, sentimientos y emociones de
forma creativa y abierta, con actitud colaborativa y de respeto.

•
CE5: en último lugar, la CE5 está conectada, especialmente, con las competencias clave
CD, CE y CCEC en cuanto a que el alumnado debe ayudarse de recursos para buscar y
seleccionar información necesaria de manera crítica y utilizar herramientas digitales de
diversa índole durante el proceso, en el resultado final y en la difusión del mismo. En cuanto
a la relación de esta competencia específica con la CD, el alumnado ha de emplear recursos
digitales y de las TIC para compartir creaciones de aula a través de la web social,
desarrollando una identidad y criterio propios con sentido de consumo responsable y
sostenible de acuerdo a la normativa vigente, y contribuir a la prevención del ciberacoso y a
la educación de una sociedad segura digitalmente. Con relación a todas las competencias
anteriores, la CE está presente desde el momento en que se deben ordenar procesos de
búsqueda, investigación, creación, interpretación y participación en producciones musicales
adquiriendo diferentes roles y fases. Finalmente, y en relación a la competencia de CCEC,
el alumnado ha de conocer, seleccionar y utilizar diversos medios y técnicas para los
diferentes proyectos, respetando y protegiendo la creatividad y las producciones de los
demás.

4. Saberes básicos

4.1.
Introducción

En el presente apartado presentamos los saberes básicos a desarrollar en cada uno de
los cursos de la materia de Música.

Los saberes básicos son el conjunto de conocimientos que el alumnado ha de adquirir a
lo largo de la etapa para poder desarrollar las competencias específicas, y que se pueden ampliar
con otros saberes deseables a lo largo de la Educación Secundaria. Estos saberes básicos se
distribuyen en dos bloques, que se dividen en subbloques (SB) y estos, a su vez, en grupos (G),
siguiendo la clasificación realizada en la etapa primaria y que posibilitan una continuidad al
aprendizaje, con el fin de dar una formación continua, integral y sólida.

El primer bloque, Percepción y análisis, hace referencia, en primer lugar, a los saberes
que se trabajarán desde la vertiente perceptiva del sonido y su correspondiente análisis desde
los diferentes contextos musicales y culturales: obras de diferentes épocas y estilos, intérpretes,
patrimonio o géneros musicales detallados en el subbloque Contextos musicales y culturales; y,
en segundo lugar, a los elementos del lenguaje musical: ritmo, melodía o armonía, entre otros,
detallados en el subbloque Elementos del sonido y estructura musical.

El segundo bloque, Interpretación y creación, hace referencia al uso del lenguaje musical
y otros lenguajes para la improvisación, interpretación y creación. Estos saberes se recogen, en
primer lugar, en el subbloque Expresión individual y colectiva y, en segundo lugar, en el
subbloque Proyectos artísticos, dedicado a la elaboración de producciones artísticas y a la
participación activa del alumnado en todas sus fases.

Cabe destacar que los dos bloques se interrelacionan y pueden trabajarse de forma
integrada, pues el fenómeno sonoro y los elementos que la conforman, así como los diferentes
contextos donde se producen, permiten el trabajo global y necesario para su desarrollo.

En la gradación de saberes se puede observar que, en el primer curso, cobran
importancia los aspectos referentes al lenguaje musical, con el fin de asentar unas bases que
provienen de la Educación Primaria, y los diferentes contextos musicales actuales, mientras que,
en el segundo, se enfatizan los aprendizajes sobre contextos musicales históricos, así como la
elaboración de proyectos artísticos mediante la percepción, la interpretación y la creación musical
e interdisciplinar.

Las competencias específicas se despliegan atendiendo a los saberes básicos de la
materia de Música y requieren de su adquisición y desarrollo. Además, existe una vinculación
entre las competencias específicas y los bloques de saberes básicos. Concretamente, la
competencia 1 y 2 hace referencia al bloque 1, Percepción y análisis, mientras que la
competencia 3 y 4 están referidas al bloque 2. Por otro lado, la competencia 5 tiene un carácter
transversal en todos los bloques.

4.2. Bloque 1. Percepción y análisis

|  | SB. 1.1. Contextos musicales y culturales (CE1, CE2) |  |  | 1.er curso |  |  | 2.º curso |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| G1. Obras e intérpretes |  |  |  |  |  |  |  |  |
| Evolución de la música y de la danza occidental. Obras de diferentes estilos y periodos históricos desde los inicios hasta la música actual. |  |  |  |  |  | x |  |  |
| Mitos, estereotipos y roles de género transmitidos a través de la música y la danza. Profesiones musicales desde una perspectiva igualitaria. |  |  | x |  |  | x |  |  |
| Compositoras y compositores de estilos y épocas diferentes. |  |  | x |  |  | x |  |  |
| Intérpretes y grupos de la actualidad: actuaciones en vivo y registradas por medios audiovisuales. |  |  | x |  |  | x |  |  |
| G2. Patrimonio musical |  |  |  |  |  |  |  |  |
| Música tradicional en España y su diversidad cultural. |  |  | x |  |  |  |  |  |
| Patrimonio musical de la Comunidad Valenciana. Estilos, danzas, eventos y manifestaciones. |  |  | x |  |  |  |  |  |
| Música y danza de otras culturas del mundo. |  |  | x |  |  |  |  |  |
| Música popular urbana y contemporánea. |  |  |  |  |  | x |  |  |
| La evolución del sonido y la música en los medios audiovisuales y tecnologías digitales. |  |  | x |  |  | x |  |  |
| G3. Géneros musicales y escénicos |  |  |  |  |  |  |  |  |
| Clasificación de los géneros musicales y escénicos. |  |  | x |  |  | x |  |  |
| Los géneros en diferentes contextos históricos. |  |  |  |  |  | x |  |  |

| Función social de la música. | x | x |
| --- | --- | --- |
| G4. Agrupaciones vocales e instrumentales |  |  |
| Agrupaciones vocales e instrumentales representativas de músicas del mundo y de la música tradicional. | x |  |
| Formaciones en la música popular urbana y contemporánea. |  | x |
| Agrupaciones vocales e instrumentales representativas a lo largo de los diferentes periodos históricos. |  | x |
| G5. La voz y los instrumentos |  |  |
| Clasificación de la voz y de las diferentes familias instrumentales. | x |  |
| Organología representativa de músicas del mundo y tradicional. | x |  |
| Organología de música popular urbana. |  | x |
| Instrumentos no convencionales desde una perspectiva de desarrollo sostenible. | x | x |
| Reconocimiento de voces e instrumentos en obras de épocas y estilos diferentes. |  | x |
| G6. Terminología y normas de comportamiento |  |  |
| Terminología musical. Argumentación oral y escrita. | x | x |
| Pautas de atención y comportamiento en la audición musical y ante diferentes propuestas artísticas. Actitud abierta y valorativa. | x | x |

|  | SB.1.2. Elementos del sonido y estructura musical (CE1, CE2, CE5) |  |  | 1.er curso |  |  | 2.º curso |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| G1. El proceso de escucha |  |  |  |  |  |  |  |  |
| Elementos que intervienen en el proceso de audición. El oído. |  |  | x |  |  |  |  |  |
| Escucha activa. Pautas de atención, percepción y memoria. |  |  | x |  |  | x |  |  |
| G2. Las cualidades del sonido |  |  |  |  |  |  |  |  |
| Las cualidades del sonido: altura, intensidad, duración y timbre. Representaciones gráficas. Unidades de medida. |  |  | x |  |  |  |  |  |
| Relación entre el silencio, el sonido y el ruido con el entorno. Agresiones acústicas y creación de ambientes sonoros saludables. |  |  | x |  |  |  |  |  |
| G3. El carácter |  |  |  |  |  |  |  |  |
| El carácter musical. La música y sus sensaciones. |  |  | x |  |  |  |  |  |
| G4. El ritmo |  |  |  |  |  |  |  |  |
| Pulso, tempo y matices agógicos. Clasificación de los compases. |  |  | x |  |  |  |  |  |
| Recursos rítmico-melódicos: síncopa, contratiempo y valores irregulares. |  |  | x |  |  | x |  |  |
| G5. Melodía y armonía |  |  |  |  |  |  |  |  |
| La melodía. Identificación de distintos tipos de melodías: lineales, onduladas y quebradas. |  |  | x |  |  |  |  |  |
| Escalas musicales. Intervalos. |  |  | x |  |  | x |  |  |
| La armonía: armaduras básicas y grados tonales. El acorde. |  |  | x |  |  | x |  |  |
| Texturas musicales: monodia, polifonía, contrapunto, homofonía y melodía |  |  | x |  |  |  |  |  |

| acompañada. |  |  |
| --- | --- | --- |
| Texturas musicales de los diferentes géneros y estilos en las diferentes épocas. |  | x |
| G6. Estructura y forma |  |  |
| La organización de la estructura musical. | x |  |
| Formas musicales de los diferentes géneros y estilos en las diferentes épocas, géneros y estilos. |  | x |
| G7. Recursos digitales y de las TIC relacionados con la percepción |  |  |
| Aplicaciones, webs y programas de edición de partituras, grabación y edición de audio. | x | x |

4.3. Bloque 2: Interpretación y creación

|  | SB.2.1. Expresión individual y colectiva (CE3, CE4) |  |  | 1.er curso |  |  | 2.º curso |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| G1. Interpretación y técnica vocal |  |  |  |  |  |  |  |  |
| La técnica vocal: respiración, fonación e impostación. Cuidado y mantenimiento de la voz: hábitos saludables. |  |  | x |  |  |  |  |  |
| Obras vocales a una y varias voces, a capella o con acompañamiento instrumental. Repertorio vocal. La memoria musical en la producción vocal. |  |  | x |  |  | x |  |  |
| G2. Interpretación y técnica instrumental |  |  |  |  |  |  |  |  |
| La técnica instrumental: respiración, control postural, emisión del sonido, articulación y digitación. |  |  | x |  |  |  |  |  |
| Progresiones básicas de acordes. El cifrado internacional. |  |  |  |  |  | x |  |  |

| Obras instrumentales de interpretación individual y grupal. Repertorio instrumental polifónico. La memoria musical y el aprendizaje por imitación. | x | x |
| --- | --- | --- |
| G3. Cuidado instrumental |  |  |
| El cuidado y mantenimiento de los instrumentos. | x | x |
| La construcción de instrumentos sencillos a partir de materiales del entorno. | x | x |
| G4. Creación e improvisación |  |  |
| Principios básicos de creación musical en contextos escolares. | x |  |
| El texto musical. Creación de textos musicales. |  | x |
| La improvisación sobre pautas previamente establecidas. La experimentación, la exploración sonora y la sonorización. | x | x |
| G5. La notación musical |  |  |
| Elementos básicos de la notación musical y representaciones gráficas no convencionales aplicados a la práctica. | x | x |
| G6. Habilidades motrices |  |  |
| Técnica corporal. | x |  |
| El cuerpo como medio de expresión. | x | x |
| Pautas de creación de coreografías básicas e improvisación. |  | x |
| Danzas del mundo y tradicionales. | x |  |
| Danzas de diferentes épocas históricas y de música popular urbana. |  | x |
| Percusión con objetos sonoros. La percusión corporal. | x | x |

| SB.2.2. Proyectos artísticos (CE3, CE4, CE5) |  | 1.er |  |  | 2.º |  |
| --- | --- | --- | --- | --- | --- | --- |
|  |  | curso |  |  | curso |  |
| G1. Planificación |  |  |  |  |  |  |
| Fases y criterios de valoración en proyectos musicales e interdisciplinares. | x |  |  |  |  |  |
| Ámbitos artísticos y profesionales que intervienen en los proyectos y/o sus fases. | x |  |  |  |  |  |
| Estrategias de búsqueda, selección y reelaboración de información de calidad. | x |  |  |  |  |  |
| G2. Producción artística |  |  |  |  |  |  |
| Proyectos basados en la voz, los instrumentos y la expresión corporal mediante el uso de los elementos del lenguaje musical. |  |  |  | x |  |  |
| G3. Artes Escénicas |  |  |  |  |  |  |
| Elementos estructurales y técnicos de las Artes Escénicas: cuerpo, espacio, tiempo, discurso, estructuras y actuación. | x |  |  | x |  |  |
| G4. Tecnología para la producción musical |  |  |  |  |  |  |
| Recursos digitales y de las TIC aplicados a la interpretación, creación y grabación. | x |  |  | x |  |  |
| Licencias de uso, autoría y protección de datos. Planteamientos y hábitos de consumo éticos y responsables. | x |  |  | x |  |  |
| G5. Actitud |  |  |  |  |  |  |
| Pautas de atención y comportamiento en la participación en las diferentes propuestas artísticas. | x |  |  | x |  |  |
| El control de las emociones en la mejora de la interpretación en público. | x |  |  | x |  |  |

5. Situaciones de aprendizaje

Diseñar situaciones de aprendizaje implica tomar decisiones acerca de los espacios,
tiempos y formas de organización más adecuadas para que el alumnado pueda conseguir ciertos
fines o propósitos educativos. En este apartado, se recogen determinados principios que pueden
ayudar en el diseño de las actividades.

Los docentes de música diseñarán transposiciones didácticas con el fin de promover la
construcción de aprendizajes y el desarrollo de las competencias, de manera progresiva y
secuenciada, a partir de la consolidación gradual de los saberes propuestos. Del mismo modo,
estas situaciones y acciones deben favorecer, en la medida de lo posible, el descubrimiento
autónomo, así como contribuir a su adaptación al contexto particular de cada centro educativo.

La adquisición de aprendizajes implica establecer situaciones de aprendizaje diversas e
innovadoras que combinen diferentes tipos de enseñanza dirigidos con otros más colaborativos
o basados en metodologías activas. Conviene plantear aprendizajes en forma de retos,
proyectos, investigaciones, producciones artísticas y, en definitiva, elaboración de proyectos
artísticos de manera individual y colaborativa, donde se apliquen los conocimientos aprendidos
y faciliten la transferencia de saberes de la materia de música en relación con el resto de
materias.

Siguiendo esta línea, se fomentan aprendizajes significativos, promoviendo la lectura, la
búsqueda y discriminación de información en diferentes fuentes, el uso de herramientas digitales,
el juego y la expresión artística, la interpretación, la improvisación, la creación musical, la
asistencia a conciertos, las visitas a entidades y asociaciones culturales, el asesoramiento y la
presencia de expertos y expertas externas en el aula, compositores y compositoras, lutiers,
técnicos de sonido o músicos, entre otros. Todo ello, con el fin de participar en procesos y generar
diversidad de proyectos a partir de detonantes o puntos de partida del entorno inmediato y de la
realidad de nuestro alumnado, basados, principalmente, en la dramatización, la interpretación y
la creación musical y coreográfica, performances, productos audiovisuales o multidisciplinares.

Estas posibles situaciones de aprendizaje relacionan, de manera implícita, el fomento de
la cultura a partir de la relación con el contexto próximo y deben garantizar la creación de
situaciones que aproximen al alumnado al patrimonio más cercano, a partir del conocimiento de
manifestaciones musicales singulares, intérpretes locales, repertorio tradicional o instituciones
musicales próximas, entre otros.

Por la fisionomía de la asignatura, se deben tener en cuenta espacios y tiempos que, en
ocasiones, poco tienen que ver con los que tradicionalmente se asocian con la práctica docente,
por lo que se valorarán lugares del centro escolar y su entorno para la creación de recursos o
propuestas propias. Del mismo modo, la formación del alumnado en el ámbito musical y
dancístico se produce en cualquier espacio físico y temporal, desde la salida de su hogar, en
descansos, desde las diferentes materias o en las actividades complementarias y extraescolares.

Por esta razón, se deben tener en cuenta las prácticas asociadas al aprendizaje informal
en un entorno sonoro y musical, como es el de nuestra sociedad, donde el alumnado aprende y
dialoga acerca de la música que le rodea.

Así mismo, es importante implicar al alumnado en la conservación del material,
equipamiento e infraestructuras escolares del aula, a partir de la reflexión sobre las normas y
valores que subyacen en sus acciones. En esta materia, especialmente, se debe fomentar el
uso, manejo y cuidado de instrumentos musicales convencionales divergentes: instrumentos de

aula, instrumentos no convencionales, instrumentos modernos o instrumentos tradicionales, así
como el mayor uso de dispositivos electrónicos de producción y grabación musical que generen
situaciones de aprendizaje propias de una educación del siglo XXI.

Las actividades y propuestas se deben realizar siguiendo el Diseño Universal de
Aprendizaje (DUA), facilitando los recursos materiales y favoreciendo el acceso al aula y a
actividades dentro y fuera del centro.

A la hora de evaluar, se utilizarán diferentes instrumentos de heteroevaluación,
autoevaluación y coevaluación, que permitan evaluar tanto el proceso de aprendizaje como el
producto final. Deberíamos disponer de instrumentos de evaluación diversos acordes al devenir
de nuestra materia que nos ayuden a comprobar el grado de adquisición del aprendizaje para
poder establecer los ajustes pertinentes en el proceso, como rúbricas, escalas de observación,
diarios de clase o análisis de grabaciones, entre otros.

En todos los procesos de enseñanza-aprendizaje y proyectos artísticos, se fomentará la
tolerancia y el respeto a las diferentes manifestaciones y opiniones, fruto de la diversidad y la
igualdad, como fuente de enriquecimiento personal, fomentando el trabajo grupal y valorando las
aportaciones al bien común. Todas las actividades que se realicen deben garantizar la
convivencia y los valores democráticos, además promocionan la participación activa en el centro
y fuera de él, dando a conocer el trabajo de aula desde una perspectiva sostenible y
contribuyendo a la consecución de los retos y desafíos del siglo XXI.

6. Criterios de evaluación

6.1. Competencia específica 1.

Analizar propuestas musicales, corporales y multidisciplinares de épocas y estilos
diferentes a través de la percepción activa, relacionando sus elementos estructurales y técnicos
con sentido crítico, y valorando la diversidad cultural que representan.

| 1.er ESO | 2.º ESO |
| --- | --- |
| CE1.1. Identificar los elementos estructurales y técnicos de diferentes géneros y estilos musicales y multidisciplinares, relacionándolos entre sí y valorando su diversidad. | CE1.1. Analizar las características de propuestas musicales y multidisciplinares de géneros, épocas y estilos diferentes a partir de sus elementos estructurales y técnicos, relacionándolas entre sí y valorando su diversidad. |
| CE1.2. Emitir opiniones personales a partir de propuestas musicales, corporales y multidisciplinares, de manera oral o escrita, con actitud abierta y terminología adecuada. | CE1.2. Argumentar juicios críticos acerca de propuestas musicales, corporales y multidisciplinares, de manera oral o escrita con actitud abierta y terminología adecuada. |

| CE1.3. Reconocer elementos del patrimonio musical del entorno del alumnado, valorando su diversidad. | CE1.3. Apreciar la riqueza del patrimonio musical de diferentes épocas y estilos, reconocer sus funciones y características, y respetar su diversidad. |
| --- | --- |

6.2. Competencia específica 2.

Relacionar los elementos del sonido, sus características y representaciones gráficas, los
instrumentos y la voz, a partir del análisis auditivo y visual, y el planteamiento de soluciones a
las agresiones acústicas del entorno.

| 1.er ESO | 2.º ESO |
| --- | --- |
| CE2.1. Reconocer las cualidades del sonido de forma combinada, sus características y representación gráfica. | CE2.1. Analizar de manera autónoma las cualidades del sonido de forma combinada, sus características y representación gráfica, utilizando el lenguaje musical y otros lenguajes. |
| CE2.2. Identificar las voces e instrumentos en diferentes contextos sonoros. | CE2.2. Reconocer las voces e instrumentos en diversos contextos sonoros, describir sus principales funciones, atendiendo a diferentes clasificaciones. |
| CE2.3. Identificar agresiones acústicas del entorno y reflexionar sobre posibles soluciones. | CE2.3. Proponer soluciones a las agresiones acústicas del entorno próximo mediante la percepción reflexiva y la sensibilización. |

6.3. Competencia específica 3.

Construir propuestas musicales basadas en la interpretación, la improvisación y la
experimentación a partir de las posibilidades expresivas y comunicativas del sonido, el cuerpo y
los medios digitales, mediante procesos individuales y colectivos.

| 1.er ESO | 2.º ESO |
| --- | --- |
| CE3.1. Interpretar propuestas musicales, utilizando los elementos del lenguaje musical y enriqueciendo la propia identidad. | CE3.1. Interpretar propuestas musicales de forma individual y grupal, utilizando los elementos del lenguaje musical y otras representaciones gráficas, y valorar el ensayo como espacio de escucha y aprendizaje. |
| CE3.2. Crear improvisaciones de forma guiada mediante procesos individuales y colectivos. | CE3.2. Crear diferentes propuestas musicales e improvisaciones favoreciendo el respeto y el sentido crítico. |
| CE3.3. Experimentar con las posibilidades expresivas y comunicativas del sonido y el cuerpo. | CE3.3. Experimentar con las posibilidades expresivas y comunicativas del sonido, el cuerpo y los medios digitales en la creación de propuestas, mostrando confianza en las propias capacidades y valorando las de los demás. |
| CE3.4. Manifestar ideas, sentimientos y emociones para favorecer procesos comunicativos, de empatía y respeto. | CE3.4. Expresar ideas, sentimientos y emociones acerca de las propuestas realizadas para potenciar la comunicación, la empatía y el respeto hacia los demás. |

6.4. Competencia específica 4.

Crear proyectos musicales e interdisciplinares mediante el diseño, la planificación y la
realización de los mismos, experimentando con diferentes roles y desarrollando la capacidad
crítica, con una valoración tanto del proceso como el resultado.

| 1.er ESO | 2.º ESO |
| --- | --- |
| CE4.1. Identificar los procesos de creación, edición y difusión musical y las profesiones que en ellos intervienen. | CE4.1. Analizar los procesos de creación, edición y difusión, así como profesiones que intervienen en proyectos musicales e interdisciplinares. |

| CE4.2. Planificar las fases principales de una producción musical y su difusión. | CE4.2. Diseñar proyectos musicales e interdisciplinares a partir de sus fases con la valoración tanto el proceso como el resultado, argumentando las conclusiones adoptadas. |
| --- | --- |
| CE4.3. Utilizar técnicas de interpretación musical y corporal, potenciando la manifestación y control de emociones. | CE4.3. Utilizar los conocimientos adquiridos en diferentes disciplinas en la creación de proyectos artísticos como medio de cohesión y participación activa. |

6.5. Competencia específica 5.

Aplicar recursos digitales a la escucha, la interpretación, la investigación, la creación y
la difusión de producciones musicales, adoptando una actitud responsable y acorde con la
normativa vigente.

| 1.er ESO | 2.º ESO |
| --- | --- |
| CE5.1. Emplear recursos digitales y de las TIC para compartir creaciones de aula a través de la web social, desarrollando una identidad y criterio propios con un sentido del consumo responsable y sostenible de acuerdo a la normativa vigente. | CE5.1. Buscar información y recursos musicales en diferentes medios digitales de forma contrastada y con el análisis y la valoración de las diferencias. |
| CE5.2 Tratar información musical en diferentes medios digitales de forma contrastada, utilizando recursos, entornos informáticos y servicios en red. | CE5.2. Utilizar recursos digitales de forma individual o colectiva para la percepción, la creación, la interpretación, la grabación y/o la edición musical de las producciones creadas. |
| CE5.3. Compartir información y contenidos digitales en proyectos musicales colaborativos, utilizando las TIC y aplicando buenas conductas para la prevención del ciberacoso. | CE5.3. Practicar un consumo digital responsable de recursos y productos musicales, respetando las licencias de uso y la normativa vigente de protección de datos y autoría. |

MÚSICA. ADENDA PARA EL 4.º CURSO DE LA ESO

1. Introducción

La materia de Música está presente de forma obligatoria en los dos primeros cursos de la Educación
Secundaria y, por este motivo, el nivel competencial que todo el alumnado debe adquirir a lo largo de la etapa
finaliza en el 2.º curso.

En el 4.º curso de la etapa, la Música es una materia optativa con competencias específicas propias,
que marcan el nivel de desarrollo competencial que el alumnado debe conseguir, con los saberes básicos
necesarios para la adquisición y el desarrollo de esas competencias, y con los correspondientes criterios de
evaluación.

Los aprendizajes esenciales, establecidos por el currículo de la materia de Música para todo el
alumnado al finalizar el 2.º curso, pretendían consolidar los conocimientos adquiridos en la etapa de primaria
y dar una visión general de los diferentes contextos musicales y culturales propuestos, también pretendían
fomentar la interpretación y la creación musical, y promover la elaboración de proyectos artísticos. Ante estas
líneas planteadas, proponemos continuar con la progresión establecida en los cursos anteriores y profundizar
en las músicas del mundo, en la música tradicional e histórica del entorno del alumnado, y en la música
presente a lo largo del siglo XX hasta la actualidad.

2. Competencias específicas de la materia de Música

2.1. Competencia específica 1

Identificar propuestas musicales corporales y multidisciplinares en los diferentes contextos de
creación, reconociendo su función cultural y social a través de la percepción activa, con sentido crítico, y una
actitud abierta y respetuosa.

2.1.1. Descripción de la competencia

En los diferentes contextos que rodean al alumnado, resulta fundamental identificar propuestas
musicales, corporales y multidisciplinares a partir de su percepción y análisis. En este proceso activo de
identificación, se deben reconocer los elementos más característicos de los estilos o géneros representativos
de las diferentes danzas y músicas a través de canales (físicos y/o virtuales) que permitan una aproximación
a su conocimiento. Así mismo, es importante reconocer las distintas funciones culturales y sociales, teniendo
en cuenta su origen y su evolución, el estudio de la perspectiva de género, así como identificar los mitos, los
estereotipos y los diferentes roles transmitidos a través de la música y la danza.

Ante las diferentes propuestas, el alumnado deberá ser capaz de identificar las características más
representativas como receptor y consumidor, desde una vertiente crítica, mostrando una actitud abierta y una
disponibilidad para percibir y analizar diferentes estilos de música desde el respeto e interés ante los
diferentes contextos y culturas.

2.2. Competencia específica 2

Analizar los elementos estructurales y técnicos de diferentes manifestaciones musicales y expresar
opiniones de forma crítica y creativa, valorando los gustos e identidades musicales de los demás.

2.2.1. Descripción de la competencia

Las manifestaciones musicales están presentes en la vida del ser humano y es, por ello, que la
percepción de la música forma parte del entorno próximo. Ante la cantidad de propuestas musicales
existentes, es necesario poder analizar los elementos que las conforman desde una vertiente estructural y
técnica, pues, a partir de este análisis, se pueden formar y manifestar diferentes opiniones sobre los estilos
estudiados.

Estas manifestaciones se deben realizar desde una perspectiva crítica y constructiva, favoreciendo
la creatividad musical y la capacidad argumentativa oral y escrita del alumnado. A su vez, en este proceso de

análisis, hay que hacer hincapié en la detección de posibles agresiones acústicas y plantear y aplicar
soluciones desde la reflexión crítica y la sensibilización.

Al mismo tiempo, es importante el respeto a las opiniones de los demás desde la escucha y la
empatía, valorando sus gustos musicales, para poder conocer los diferentes estilos y géneros que conforman
la identidad musical.

2.3. Competencia específica 3

Construir propuestas musicales basadas en la interpretación, la improvisación, la sonorización y la
experimentación con el sonido, el cuerpo y los medios digitales, y seleccionar los recursos necesarios,
desarrollando habilidades técnicas y de autoconfianza.

2.3.1. Descripción de la competencia

Esta competencia hace referencia al desarrollo de la expresión musical y corporal mediante la
interpretación de diferentes propuestas, así como la improvisación guiada y libre, de forma individual y grupal.

En la materia de Música, se debe fomentar la interpretación como forma de expresión y comunicación,
y el uso de formas interpretativas, como la improvisación, la sonorización de textos y de imágenes,
referenciando la música y el cine como ejemplo. Otro aspecto que se debe incentivar es la utilización de los
medios digitales para la construcción de propuestas musicales.

Al mismo tiempo, es recomendable realizar interpretaciones en público y valorar los ensayos como
espacios de escucha y aprendizaje para que el proceso musical, como sucede en cualquier manifestación
artística, pueda cumplir su finalidad última: la ejecución y el disfrute del intérprete y el público. Para este
proceso constructivo, habrá que seleccionar los recursos necesarios en cuanto a instrumental, partituras,
medios digitales, y el uso de lenguaje convencional o no convencional, entre otros.

Las diferentes manifestaciones se deben realizar de forma individual y grupal mediante actuaciones
que permitan el desarrollo de las habilidades técnicas e interpretativas del alumnado, teniendo en cuenta la
mejora de las capacidades, la autoestima, la autoconfianza y el control de las emociones, favoreciendo así su
educación integral.

2.4. Competencia específica 4

Crear proyectos musicales e interdisciplinares, siguiendo las fases de elaboración e identificando las
profesiones vinculadas, mostrando interés e iniciativa; y valorar tanto el proceso como el resultado.

2.4.1. Descripción de la competencia

La creación de proyectos musicales e interdisciplinares supone la integración de conocimientos de la
materia de Música, de otras materias y del uso de los diferentes recursos disponibles. Para esta creación, el
alumnado debe seguir las fases propias de diseño, de planificación y de elaboración de diferentes proyectos.
Al mismo tiempo, y desde una perspectiva igualitaria, debe conocer las distintas profesiones que intervienen
en los proyectos, en su desarrollo y en los diferentes ámbitos relacionados con la industria y la práctica musical

Este proceso permite promover el interés y la iniciativa en el alumnado con el fin de favorecer la
participación activa y desarrollar los procesos de elaboración, de producción y de participación en el resultado
final, así como su difusión.

2.5. Competencia específica 5

Utilizar recursos digitales para la escucha, la interpretación, la investigación, la sonorización, la
creación y la difusión de proyectos artísticos, así como para la edición de sonido e imagen de forma crítica y
responsable, aplicando la normativa vigente.

2.5.1. Descripción de la competencia

La tecnología digital está presente en todos los ámbitos de la vida, incluida la educación formal, por
lo que es necesario aprender a utilizar recursos digitales en los diferentes aspectos trabajados en la materia.

La incorporación de las tecnologías a los procesos de escucha, interpretación, investigación,

sonorización y creación incluye el uso de aplicaciones, webs y programas que contribuyen al desarrollo de la
competencia digital, lo que fomenta en todo momento la difusión de los proyectos artísticos realizados en el
aula y/o centro.

Al mismo tiempo, se deben utilizar recursos diversos que permitan la edición de sonido e imagen,
recursos estos necesarios para dar cobertura a diferentes propuestas de elaboración de proyectos artísticos.

Esta utilización de los recursos digitales implica la valoración y discriminación de la información
disponible desde una posición crítica y responsable, atendiendo en todo momento a la normativa vigente en
cuanto a protección de datos y derechos de propiedad intelectual, y escogiendo las licencias de uso
pertinentes.

3. Saberes básicos

3.1. Introducción

Los saberes básicos de la materia de Música en 4º ESO se organizan en dos bloques en continuidad
con la estructura adoptada en la Educación Primaria y en los dos primeros cursos de la Educación Secundaria
Obligatoria.

El bloque 1, Percepción y análisis, incluye un conjunto de saberes que se trabajan desde la vertiente
perceptiva del sonido y su correspondiente análisis. El bloque se divide en dos subbloques: 1.1. Contextos
musicales y culturales y 1.2. Elementos estructurales y técnicos.

El bloque 2, Interpretación y creación, hace referencia al uso de lenguaje musical y otros lenguajes
para la improvisación, la interpretación, la sonorización, la experimentación y la creación. Estos saberes se
presentan en dos subbloques: 2.1. Expresión individual y colectiva, y 2.2. Proyectos artísticos.

3.2. Bloque 1. Percepción y análisis

SB. 1.1. Contextos musicales y culturales (CE1, CE2)

G.1. Obras e intérpretes

•
Evolución de la música y de la danza en España. Características y obras de estilos y
periodos históricos diferentes desde los inicios hasta la actualidad.
•
Mitos, estereotipos y roles de género transmitidos a través de la música y la danza.
Profesiones musicales desde una perspectiva igualitaria.
•
Compositoras y compositores de estilos y épocas diferentes.
•
Intérpretes y grupos de la actualidad: actuaciones en vivo y registradas por medios
audiovisuales.

G2. Patrimonio musical

•
Músicas y danzas de diversas culturas del mundo: características, funciones e influencias
en otros estilos musicales.
•
La música tradicional y en la actualidad de la Comunidad Valenciana. Evolución,
repertorio, danzas, estilos, eventos y manifestaciones.
•
Música popular urbana y contemporánea.
•
La evolución del sonido y la música en los medios audiovisuales y tecnologías digitales.
•
La música y su relación con otras artes y lenguajes. La música en el cine.

G3. Géneros musicales, escénicos y audiovisuales

•
La música en las artes escénicas y audiovisuales: teatro, danza, ópera, teatro musical,
cine y videodanza.

•
La evolución de los géneros de la música y la danza en España.

G4. La voz y los instrumentos. Agrupaciones

•
Instrumentos y agrupaciones vocales e instrumentales representativas de músicas y
danzas del mundo y de la música y la danza a lo largo de la historia en España.
•
Organología de la música tradicional y en la actualidad de la Comunidad Valenciana.
•
Instrumentos y formaciones en la música popular urbana y contemporánea.
•
Instrumentos no convencionales desde una perspectiva de desarrollo sostenible.

G5. El consumo musical

•
La música en los medios de comunicación.
•
El consumo en la actualidad: aplicaciones, redes y plataformas digitales.
•
La industria musical. Profesiones en la industria y en la práctica musical.
•
Funciones sociales de la música en la actualidad.
•
Silencio, sonido, ruido y escucha activa. Sensibilización y actitud crítica ante las
agresiones acústicas y el consumo musical indiscriminado.

G6. Terminología y normas de comportamiento

•
Terminología musical. Argumentación oral y escrita.
•
Pautas de atención y comportamiento en la audición musical y ante diferentes propuestas
artísticas. Actitud abierta y valorativa.

SB.1.2. Elementos estructurales y técnicos (CE1, CE2, CE5)

G1. Melodía y armonía

•
Escalas y modos representativos en las músicas del mundo y en la música popular
urbana.
•
Función melódica en la música cinematográfica y en los medios de comunicación.
•
Elementos melódicos en la música tradicional y actual de la Comunidad Valenciana.
•
Tonalidades y modulaciones básicas.
•
La armonía. Funciones armónicas. La rueda de acordes.
•
Texturas musicales en los diferentes estilos estudiados.

G2. Estructura y forma

•
Formas musicales utilizadas en los periodos, estilos y culturas.

G3. Recursos digitales y de las TIC relacionados con la percepción

•
Aplicaciones, webs y programas de edición de partituras, grabación y edición de audio.

3.3. Bloque 2. Interpretación y creación

SB.2.1. Expresión individual y colectiva (CE3, CE4)

G1. Interpretación y técnica vocal e instrumental

•
Técnica y repertorio vocal, instrumental y corporal.
•
Obras representativas de las músicas y danzas del mundo, de la música y danza histórica
en España y de la música tradicional y actual de la Comunidad Valenciana.
•
Repertorio de música popular urbana, música cinematográfica y en los medios de
comunicación.
•
Progresiones básicas de acordes.

G2. Cuidado instrumental

•
El cuidado y mantenimiento de los instrumentos musicales.
•
La construcción de instrumentos no convencionales desde una perspectiva de desarrollo
sostenible.

G3. Creación e improvisación.

•
El texto de la canción: la creación de textos y la musicalización.
•
Técnicas para la improvisación guiada y libre en propuestas vocales, instrumentales o
multidisciplinares.
•
Sonorización de audiovisuales, imágenes y textos.
•
Pautas de creación musical guiada de melodías sencillas con acompañamientos básicos.

G4.  La notación musical

•
Notación musical convencional y representaciones gráficas no convencionales aplicados
a la interpretación.

G5. El cuerpo como medio de expresión

•
Técnica corporal.
•
Percusión con objetos sonoros. La percusión corporal.
•
Pautas para la creación e improvisación de coreografías.
•
Danzas del mundo y danzas históricas y tradicionales en España.
•
Bailes de música popular, urbana y contemporánea.

SB.2.2. Proyectos artísticos (CE3, CE4, CE5)

G1. Planificación

•
Fases de un proyecto artístico musical e interdisciplinar.
•
Ámbitos artísticos y profesionales que intervienen en los proyectos y/o sus fases.
•
Estrategias de búsqueda, selección y reelaboración de información de calidad.

G2. Producción artística

•
Proyectos basados en la voz, los instrumentos y la expresión corporal, utilizando los
elementos del lenguaje musical convencional y no convencional.

G3. Artes escénicas

•
Elementos estructurales y técnicos de las artes escénicas.

G4. Tecnología para la producción musical

•
Recursos digitales y de las TIC aplicadas a la elaboración de proyectos artísticos.
•
Aplicaciones, webs y programas de edición de partituras, grabación y edición de sonido.
•
Licencias de uso, autoría y protección de datos. Planteamientos y hábitos de consumo
éticos y responsables.

G5. Actitud

•
Pautas de atención y comportamiento en la participación en los diferentes proyectos
artísticos.
•
El control de las emociones en la mejora de la interpretación en público.

4. Criterios de evaluación

Competencia específica 1

Identificar propuestas musicales corporales y multidisciplinares en los diferentes contextos de
creación, reconociendo su función cultural y social, a través de la percepción activa, con sentido crítico y
actitud abierta y respetuosa.

•
CE1.1. Seleccionar propuestas musicales, corporales y multidisciplinares en diferentes contextos a
partir de la percepción activa, reconociendo sus funciones culturales y sociales.
•
CE1.2. Elaborar juicios críticos acerca de las funciones de las propuestas musicales, corporales y
multidisciplinares, utilizando una terminología adecuada y con actitud abierta y respetuosa.
•
CE1.3. Apreciar las diferentes músicas en su contexto, reconociendo sus funciones y la importancia
en el momento en que se producen.

Competencia específica 2

Analizar los elementos estructurales y técnicos de diferentes manifestaciones musicales, expresar
opiniones de forma crítica y creativa, valorando los gustos e identidades musicales de los demás.

•
CE2.1. Identificar los elementos estructurales y técnicos de las diferentes manifestaciones musicales,
respetando los diferentes gustos y valorando la identidad musical individual y del grupo.
•
CE2.2. Expresar, de forma crítica y creativa, opiniones sobre las diferentes manifestaciones artísticas
de forma oral y escrita, utilizando la terminología adecuada.
•
CE2.3. Aplicar soluciones a las agresiones acústicas del entorno próximo mediante el análisis, la
reflexión y la sensibilización.

Competencia específica 3

Construir propuestas musicales basadas en la interpretación, la improvisación, la sonorización y la
experimentación con el sonido, el cuerpo y los medios digitales; seleccionar los recursos necesarios; y
desarrollar habilidades técnicas y de autoconfianza.

•
CE3.1. Interpretar propuestas musicales, utilizando los elementos del sonido, el cuerpo y los medios
digitales, favoreciendo la mejora de las habilidades técnicas y personales y enriqueciendo la propia
identidad y la del grupo.
•
CE3.2. Crear propuestas musicales mediante improvisaciones, favorecer el respeto, la empatía y la
cohesión grupal.
•
CE3.3. Experimentar con las posibilidades expresivas y comunicativas del sonido mediante la
sonorización, seleccionar los recursos necesarios y favorecer la autoconfianza y la autoestima.

•
CE3.4. Expresar ideas, sentimientos y emociones acerca de las propuestas realizadas, mostrando
respeto ante las manifestaciones realizadas.

Competencia específica 4

Crear proyectos musicales e interdisciplinares, siguiendo las fases de elaboración e identificar las
profesiones vinculadas, mostrar interés e iniciativa y valorar tanto el proceso como el resultado.

•
CE4.1. Planificar proyectos musicales e interdisciplinares, especificando las distintas fases y
valorando las diferentes profesiones que intervienen.
•
CE4.2. Crear proyectos musicales e interdisciplinares, prestando atención tanto al proceso como el
producto y valorar los resultados.
•
CE4.3. Aplicar los conocimientos adquiridos en diferentes disciplinas en la creación de proyectos
artísticos, mostrando interés e iniciativa.

Competencia específica 5

Utilizar recursos digitales para la escucha, la interpretación, la investigación, la sonorización, la
creación y la difusión de proyectos artísticos, así como para la edición de sonido e imagen, de forma crítica y
responsable, aplicando la normativa vigente.

•
CE5.1. Seleccionar información y recursos en diferentes aplicaciones, webs y plataformas digitales
de forma contrastada, valorando la información que presentan de forma crítica y responsable.
•
CE5.2. Utilizar recursos digitales y de las TIC para la edición, la grabación y la reproducción del sonido
e imagen, así como en los procesos de percepción, interpretación, investigación, creación y difusión
de los proyectos musicales e interdisciplinares realizados.
•
CE5.3. Ejercer un consumo digital responsable en las diferentes fases de los proyectos artísticos,
respetando las licencias de uso y la normativa vigente de protección de datos y autoría.
