# FÍSICA Y QUÍMICA

> Fuente: Secundaria.pdf, páginas 776-837 (versión en castellano).

FÍSICA Y QUÍMICA

1. Presentación

El conocimiento de la Física y la Química, junto con el resto de las materias que componen el ámbito
científico, resulta imprescindible para comprender el desarrollo social, económico y tecnológico en el que se
encuentra la sociedad actual, así́ como para poder actuar con criterios propios ante algunos de los grandes
desafíos de nuestra época.

Las competencias específicas de esta materia contribuyen a la educación global del alumnado porque
le hacen capaz de actuar de manera reflexiva ante situaciones que se consideran relevantes, a través del
desarrollo del pensamiento crítico. Asimismo, la materia contribuye a fomentar la cooperación y el trabajo en
equipo, dado que el trabajo científico es un proceso colaborativo. Este proceso requiere de la comunicación
de resultados y en esta comunicación se emplean diferentes herramientas digitales, por lo que también se
contribuye a la mejora de las competencias digital y lingüística.

El alumnado adquirirá las competencias clave al resolver los problemas que le plantean los
fenómenos del entorno físico, llevando a cabo una actividad científica escolar que debe ser conceptual y
práctica y al mismo tiempo debe tener fines humanos y sociales. Para ello, es necesario que las alumnas y
alumnos conozcan y sepan aplicar los principales modelos y procesos de las ciencias, en diferentes contextos
y según diferentes demandas o finalidades. Lo conseguirán mediante los intercambios de ideas y de formas
de trabajar en clase, la comunicación y el uso de los lenguajes específicos que adquirirán a medida que los
necesiten.

El razonamiento, la elaboración de argumentaciones sólidas y la comunicación de las mismas, bases
del pensamiento crítico, así como el aprendizaje y uso del lenguaje propio de la disciplina, no son destrezas
fáciles de adquirir. Por el contrario, son capacidades de una alta demanda intelectual. Su adquisición exige
un diseño cuidadoso de actividades, una adecuada graduación y la dedicación de tiempo y esfuerzo.

Con este planteamiento, el desarrollo de las once competencias específicas se estructura en cuatro
grupos en los que se prioriza la profundidad en el tratamiento de los contenidos frente a la amplitud. Estos
grupos de competencias específicas son, por un lado, una continuación de los que están presentes en el área
de Conocimiento del Medio Natural y Social de la Educación Primaria, como es el caso de la metodología de
la ciencia y la interpretación de los fenómenos del mundo natural; y por otro, incorporan nuevos saberes que
profundizan en el conocimiento de determinados aspectos más específicos.

Los saberes básicos que se trabajarán a lo largo de la ESO se organizan en cuatro bloques. El primer
bloque, compartido con la materia de Biología y Geología al igual que las competencias específicas más
directamente relacionadas con él, está dedicado al método científico, con el énfasis puesto en la construcción
y validación del conocimiento científico, el funcionamiento de la ciencia y la comunidad científica y las
relaciones entre ciencia, tecnología y sociedad. En el segundo bloque, dedicado a materia y sus cambios, se
incluyen los conocimientos básicos de las propiedades macroscópicas y microscópicas de la materia, así
como las principales transformaciones físicas y químicas de los sistemas materiales y naturales y sus
aplicaciones y contribuciones que contribuyen a hacer un mundo mejor. En el tercero, dedicado a la energía,
se profundiza en los conocimientos ya trabajados en la Educación Primaria sobre las fuentes de energía y
sus usos prácticos, incluyendo los conceptos básicos de este ámbito. Finalmente, el cuarto bloque tiene como
foco las interacciones y en él se presentan las principales fuerzas del mundo natural, sus interacciones y sus
aplicaciones.

Los saberes incluidos en estos bloques se consideran necesarios para adquirir y desarrollar las once
competencias específicas de la materia. En otras palabras, los saberes básicos son el medio para trabajar las
competencias específicas, pero también los conocimientos mínimos de ciencias físicas y químicas que el
alumnado debe adquirir.

Los bloques de saberes de la materia de Física y Química se han distribuido de forma asimétrica
entre el segundo y tercer curso. Así, teniendo en cuenta los conocimientos que el alumnado ha adquirido ya
durante la Educación Primaria y su grado de maduración intelectual, en el segundo curso predominan los
contenidos sobre la materia, con un tratamiento macroscópico y se inicia el estudio de las interacciones,
mientras el tratamiento microscópico de la materia se aborda en el tercer curso junto con los saberes
relacionados con la energía.

En cuarto curso, atendiendo al carácter optativo de la materia, se profundiza en los aspectos que
aseguran una preparación científica más general y cultural. De este modo, en lo que concierne a la Física, se
incluyen los conceptos y aplicaciones de fuerzas y movimientos y se estudian además las energías mecánica
y ondulatoria. Y en lo que concierne a la Química, se abordan, sobre todo, los cambios químicos y los primeros
modelos atómicos y se propone una introducción de los compuestos del carbono.

Los criterios de evaluación son indicadores que permiten medir el grado de desarrollo de las
competencias y el docente puede conectarlos de forma flexible con los saberes de la materia durante el
proceso de enseñanza y aprendizaje con el fin de obtener una visión objetiva de los aprendizajes del
alumnado.

Las competencias y saberes deben trabajarse en forma de situaciones de aprendizaje o actividades
con un objetivo claro, conectadas con la realidad y que inviten al alumnado a la reflexión y la colaboración.

2. Competencias específicas

2.1.
Competencia específica 1

Resolver problemas científicos abordables en el ámbito escolar a partir de trabajos de investigación
de carácter experimental.

2.1.1.Descripción de la competencia 1

Las experiencias prácticas realizadas en el ámbito escolar que requieren un trabajo experimental
implican hacer operaciones destinadas a comprobar o demostrar determinados fenómenos o principios
científicos. Es por esto que detrás de cada diseño de un experimento debe haber una finalidad que dirija el
trabajo del alumno hacia la comprensión de fenómenos o principios que se ponen de manifiesto.

Estas experiencias se convierten en pequeñas investigaciones cuando van acompañadas de un
aprendizaje por indagación guiada, cuyo objetivo es enseñar ciencia haciendo ciencia. De esta forma se
consigue el desarrollo de habilidades para la investigación y se ponen en juego las características y valores
del trabajo científico. Estas actividades propician la adquisición de los procedimientos propios de la ciencia,
lo que conocemos genéricamente como método científico: planteamiento del problema, observación crítica,
formulación de hipótesis, diseño de experimentos, recopilación de  datos y establecimiento de relaciones o
tendencias mediante tablas o gráficos, interpretación de  los resultados obtenidos, razonamiento  y revisión
de las pruebas obtenidas a la luz de lo que ya se conoce, extracción y comunicación de conclusiones.

Hay que señalar que las actividades experimentales pueden ser indagativas o no, ya que no siempre
que hacemos experimentos se activan automáticamente todos los procesos asociados al método científico.
No obstante, en numerosas ocasiones es necesario recurrir a experimentación práctica de tipo demostrativo
para ilustrar ejemplos o adquirir destrezas en el manejo de instrumentos científicos, sin realizar preguntas
investigables ni hipótesis que contrastar, lo que requiere menor maduración del alumnado en esta destreza.

Grado:

Las diferencias de grado en el desarrollo de esta competencia específica se manifiestan a través de
la distinta complejidad de las investigaciones planteadas, tanto en el problema a abordar, como en el
planteamiento del experimento o en la comunicación de los resultados, y en función de los saberes básicos
asociados al nivel.

Al acabar el segundo curso, el alumnado debe haber adquirido las destrezas básicas implicadas en
el uso de los materiales y herramientas propias de un laboratorio, así como ser capaz de realizar prácticas
demostrativas y pequeñas investigaciones guiadas en las que se exige identificar el problema y las variables
que intervienen, emitir hipótesis, realizar diseños experimentales, obtener resultados y saber comunicarlos.
En este nivel los problemas planteados son más sencillos y los resultados se presentan generalmente
mediante informes descriptivos y observaciones cualitativas (dibujos y esquemas).

Al acabar el tercer curso, el alumnado debe ser capaz de relacionar las variables de manera
cuantitativa o cualitativa, comunicar el proceso con precisión, sacar conclusiones y hacer predicciones en
distintas condiciones. Los informes de los resultados deben ser interpretativos de los fenómenos estudiados.

2.2.
Competencia específica 2

Analizar y resolver situaciones problemáticas del ámbito de la Física y la Química utilizando la lógica
científica y alternando las estrategias del trabajo individual con el trabajo en equipo.

2.2.1.Competencia específica 2

Hablar de situaciones problemáticas implica considerar aquellas situaciones que demandan reflexión,
búsqueda, investigación y en las que para poder afrontarlas y resolverlas hay que pensar previamente en
posibles soluciones y definir una estrategia de resolución. La aplicación de estrategias de resolución de
problemas implica varios tipos de acciones: comprender la situación, analizar el marco teórico, planificar el
procedimiento de solución, realizar lo planificado, analizar y verificar los resultados, evaluar las consecuencias
que se derivan de la solución propuesta (éticas, legales y sociales).

Es importante señalar que el proceso de resolución de problemas es global y no está rígidamente
dividido en pasos.

Por otro lado, la resolución colaborativa de problemas plantea numerosas ventajas como: la división
efectiva del trabajo, la incorporación de información procedente de múltiples perspectivas, experiencias y
fuentes de conocimiento, y una mayor creatividad y calidad de las soluciones aportadas por los diferentes
miembros de los grupos de trabajo.

Grado:

Al acabar el segundo curso, el alumnado será capaz de afrontar, analizar y resolver situaciones
problemáticas acotadas, contando para ello con información proporcionada por el profesorado. Asimismo,
será capaz de extrapolar los resultados obtenidos a otras situaciones de la vida cotidiana. Al acabar el tercer
curso, el alumnado será capaz de abordar situaciones y problemas de carácter abierto, acotándolos para
abordar su análisis y buscando y seleccionando la información relevante que permita su resolución. También
será capaz de valorar las consecuencias que puede tener un cambio en las condiciones iniciales para la
solución que se propone.

2.3.
Competencia específica 3

Utilizar el conocimiento científico como instrumento del pensamiento crítico, interpretando y
comunicando mensajes científicos, desarrollando argumentaciones y accediendo a fuentes fiables, para
distinguir la información contrastada de los bulos y opiniones.

2.3.1.Descripción de la competencia 3

El desarrollo del pensamiento crítico entendido como “pensamiento reflexivo y razonable que orienta
la decisión sobre qué hacer o qué creer” es una demanda de la sociedad actual. Este pensamiento crítico se
encuentra fuertemente vinculado con la capacidad de aprender a aprender y el aprendizaje permanente. Para
ello, el alumnado deberá ser capaz de distinguir las fuentes fiables de aquellas que no lo son. La reiterada
presencia en el mundo actual de bulos basados en fuentes poco fiables y en opiniones carentes de una base
científica, así como el avance de las pseudociencias, hace imprescindible el desarrollo, por parte de la
ciudadanía, de una competencia que le permita distinguir entre informaciones contrastadas y valoraciones sin
ningún fundamento.

Desarrollar esta competencia implica la capacidad de reunir datos de una forma que permita utilizarlos
para acotar los problemas y realizar una descripción precisa de los mismos, debatir, argumentar y defender
posturas, contrastar opiniones y redactar informes. Esto exige aplicar un código común, propio de la
comunidad científica: el uso de un lenguaje preciso, de información en formato numérico y gráfico, de citación
de fuentes fiables o de revisión por pares antes de ser publicados los resultados.

La utilización del lenguaje científico ya sea para leer textos o para producirlos, implica el conocimiento
de las reglas de ese lenguaje, además del vocabulario técnico específico, y la adquisición de las destrezas
propias de la argumentación, como el razonamiento lógico, el cuestionamiento de las propias creencias, y la
contrastación de los hechos o hipótesis.

Por otro lado, la comunicación desempeña un papel esencial en la construcción del conocimiento
científico que se va desarrollando en la sociedad.

Grado:

El grado en el desarrollo de esta competencia específica viene dado por la complejidad de los
conocimientos que implica identificar los rasgos propios de la ciencia en un discurso para validar el mismo en
base a su adecuación a las teorías y modelos científicos.

Al acabar el segundo curso, el alumnado debe ser capaz de identificar los elementos característicos
del discurso científico y tener un criterio propio para distinguir la información fiable de las opiniones personales
o faltas de fiabilidad, así como de interpretar textos científicos sencillos, elaborar informes de las experiencias
realizadas y exponerlos de manera oral.

Al finalizar el tercer curso, el alumnado debe ser capaz de argumentar y defender una opinión propia
en torno a cuestiones investigables utilizando los elementos principales del pensamiento crítico: construir una
argumentación a partir de análisis de datos que dé base a una opción o desmienta a otra.

2.4.
Competencia específica 4

Justificar la validez del modelo científico como producto dinámico que se va revisando y
reconstruyendo bajo la influencia del contexto social e histórico, atendiendo la importancia de la ciencia en el
avance de las sociedades, así como a los riesgos de un uso inadecuado o interesado de los conocimientos y
a sus limitaciones.

2.4.1.Descripción de la competencia 4

Esta competencia alude al hecho de que el conocimiento es un producto en continua revisión, con
influencias del pensamiento de la época. En ese sentido, las explicaciones científicas que son modelos válidos
en un entorno social y momento dado sufren cambios en función del conocimiento existente, mejorando su
capacidad de explicar la realidad. La ciencia debe entenderse y apreciarse no como un saber acabado, sino
como la descripción más razonable y adecuada a los conocimientos en cada momento histórico.

Igualmente importante en esta competencia es el conocimiento de la forma en que se gestaron las
ideas científicas y las circunstancias en las que se produjeron los descubrimientos, lo que aporta una
perspectiva sobre la ciencia que permite comprender el avance en el pensamiento humano y las
circunstancias que lo envuelven, favoreciendo o frenando dicho avance. Ciertamente, la ciencia se caracteriza
por una continua revisión de sus propuestas, asociada a nuevos descubrimientos o al progreso tecnológico
que permiten obtener datos más precisos. El conocimiento de la época en la cual se realizaron los
descubrimientos proporciona una visión más realista de la ciencia, como un trabajo de equipos y en continua
revisión, lejos de una concepción asociada a la genialidad de individuos aislados de su entorno.

El desarrollo de esta competencia conlleva una actitud crítica acerca del alcance y las limitaciones de
la ciencia, en la que, al contrario de lo que sucede en las pseudociencias o las creencias, no existen certezas
entendidas como verdades absolutas e incuestionables.

Un aspecto relevante de la epistemología de las ciencias es el papel jugado por las controversias
científicas. La discusión y el análisis de controversias científicas es fundamental para alcanzar una adecuada

alfabetización científica, ya que permiten transmitir una imagen de ciencia más adecuada, mostrando
características básicas de la misma, como la incertidumbre, el carácter tentativo, la subjetividad, la existencia
de múltiples perspectivas, el rol del financiamiento, los intereses políticos y su relación con el entorno social.

Grado:

El grado en el desarrollo de esta competencia específica depende de la dificultad para comprender
los modelos estudiados y los nuevos descubrimientos o avances en las técnicas que impulsan los avances
de la ciencia, y de las relaciones con otros conocimientos de otras áreas que influyen en la ciencia en un
momento histórico dado.

En el transcurso del segundo curso, el alumnado avanzará en el conocimiento de las relaciones entre
ciencia y sociedad y, al finalizar el ciclo, deberá ser capaz de aportar ejemplos de utilización positiva y negativa
del conocimiento científico como muestra del carácter de la ciencia y de su utilización en función de intereses
concretos, en muchas ocasiones nobles, pero en otras, perversos. También serán capaces de aportar
ejemplos de cambios sufridos por las teorías científicas con el tiempo.

Al finalizar el tercer curso, el alumnado deberá será capaz de situar en contexto las teorías científicas
teniendo en cuenta la época en que fueron planteadas y aportar algunos datos sobre las causas de los
avances que supusieron y su relación con el contexto histórico y social. Han de valorar las explicaciones
científicas aceptadas como la mejor explicación posible con los datos disponibles en un momento dado.

2.5.
Competencia específica 5

Analizar algunos fenómenos naturales y predecir su comportamiento utilizando modelos de Física y
Química para poder identificarlos, caracterizarlos y explicar otros fenómenos nuevos.

2.5.1.Descripción de la competencia 5

El desarrollo del conocimiento científico relativo a cualquier fenómeno se relaciona normalmente con
la producción de una serie de modelos con diferentes alcances y poder de predicción. Los modelos científicos
escolares son la versión escolar de los modelos científicos incluidos en el currículo.

Los modelos son representaciones de un objeto, un proceso o un fenómeno, construidas con la
finalidad de explicar su estructura o funcionamiento y predecir futuros estados. Ocupan una posición
intermedia entre los fenómenos y las teorías. Son un mediador entre la realidad que se modeliza y las teorías
sobre esa realidad. Son, por tanto, representaciones parciales de la realidad, lo que implica que no son la
realidad ni copias de la realidad.

Alcanzar esta competencia supone ser capaz de relacionar algunos fenómenos que se consideren
relevantes con los modelos teóricos de la física y de la química. Los alumnos deben conformar conjuntos de
conceptos y fenómenos que son modelos para explicar otros fenómenos nuevos, que siguen las mismas
leyes.

Esta competencia implica aprender a ver en los cambios que estudien, y en los que se puede
intervenir experimentalmente, las características específicas que les hacen similares a otros cambios. Este
conocimiento ayuda a reconocer estos cambios más allá de las aulas y el laboratorio. Así, el alumnado no
aprende los conceptos aislados, sino conformando conjuntos que tienen sentido para ellos para que expliquen
fenómenos que conocen y que se convierten en modelos para explicar otros fenómenos nuevos.

Los modelos deben ser pocos y significativos. Tienen que permitir al alumnado describir y explicar los
fenómenos, deducir preguntas, hacer predicciones y resolver problemas relevantes de la vida cotidiana
relacionados con la física y la química y otras disciplinas.

En esta etapa educativa, los modelos que se estudian son el modelo cinético-corpuscular, el modelo
atómico de Dalton, el modelo de carga eléctrica, el modelo de interacción  y el modelo de energía.

Grado:

Al finalizar el segundo curso, el alumnado será capaz de relacionar un fenómeno natural con el
modelo de explicación que le corresponde, identificar los elementos básicos y comunicarlo con un lenguaje
llano.

Al finalizar el tercer curso, el alumnado podrá predecir los cambios que tendrán lugar cuando se
modifican las condiciones que afectan al fenómeno caracterizado, y comunicar la solución mediante la
terminología y el lenguaje simbólico propios de la ciencia.

2.6.
Competencia específica 6

Utilizar adecuadamente el lenguaje científico propio de la Física y la Química en la interpretación y
transmisión de información.

2.6.1.Descripción de la competencia 6

La comunidad científica utiliza un lenguaje universal que permite establecer flujos de información
multidireccionales que ayudan a la interpretación y transmisión de la información. En el caso de las disciplinas
de Física y Química, este lenguaje dista mucho de ser sencillo. De hecho, su complejidad es tal que se suele
comparar en ocasiones con el aprendizaje de una lengua extranjera.

Todas las formas referidas de comunicación en ciencia implican el desarrollo de capacidades
cognitivamente exigentes, que se deben aprender en el contexto social del aula de ciencias.

La comprensión de la Física y de la Química requiere la capacidad de leer textos y, por lo tanto, la
alfabetización está en el centro de la alfabetización científica. En este sentido, hay que señalar que los textos
expositivos y argumentativos utilizados en esta materia tienen unas características que los hacen más difíciles
en su comprensión que los textos narrativos, por lo que el desarrollo de estrategias de lectura de estos tipos
de textos es crucial en el aprendizaje de la misma. Entre las dificultades en el aprendizaje del lenguaje propio
de la materia, conviene destacar las siguientes: la introducción de una gran cantidad de terminología
específica nueva; el carácter polisémico de algunos términos, que pueden tener un significado diferente en el
contexto cotidiano y el científico; la utilización de terminología que procede del lenguaje cotidiano, pero que
adquiere un significado diferente al ser usada en un contexto científico; evolución histórica del significado de
algunos términos; uso de conectores lógicos (sin embargo, por tanto, en consecuencia, además, por el
contrario, ya que, etc.).

Por otro lado, las capacidades de hacerse preguntas y de hacerlas a otros con espíritu crítico, de
responderlas, de comunicar de forma convincente y de compartir conocimiento son intrínsecas a la actividad
cientíﬁca. En toda investigación se debe hacer uso de argumentos y de razonamientos lógicos y bien
estructurados que propicien describir y explicar lo mejor posible la realidad objeto de estudio, por lo que el
dominio del lenguaje en general, y del lenguaje específico utilizado en la materia en particular, deviene una
cuestión central.

Grado:

Al finalizar el segundo curso, el alumnado deberá ser capaz de leer, interpretar y producir textos
breves, preferentemente de carácter descriptivo, sobre los fenómenos objeto de estudio.

Al finalizar el tercer curso, el alumnado deberá ser capaz de producir textos explicativos utilizando la
terminología propia de la Física y la Química y del conocimiento científico en general.

2.7.
Competencia específica 7

Interpretar correctamente la información presentada en diferentes formatos de representación gráfica
y simbólica utilizados habitualmente en la Física y la Química.

2.7.1.Descripción de la competencia 7

Cuando se dispone de datos de un estudio científico y antes de abordar análisis más complejos, un
primer paso consiste en presentar esa información de forma que ésta se pueda visualizar de una manera más

sistemática y resumida. La claridad de dicha presentación es de vital importancia para la comprensión de los
resultados y la interpretación de los mismos.

Ello implica el dominio de todo un lenguaje semiótico: símbolos (ecuaciones químicas y fórmulas
matemáticas), tablas y gráficas, así como ciertas representaciones correspondientes a distintos modelos de
las ciencias físico-químicas

Las funciones y los gráficos representan uno de los primeros puntos en los que un estudiante usa un
sistema simbólico para expandir y comprender otro (p.ej. funciones algebraicas y sus gráficas, patrones de
datos y sus gráficas, etc.). En un sentido instructivo, son interesantes porque tienden a centrarse en la relación
además de en la entidad y porque son una magnífica herramienta para examinar patrones.

La mayor parte de las acciones relacionadas con las tareas de gráficos y funciones pueden
clasificarse en dos categorías principales: interpretación y construcción. El dominio de estas estrategias
permite al alumnado realizar tareas de clasificación, de predicción y de valoración de la escala.

Es interesante para la adquisición de la competencia, que el profesor tenga el papel de provocar,
mediante preguntas a los alumnos, la comprensión de los diferentes tipos de representación, del paso de la
una a la otra, ayudarles a apreciar los matices asociados a cada representación, ayudarles a tomar conciencia
de sus progresos en la elaboración de nuevas representaciones, en la comprensión de las representaciones
de los compañeros y en la capacidad de ir cambiando de un tipo de representación a otro.

Grado:

Al finalizar el segundo curso, el alumnado interpretará correctamente el significado de la simbología
representativa de las sustancias y su significado en una reacción química, y será capaz de representar las
sustancias utilizando el modelo de partícula. También podrá construir gráficos a partir de datos y dar una
explicación cualitativa a la forma de la gráfica obtenida (relaciones lineales). Al finalizar el tercer curso, el
alumnado deberá ser capaz de extraer la ecuación teórica a partir de la forma de la gráfica.

2.8.
Competencia específica 8

Distinguir las diferentes manifestaciones de la energía e identificar sus formas de transmisión, su
conservación y disipación en contextos cercanos.

2.8.1.Descripción de la competencia 8

La adquisición de esta competencia requiere que el alumnado conozca que la energía es primordial
para el desarrollo de nuestra sociedad y a su vez que tome conciencia de los problemas medioambientales
que su producción genera. Para ello, es importante que conozca las leyes de conservación de la energía y
los mecanismos de transmisión, transformación y degradación de la misma.

Es importante analizar las distintas formas de energía, sus ventajas e inconvenientes y comprender
las limitaciones a la demanda de energía que imponen los sistemas físicos, químicos, biológicos y geológicos.
Además, el alumnado tiene que ser capaz de explicar los impactos ambientales que generan los distintos
modos de producción y consumo. También ha de poder justificar decisiones y proponer reglas de uso
responsable de energía. Asimismo, implica tener conciencia de que es necesaria la colaboración y
cooperación de muchas personas, incluido uno mismo, para asegurar que los recursos se aprovechan bien y
llegan a todas las personas

Grado:

Esta competencia se trabaja en 3º de ESO, por la dificultad conceptual que implica el tratamiento de
la energía.

2.9.
Competencia específica 9

Identificar y caracterizar las sustancias a partir de sus propiedades físicas para relacionar los
materiales de nuestro entorno con el uso que se hace de ellos.

2.9.1.Descripción de la competencia 9

El estudio de la composición, estructura y propiedades de las sustancias es fundamental para
entender cómo se comporta nuestro entorno material e incluso nuestro propio cuerpo. Así, por ejemplo, el
cuerpo humano está formado por un 99% en masa de once elementos químicos (de los que el oxígeno, el
carbono, el hidrógeno, el nitrógeno, el calcio y el fósforo, en orden decreciente, son los mayoritarios) y el 1%
restante por trazas de otros. Estos elementos forman los compuestos (agua, proteínas, grasas,
carbohidratos…) de las células que, a su vez, se agrupan formando tejidos y órganos.

Sustancias tan sencillas como el agua y el oxígeno son imprescindibles para la vida y, por lo tanto, el
conocimiento de sus propiedades y comportamiento es de especial importancia.

Por otro lado, el descubrimiento, desarrollo y uso de los nuevos materiales han hecho que la vida
humana sea más fácil y ha contribuido en cada época histórica a su bienestar.

El conocimiento de la estructura de los materiales a escala atómica y molecular ha hecho posible
alcanzar prestaciones insospechadas tanto a los materiales clásicos utilizados en la ingeniería civil,
arquitectura, telecomunicaciones, energía y medio ambiente, biomedicina, etc., como a una nueva generación
de materiales fabricados artificialmente.

Un ámbito en el que los materiales han cobrado gran relevancia es la medicina y las áreas
relacionadas con la salud. En la actualidad, materiales poliméricos, cerámicos, metálicos o híbridos se están
empleando en sustitución de tejidos humanos, ya sea de manera temporal o permanente.

Grado:

Al finalizar el segundo curso, el alumnado será capaz de definir los estados en los que se presenta la
materia en el Universo y describirlos atendiendo a sus propiedades macroscópicas y microscópicas, utilizando
para ello el modelo cinético-corpuscular de la materia. Será también capaz de interpretar los cambios de
estado utilizando este modelo e identificando los intercambios de energía que tienen lugar en el proceso.

Al finalizar el tercer curso, el alumnado será capaz de conocer algunas propiedades características
de una colección de sólidos y clasificarlos según sus propiedades. Asimismo, podrá citar ejemplos de nuevos
materiales y señalar los beneficios que aportan o los problemas que resuelven identificando qué característica
del material contribuye a ello.

2.10. Competencia específica 10

Caracterizar los cambios químicos como transformación de unas sustancias en otras diferentes,
reconociendo la importancia de las transformaciones químicas en actividades y procesos cotidianos.

2.10.1.Descripción de la competencia 10

El estudio de las reacciones por las cuales una sustancia se convierte en otra, eje central de la
química, es fundamental para entender un gran número de procesos que tienen lugar en la vida cotidiana

Los procesos corporales son químicos en su mayoría. Mientras respiramos, hacemos la digestión,
crecemos, envejecemos e incluso pensamos, estamos siendo reactores químicos ambulantes. Los procesos
químicos de las fábricas son diferentes en escala, más que conceptualmente, puesto que en ellas se
procesan, se separan y se recombinan materiales para convertirlos en nuevas y provechosas formas.

Muchos aspectos de la época contemporánea, a los que frecuentemente se alude en los medios de
comunicación, están estrechamente vinculados con procesos de trasformación química: el efecto invernadero,
la lluvia ácida, el agujero de ozono, la producción de alimentos, las pilas alcalinas, los cosméticos, los
medicamentos, la corrosión, la batería de un automóvil, la información nutricional, el tratamiento de los
residuos urbanos, el problema de disponer de agua potable para una población cada vez mayor, entre otros.

Grado:

Al finalizar el segundo curso, el alumnado será capaz de describir las reacciones químicas desde un
punto de vista macroscópico como un proceso de transformación de sustancias y valorar los diferentes
factores que influyen en la velocidad de las reacciones químicas, identificar distintas reacciones químicas que

ocurren en su vida cotidiana y reconocer su importancia, los intercambios energéticos que se producen y la
ley de conservación de la masa.

Al finalizar el tercer curso, deberá ser capaz de interpretar la representación simbólica de las
ecuaciones químicas y realizar cálculos sencillos a partir de las leyes de Proust y Lavoisier. También podrá
explicar el proceso de reacción a partir del modelo de Dalton.

2.11. Competencia específica 11

Identificar las interacciones como causa de las transformaciones que tienen lugar en nuestro entorno
físico para poder intervenir en el mismo, modificando las condiciones que nos permitan una mejora en
nuestras condiciones de vida.

2.11.1.Descripción de la competencia 11

La idea de interacción constituye un pilar fundamental en la explicación cientíﬁca del mundo: los
cambios en los objetos o sistemas son siempre producidos por acciones mutuas entre ellos.  La identificación
y comprensión de las interacciones en el mundo físico nos permite intervenir en él para producir mejoras en
nuestras condiciones de vida. Desde aplicaciones sencillas, como la palanca, hasta la navegación espacial,
pasando por el funcionamiento de motores, el transporte marítimo o las aplicaciones energéticas, son
múltiples las situaciones de la vida diaria gobernadas por el modelo de interacción física, así como las
aplicaciones tecnológicas de las que podemos disponer para ayudar a mejorar las condiciones de la
existencia.

Grado:

El estudio de las interacciones se inicia en el segundo curso con la introducción de la mecánica, y
continúa en 3r curso de Física y Química con el estudio de la interacción eléctrica.

3. Conexiones de las competencias específicas entre sí, con las competencias de otras áreas/materias
y con las competencias clave (para el conjunto de las competencias del área/materia)

3.1.
Relaciones o conexiones con las otras CE del área/materia

La CE1 está ligada a las dos competencias específicas siguientes (CE 2 y CE 3) que abarcan la
metodología de la ciencia y no puede desarrollarse de forma independiente de ellas. La adquisición y el uso
de conocimientos específicos da respuestas y soluciones a los problemas científicos. Las leyes, los principios
y los conceptos científicos se utilizan para definir un problema y formularlo en términos que se aproximen a
una respuesta o solución. Esta competencia no puede desarrollarse sin el dominio de las estrategias de
comunicación. Por otro lado, en la medida en que se aplicará para facilitar la comprensión de los fenómenos
de nuestro entorno, se relaciona con el resto de competencias de la materia, al constituir el instrumento que
facilitará dicha comprensión.

La competencia 2 está ligada a la CE 6 de esta misma materia y no puede desarrollarse de forma
independiente de ella. La adquisición y el uso de conocimientos específicos permite dar respuestas a
situaciones reales. Las leyes, los principios y los conceptos científicos se utilizan para definir un problema y
formularlo en términos que se aproximen a una respuesta o solución. Del mismo modo, esta competencia no
puede desarrollarse sin el dominio de las estrategias de argumentación y comunicación propios de la ciencia
a los que remite la CE 3.

La CE3 no puede desarrollarse independientemente de las dos anteriores. Se enriquece con la mejor
comprensión de los procesos al resolver problemas aplicando el razonamiento científico, o al emitir hipótesis
y comunicar los resultados de una investigación, pero en ambos casos la comunicación de los resultados o
conclusiones, o la argumentación realizada, se llevan a cabo mediante un tipo de discurso argumentativo y
un lenguaje propios de la ciencia, que implican la utilización del lenguaje matemático y la comprensión de las
leyes de la ciencia.

La competencia específica 4 se relaciona con las otras tres por suponer un avance en la comprensión
de cómo funciona la ciencia y su incidencia en la vida de las personas, aportando a dicha comprensión la
relación con la sociedad en la que se encuentran las personas que desarrollan las teorías.

La relación de las cuatro primeras competencias con el resto de competencias específicas se basa
en la naturaleza del sistema de trabajo propio de la ciencia. Con sus limitaciones asociadas a la dependencia
de los principios aplicados de los distintos descubrimientos que se van produciendo y el carácter dinámico
que ello le confiere, el trabajo científico constituye un buen sistema de interpretación de la realidad que facilita
la previsión de acontecimientos y, por tanto, las actuaciones que facilitan la vida a los seres humanos y
permiten prever las consecuencias de sus actos. Estas cuatro competencias específicas deben impregnar,
en consecuencia, todos los niveles educativos y todas las áreas y materias del currículo, no solo las del ámbito
científico y tecnológico.

En cuanto a su relación con el resto de competencias específicas de Física y Química, por su carácter
transversal, las cuatro primeras competencias específicas afectan a todos los aspectos de la ciencia,
facilitando el uso de modelos para caracterizar algunos fenómenos naturales (CE 5), el uso adecuado del
lenguaje científico (CE 6), la interpretación de representaciones gráficas y simbólicas propias de la Física y
Química (CE 7), el conocimiento de las diferentes formas de energía (CE 8), la identificación y transformación
de algunas sustancias (CE 9) y (CE 10) y la identificación de interacciones como causa de transformaciones
en nuestro entorno físico (CE 11).

Por lo que respecta a la (CE 5) que se refiere al uso del lenguaje científico, apela a la utilización de
los modelos de Física y Química de algunos fenómenos naturales como son los relacionados con la energía
(CE 8) y la identificación y transformación de sustancias (CE 9) y (CE 10) así como facilita la comprensión de
las interacciones en nuestro entorno físico (CE 11). Lo mismo pasa con la (CE 6) que trata de la interpretación
de representaciones gráficas y simbólicas e impregnan a todas las competencias.

Por último, la identificación de interacciones en nuestro entorno físico como causa de las
transformaciones (CE 11), está estrechamente relacionada con el intercambio de energía que estas
transformaciones conllevan (CE 8).

3.2.
Relaciones o conexiones con las CE de otras áreas/materias de la etapa

En el siguiente cuadro se establece la relación de las competencias de la materia de Física y Química
con el resto de materias de la etapa:

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| EDUCACIÓN PLÁSTICA Y VISUAL |  |  |  |  |  |  |  |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| CE1: Analizar de manera crítica y argumentada diferentes propuestas artísticas, identificando en ellas, a través de distintos canales y contextos, referencias socioculturales, funcionalidades y elementos de contenido de la cultura visual y audiovisual y del patrimonio |  |  | X |  |  |  |  |  |  |  |  |
| CE2: Elaborar propuestas creativas, utilizando los formatos, materiales y discursos propios de la contemporaneidad artística. |  | X |  |  |  |  | X |  |  |  |  |
| CE3: Compartir ideas y opiniones usando la terminología específica del área en la comunicación de las experiencias de apreciación y creación artística. |  |  | X |  |  | X |  |  |  |  |  |
| CE4: Comunicar ideas, sentimientos y emociones, experimentando con los elementos del lenguaje visual y con diferentes técnicas y materiales en la elaboración de producciones artísticas creativas individuales o colectivas. |  |  | X |  |  |  |  |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| CE5: Seleccionar de manera responsable y autónoma recursos digitales aplicados a la percepción, la investigación y la creación en el desarrollo de propuestas y proyectos artísticos, desarrollando una identidad y criterio propio en un consumo responsable y sostenible de acuerdo a la normativa vigente |  |  | X |  |  |  | X |  |  |  |  |
| CE6: Crear producciones artísticas colectivas, atendiendo a las diferentes fases del proceso creativo y aplicando los conocimientos específicos relevantes adquiridos. |  |  |  |  |  |  | X |  |  |  |  |
| MÚSICA |  |  |  |  |  |  |  |  |  |  |  |
| CE1. Analizar propuestas musicales, corporales y multidisciplinares de diferentes épocas y estilos, asimilando sus funciones, a través de la percepción activa, relacionando sus elementos estructurales y técnicos con sentido crítico, valorando la diversidad cultural que representan. |  |  | X |  |  |  |  |  |  |  |  |
| CE2. Relacionar los elementos del sonido, sus características y representaciones gráficas, los instrumentos y la voz, a partir del análisis auditivo y visual desde una |  |  |  |  |  |  | X | X |  |  | X |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| perspectiva de desarrollo sostenible. |  |  |  |  |  |  |  |  |  |  |  |
| CE3. Construir propuestas musicales basadas en la interpretación, la improvisación y la experimentación a partir de las posibilidades expresivas y comunicativas del sonido, el cuerpo y los medios digitales, mediante procesos individuales y colectivos. | X |  |  |  |  |  |  |  |  |  |  |
| CE4. Crear proyectos musicales e interdisciplinares, mediante el diseño, planificación y realización de las mismas, experimentando con diferentes roles, para desarrollar la capacidad crítica y valorando tanto el proceso como el resultado. | X |  | X |  |  |  |  |  |  |  |  |
| CE5. Aplicar recursos digitales a la escucha, interpretación, investigación, creación y difusión de producciones musicales, adoptando una actitud responsable y acorde con la normativa vigente y el criterio propio. |  |  |  |  |  | X | X |  |  |  |  |
| EDUCACIÓN FÍSICA |  |  |  |  |  |  |  |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| CE1. Integrar un estilo de vida activo mediante la práctica de la actividad física y deportiva autorregulada, y el establecimiento de conexiones entre los hábitos de comportamiento cotidianos y el bienestar físico y mental. |  |  |  |  |  |  |  | X | X | X |  |
| CE2. Resolver con éxito diferentes retos y situaciones motrices a través de propuestas físicas y deportivas específicas aplicando las técnicas, tácticas y estrategias de juego adecuados. | X |  |  |  |  |  |  | X |  |  |  |
| CE3. Participar en procesos de creación de naturaleza artisticoexpressiva mediante el uso del cuerpo, el gesto y el movimiento como medios de autoconocimiento para expresar ideas y sentimientos. |  |  | X |  |  |  |  |  |  |  | X |
| CE4. Interaccionar de manera sostenible con el patrimonio natural y cultural mediante actividades físicas y artisticoexpresivas. |  |  | X |  |  |  |  |  | X |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| CE5. Seleccionar y hacer un uso crítico y seguro de las tecnologías de la información y la comunicación como facilitadoras de la actividad física y de una vida activa y saludable. |  |  | X |  |  |  | X |  |  | X | X |
| LENGUAS – CASTELLANO/VALENCIANO |  |  |  |  |  |  |  |  |  |  |  |
| CE1. Describir y apreciar la diversidad lingüística y cultural del mundo a través del reconocimiento de las lenguas del alumnado y de la realidad multilingüe e intercultural de la Comunidad Valenciana y de España, analizando las características, el origen y el desarrollo sociohistórico de las dos lenguas oficiales y de las principales variedades lingüísticas, para favorecer la reflexión interlingüística y combatir los prejuicios lingüísticos. |  |  |  |  |  | X | X |  |  |  |  |
| CE2. Comprender, interpretar y valorar, de manera autónoma, textos orales y multimodales propios de los ámbitos personal, social, educativo y profesional, a través de la escucha activa, aplicando estrategias de comprensión oral, reflexionando sobre el contenido y la forma, y evaluando su calidad y fiabilidad. |  |  | X |  |  |  | X |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| CE3. Comprender, interpretar y valorar, de manera autónoma, textos escritos y multimodales propios de los ámbitos personal, social, educativo y profesional, a través de la lectura de textos, aplicando estrategias de comprensión escrita, reflexionando sobre el contenido y la forma, y evaluando su calidad y fiabilidad. |  |  | X |  |  |  | X |  |  |  |  |
| CE4. Producir mensajes orales con coherencia, cohesión y adecuación, fluidez y corrección, a través de diferentes soportes y situaciones de comunicación del ámbito familiar, social, educativo o profesional. |  |  | X |  |  |  |  |  |  |  |  |
| CE5. Producir textos escritos y multimodales coherentes, cohesionados, adecuados y correctos empleando estrategias de planificación, textualización, revisión y edición. |  |  | X |  |  | X |  |  |  |  |  |
| CE6. Interactuar de manera oral, escrita y multimodal, de forma autónoma, a través de textos complejos de los ámbitos personal, social, educativo y profesional, utilizando un lenguaje no discriminatorio y estrategias variadas de comprensión, expresión y resolución dialogada de |  |  | X |  |  | X | X |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| conflictos, de forma síncrona y asíncrona. |  |  |  |  |  |  |  |  |  |  |  |
| CE7. Mediar entre interlocutores aplicando estrategias de adaptación, simplificación y reformulación del lenguaje para procesar y transmitir información más elaborada, en situaciones comunicativas de ámbito personal, social, educativo y profesional. | X |  | X |  |  | X | X |  |  |  |  |
| CE8. Leer obras y textos de carácter diverso y de complejidad progresiva, que configuran la autonomía capa un perfil lector competente y hagan disfrutar de la lectura como fuente de conocimiento, de placer y de enriquecimiento personal y social. |  |  | X |  |  |  |  |  |  |  |  |
| CE9. Leer y producir textos literarios, contextualizados con la cultura y la sociedad, como dimensión de placer y de conocimiento. |  |  | X |  |  | X |  |  |  |  |  |
| MATEMÁTICAS |  |  |  |  |  |  |  |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| CE1. Resolver problemas relacionados con situaciones diversas del ámbito social y de iniciación a los ámbitos profesional y científico utilizando estrategias formales, representaciones y conceptos que permitan la generalización y abstracción de las soluciones. | X | X |  |  |  |  |  |  |  |  |  |
| CE2. Explorar, formular y generalizar conjeturas y propiedades matemáticas, haciendo demostraciones sencillas y reconociendo y conectando los procedimientos, patrones y estructuras abstractas implicados en el razonamiento. | X | X |  |  |  |  |  |  |  |  |  |
| CE3. Construir modelos matemáticos generales utilizando conceptos y procedimientos matemáticos funcionales con el fin de interpretar, analizar, comparar, valorar y hacer aportaciones al abordaje de situaciones, fenómenos y problemas relevantes en el ámbito social y de iniciación a los ámbitos profesional y científico. |  | X |  |  |  |  |  |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| CE4. Implementar algoritmos computacionales organizando datos, descomponiendo un problema en partes, reconociendo patrones y empleando lenguajes de programación y otras herramientas TIC como soporte para resolver problemas y afrontar desafíos del ámbito social y de iniciación a los ámbitos profesional y científico. | X | X |  |  |  |  |  |  |  |  |  |
| CE5. Manejar con precisión el simbolismo matemático haciendo transformaciones y conversiones entre representaciones icónico- manipulativas, numéricas, simbólico-algebraicas, tabulares, funcionales, geométricas y gráficas que permitan pensar matemáticamente sobre situaciones del ámbito social y de iniciación a los ámbitos profesional y científico. | X |  |  |  | X |  | X |  |  |  |  |
| CE6. Producir, comunicar e interpretar mensajes orales y escritos complejos de manera formal, empleando el lenguaje matemático, para comunicar e intercambiar ideas generales y argumentos sobre características, conceptos, procedimientos y resultados relacionados con situaciones del ámbito social y de iniciación a los ámbitos profesional y científico. |  |  | X |  |  | X |  |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| CE7. Conocer el valor cultural e histórico de las matemáticas e identificar sus aportaciones en los avances significativos del conocimiento científico y del desarrollo tecnológico especialmente relevantes para abordar los desafíos con los que se enfrenta actualmente la humanidad. | X | X |  | X |  |  |  |  |  |  |  |
| CE8. Gestionar y regular las emociones, creencias y actitudes implicadas en los procesos matemáticos, asumiendo con confianza la incertidumbre, las dificultades y errores que dichos procesos conllevan, y regulando la atención para lograr comprender sus propios procesos de aprendizaje y adaptarlos con éxito a situaciones variadas. | X |  |  |  |  |  |  |  |  |  |  |
| VALORES |  |  |  |  |  |  |  |  |  |  |  |
| CE1. Dialogar y debatir de forma asertiva, respetuosa y correctamente argumentada sobre problemas morales planteados en cualquier situación de la vida diaria para poder llegar a acuerdos o consensos. |  |  | X |  |  |  |  |  |  |  |  |
| CE2. Gestionar las emociones en situaciones de conflicto para poder afrontarlas desde la cultura de la paz y explorar y |  |  | X |  |  |  |  |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| proponer soluciones equitativas y creativas. |  |  |  |  |  |  |  |  |  |  |  |
| CE3. Analizar de forma crítica las normas y leyes vigentes en el marco de la Declaración Universal de los Derechos Humanos y adecuarse a ellas valorando su legitimidad. |  |  | X |  |  |  |  |  |  |  |  |
| CE4. Reconocer, denunciar y combatir los estereotipos y roles asociados a partir de una reflexión personal y crítica. |  |  | X | X |  |  |  |  |  |  |  |
| CE5. Identificar, analizar y valorar en el ámbito internacional los beneficios de los valores democráticos promovidos por leyes e instituciones para la construcción de una ciudadanía global. |  |  | X | X |  |  |  |  |  |  |  |
| CE6. Proponer y desplegar acciones responsables y justas comprometidas con la transformación social y la lucha efectiva contra las desigualdades e injusticias en cualquier situación real de acuerdo con los principios de una sociedad igualitaria e inclusiva. |  |  | X |  |  |  |  |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| CE7. Explicar los desafíos ecológicos planteados por los Objetivos de Desarrollo Sostenible y actuar de manera comprometida con la transformación de la situación medioambiental del planeta. | X | X | X |  |  |  |  |  |  |  |  |
| GEOGRAFIA E HISTORIA |  |  |  |  |  |  |  |  |  |  |  |
| CE 1. Describir y contextualizar en el tiempo y el espacio los acontecimientos y procesos más relevantes de la historia propia y universal, adquiriendo referentes sobre la evolución hacia la sociedad actual y valorando su diversidad. |  |  |  | X |  |  |  |  |  |  |  |
| CE 2. Identificar la información referente a hechos históricos, geográficos y artísticos a partir de diferentes fuentes documentales, realizando un tratamiento correcto en cuanto a investigación, clasificación, recogida, organización, crítica y respeto. | X | X |  |  |  |  |  |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| CE 3- Explicar las nociones básicas de cambio y continuidad en la historia empleando una perspectiva causal y contextualizada, reconociendo en el pasado el origen y evolución de las cuestiones más relevantes del mundo actual y expresando juicios y opiniones sobre el presente y el futuro. |  |  |  | X |  |  |  |  |  |  |  |
| CE 4. Contrastar las identidades individuales con las colectivas, identificando las aportaciones decisivas en su construcción y reconociendo y valorando las actuaciones de tolerancia y respeto. |  |  |  | X |  |  |  |  |  |  |  |
| CE 5. Explicar las interrelaciones económicas fundamentales entre los elementos del espacio físico y las actividades de las sociedades humanas, así como su repercusión en la sostenibilidad. |  |  |  |  |  |  |  |  |  |  | X |
| CE 6. Contrastar los principales modelos de ocupación territorial, de organización política y económica, que explican la desigualdad entre los seres humanos, tanto a escala local como global. |  |  |  | X |  |  |  |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| CE 7. Dar argumentos desde una perspectiva crítica, fundamentada en la historia y la geografía, acerca de problemas sociales relevantes, asumiendo valores democráticos y pronunciándose en su defensa. |  |  | X | X |  |  |  |  |  |  |  |
| CE 8. Promover y participar en proyectos cooperativos de convivencia, tomando como base la construcción histórica de la Unión Europea, que favorezcan un entorno más justo y solidario mediante la aplicación de valores y procedimientos democráticos. |  |  |  | X |  |  |  |  |  |  |  |
| CE 9. Identificar el origen y reconocer el valor del patrimonio cultural y natural, especialmente de sus elementos geográficos, históricos y artísticos, tanto a escala local como a escala global, participando en la elaboración y difusión de propuestas que favorezcan su preservación y puesta en valor. |  |  |  | X |  |  |  |  |  |  |  |
| CULTURA CLÁSICA |  |  |  |  |  |  |  |  |  |  |  |
| CE1. Reconocer y valorar la pervivencia de las características de la vida social griega y romana en el desarrollo de nuestra actividad cotidiana y en nuestras raíces |  |  |  | X |  |  |  |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| comunes con otros países de nuestro entorno. |  |  |  |  |  |  |  |  |  |  |  |
| CE2. Relacionar los acontecimientos más relevantes de la historia griega y romana con la configuración sociopolítica de la Europa del siglo XXI y del mundo actual a partir de fuentes históricas, teniendo en cuenta los límites geográficos y las características específicas del mundo clásico. |  |  |  | X |  |  |  |  |  |  |  |
| CE3. Identificar los rasgos y valorar la importancia y la huella de la lengua griega y latina en los idiomas que el alumnado utiliza y estudia, a través del aprendizaje del alfabeto, la etimología, los helenismos y latinismos, la composición y derivación. |  |  |  |  |  | X | X |  |  |  |  |
| CE4. Localizar y relacionar la presencia del mundo clásico en el patrimonio histórico de Europa, de la Península Ibérica y de la Comunidad Valenciana y contribuir a su conservación y respeto. |  |  |  | X |  |  |  |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| CE5. Investigar, identificar y explicar los referentes culturales de la época clásica en el desarrollo de la ciencia y en las diversas manifestaciones artísticas actuales. | X | X |  | X |  |  |  |  |  |  |  |
| TECNOLOGÍA Y DIGITALIZACIÓN |  |  |  |  |  |  |  |  |  |  |  |
| CE1. Identificar y resolver problemas tecnológicos sencillos y cercanos aplicando el método de proyectos, propio de la ingeniería, ejecutando, si es necesario, sus fases características y utilizando los medios tecnológicos y digitales más adecuados al contexto. | X | X |  |  |  |  |  |  |  |  |  |
| CE2. Buscar, obtener, analizar y seleccionar información de forma fiable y segura para poder gestionar, de la manera más adecuada y siguiendo un plan de trabajo realista, el tiempo, los conocimientos y los recursos disponibles a la hora de abordar retos tecnológicos cotidianos en una sociedad abierta y cambiante. | X | X |  |  |  | X | X |  |  |  |  |
| CE3. Configurar, utilizar y mantener máquinas, herramientas, aplicaciones y sistemas digitales, haciendo una selección idónea y un uso seguro y adecuado de los mismos en función de la naturaleza y características de la tarea. | X | X |  |  |  |  |  |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| CE4. Realizar un uso responsable y sostenible de los objetos, materiales, productos y soluciones tecnológicas y digitales existentes en el entorno ordinario, analizando críticamente sus implicaciones y repercusiones ambientales, sociales y éticas. | X | X | X |  |  |  |  | X | X | X | X |
| CE5. Crear, expresar, comprender y comunicar ideas, opiniones y propuestas relacionadas con aspectos tecnológicos y digitales cotidianos y habituales, tanto en el ámbito académico como en el personal y social, utilizando correctamente los lenguajes y los medios propios de este ámbito de conocimiento. | X | X |  |  |  | X | X |  |  |  |  |
| CE6. Analizar problemas sencillos y plantear sus soluciones automatizando procesos con lenguajes de programación, sistemas de control o robótica, aplicando el pensamiento computacional. | X | X |  |  |  |  |  |  |  |  |  |
| CE7. Utilizar las nuevas tecnologías poniéndolas al servicio del desarrollo personal y profesional, social y comunitario y proponiendo soluciones creativas a los grandes desafíos del mundo actual. | X | X | X |  |  |  |  | X | X | X | X |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| BIOLOGÍA Y GEOLOGÍA |  |  |  |  |  |  |  |  |  |  |  |
| CE1. Resolver problemas científicos abordables en el ámbito escolar a partir de trabajos de investigación de carácter experimental. | X |  |  |  |  |  |  |  |  |  |  |
| CE2. Analizar situaciones problemáticas reales utilizando la lógica científica y explorando las posibles consecuencias de las soluciones propuestas para afrontarlas. |  | X |  |  | X | X |  |  |  |  |  |
| CE3 - Utilizar el conocimiento científico como instrumento del pensamiento crítico, interpretando y comunicando mensajes científicos, desarrollando argumentaciones y accediendo a fuentes fiables, para distinguir la información contrastada de los bulos y opiniones. |  |  | X |  |  |  |  |  |  |  |  |
| CE4 - Justificar la validez del modelo científico como producto dinámico que se va revisando y reconstruyendo con influencia del contexto social e histórico, atendiendo a la importancia de la ciencia en el avance de las sociedades, a los riesgos de un uso inadecuado o interesado de los conocimientos y a sus limitaciones. |  |  | X | X |  |  |  |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| CE5. Adoptar hábitos de vida saludable basados en el conocimiento del funcionamiento del propio cuerpo y de los peligros del uso y abuso de determinadas prácticas y del consumo de algunas sustancias. |  |  |  |  |  |  |  |  |  |  |  |
| CE6. Identificar y aceptar la sexualidad personal, y respetar la variedad de identidades de género y de orientaciones sexuales existentes, en base al conocimiento del cuerpo humano y del propio cuerpo. |  |  | X |  | X |  |  |  |  |  |  |
| CE7. Actuar con responsabilidad participando activamente en la conservación de todas las formas de vida y del planeta en base al conocimiento de los sistemas biológicos y geológicos. |  |  |  |  |  |  |  | X | X | X | X |
| CE8. Utilizar el conocimiento geológico básico sobre el funcionamiento del planeta Tierra como sistema, con el fin de analizar su impacto sobre las poblaciones y proponer y valorar actuaciones de previsión e intervención. |  |  | X |  |  |  |  | X | X | X | X |
| CE9. Valorar la magnitud del tiempo geológico para analizar e interpretar la historia del planeta, así como los diferentes procesos evolutivos de los sistemas naturales |  |  |  |  | X |  |  |  |  |  |  |

| CONEXIONES ENTRE LAS COMPETENCIAS ESPECÍFICAS DE FÍSICA Y QUÍMICA Y EL RESTO DE LAS ASIGNATURAS |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Competencias específicas de Física y Química |  |  |  |  |  |  |  |  |  |  |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| CE10. Adoptar hábitos de comportamiento en la actividad cotidiana responsables con el entorno, aplicando criterios científicos y evitando o minimizando el impacto medioambiental. |  |  | X |  |  |  |  | X | X | X | X |
| CE11. Proponer soluciones realistas basadas en el conocimiento científico ante problemas de naturaleza ecosocial a nivel local y global, argumentar su idoneidad y actuar en consecuencia. |  |  | X |  |  |  |  | X | X | X | X |

3.3.
Relaciones o conexiones con las competencias clave

El cuadro adjunto muestra la existencia de una relación especialmente significativa y relevante entre
las once competencias específicas de esta materia y algunas competencias clave incluidas en el perfil de
salida del alumnado al finalizar la educación básica. En todos los casos, esta relación opera en las dos
direcciones. Por una parte, la adquisición y desarrollo de las competencias específicas señaladas contribuye
a la adquisición y desarrollo de las competencias clave con las que aparecen estrechamente vinculadas; por
otra parte, estas competencias clave juegan un papel importante en la adquisición y desarrollo de las
competencias específicas señaladas.

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 | X | X | X | X | X |  | X |  |
| CE2 | X |  | X | X | X | X | X |  |
| CE3 | X | X | X | X | X | X |  | X |
| CE4 |  |  | X |  | X | X |  |  |
| CE5 | X |  | X |  | X |  |  |  |

| CE6 | X | X | X | X |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE7 | X |  | X | X |  |  |  |  |
| CE8 |  |  | X | X | X |  |  | X |
| CE9 |  |  | X |  | X |  |  | X |
| CE10 |  |  | X |  | X |  |  | X |
| CE11 |  |  | X |  | X |  |  | X |

•
CE1: Resolver problemas científicos abordables en el ámbito escolar a partir de trabajos de
investigación de carácter experimental.

•
CE2: Analizar, y resolver situaciones problemáticas del ámbito de la Física y la Química
utilizando la lógica científica y alternando las estrategias del trabajo individual con el trabajo
en equipo.

•
CE3: Utilizar el conocimiento científico como instrumento del pensamiento crítico,
interpretando y comunicando mensajes científicos, desarrollando argumentaciones y
accediendo a fuentes fiables, para distinguir la información contrastada de los bulos y
opiniones.

•
CE4: Justificar la validez del modelo científico como producto dinámico que se va revisando
y reconstruyendo bajo la influencia del contexto social e histórico, atendiendo la importancia
de la ciencia en el avance de las sociedades, así como a los riesgos de un uso inadecuado
o interesado de los conocimientos y a sus limitaciones.

•
CE5: Utilizar modelos de Física y Química para identificar, caracterizar y analizar algunos
fenómenos naturales, así como para explicar otros fenómenos de características similares.

•
CE6: Utilizar adecuadamente el lenguaje científico propio de la Física y la Química en la
interpretación y transmisión de información.

•
CE7: Interpretar correctamente la información presentada en diferentes formatos de
representación gráfica y simbólica utilizados habitualmente en la Física y la Química.

•
CE8: Distinguir las diferentes manifestaciones de la energía e identificar sus formas de
transmisión, su conservación y disipación en contextos cercanos.

•
CE9: Identificar y caracterizar las sustancias a partir de sus propiedades físicas para
relacionar los materiales de nuestro entorno con el uso que se hace de ellos.

•
CE10: Caracterizar los cambios químicos como transformación de unas sustancias en otras
diferentes, reconociendo la importancia de las transformaciones químicas en actividades y
procesos cotidianos.

•
CE11: Identificar las interacciones como causa de las transformaciones que tienen lugar en
nuestro entorno físico para poder intervenir en el mismo, modificando las condiciones que nos
permitan una mejora en nuestras condiciones de vida.

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

•
CCL: competencia en comunicación lingüística

•
CP: competencia plurilingüe

•
CMCT: competencia matemática, ciencia y tecnológica

•
CD: competencia digital

•
CPSAA: competencia personal, social y de aprender a aprender

•
CC: competencia ciudadana

•
CE: competencia emprendedora

•
CCEC: competencia en conciencia y expresión cultural

A continuación, se exponen algunas consideraciones respecto a la relación de las competencias
específicas con las competencias clave. Siendo evidente, por la naturaleza de la materia, la relación de todas
las competencias específicas con la competencia matemática y la competencia en ciencia, tecnología e
ingeniería, no se considera necesario insistir en este punto.

Resolver problemas científicos a partir de investigaciones (CE 1), analizar situaciones problemáticas
reales utilizando la lógica científica (CE 2) y utilizar el conocimiento científico como instrumento del
pensamiento crítico (CE 3) requieren movilizar todos los conocimientos y habilidades adquiridos propios de la
ciencia, así como las herramientas digitales para buscar, tratar, procesar y comunicar la información,
estableciéndose así una relación clara con la competencia digital. La elaboración de informes en el lenguaje
de la ciencia y, con frecuencia, la consulta de información en más de una lengua, así como la comunicación
escrita u oral de los resultados obtenidos, se vincula con las competencias clave en comunicación lingüística
y plurilingüe. Estas relaciones son especialmente destacables en la medida en que estamos en una
comunidad autónoma con lengua propia. Asimismo, al proponer soluciones y comprobar el resultado de estas,
también desarrolla la competencia personal, social y de aprender a aprender. Cuando están implicadas
soluciones a problemas globales, se ha de tener en cuenta, además, multitud de factores sociales, y de
contribución al bienestar común desde el respeto a las diferencias y a la diversidad, conectando de este modo
con la competencia ciudadana. En la (CE 3), además, es claro este vínculo, habida cuenta de la importancia
de discernir la diferencia entre lo que es ciencia y lo que es solamente una opinión. Y lo mismo sucede con
la competencia ciudadana, ya que cuida de que las relaciones grupales se den de forma igualitaria e inclusiva.

Respecto a la justificación de la validez del modelo científico como producto dinámico (CE 4) se basa
en la naturaleza del sistema de trabajo propio de la ciencia. Con sus limitaciones asociadas a la dependencia
de los principios aplicados de los distintos descubrimientos que se van produciendo y el carácter dinámico
que ello le infiere, el trabajo científico constituye un buen sistema de interpretación de la realidad que facilita
la previsión de acontecimientos y, por tanto, las actuaciones que facilitan la vida a los seres humanos y
permiten prever las consecuencias de sus actos. Está conectada con la competencia ciudadana, ya que en
la comprensión de los modelos científicos se recurre al contexto social, a los hechos y a las relaciones ciencia
– sociedad que hacen que estos modelos adquieran sentido en un momento histórico dado. También suponen
plantearse problemas éticos en cuanto a los riesgos inadecuados del uso del conocimiento científico en la
sociedad. Por otro lado, su desarrollo requiere conocer y respetar el patrimonio cultural y artístico de otras
épocas que ayudan a comprender la visión historicista de la ciencia, lo que las vincula con la competencia
clave en conciencia y expresión cultural. Las competencias en el ámbito humanístico resultan así esenciales
para el desarrollo de esta competencia específica.

En lo que concierne a la utilización de modelos de Física y Química para identificar, caracterizar y
analizar algunos fenómenos naturales (CE 5), está conectada con la competencia clave en comunicación
lingüística, en la medida en que el desarrollo del conocimiento científico se relaciona con una serie de modelos
de Física y Química a partir de los que poder explicar y predecir algunos fenómenos naturales. También
implica entender las causas que los originan y su naturaleza, posibilitando la creación de nuevo conocimiento

científico a través de la interpretación de fenómenos, contribuyendo de este modo al desarrollo de las
competencias personal, social y de aprender a aprender.

Por otra parte, la competencia específica referida a la utilización adecuada del lenguaje científico
propio de la Física y la Química (CE 6), se vincula con las competencias clave en comunicación lingüística y
plurilingüe, ya que el lenguaje es fundamental en la interpretación y comunicación de la información, el trabajo
con textos expositivos y argumentativos y el manejo de terminología específica de Física y Química. La
comprensión de la Física y de la Química requiere la capacidad de leer textos y, por lo tanto, la alfabetización
está en el centro de la alfabetización científica.

En cuanto a la interpretación correcta de la información gráfica y simbólica utilizada en Física y
Química (CE 7), está conectada con la competencia clave en comunicación lingüística, en la medida en que
requieren un dominio de la competencia lingüística para exponer dicha información de manera clara y facilitar
un posterior análisis. También potencia la competencia digital, ya que requiere de la búsqueda avanzada de
información, el tratamiento adecuado de la misma, y la comunicación a través de plataformas virtuales y
herramientas informáticas.

La competencia referida a distinguir las diferentes manifestaciones de energía, (CE 8) mantiene una
estrecha relación con la competencia digital, asociada a la utilización de herramientas de búsqueda y uso de
aplicaciones que facilitan la propuesta de soluciones y su comunicación mediante las herramientas TIC más
adecuadas. Existe también una relación con la competencia personal, social y de aprender a aprender, ya
que los problemas energéticos requieren un conocimiento de los problemas asociados a las alteraciones del
medio ambiente. Otra competencia clave con la que se vincula es la ciudadana, dado el nivel de compromiso
con la sociedad que se requiere para abordar los problemas energéticos y proponer soluciones.

Finalmente, las competencias referidas a identificar y caracterizar las sustancias (CE 9), caracterizar
los cambios químicos como transformación de unas sustancias en otras (CE10) e identificar las interacciones
como causa de transformaciones (CE 11) están fuertemente relacionadas con la competencia ciudadana, ya
que son fundamentales para entender gran cantidad de procesos que tienen lugar en nuestro día a día. La
competencia digital, por su parte, está asociada a la utilización de herramientas de búsqueda y uso de
aplicaciones que facilitan la propuesta de soluciones y su comunicación mediante las herramientas TIC más
adecuadas. Asimismo, mantienen también una estrecha relación con la competencia personal, social y de
aprender a aprender, ya que aluden a muchos fenómenos que continuamente aparecen en los medios de
comunicación y provocan en el alumnado un interés creciente adquirir nuevos conocimientos.

4. Saberes básicos (para el conjunto de las competencias del área/materia)

4.1.
Introducción

Los saberes básicos se presentan organizados en bloques asociados a la interpretación de conjuntos
de fenómenos relevantes para la formación de todas las personas: la metodología de la ciencia; el mundo
material y sus cambios; la energía y su transferencia; las interacciones. Su selección responde al criterio de
que la adquisición y desarrollo de las once competencias específicas de la materia de Física y Química exige
el aprendizaje, la articulación y movilización de los mismos.

Para la secuenciación de los saberes se ha buscado que el alumnado explore y experimente ideas y
conceptos cada vez más complejos yendo desde lo macroscópico a lo microscópico, desde el universo de lo
descriptivo a lo explicativo y finalmente, a lo predictivo.  La progresión de las unidades no es lineal, sino cíclica,
de manera que permite al alumnado revisar los conocimientos existentes, relacionarlos con su nuevo
aprendizaje y ajustar sus esquemas a la luz de los nuevos descubrimientos.

4.1.1.Bloque 1: Metodología de la ciencia

Para desarrollar las competencias relacionadas con la metodología de la ciencia resulta
imprescindible adquirir unos conocimientos básicos sobre el fundamento del trabajo científico, unas destrezas

en el manejo del instrumental y en la realización de las prácticas, en el tratamiento de los datos y la
comunicación de los resultados.

Los saberes básicos que integran estas competencias están interrelacionados entre sí conformando
un bloque que no se identifica con unos contenidos curriculares concretos. Se trata de saberes que afectan
al resto de los saberes, que tienen, por tanto, un carácter transversal y que se deben tratar en cada una de
las unidades didácticas y en todos los niveles.

| Saberes básicos |  |  |  | Curso |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  | 3º |  |
|  |  |  |  | 2º |  |  |  |
|  |  |  |  |  |  | X |  |
|  | Metodología de la ciencia |  |  | X |  |  |  |
| • Contribución de las grandes científicas y científicos en el desarrollo de las ciencias Físicas y Químicas • Estrategias de utilización de herramientas digitales para la búsqueda de la información, la colaboración y la comunicación de procesos, resultados e ideas en diferentes formatos (infografía, presentación, póster, informe, gráfico...). • Lenguaje científico y vocabulario específico de la materia de estudio en la comprensión de informaciones y datos, la comunicación de las propias ideas, la discusión razonada y la argumentación sobre problemas de carácter científico. • Procedimientos experimentales en laboratorio: control de variables, toma (error en la medida) y representación de los datos (tablas y gráficos), análisis e interpretación de los mismos. • Pautas del trabajo científico en la planificación y ejecución de un proyecto de investigación en equipo: identificación de preguntas y planteamiento de problemas que puedan responderse, formulación de hipótesis, contrastación y puesta a prueba a través de la experimentación, y comunicación de resultados. • Instrumentos, herramientas y técnicas propias del laboratorio de Física y Química. Normas de seguridad en el laboratorio. Resulta imprescindible conocerlas para acceder al laboratorio con seguridad (primer ciclo) pero también reforzarlas en cada curso. |  |  |  |  |  |  |  |

Las herramientas digitales utilizadas pueden ser las mismas en los dos cursos, pero trabajadas de
forma más pautada o guiada en segundo curso y de forma más autónoma en tercero. En este curso el
alumnado puede ser más autónomo para elegir la herramienta más adecuada para comunicar sus resultados
dependiendo de la tarea desarrollada. Esto mismo sucede en el resto de los saberes de este bloque.

4.2.
Bloque 2: el mundo material y sus cambios.

El estudio de la materia, por su importancia, ocupa prácticamente la totalidad de los contenidos del
segundo curso, pero se extiende también a los otros cursos de la etapa, graduando su complejidad en función
de la madurez del alumnado, en una estructura que, como se comentó más arriba, no es lineal, sino cíclica.

El tratamiento en el segundo curso permite profundizar en aspectos que son relevantes y que
permitirán al alumnado afianzarse con seguridad en cursos posteriores. Se pone especial énfasis en los

aspectos lingüísticos, las distinciones semánticas, el uso de la terminología científica, la descripción
cuidadosa de fenómenos, la clasificación y representación, el establecimiento de correlaciones, afianzando
las estrategias que permitirán más adelante utilizar las herramientas de la metodología científica con
solvencia. Se aborda principalmente desde un punto de vista macroscópico, aunque se introduce ya la noción
de modelo, ejemplificada con el modelo cinético-corpuscular para la descripción de los estados de agregación
y la explicación de sus transformaciones a escala microscópica.

En tercer curso se introducen nuevos modelos, que permiten dar explicaciones desde el punto de
vista microscópico, a los fenómenos estudiados en el curso anterior, tanto en relación a la noción de sustancia,
como a las transformaciones físicas y químicas que estas sufren. Al mismo tiempo, se establecen las
limitaciones de estos modelos, lo cual dará pie, a lo largo del curso y también en cursos posteriores a abordar
modelos de mayor complejidad, ayudando a proporcionar una idea del modo de construcción de las ciencias
y a tener una visión de las mismas como un proceso inacabado, en continua revisión, no exento de
controversias.  En este curso se sigue insistiendo en el papel del lenguaje de la física y la química como
vertebrador del discurso científico y de adquisición de saberes.

| Saberes básicos |  |  |  | Curso |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  | 3º |  |
|  |  |  |  | 2º |  |  |  |
|  | La materia y su medida |  |  | x |  |  |  |
|  | • Magnitudes físicas. Diversidad de unidades, significados y empleo. |  |  |  |  |  |  |
|  | Necesidad de normalización: Sistema Internacional. Cambios de unidades: |  |  |  |  |  |  |
|  | masa, longitud, superficie y volumen. |  |  |  |  |  |  |
|  | • Medida de volúmenes de líquidos: probetas, pipetas y buretas. |  |  |  |  |  |  |
|  | • Volumen ocupado por sólidos regulares e irregulares. Método geométrico y |  |  |  |  |  |  |
|  | por desplazamiento de agua u otro líquido. |  |  |  |  |  |  |
|  | • Polisemia de volumen. Distinción de volumen ocupado, capacidad y |  |  |  |  |  |  |
|  | volumen de material. |  |  |  |  |  |  |
|  | • Relación entre la masa y el volumen en sólidos y líquidos. Método |  |  |  |  |  |  |
|  | experimental. Definición de densidad. Caracterización de sustancias |  |  |  |  |  |  |
|  | • Densidad de un gas en condiciones ambientales. |  |  |  |  |  |  |
|  | • Densidades de las sustancias en sus diferentes estados de agregación. |  |  |  |  |  |  |
|  | Estados de la materia. |  |  | x |  |  |  |

| • Lenguaje académico relacionado con la materia. Uso de los conceptos: inherente, propio, constante, deformable, adaptable, rigidez, viscosidad y fluido. • Concepto macroscópico de sólido y de líquido. Limitaciones y crítica razonada de las propiedades tradicionales asignadas a estos dos estados. Uso inadecuado de rigidez como propiedad específica de los sólidos y de capacidad de fluir y de adaptarse a la forma del recipiente como propiedades singulares de los líquidos. Búsqueda de definiciones alternativas que superen las limitaciones observadas. • Estado gaseoso. Propiedades. Masa, volumen y densidad. • Cambios de estado: significado del sufijo -ción en los cambios de estado. Diferencias entre ebullición y evaporación. Cambios de estado y conservación de la masa. Gráficos de calentamiento y enfriamiento. • Densidad, temperatura de fusión y temperatura de ebullición como propiedades características de las sustancias. • Modelo cinético-corpuscular: polisemia de modelo. Diferencias entre los significados en el ámbito cotidiano y el científico. Distinción entre modelo científico y el comportamiento macroscópico de la materia que pretende explicar y predecir • Modelo cinético-corpuscular para explicar los estados de la materia y sus cambios. Limitaciones del modelo. • Estudio cualitativo referido a la intensidad de las fuerzas de interacción entre partículas a partir de la comparación de los valores de temperaturas de fusión y de ebullición de diferentes sustancias. |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | Propiedades de los gases: explicación según el modelo cinético-corpuscular |  |  |  | x |  |
| • Concepto de gas en la vida cotidiana. Lenguaje académico relacionado con las sustancias en estado gaseoso: gas, expansión, compresión, difusión. • Variables macroscópicas que definen el estado de una cierta masa de gas: presión, volumen, temperatura. Descripción y relación entre ellas. • Variación de la densidad con el volumen (cambios de presión o de temperatura-escalas centígrada y Kelvin). Análisis y construcción de gráficas. • Cambios de estado: diferencia entre condensación y licuefacción. • Propiedades de los gases. Explicación según el modelo cinético- corpuscular. Diferenciación entre el modelo y la realidad que pretende explicar: idea de vacío e inadecuada asunción de propiedades macroscópicas (color, etc.) a las partículas. Predicción de la evolución de sistemas. Simulaciones. • Composición y propiedades de la atmósfera. Contaminación atmosférica. |  |  |  |  |  |  |
|  |  |  | x |  |  |  |
|  | Clasificación de la materia: mezclas y sustancias puras |  |  |  |  |  |

| • Concepto de mezcla. • Clasificación de las mezclas: homogéneas y heterogéneas. Clasificación de disoluciones: sólido en sólido; gas en líquido; líquido en líquido; sólido en líquido; gas en gas. • Polisemia de la palabra puro. Contextualización en el ámbito científico. • Caracterización de sustancias puras. Propiedades características. Identificación de sustancias puras: variación de las temperaturas de fusión y ebullición con la temperatura. Gráficas T = f(tiempo). • Métodos de separación de mezclas: fundamento de cada proceso y aplicación experimental. • Clasificación de sustancias puras: simples y compuestos. • Sustancias puras simples de especial interés: hidrógeno, nitrógeno y oxígeno. Propiedades. • Importancia de otras sustancias simples: helio, carbono, hierro, silicio y aluminio. Fuentes, obtención y aplicaciones. • Sustancias puras compuesto de especial interés: agua y amoniaco. • Aproximación al concepto de reacción química desde el punto de vista macroscópico: formación de sustancias compuesto a partir de sustancias simples y descomposición de sustancias compuesto en sustancias simples. Propiedades características. • Importancia de algunas sustancias compuesto: Ǧ El agua: propiedades singulares y aplicaciones. El agua en nuestro planeta. Agua potable y agua contaminada. Ǧ El amoniaco: breve reseña histórica como materia prima de compuestos nitrogenados. Importancia industrial. Ǧ El dióxido de carbono: importancia para los seres vivos y peligros para nuestro planeta. Ǧ La sal común: importancia histórica, obtención, usos y peligros para la salud. Ǧ La aspirina: historia de su síntesis, aplicaciones como medicamento y precauciones. • Representación submicroscópica de una mezcla y de una sustancia pura. Limitaciones del modelo de representación. • Concentración de una disolución. Aproximación inicial cualitativa al concepto de concentración. Formas para variar la concentración de una disolución. Relación masa de soluto/masa de disolución. Cálculos relacionados. • Solubilidad de sales en agua. Concepto de disolución saturada. Variación de la solubilidad con la temperatura. Interpretación de las curvas de solubilidad de distintas sustancias. Predicciones de solubilidad con la temperatura y cálculos relacionados. |  |  |  |  |
| --- | --- | --- | --- | --- |
| Clasificación de sustancias simples e importancia |  |  |  |  |
|  |  | x |  |  |

|  | • Sustancias simples conocidas desde la Antigüedad. |  |  |  |
| --- | --- | --- | --- | --- |
|  | • Técnicas de descomposición de compuestos y de análisis de sustancias |  |  |  |
|  | aparecidos en el siglo XIX. Incremento singular y significativo de nuevas |  |  |  |
|  | sustancias simples. Necesidad de establecer una clasificación para su estudio. |  |  |  |
|  | • Nuevas sustancias simples descubiertas por españoles. Contexto de |  |  |  |
|  | descubrimiento y disputas sobre prioridades y nombres. |  |  |  |
|  | • Criterios sobre el nombre de las distintas sustancias elementales: nombres de |  |  |  |
|  | cuerpos celestes, topónimos, nombres de científicos, mitología y propiedades |  |  |  |
|  | específicas. Algunos casos significativos (ejemplos: Mt, Sg, He, V, Ga, Ge, Ag, |  |  |  |
|  | Tl) |  |  |  |
|  | • Concepto de elemento químico asociado a la idea de átomo e intento de |  |  |  |
|  | caracterización mediante la masa atómica. Primer Congreso de Química en |  |  |  |
|  | Karlsruhe. |  |  |  |
|  | • Primeras clasificaciones realizadas por D. Mendeleiev. Criterio de clasificación |  |  |  |
|  | y características de las tablas realizadas: periodicidad, filas y columnas. |  |  |  |
|  | Predicciones. Limitaciones. |  |  |  |
|  | • Metales, no metales y semimetales. Propiedades y aplicaciones. Comparación |  |  |  |
|  | de los significados de metal en la vida diaria y en el contexto químico. |  |  |  |
|  | • Abundancia de elementos químicos en el universo y en la Tierra. |  |  |  |
|  | • Abundancia de elementos químicos en el cuerpo humano. Importancia |  |  |  |
|  | biológica. Calcio, hierro, sodio, potasio y yodo: alimentos que lo aportan y |  |  |  |
|  | problemas de déficit. |  |  |  |
|  | • Formas alotrópicas del carbono. Aplicaciones. |  |  |  |
|  | • Familias de elementos en la Tabla Periódica actual. |  |  |  |
|  | Reacciones químicas |  | X |  |

| • Aproximación experimental al concepto de reacción química desde el punto de vista macroscópico: procesos en los que a partir de una o más sustancias se obtienen otra u otras (con diferentes propiedades características a la(s) de partida): formación de sustancias insolubles a partir de otras solubles en agua o formación de gases (que se pueden caracterizar como el hidrógeno, el oxígeno o el dióxido de carbono), que suelen ir acompañados de cambios energéticos (variación de la temperatura, emisión de luz o producción de sonido). • Aproximación experimental a reacciones de descomposición; reacciones de precipitación; reacciones de formación. Las reacciones químicas en la vida cotidiana. • Conservación de la masa en las reacciones químicas. • Reacciones rápidas y lentas. Estudio experimental de los factores de los que depende la velocidad de una reacción química: estado físico, concentración, temperatura, catalizador. • Formación de dióxido de carbono y de vapor de agua en procesos de combustión de hidrocarburos. Caracterización de ambas sustancias. • Oxidación del hierro y de otros metales. • Descomposición de alimentos y cómo disminuir la velocidad del proceso. • Ácidos y bases en la vida diaria. Clasificación experimental de sustancias de la vida diaria: medida cualitativa del pH. Reacciones de neutralización en el laboratorio. Uso de indicadores. |  |  |
| --- | --- | --- |
| Modelo atómico de Dalton para diferenciar mezclas y sustancias puras (simples y compuestos) y explicar la reacción química. |  | x |

|  | • Clasificación de la materia. Diferencias entre mezcla y sustancia compuesto. |  |  |  |
| --- | --- | --- | --- | --- |
|  | Aplicación del modelo de partícula para diferenciar una mezcla y una sustancia |  |  |  |
|  | pura. Representación mediante el modelo de partícula. |  |  |  |
|  | • Necesidad de ampliar el modelo de partícula para diferenciar una sustancia |  |  |  |
|  | simple de una sustancia compuesto. |  |  |  |
|  | • La reacción química: concepto macroscópico de reacción química. |  |  |  |
|  | • Conservación de la masa en las reacciones químicas en las que participan |  |  |  |
|  | sustancias gaseosas. |  |  |  |
|  | • Ley de las proporciones constantes: formación de compuestos a partir de |  |  |  |
|  | sustancias simples (así como el proceso inverso de descomposición de un |  |  |  |
|  | compuesto en sustancia simples) |  |  |  |
|  | • Descubrimiento múltiple del oxígeno y la unificación conceptual de Lavoisier en |  |  |  |
|  | la explicación de distintos procesos químicos. |  |  |  |
|  | • El hidrógeno como fuente alternativa de energía. |  |  |  |
|  | • Modelo de Dalton para explicar las leyes ponderales. Conceptos de átomo y |  |  |  |
|  | elemento químico. Distinción entre sustancia simple y sustancia compuesto. |  |  |  |
|  | Concepto submicroscópico de reacción química: explicación de la ley de |  |  |  |
|  | conservación de la masa. Explicación de la ley de las proporciones constantes. |  |  |  |
|  | • Significado de fórmula química empleando símbolos químicos. Utilización de los |  |  |  |
|  | símbolos químicos para representar una reacción química como alternativa a la |  |  |  |
|  | simbología empleada por Dalton. Explicación de lo que significa una ecuación |  |  |  |
|  | química ajustada. Significado submicroscópico de las relaciones existentes |  |  |  |
|  | entre los coeficientes que acompañan a cada fórmula química. |  |  |  |

4.3.
Bloque 3:  la energía

Por su complejidad conceptual, la energía se introduce en el tercer curso, cuando se convierte en el
núcleo principal en torno al cual se estructuran los saberes. De las diversas formas de transferencia, en este
curso se tratará la transferencia en forma de calor y trabajo eléctrico, por sus aplicaciones y usos en la vida
cotidiana y por representarse en contextos cercanos al alumnado. Se pone el énfasis en la distinción entre
los usos comunes de los términos y su significado en el contexto de la física y la química. Se estudiarán
asimismo los problemas asociados a la obtención y uso de los recursos energéticos.

| Saberes básicos |  |  |  | Curso |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  | 2º |  | 3º |  |  |
|  | La energía |  |  |  |  | x |  |

|  | • La energía y su relación con el cambio |  |  |  |
| --- | --- | --- | --- | --- |
|  | • Transformaciones y conservación de la energía |  |  |  |
|  | • Modos de transferencia de la energía: transferencia de energía en forma de |  |  |  |
|  | trabajo. La corriente eléctrica: concepto de intensidad de corriente e idea |  |  |  |
|  | cualitativa de diferencia de potencial. Movimiento espontáneo de cargas. |  |  |  |
|  | Condición para que exista corriente eléctrica constante. |  |  |  |
|  | Ǧ Circuitos eléctricos y sus componentes. Ley de Ohm. Medida de la |  |  |  |
|  | resistencia de un componente del circuito. |  |  |  |
|  | Ǧ Resistencia eléctrica de materiales y aplicaciones. Variación de la |  |  |  |
|  | resistencia eléctrica con la temperatura. Superconductores. |  |  |  |
|  | Ǧ Asociación de resistencias. Medida de la intensidad y la diferencia de |  |  |  |
|  | potencial entre dos puntos de un circuito. |  |  |  |
|  | Ǧ Ley de Joule. Degradación de la energía. |  |  |  |
|  | Ǧ Potencia eléctrica. Carga de baterías. Potencia contratada en |  |  |  |
|  | viviendas y significado. |  |  |  |
|  | Ǧ Aplicación a otros fenómenos cotidianos. Significado de ‘consumo’ |  |  |  |
|  | de energía. |  |  |  |
|  | Ǧ Formas (físicas y químicas) de producción de corriente eléctrica. |  |  |  |
|  | Ǧ El problema del precio de la energía eléctrica: formas de abaratar su |  |  |  |
|  | producción. |  |  |  |
|  | Ǧ Estudio cualitativo de fenómenos electromagnéticos. |  |  |  |
|  | • Modos de transferencia de energía: transferencia en forma de calor. |  |  |  |
|  | Ǧ Diferencia de temperatura entre sistemas y equilibrio térmico. |  |  |  |
|  | Ǧ Estudio de la relación de la transferencia de calor con la variación de |  |  |  |
|  | temperatura, la masa y el tipo de sustancia. |  |  |  |
|  | Ǧ Identificación experimental del metal de que está hecha una pieza |  |  |  |
|  | metálica. |  |  |  |
|  | Ǧ Estudio de procesos exotérmicos y endotérmicos. Aplicaciones |  |  |  |
|  | Ǧ Relación de la transferencia de calor con los cambios de estado. |  |  |  |
|  | Ǧ Propagación del calor (conducción, convección y radiación). |  |  |  |
|  | Materiales aislantes y conductores. Modelo cinético. Fenómenos de |  |  |  |
|  | la vida cotidiana. Propiedades singulares del agua. |  |  |  |
|  | Ǧ Rendimiento de máquinas. Disipación de la energía. |  |  |  |
|  | • Uso racional de la energía: consumo responsable. Fuentes de energía |  |  |  |
|  | renovables y no renovables. |  |  |  |

4.4.
Bloque 4:  interacciones

El estudio de las interacciones se inicia en segundo curso, estableciendo su relación con los cambios
en la posición, la velocidad o la forma de los cuerpos. Se introduce asimismo una primera aproximación a las
interacciones eléctrica y magnética. En tercer curso se profundiza en el estudio de estas últimas y se conecta
con el bloque de la energía al introducir la interacción como causa de las transformaciones de los sistemas

que conlleva una transferencia de energía. En este nivel se propone identificar las interacciones relevantes
en situaciones estáticas para, en niveles superiores, analizar las interacciones presentes en situaciones
dinámicas. La construcción de dispositivos sencillos permite describir este tipo de interacciones, formular
preguntas y poner a prueba las respuestas.

| Saberes básicos |  |  |  | Curso |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  | 2º |  |  | 3º |  |
| Movimiento e interacciones |  |  |  |  |  |  |  |  |
|  | • Necesidad de un sistema de referencia para el estudio del movimiento. |  |  |  |  |  |  |  |
|  | Aproximación inicial cualitativa al concepto de rapidez. |  |  |  |  |  |  |  |
|  | • Rapidez instantánea y rapidez media. |  |  |  |  |  |  |  |
|  | • Interpretación y construcción de gráficos espacio-tiempo. Aplicación a casos |  |  |  |  |  |  |  |
|  | concretos con rapidez constante. |  |  |  |  |  |  |  |
|  | • Diferencia entre rapidez y velocidad: aproximación inicial a su carácter |  |  |  |  |  |  |  |
|  | vectorial a través de ejemplos. |  |  |  |  |  |  |  |
|  | • Necesidad de medir lo rápido que se cambia la velocidad. Factores de los |  |  |  |  |  |  |  |
|  | que depende y definición de la nueva magnitud. |  |  |  |  |  |  |  |
|  | • Interpretación y construcción de gráficos velocidad-tiempo en casos de |  |  |  |  |  |  |  |
|  | aceleración constante. Comparación de diferentes móviles. |  |  |  |  |  |  |  |
|  | • Estimación cualitativa del espacio recorrido de un móvil que acelera, a |  |  |  |  |  |  |  |
|  | intervalos de tiempo idénticos. Diferencias con el caso en el que la velocidad |  |  |  |  |  |  |  |
|  | es constante. |  |  |  |  |  |  |  |
|  | • La aceleración en la vida diaria: coche de fórmula 1; frenado en un semáforo; |  |  |  |  |  |  |  |
|  | distancia de seguridad entre vehículos. |  |  |  |  |  |  |  |
|  | • La caída libre. Comparación experimental del tiempo de caída de diferentes |  |  |  |  |  |  |  |
|  | móviles desde una misma altura. |  |  |  |  |  |  |  |
|  | • Las fuerzas como interacción. Ejemplos de la vida diaria. |  |  |  |  |  |  |  |
|  | • Efectos de una fuerza: deformaciones. Medida de fuerzas. |  |  |  |  |  |  |  |
|  | • Efectos de una fuerza: aceleración (intento de superación de la asociación |  |  |  |  |  |  |  |
|  | fuerza-velocidad). Relación entre la fuerza ejercida y la aceleración |  |  |  |  |  |  |  |
|  | experimentada: estudio gráfico. Significado de la pendiente de la recta. |  |  |  |  |  |  |  |
|  | • Mitigación de los efectos de una fuerza: elementos de seguridad. |  |  |  |  |  |  |  |
|  | • Introducción a las fuerzas de tipo eléctrico y magnético. |  |  |  |  |  |  |  |
| Interacción eléctrica y magnética |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  | x |  |

|  | • Concepto de interacción |  |  |  |
| --- | --- | --- | --- | --- |
|  | • Tipos de interacciones |  |  |  |
|  | • La interacción eléctrica |  |  |  |
|  | • Fenómenos electrostáticos: fenómenos de atracción/repulsión. |  |  |  |
|  | • Modelo explicativo. Cuerpos neutros: significado y explicación. Introducción |  |  |  |
|  | de la noción de carga eléctrica. Proceso de carga eléctrica (positiva y |  |  |  |
|  | negativa). Utilidad del concepto a través de la explicación de los fenómenos |  |  |  |
|  | de atracción/repulsión observados mediante esquemas/dibujos en los que se |  |  |  |
|  | indique la distribución de cargas. Descripción cualitativa utilizando un registro |  |  |  |
|  | científico adecuado. |  |  |  |
|  | • Las fuerzas como interacción entre cargas eléctricas Medida de la |  |  |  |
|  | interacción entre cargas. Ley de Coulomb. |  |  |  |
|  | • Interacción magnética. |  |  |  |

5. Situaciones de aprendizaje para el conjunto de las competencias del área/materia

Las situaciones de aprendizaje derivan de contextos vinculados con los “Principales retos del siglo
XXI” e integran todos los elementos que constituyen el proceso de enseñanza-aprendizaje competencial.  Por
tanto, las situaciones de aprendizaje tienen como finalidad la adquisición y desarrollo de las competencias
específicas necesarias para afrontar los principales desafíos del siglo XXI. Plantean tareas complejas en las
que el alumnado moviliza un conjunto de recursos y saberes para resolverlas. La capacidad de actuación del
alumnado al enfrentarse a una situación de aprendizaje requiere, en efecto, movilizar todo tipo de saberes:
conceptos, procedimientos y actitudes y valores.

En el caso de Física y Química, las situaciones de aprendizaje deben proponer un problema real o
potencial cuyas tareas impliquen las capacidades y las actuaciones referidas en las competencias específicas:
resolver problemas; razonar siguiendo la metodología científica; predecir el comportamiento de los sistemas
físicos aplicando modelos de Física y Química; manejar la simbología científica y sus representaciones;
interpretar y comunicar mensajes científicos.

Entre los criterios que conviene tener en cuenta en el diseño y desarrollo de las situaciones de
aprendizaje en esta materia, conviene tener en cuenta los siguientes:

•
Plantear una problemática que se corresponda con una situación real y compleja que sirva para
desarrollar más de una competencia.

•
Ser abiertas y poder graduarse. Es decir, deben ser suficientemente flexibles, complejas y
relevantes para controlar el grado de accesibilidad y profundización que permita su uso
adaptado a los diferentes niveles del alumnado.

•
Incitar a la reflexión y desarrollar un enfoque crítico.

•
Permitir un tratamiento interdisciplinar y conectar con otras experiencias de aprendizaje fuera de
la escuela, así como establecer conexiones con los diferentes temas de interés encaminados al
abordaje de los principales retos del siglo XXI.

•
Permitir que sean abordadas tanto de manera individual como grupal, incorporando un enfoque
inclusivo y técnicas de trabajo cooperativo o colaborativo.

•
Contemplar formatos variados: enunciados verbales con o sin ilustraciones de apoyo;
enunciados con incorporación de distintas fuentes de información; o enunciados que exigen
interpretar tablas o gráficos.

•
Movilizar en el alumnado el uso de estrategias y procesos destinados a encontrar soluciones.

•
Promover el desarrollo de las destrezas propias de la metodología científica tales como emisión
de hipótesis, recogida de datos, estrategias de representación y análisis de resultados.

•
Estimular la comprensión lectora a través de enunciados de diferente extensión y grado de
complejidad adecuadamente secuenciados.

•
Implicar la comunicación de resultados y la elaboración de informes utilizando la terminología
científica adecuada, la simbología propia de Física y Química y los sistemas de representación
apropiados.

En la evaluación se pondrá énfasis tanto en el proceso como en los resultados. Conviene recordar
que en la educación obligatoria la evaluación es una herramienta cuya finalidad no es únicamente calificar,
sino más bien facilitar una retroalimentación continua del proceso de enseñanza y aprendizaje para ajustar
los ritmos, contenidos y procedimientos utilizados.

6. Criterios de evaluación

Competencia específica 1. Criterios de evaluación

CE1. Resolver problemas científicos abordables en el ámbito escolar a partir de trabajos de
investigación de carácter experimental.

| Segundo curso | Tercer Curso |
| --- | --- |
| Analizar y resolver problemas asociados a la medida de sólidos irregulares. | Averiguar mediante diseños experimentales cómo medir la masa y el volumen ocupados por un gas desprendido en reacciones químicas. |
| Averiguar mediante diseños experimentales la influencia de factores como la temperatura o la concentración en la velocidad de las reacciones químicas. | Realizar investigaciones para averiguar las relaciones entre la presión, el volumen y la temperatura de los gases. |
| Investigar la sustancia que corresponde a un determinado sólido problema. | Investigar el metal de que está hecha una pieza-problema |
| Realizar estudios experimentales sobre distintos tipos de reacciones. | Realizar estudios experimentales de carácter cuantitativo sobre reacciones de especial interés. |
| Comprobar que se cumple la ley de conservación de la masa en experiencias de carácter práctico. | Utilizar adecuadamente aparatos de medida de la intensidad y la diferencia de potencial entre dos puntos de un circuito. |

| Realizar experiencias en las que se produzcan reacciones químicas de distintos tipos (descomposición, precipitación, síntesis, combustión, neutralización), identificando reactivos y productos por sus diferentes propiedades características, y, en el caso de las reacciones ácido- base, utilizando la escala de pH para identificar el carácter ácido o básico de las sustancias implicadas. | Realizar una investigación sobre la medida de la resistencia de un componente en un circuito. |
| --- | --- |
| Realizar experiencias sencillas de preparación de disoluciones, describiendo el procedimiento seguido y el material utilizado, determinando la concentración. | Comprobar que se cumple la ley de conservación de la masa en experiencias de carácter práctico que incluyan sustancias en estado gaseoso. |
| Resolver situaciones problemáticas relacionadas con el movimiento de los cuerpos en situaciones cotidianas. |  |

Competencia específica 2. Criterios de evaluación

CE2. Analizar y resolver situaciones problemáticas del ámbito de la Física y la Química utilizando la
lógica científica y alternando las estrategias del trabajo individual con el trabajo en equipo.

| Segundo curso | Tercer curso |
| --- | --- |
| Analizar los enunciados de las situaciones planteadas y describir la situación a la que se pretende dar respuesta, identificando las variables que intervienen. | Analizar los enunciados de las situaciones planteadas (*) y describir la situación a la que se pretende dar respuesta, identificando las variables que intervienen. |
| Elegir, al resolver un determinado problema, el tipo de estrategia más adecuada, justificando adecuadamente su elección | Elegir, al resolver un determinado problema (*), el tipo de estrategia más adecuada, justificando adecuadamente su elección |
| Buscar y seleccionar la información necesaria para la resolución de la situación en problemas suficientemente acotados | Buscar y seleccionar la información necesaria para la resolución de la situación en problemas (*) con algunos grados de apertura. |
| Expresar, utilizando el lenguaje matemático adecuado a su nivel, el procedimiento que se ha seguido en la resolución de un problema | Expresar, utilizando el lenguaje matemático adecuado a su nivel, el procedimiento que se ha seguido en la resolución de un problema (*) |
| Comprobar e interpretar las soluciones encontradas. | Comprobar e interpretar las soluciones encontradas. (*) |

| Participar en equipos de trabajo para resolver los problemas planteados asumiendo diversos roles con eficacia y responsabilidad. |  |  |  |
| --- | --- | --- | --- |
|  |  | Participar en equipos de trabajo para |  |
|  |  | resolver los problemas planteados, apoyar a |  |
|  |  | compañeros y compañeras demostrando empatía y |  |
|  |  | reconociendo sus aportaciones y utilizar el diálogo |  |
|  |  | igualitario para resolver conflictos y discrepancias. |  |

(*) La graduación del criterio de evaluación dependerá de la elección de la situación problemática,
que será más abierta y compleja en el tercer curso

Competencia específica 3. Criterios de evaluación

CE3. Utilizar el conocimiento científico como instrumento del pensamiento crítico, interpretando y
comunicando mensajes científicos, desarrollando argumentaciones y accediendo a fuentes fiables, para
distinguir la información contrastada de los bulos y opiniones.

| Segundo curso | Tercer curso |
| --- | --- |
| Buscar y seleccionar información a partir de una estrategia de filtrado y de forma contrastada en medios digitales, identificando las fuentes de las que procede. | Identificar algunas de las falacias más utilizadas en los discursos pseudocientíficos. |
| Exponer las ideas de una manera clara y ordenada, utilizando un lenguaje preciso y adecuado. | Identificar los elementos representativos de un texto científico argumentativo. |
|  | Elaborar secuencias argumentativas consistentes, coherentes y congruentes, utilizando los conectores lógicos adecuados. |

Competencia específica 4. Criterios de evaluación

CE4. Justificar la validez del modelo científico como producto dinámico que se va revisando y
reconstruyendo con influencia del contexto social e histórico, atendiendo la importancia de la ciencia en el
avance de las sociedades, a los riesgos de un uso inadecuado o interesado de los conocimientos y a sus
limitaciones.

| Segundo curso | Tercer curso |
| --- | --- |
| Aportar ejemplos de utilización del conocimiento científico y relacionarlos con las consecuencias que han tenido para el ser humano y el desarrollo de la sociedad. |  |
|  | Analizar las polémicas relativas a las leyes de combinación en la química. |
| Explicar la necesidad de sistematizar de una forma u otra la nomenclatura química y la formulación de las sustancias. | Describir las consecuencias de la introducción de nuevas técnicas en la descomposición de compuestos y análisis de |

|  | sustancias para el desarrollo de la ciencia química. |
| --- | --- |
| Explicar el papel de las instituciones científicas del siglo XIX en el desarrollo de las ciencias físico-químicas. Analizar la cantidad de mujeres presentes y explicar las causas. | Describir las implicaciones de la incorporación generalizada de la energía eléctrica a nuestra sociedad. |
| Describir las dificultades para establecer una clasificación de los elementos químicos y explicar la clasificación de Mendeleiev, su originalidad y sus limitaciones. |  |

Competencia específica 5. Criterios de evaluación

CE5. Utilizar modelos de Física y Química para identificar, caracterizar y analizar algunos fenómenos
naturales, así como para explicar otros fenómenos de características similares.

| Segundo curso | Tercer curso |
| --- | --- |
| Utilizar el modelo cinético-corpuscular para explicar los estados de la materia y sus cambios, así como la variación de la densidad en los cambios de estado. | Utilizar el modelo de energía para explicar su papel en las transformaciones que tienen lugar en nuestro entorno. |
| Utilizar el modelo del cambio químico para explicar la transformación de unas sustancias en otras de diferentes propiedades. | Utilizar el modelo de Dalton para explicar las leyes ponderales. |
| Utilizar el modelo de interacción para explicar los cambios en la velocidad de los cuerpos o sus deformaciones. | Utilizar el modelo de carga e interacción eléctrica para explicar los fenómenos de atracción/repulsión eléctricas. |

Competencia específica 6. Criterios de evaluación

CE6. Utilizar adecuadamente el lenguaje científico propio de la Física y la Química en la interpretación
y transmisión de información.

| Segundo curso | Tercer curso |
| --- | --- |

| Reconocer la terminología conceptual propia del área y utilizarla correctamente en actividades orales y escritas. | Reconocer la terminología conceptual propia del área y utilizarla correctamente en actividades orales y escritas en formatos digitales. |
| --- | --- |
| Leer textos de extensión breve en formatos diversos propios del área utilizando las estrategias de comprensión lectora para obtener información y aplicarla en la reflexión sobre el contenido. | Leer textos, tanto argumentativos como expositivos, en formatos diversos propios del área utilizando las estrategias de comprensión lectora para obtener información y aplicarla en la reflexión sobre el contenido. |
| Escribir textos descriptivos y explicativos propios del área en diversos formatos y soportes, cuidando sus aspectos formales, aplicando las normas de corrección ortográfica y gramatical, para transmitir de forma organizada sus conocimientos con un lenguaje no discriminatorio. | Escribir textos argumentativos propios del área en diversos formatos y soportes, cuidando sus aspectos formales, aplicando las normas de corrección ortográfica y gramatical, para transmitir de forma organizada sus conocimientos con un lenguaje no discriminatorio. |
| Expresar oralmente textos previamente planificados, propios del área, en exposiciones de corta duración, para transmitir de forma organizada sus conocimientos con un lenguaje no discriminatorio. | Expresar oralmente textos previamente planificados, propios del área, para transmitir de forma organizada sus conocimientos con un lenguaje no discriminatorio. |

Competencia específica 7. Criterios de evaluación

CE7.  Interpretar la información que se presenta en diferentes formatos de representación gráfica y
simbólica utilizados en la Física y la Química.

| Segundo curso | Tercer curso |
| --- | --- |
| Reconocer la importancia de normalización del sistema de unidades y utilizar adecuadamente las medidas del sistema internacional. | Elaborar e interpretar gráficos y modelos sencillos sobre las relaciones presión-volumen- temperatura de los gases. |
| Realizar cambios de unidades de masa, longitud, superficie y volumen. | Diferenciar una mezcla y una sustancia pura mediante representaciones según el modelo de partícula. |
| Construir tablas de parejas de valores masa-volumen de sustancias sólidas y líquidas. Construir los gráficos representativos. Predecir e interpretar representaciones V =f(T); P = f(V); P = f(T). | Utilizar los símbolos químicos para representar una reacción química y explicar lo que significa una ecuación química ajustada. Reconocer el significado submicroscópico de las relaciones existentes entre los coeficientes que acompañan a cada fórmula química. |

| Reconocer el significado de fórmula química empleando símbolos químicos. Distinguir entre el uso de fórmulas químicas cuando se utilizan para representar moléculas y cuando se utilizan para representar estructuras cristalinas o poliméricas. | Utilizar esquemas/dibujos en los que se indique la distribución de cargas para explicar los fenómenos de atracción/repulsión eléctricas |
| --- | --- |
| Interpretar las curvas de solubilidad de distintas sustancias. |  |
| Construir e interpretar gráficos espacio-tiempo y velocidad-tiempo en casos de aceleración constante. |  |

Competencia específica 8. Criterios de evaluación

CE8.  Distinguir las diferentes manifestaciones de la energía e identificar sus formas de transmisión,
su conservación y disipación, en contextos cercanos al alumnado.

Tercer curso

Identificar los diferentes tipos de energía puestos de manifiesto en fenómenos cotidianos
y en experiencias sencillas realizadas en el laboratorio

Identificar el calor como un proceso de transferencia de energía entre los cuerpos a
diferente temperatura y describir casos reales en los que se pone de manifiesto.

Justificar la transformación de energía en los sistemas aplicando el principio de
conservación de la energía y valorando la limitación que el fenómeno de la degradación de la
energía supone para la optimización de los procesos de obtención de energía.

Relacionar los conceptos de energía, calor y temperatura, en términos de la teoría cinético-
corpuscular y describir los mecanismos por los que se transfiere la energía térmica en diferentes
situaciones cotidianas

Razonar ventajas e inconvenientes de las diferentes fuentes energéticas. Enumerar
medidas que contribuyen al ahorro colectivo o individual de energía. Explicar por qué la energía no
puede reutilizarse sin límites.

Explicar el fenómeno físico de la corriente eléctrica e interpretar el significado de las
magnitudes intensidad de corriente, diferencia de potencial y resistencia, así como las relaciones
entre ellas.

Cuantificar la energía y analizar el consumo energético, utilizando los datos suministrados
por los electrodomésticos.

Calcular la energía necesaria para mantenerse un día completo y la dieta alimenticia
correspondiente a dicha energía a partir de tablas del gasto calórico correspondiente a diversas
actividades corporales y del valor energético de diferentes alimentos.

Reconocer la importancia y repercusiones para la sociedad y el medio ambiente de las
diferentes fuentes de energía renovables y no renovables

Competencia específica 9. Criterios de evaluación

CE9.   Identificar y caracterizar las sustancias a partir de sus propiedades físicas para relacionar los
materiales de nuestro entorno con el uso que se hace de ellos.

| Segundo curso | Tercer curso |
| --- | --- |
| Utilizar las propiedades características de las sustancias para proponer métodos de separación de mezclas, describiendo el material de laboratorio adecuado. | Diferenciar el disolvente del soluto al analizar la composición de mezclas homogéneas de especial interés. Efectuar correctamente cálculos numéricos sencillos sobre su composición. |
| Clasificar materiales por sus propiedades, relacionando las propiedades de los materiales de nuestro entorno con el uso que se hace de ellos. | Predecir la variación que experimentará la densidad de un gas al variar la temperatura (cambios de T o de P). |
| Comparar las densidades de distintas sustancias (sólidos, líquidos y gases). |  |
| Distinguir entre sistemas materiales de uso cotidiano para clasificarlos en sustancias puras y mezclas, diferenciando entre sus distintos tipos. |  |

Competencia específica 10. Criterios de evaluación

CE10.   Caracterizar los cambios químicos como transformación de unas sustancias en otras
diferentes, reconociendo la importancia de las transformaciones químicas en actividades y procesos
cotidianos.

| Segundo curso | Tercer curso |
| --- | --- |

| Reconocer situaciones de la vida cotidiana en las que se producen reacciones químicas y predecir cómo la influencia de ciertos factores puede servir para controlar estos procesos, ralentizándolos o acelerándolos para solucionar problemas que afectan a nuestra calidad de vida. | Utilizar los símbolos químicos para representar una reacción química como alternativa a la simbología empleada por Dalton. |
| --- | --- |
| Describir reacciones de interés industrial y los usos de los productos obtenidos, así como las reacciones de combustión, para justificar su importancia en la producción de energía eléctrica y otras reacciones de importancia biológica o industrial. | Explicar el significado de una ecuación química ajustada, interpretando el significado submicroscópico de las relaciones existentes entre los coeficientes que acompañan a cada fórmula química. |
|  | Aplicar las leyes de Lavoisier y de Proust en el cálculo de masas en reacciones químicas sencillas aplicadas a procesos que ocurren en la vida cotidiana. |
|  | Justificar la elaboración del modelo atómico de Dalton a partir de las leyes de las reacciones químicas. |

Competencia específica 11. Criterios de evaluación

CE11.  Identificar las interacciones como causa de las transformaciones que tienen lugar en nuestro
entorno físico para poder intervenir en el mismo, modificando las condiciones que nos permitan una mejora
en nuestras condiciones de vida.

| Segundo curso | Tercer curso |
| --- | --- |
| Reconocer las distintas fuerzas que aparecen en la naturaleza y los distintos fenómenos asociados a ellas. | Describir los tipos de cargas eléctricas, su papel en la constitución de la materia y las características de las fuerzas que se manifiestan entre ellas. |
| Relacionar las fuerzas con los efectos que producen y comprobar esta relación experimentalmente, registrando los resultados en tablas y representaciones gráficas. | Interpretar fenómenos eléctricos mediante el modelo de carga eléctrica y valorar la importancia de la electricidad en la vida cotidiana. |
|  | Justificar cualitativamente fenómenos magnéticos y valorar la contribución del magnetismo en el desarrollo tecnológico. |

|  | Comparar los distintos tipos de imanes, analizar su comportamiento y deducir mediante experiencias las características de las fuerzas magnéticas puestas de manifiesto, así como su relación con la corriente eléctrica. |
| --- | --- |

FÍSICA Y QUÍMICA

ADENDA 4º ESO

1. Saberes básicos (para el conjunto de las competencias de la materia)

1.1.
Introducción

Los saberes básicos se presentan organizados en bloques asociados a la interpretación
de conjuntos de fenómenos relevantes para la formación de todas las personas: la metodología
de la ciencia; el mundo material y sus cambios; la energía y su transferencia; las interacciones.
Su selección responde al criterio de que la adquisición y desarrollo de las once competencias
específicas de la materia de Física y Química exige el aprendizaje, la articulación y movilización
de los mismos.

Para la secuenciación de los saberes, se ha buscado tanto la conexión y la continuidad
con el curso anterior, como la previsible ampliación de saberes en etapas posteriores, tal como
se explicita en cada uno de los bloques de saberes.

1.2.
Bloque 1: Metodología de la ciencia

Los saberes básicos que integran estas competencias están interrelacionados entre sí
conformando un bloque que no se identifica con unos contenidos curriculares concretos. Se trata
de saberes vinculados al resto y que tienen, por tanto, un carácter transversal debiéndose
atender en cada una de las unidades didácticas. En este curso, aunque los saberes del bloque
coinciden con los del curso precedente, la autonomía del alumnado marcará el grado de
desarrollo competencial.

SABERES BÁSICOS

METODOLOGÍA DE LA CIENCIA

•
Formulación de preguntas, hipótesis y conjeturas científicas.

•
Colaboración y comunicación de procesos, resultados o ideas en diferentes formatos
(presentación, gráfica, vídeo, póster, informe...) seleccionando la herramienta más
adecuada.

•
Reconocimiento y utilización de fuentes veraces de información científica.

•
Diseño de pequeñas investigaciones justificando el desarrollo de las mismas en base al
método científico para obtener resultados objetivos y fiables en un experimento.

•
Utilización de herramientas, instrumentos y espacios (laboratorio, aulas, entorno...) de
forma adecuada y precisa.

•
Diferenciación entre correlación y causalidad.

•
Papel de las grandes científicas y científicos en el desarrollo de las ciencias fisico-
químicas.

•
Teorías y modelos científicos en su contexto histórico: el conocimiento científico como
un proceso en continuo cambio y perfeccionamiento.

•
Búsqueda y selección de información de carácter científico mediante herramientas
digitales y otras fuentes.

•
Interpretación de información de carácter científico y su utilización para formarse una
opinión propia, expresarse con precisión y tomar decisiones sobre problemas científicos
abordables en el ámbito escolar.

1.3.
Bloque 2: el mundo material y sus cambios.

En cuarto curso, atendiendo al carácter optativo de la materia y como puerta de entrada
a saberes más especializados, se abordan por primera vez distintos modelos sobre la estructura
del átomo, en concreto los de Thomson y Rutherford, estableciendo las limitaciones de ambos
modelos y preparando al alumnado para su superación en etapas posteriores. La exposición de
controversias científicas en el aula permite interiorizar contenidos metacientíficos y, al mismo
tiempo, fortalecer la capacidad argumentativa. Se abordan aspectos cuantitativos de las
reacciones químicas y se inicia el estudio de los compuestos del carbono, que son de especial
interés tanto por su diversidad, como por ser compuestos constitutivos de todos los seres vivos,
así como por sus múltiples usos y aplicaciones en la vida diaria: polímeros, medicamentos,
combustibles, entre otros.

SABERES BÁSICOS

MODELOS ATÓMICOS, SISTEMA PERIÓDICO Y ENLACE QUÍMICO

•
La visión continua versus la visión discontinua de la materia. Argumentaciones para
sostener cada una de las dos visiones.

•
La hipótesis atómica para explicar la diversidad de las sustancias: introducción al
concepto de elemento químico.

•
Del átomo de Dalton a los diferentes modelos atómicos:

-
Discusión del significado de modelo.

-
Modelo de Dalton. Explicación de las leyes ponderales. Concepto de elemento
químico.

•
La naturaleza eléctrica de la materia y el modelo atómico de Thomson.

-
Las experiencias de Thomson. Antecedentes. Controversia sobre la naturaleza
(onda o partícula) de los rayos catódicos. Interpretación de Thomson:
descubrimiento del electrón.

-
Limitaciones del modelo de Dalton. El modelo de Thomson.

•
El descubrimiento de la radiactividad. Experiencia de Geiger y Marsden.

-
Controversia Thomson-Rutherford: Limitaciones del modelo de Thomson. Modelo
atómico de Rutherford. Revisión del concepto de elemento químico. Predicción
existencia del neutrón. Isótopos. Cationes y aniones.

-
Limitaciones del modelo de Rutherford

•
El sistema periódico actual. Criterio de ordenación y periodicidad. Familias y electrones
de valencia. Aproximación inicial a la formación de cationes y aniones de los distintos
elementos químicos.

•
Uniones entre átomos. Criterio electrónico.

-
Explicación inicial de la formación de compuestos iónicos: principio de
electroneutralidad.

-
Formación de moléculas simples entre no metales: enlace covalente.
Estructuras de Lewis.

-
Formulación y nomenclatura de compuestos binarios iónicos y covalentes.
Nombres tradicionales y criterio IUPAC.

LA REACCIÓN QUÍMICA

•
Concepto macroscópico de reacción química. Explicación submicroscópica de un
proceso químico: modelo elemental para las reacciones química.

-
Significado del ajuste de las ecuaciones químicas. Interpretación de las
relaciones/proporciones que indica una ecuación química.

•
Reversibilidad de algunas reacciones químicas.

•
Cálculos masa-masa en las reacciones químicas.

•
Necesidad del concepto de cantidad de sustancia: su utilidad en la interpretación de
las reacciones químicas.

-
Unidad de cantidad de sustancia: mol.

-
Masa atómica, masa molecular y masa molar.

•
Estudio experimental de los cambios de energía en las reacciones químicas

-
Reacciones exotérmicas.

-
Reacciones endotérmicas.

INICIACIÓN A LA QUÍMICA DEL CARBONO

•
Primeras ideas en la explicación de la existencia de sustancias orgánicas. El carbono
como componente esencial de los seres vivos.

•
El carbono y la gran cantidad de compuestos orgánicos. Características de los
compuestos de carbono.

•
Descripción de los compuestos orgánicos más sencillos: hidrocarburos y su
importancia como recursos energéticos. Alcoholes. Ácidos orgánicos.

•
Nomenclatura y formulación de compuestos orgánicos sencillos (pocos átomos de
carbono y sólo una cadena lateral), con un solo grupo funcional. Criterio IUPAC.

•
Polímeros sintéticos.

•
Fabricación y reciclaje de materiales plásticos.

•
Macromoléculas: importancia en la constitución de los seres vivos.

•
Valoración del papel de la química en la comprensión del origen y desarrollo de la vida.

1.4.
Bloque 3:  las interacciones

El estudio de la mecánica (fuerzas y movimientos) se aborda en cuarto curso atendiendo
a la continuidad que tiene este bloque en etapas posteriores y a la complejidad de los
instrumentos matemáticos requeridos para su desarrollo. En este curso no se aborda el estudio
del movimiento con el rigor del cálculo vectorial, pero sí se introduce la noción de magnitud
vectorial y se describen sus propiedades distintivas respecto de las magnitudes escalares. Se
suman y descomponen vectores de forma gráfica, dejando para etapas posteriores su
tratamiento analítico.

SABERES BÁSICOS

EL MOVIMIENTO Y LAS FUERZAS

•
Estudio de los elementos que describen el movimiento: posición, trayectoria,
desplazamiento, espacio recorrido.

•
Relatividad del movimiento. Necesidad de establecer un sistema de referencia.

-
Representación gráfica de movimientos en una dimensión. Gráficos lineales.

-
Representación gráfica posición-tiempo.

-
Aplicación a situaciones problemáticas: representación de situaciones de
encuentro.

•
Rapidez de los cambios en la posición.

-
Definición de velocidad.

-
Investigación de la velocidad de traslación de móviles.

-
Representaciones gráficas. Construcción e interpretación de gráficos posición-
tiempo.

-
Estudio del movimiento rectilíneo uniforme.

•
Rapidez de los cambios en la velocidad: el concepto de aceleración. Movimiento
uniformemente acelerado.

-
Representaciones gráficas posición-tiempo y velocidad-tiempo aplicadas a la vida
diaria.

-
Estudio del movimiento rectilíneo uniformemente acelerado. La caída libre.

•
La fuerza como causa del cambio: relación entre la fuerza y las deformaciones.

-
Investigación de la relación entre fuerza y deformación de un muelle: ley de Hooke.

•
La fuerza como interacción.

-
Fuerzas y equilibrio. Representación de las fuerzas que actúan sobre un cuerpo.

-
Concepto de centro de gravedad. Aplicaciones.

•
Relación entre la fuerza y los cambios en el movimiento: investigación de la relación
fuerza-aceleración.

-
Principios de la dinámica

•
Tipos de fuerzas en la naturaleza: fuerzas eléctricas y magnéticas. Estudio cualitativo.

•
Tipos de fuerzas en la naturaleza: fuerza de atracción gravitatoria.

-
Síntesis de Newton. La ley de la Gravitación universal y la culminación de la
primera de las revoluciones científicas.

-
Distinción masa-peso.

-
Investigación de caída de graves. Independencia de la masa.

•
Tratamiento cualitativo de la fuerza de rozamiento.

FUERZAS EN LOS FLUIDOS

•
Concepto de fluido.

-
Fluidos compresibles e incompresibles.

•
Concepto de presión.

-
Presiones en los líquidos: principio fundamental de la hidrostática.

-
Presiones en los gases.

-
La presión atmosférica.

•
Principio de Pascal y la multiplicación de la fuerza: prensa hidráulica. Aplicaciones.

•
El principio de Arquímedes. La fuerza de empuje. Flotación de objetos en un líquido y
en el aire.

1.5.
Bloque 4:  la energía y su transferencia

En cuarto curso se abordará la transmisión de energía en forma de trabajo mecánico,
debido a su relación con los saberes de mecánica que se establecen en este curso. También se
abordará su transmisión en forma de ondas, de mayor complejidad conceptual, razón por la que
no ha sido introducida en cursos anteriores, pero fundamental para la explicación de multitud de
fenómenos que tienen lugar en nuestro entorno cotidiano (transmisión del sonido, de la luz,
movimientos sísmicos, funcionamiento del microondas, vitrocerámica, entre otros).

SABERES BÁSICOS

LA ENERGÍA Y SU TRANSFERENCIA

•
Revisión y recuerdo de los mecanismos de transmisión de energía.

•
Transferencia de energía en forma de trabajo. Potencia. El trabajo y la energía
mecánica: energía cinética y energía potencial. Conservación de la energía mecánica
en la caída libre.

•
Otros mecanismos de transmisión de energía: ondas mecánicas y radiación.

-
Producción y propiedades de ondas mecánicas. Estudio del sonido como onda
mecánica. Energía transmitida por el sonido. Velocidad de propagación del sonido.
Contaminación acústica. Aplicaciones en la vida diaria: ultrasonidos, ecografías,
sonar.

-
Estudio de la luz como ejemplo de radiación. Reflexión y refracción de la luz.
Introducción al espectro de ondas electromagnéticas. Aplicaciones en la vida
diaria: radiación ultravioleta, microondas, ondas de radio y televisión.

2. Criterios de evaluación

2.1.
Competencia específica 1. Criterios de evaluación.

CE1. Resolver problemas científicos abordables en el ámbito escolar a partir de trabajos
de investigación de carácter experimental.

•
Investigar si una sustancia es simple o compuesta a partir de las reacciones de
descomposición o síntesis a que da lugar.

•
Investigar experimentalmente el comportamiento de sustancias orgánicas.

•
Realizar en el laboratorio síntesis de polímeros.

•
Realizar diseños experimentales para el cálculo de la velocidad y la aceleración
de un móvil.

•
Realizar diseños experimentales para el estudio de la caída de graves.

•
Investigar experimentalmente procesos ondulatorios como la reflexión y
refracción de la luz.

•
Realizar investigaciones sobre el equilibrio de los cuerpos rígidos basándose en
la noción de centro de gravedad.

•
Construir dispositivos de transformación energética, como motores o pilas.

2.2.
Competencia específica 2. Criterios de evaluación

CE2. Analizar y resolver situaciones problemáticas del ámbito de la Física y la Química
utilizando la lógica científica y alternando las estrategias del trabajo individual con el trabajo en
equipo.

•
Analizar los enunciados de las situaciones planteadas y describir la situación a
la que se pretende dar respuesta, identificando las variables que intervienen, así
como su carácter escalar o vectorial.

•
Elegir, al resolver un determinado problema, el tipo de estrategia más adecuada,
justificando adecuadamente su elección.

•
Buscar y seleccionar la información necesaria para la resolución de la situación
en problemas con algunos grados de apertura.

•
Expresar, utilizando el lenguaje matemático adecuado a su nivel, el
procedimiento que se ha seguido en la resolución de un problema.

•
Comprobar e interpretar las soluciones encontradas.

•
Participar en equipos de trabajo para resolver los problemas planteados, apoyar
a compañeros y compañeras demostrando empatía y reconociendo sus
aportaciones y utilizar el diálogo igualitario para resolver conflictos y
discrepancias.

2.3.
Competencia específica 3. Criterios de evaluación.

CE3. Utilizar el conocimiento científico como instrumento del pensamiento crítico,
interpretando y comunicando mensajes científicos, desarrollando argumentaciones y accediendo
a fuentes fiables, para distinguir la información contrastada de los bulos y opiniones.

•
Aportar argumentos consistentes, coherentes y congruentes para defender una
postura ante el planteamiento de determinadas controversias científicas.

•
Aportar razones a favor y en contra de una conclusión determinada.

•
Explicitar los criterios por los que unas teorías ofrecen una mejor interpretación
que otras frente a un fenómeno determinado.

•
Utilizar estrategias de filtrado para seleccionar información en medios digitales,
identificando las fuentes de las que procede y aportando razones para descartar
las fuentes no fiables.

2.4.
Competencia específica 4. Criterios de evaluación.

CE4. Justificar la validez del modelo científico como producto dinámico que se va
revisando y reconstruyendo con influencia del contexto social e histórico, atendiendo la
importancia de la ciencia en el avance de las sociedades, a los riesgos de un uso inadecuado o
interesado de los conocimientos y a sus limitaciones.

•
Describir las causas por las que se produce en el s. XX un momento propicio
para el desarrollo de los modelos atómicos.

•
Describir el desarrollo e importancia de las sociedades científicas y su
reconocimiento social.

•
Describir el papel de los y las científicas en los conflictos bélicos, estableciendo
cómo afectan estos al desarrollo de la ciencia y discutiendo posturas éticas.

2.5.
Competencia específica 5. Criterios de evaluación

CE5. Utilizar modelos de Física y Química para identificar, caracterizar y analizar algunos
fenómenos naturales, así como para explicar otros fenómenos de características similares.

•
Utilizar el modelo atómico de Thomson para explicar los fenómenos de
electrización y la formación de iones.

•
Utilizar el modelo atómico de Rutherford para explicar la existencia de isótopos
y algunos fenómenos radiactivos.

•
Utilizar el modelo de interacción física para explicar las fuerzas y los cambios en
el movimiento.

•
Utilizar el modelo de energía para explicar algunos fenómenos ondulatorios.

2.6.
Competencia específica 6. Criterios de evaluación

CE6. Utilizar adecuadamente el lenguaje científico propio de la Física y la Química en la
interpretación y transmisión de información.

•
Reconocer la terminología conceptual propia del área y utilizarla correctamente
en actividades orales y escritas.

•
Leer textos, tanto argumentativos como expositivos, en formatos diversos
propios del área utilizando las estrategias de comprensión lectora para obtener
información y aplicarla en la reflexión sobre el contenido.

•
Escribir textos argumentativos propios del área en diversos formatos y soportes,
cuidando sus aspectos formales, aplicando las normas de corrección ortográfica
y gramatical, para transmitir de forma organizada sus conocimientos con un
lenguaje no discriminatorio.

2.7.
Competencia específica 7. Criterios de evaluación.

CE7.  Interpretar la información que se presenta en diferentes formatos de
representación gráfica y simbólica utilizados en la Física y la Química.

•
Representar gráficamente las fuerzas que actúan sobre un cuerpo en una
dimensión.

•
Relacionar las magnitudes de velocidad, aceleración y fuerza con una expresión
matemática y aplicar correctamente las principales ecuaciones.

•
Distinguir claramente entre las unidades de velocidad y aceleración, así como
entre magnitudes lineales y angulares.

•
Utilizar un sistema de referencia para representar los elementos del movimiento
mediante vectores, justificando la relatividad del movimiento y clasificando los
movimientos por sus características.

•
Emplear las representaciones gráficas de posición y velocidad en función del
tiempo para deducir la velocidad media e instantánea y justificar si un
movimiento es acelerado o no.

•
Emplear las representaciones gráficas de espacio y velocidad en función del
tiempo para deducir la velocidad media e instantánea y justificar si un
movimiento es acelerado o no.

•
Representar mediante ecuaciones las transformaciones de la materia de manera
consistente con el principio de conservación de la materia.

•
Escribir fórmulas sencillas de los compuestos de carbono.

2.8.
Competencia específica 8. Criterios de evaluación.

CE8.  Distinguir las diferentes manifestaciones de la energía e identificar sus formas de
transmisión, su conservación y disipación, en contextos cercanos al alumnado.

•
Diferenciar entre trabajo mecánico y trabajo fisiológico. Explicar que el trabajo
consiste en la transmisión de energía de un cuerpo a otro mediante una fuerza
que desplaza su punto de aplicación.

•
Identificar la potencia con la rapidez con que se realiza un trabajo y explicar la
importancia de esta magnitud en la industria y la tecnología.

•
Relacionar la variación de energía mecánica que ha tenido lugar en un proceso
con el trabajo con que se ha realizado. Aplicar de forma correcta el principio de
conservación de la energía en el ámbito de la mecánica.

•
Explicar las características fundamentales de los movimientos ondulatorios.
Identificar hechos reales en los que se manifieste un movimiento ondulatorio.

•
Relacionar la formación de una onda con la propagación de la perturbación que
la origina.

•
Indicar las características que deben tener los sonidos para ser audibles.
Describir la naturaleza de la emisión sonora.

2.9.
Competencia específica 9. Criterios de evaluación.

CE9.   Identificar y caracterizar las sustancias a partir de sus propiedades físicas para
relacionar los materiales de nuestro entorno con el uso que se hace de ellos.

•
Identificar hidrocarburos sencillos y representarlos mediante su fórmula
molecular, describiendo sus aplicaciones, y reconocer los grupos funcionales
presentes en moléculas de especial interés.

•
Justificar la gran cantidad de compuestos orgánicos existentes, así como la
formación de macromoléculas y su importancia en los seres vivos.

•
Describir algunas de las principales sustancias químicas aplicadas en diversos
ámbitos de la sociedad: agrícola, alimentario, construcción e industrial.

•
Explicar las características básicas de compuestos químicos de interés social:
petróleo y derivados, y fármacos. Explicar los peligros del uso inadecuado de los
medicamentos

•
Explicar las características básicas de los procesos radiactivos, su peligrosidad
y sus aplicaciones.

2.10. Competencia específica 10. Criterios de evaluación.

CE10.   Caracterizar los cambios químicos como transformación de unas sustancias en
otras diferentes, reconociendo la importancia de las transformaciones químicas en actividades y
procesos cotidianos.

•
Explicar los procesos de oxidación y combustión, y analizar su incidencia en el
medio ambiente.

•
Explicar las características de los ácidos y de las bases y realizar experiencias
de neutralización.

•
Utilizar la noción de cantidad de sustancia para realizar cálculos en reacciones
químicas.

2.11. Competencia específica 11. Criterios de evaluación.

CE11.  Identificar las interacciones como causa de las transformaciones que tienen lugar
en nuestro entorno físico para poder intervenir en el mismo, modificando las condiciones que nos
permitan una mejora en nuestras condiciones de vida.

•
Utilizar las nociones básicas de la estática de fluidos para describir sus
aplicaciones.

•
Explicar cómo actúan los fluidos sobre los cuerpos que flotan o están sumergidos
en ellos aplicando el Principio de Arquímedes.

•
Identificar las fuerzas que actúan sobre un cuerpo, generen o no aceleraciones.

•
Describir los principios de la Dinámica y aportar a partir de ellas una explicación
científica a los movimientos cotidianos. Determinar la importancia de la fuerza
de rozamiento en la vida real.

•
Identificar las fuerzas implicadas en fenómenos cotidianos señalando las
interacciones del cuerpo en relación con otros cuerpos.

•
Identificar el carácter universal de la fuerza de la gravitación y vincularlo a una
visión del mundo sujeto a leyes que se expresan en forma matemática.
