# FILOSOFÍA

> Fuente: Secundaria.pdf, páginas 1112-1124 (versión en castellano).

FILOSOFÍA

1. Presentación

La materia de filosofía promueve en el alumnado su capacidad de pensar, comprender,
reflexionar y argumentar poniendo a su alcance las herramientas necesarias tanto teóricas como
prácticas. Además, el análisis filosófico va más allá del campo concreto de estudio del resto de
materias planteando una reflexión global sobre qué es el ser humano, el conocimiento, la
conducta adecuada y la vida social y política y despliega, de ese modo, su capacidad de
transformación y cambio tanto individual como social.

Esta materia, acerca al alumnado a los temas de la filosofía que le son más próximos, al
uso de los conceptos específicos de la misma y a las teorías que han dado diferentes respuestas.
Además de esto, promueve la reflexión sobre los contenidos que plantea no sólo desde una
perspectiva teórica sino también desde su propia experiencia. La filosofía permite al alumnado
analizar de forma crítica la tradición y sus ideas preconcebidas sobre la realidad y, en
consecuencia, liberarse de prejuicios e ideas dominantes mayoritariamente aceptadas.

La mejora de los procesos de pensamiento y la adquisición de una mirada crítica que
permita analizar la realidad y actuar de forma responsable y comprometida son dos de los
objetivos fundamentales de la filosofía, en particular, y de la educación, en general. Estos
objetivos requieren la adquisición de otras destrezas necesarias para su consecución. Aprender
a pensar pasa por utilizar de forma precisa los conceptos y los argumentos. Esa capacidad
discursiva de enfrentarse mentalmente a un problema para entenderlo en profundidad y llegar a
soluciones es una habilidad que se aprende y que supone la capacidad de identificar premisas,
hacer inferencias correctas a partir de las mismas, aportar razones consistentes y argumentos
bien fundados, entre otras. Pensar de forma crítica es clave para enfrentarse a los complejos
desafíos que el mundo actual plantea y para construir un proyecto de vida personal, académico
y profesional satisfactorio.

El ejercicio de estas capacidades a través del planteamiento de los desafíos que los
Objetivos de Desarrollo Sostenible recogen contribuye a educar una ciudadanía empoderada y
libre que pueda tomar decisiones razonadas y justas y que se comprometa con la mejora de la
sociedad y la defensa del bien común. El trabajo de los desafíos a partir de problemas actuales
y desde un planteamiento práctico y empírico, permite el desarrollo de las habilidades cognitivas
y discursivas necesarias para el análisis crítico y supone acercarse a la experiencia del trabajo
filosófico.

La otra cara de este planteamiento implica la capacidad de defender el propio punto de
vista y de plantear objeciones y alternativas que la sociedad supone a toda persona adulta. Al
igual que sucede con el razonamiento, la capacidad de defender de forma oral o escrita una
postura determinada también se aprende. El diálogo ha sido, a lo largo de la historia, la
herramienta fundamental del ejercicio político en la democracia. Sin embargo, la lógica del
discurso se aprende en los conflictos más cercanos, investigando causas, analizando
argumentos, aprendiendo formas de inferencia correctas, desentrañando trampas del discurso,
identificando falacias y aportando razones consistentes. El entorno escolar, a través de los
conflictos de la convivencia diaria, el de las amistades y el familiar, así como la publicidad, las
noticias o los espacios virtuales, se presentan como marcos privilegiados para iniciar la reflexión
que lleve al análisis de los problemas globales que nos llevan a los desafíos para el siglo XXI.

El aprendizaje de la oralidad del discurso plantea, además otros beneficios en la medida
en que el alumnado se encontrará a lo largo de la vida en situaciones para las que la
comunicación oral supone una herramienta fundamental: para llegar a acuerdos en el trabajo en
equipo, para justificar decisiones o acciones, para gestionar emociones y conflictos, para
enfrentarse con garantías a entrevistas de trabajo, entre otras.

Sin embargo, el conocimiento y manejo de las estrategias discursivas no justifica la
defensa de cualquier postura frente a un dilema o conflicto de valores. La competencia
comunicativa no puede separarse de la responsabilidad moral del uso de los argumentos y las
consecuencias que estos generan. No se trata de educar oradoras y oradores brillantes, sino
personas morales, conectadas con su tiempo, vinculadas con las necesidades de su entorno y
capaces de argumentar y defender su planteamiento frente a manipulaciones o injerencias. Esa
exigencia de compromiso y responsabilidad plantea, a su vez, la necesidad de diferenciar entre
aquello que es verdadero y lo que se presenta como verosímil.

Cabe destacar que se trata de una materia con un carácter eminentemente práctico que
tiene que convertir la clase en un laboratorio de ideas y de discusiones vivo y activo. Se trata de
plantear problemas reales o situaciones problemáticas que guían la investigación y el debate. El
alumnado aprende a desarrollar estrategias de razonamiento, adquirir conocimiento de la materia
en situaciones reales y a desarrollar habilidades cognitivas, como el análisis, la argumentación o
la resolución de problemas y habilidades de carácter interpersonal y social, como la
comunicación y la cooperación.  Desde esa perspectiva se han seleccionado los saberes básicos
necesarios para desarrollar las competencias.

Los saberes que se proponen como básicos en la presente materia recogen, de manera
genérica, alguna de las grandes preguntas de las que se ocupa la Filosofía, e incluyen, también,
los planteamientos de los desafíos para el siglo XXI que se desprenden de los Objetivos de
Desarrollo Sostenible pero planteados en forma de dilema. La intención es mostrar que en la
reflexión y debate de esos problemas se ha de adoptar una postura moral y tomar partido
implicándose en la mejora global porque lo contrario supone la desaparición, en ocasiones
definitiva, de algunas de las características que configuran nuestra humanidad o la mera
posibilidad de existir.

Esta materia guarda una estrecha relación con la materia de Educación en Valores
Cívicos y Éticos. Ambas persiguen el ejercicio activo y responsable de la ciudadanía a través del
desarrollo de la autonomía moral y la personalidad del alumnado. A su vez, las dos materias
inciden en la necesidad de analizar de forma crítica los problemas que la realidad plantea y
adoptar una posición fundamentada respecto de los mismos.

Por último, es importante señalar que la estrecha relación que guardan todos los desafíos
marca la imposibilidad de afrontarlos únicamente de manera individual. La tarea del desarrollo
sostenible es una tarea que concierne a la humanidad y que trasciende el espacio individual tanto
en la reflexión como en las soluciones que puedan aportarse. De la comprensión de la realidad
y sus condicionamientos se desprenden implicaciones morales que resultan ya por completo
insoslayables. De este modo, las preocupaciones individuales características de la adolescencia
se conectan de manera inevitable con las globales y aquello que promueve una mejora individual
tiene, también, consecuencias en el bien común a través del compromiso social y la participación
democrática.

2. Competencias específicas

2.1. Competencia específica 1

Analizar problemas cotidianos desde una perspectiva filosófica y con una mirada crítica,

constructiva y éticamente comprometida.

2.1.1. Descripción de la competencia 1

El alumnado de esta etapa es ya plenamente consciente de las dificultades y conflictos
que la convivencia plantea a todos los niveles. Muchos de los problemas más habituales de su
día a día están relacionados de forma directa con los desafíos que plantean los Objetivos de
Desarrollo Sostenible. En un momento en que el alumnado está empezando a definir su proyecto
de vida, personal, social y profesional, la complejidad de los problemas a los que se enfrenta
resulta cada vez mayor. Sin embargo, el tránsito que vive de la infancia a la edad adulta, le dota
de una disposición privilegiada para poner en cuestión y revisar todo aquello que se presenta
como problemático.

Esta materia pone al alcance del alumnado las herramientas que le permiten analizar en
profundidad todas esas inquietudes características a las que se enfrenta a la hora de definir y
ubicar su lugar en el mundo: el sentido de existir; el contenido de la vida; la incertidumbre del
futuro; la definición de la propia identidad; la consistencia de las relaciones; la sexualidad; entre
otros. Todas estas preocupaciones se presentan en forma de dilemas o conflictos de valores que
cuestionan el fundamento de lo que siempre se ha asumido como normalidad y de las decisiones
que se tomen a partir de entonces. Un abordaje filosófico de dichas cuestiones permite una
reflexión pausada, clave para el desarrollo de una mirada crítica y constructiva. La reflexión
filosófica sobre los problemas que le conciernen muestra, además, la necesidad insoslayable de
tomar partido desde una perspectiva moral para poder aportar soluciones creativas y
comprometerse con ideas y proyectos transformadores de la realidad. Ninguno de los desafíos
relacionados con las inquietudes propias del alumnado se puede enfrentar únicamente de
manera individual. Todos ellos implican una estrecha relación entre el desarrollo personal y el
bien común.

El trabajo sobre las propias preocupaciones, el análisis filosófico de las mismas y la
comprensión de su íntima interrelación facilita que el alumnado construya una visión del mundo
propia, no arbitraria, crítica y creativa y favorece que se relacione con el mundo de una manera
ética.

2.2. Competencia específica 2

Identificar y diferenciar las premisas, estrategias argumentativas y conclusiones de
textos o discursos, distinguiendo los usos correctos de las argumentaciones falaces.

2.2.1. Descripción de la competencia 2

Para poder tener una mirada crítica, es requisito que la información con la que se trabaja
sea contrastada y fiable. Es necesario, también, distinguir de forma clara el conocimiento de las
creencias o las meras opiniones para poder evitar juicios precipitados, incorrectos, ambiguos o
faltos de fundamento.

La vida cotidiana está llena de informaciones que giran alrededor de los problemas
vinculados a los desafíos para el siglo XXI. Esa información llega por todo tipo de canales y en
diferentes formatos y se presenta como un producto de consumo más. Poder identificar y
descubrir los mecanismos y técnicas que se emplean para elaborar la información que se
muestra es fundamental para garantizar el acceso a un conocimiento seguro del mundo en el
que se vive.

En primer lugar, el alumnado ha de adquirir el conocimiento necesario para diferenciar
entre premisas, argumentos y conclusiones; ha de conocer diferentes tipos de argumentos, así
como distinguir entre aquellos que son correctos y los que son falaces y nos conducen a engaño.

Todas estas destrezas favorecen que el alumnado tome conciencia de las implicaciones de lo
que se dice, lo que se lee y lo que se escucha.

Detectar, explicar y desactivar las falacias evaluando argumentos y analizando
inferencias de textos, discursos, noticias, posts o cualquier otro canal por el que llegue la
información, prepara para construir discursos propios consistentes. Es también la forma de
distinguir entre aquello que es verdadero y lo que es verosímil y permite poner en evidencia las
técnicas y los peligros de las noticias o discursos falsos que persiguen la desinformación.

2.3. Competencia específica 3

Explicar las diferencias entre elementos racionales y emocionales en la justificación de
decisiones a propósito de conflictos de valores.

2.3.1. Descripción de la competencia 3

Los dilemas y conflictos objeto de reflexión en esta materia, no se caracterizan
únicamente por su faceta teórica sino, sobre todo, por su vertiente práctica y su profunda
vinculación con la vida cotidiana y las preocupaciones más íntimas del alumnado. Existen
motivos que matizan o condicionan la reflexión vinculados a las emociones y no a la mera razón
teórica. Por ello, es importante poder construir una argumentación racional sobre los conflictos;
sus características; sus implicaciones sociales y políticas; los diferentes puntos de vista desde
los que analizarlos o las diferentes alternativas que se pueden aportar como vías de compromiso
y mejora, pero también una explicación de los elementos emocionales que condicionan la
reflexión y la decisión. Destacar la importancia de los argumentos que se construyen desde las
emociones adquiere especial relevancia cuando los problemas tratados, y el aprendizaje que se
desprende de ellos, ha de conducir a la acción transformadora. Vincular el aprendizaje a la acción
y al sentido y dirección de la propia existencia es la forma de dar valor al conocimiento.

El reconocimiento de las propias emociones es esencial para el desarrollo y crecimiento
personal y para la identificación y comprensión de las emociones ajenas, así como para su
gestión en la vida cotidiana y, especialmente, en situaciones de conflicto inherentes a todos los
ámbitos de las relaciones humanas. Además, desde la reflexión que se produce al afrontar los
desafíos para el siglo XXI que los Objetivos de Desarrollo Sostenible plantean, el reconocimiento
de las emociones adquiere una dimensión social en la medida en que influye en la toma de
decisiones y la asunción de compromisos por el bien común.

Incluir las emociones como parte del argumentario alrededor de los conflictos de valores,
permite acceder a aspectos que la razón teórica no alcanza ni explica. Además, promueve la
aceptación de la incertidumbre que supone la vida social y prepara para la gestión de la misma.
Es por ello que se plantea como fundamental la capacidad para distinguir ambos elementos y
tratarlos con igual profundidad en el análisis de los dilemas.

2.4. Competencia específica 4

Elaborar y exponer de una manera clara, ordenada y argumentada ideas y propuestas
filosóficas prácticas que fomenten el crecimiento personal y el compromiso social.

2.4.1. Descripción de la competencia 4

La elaboración por parte del alumnado de producciones textuales, orales o multimodales
a partir de sus conclusiones es igual de importante que saber desentrañar la estructura
argumentativa de los materiales a partir de los que el alumnado elabora sus reflexiones y su
aproximación a la realidad.

El objetivo último del análisis de la realidad es el desarrollo de un punto de vista personal
y crítico fundado en razones que el alumnado pueda justificar y argumentar. La elaboración de
producciones en las que concreta sus reflexiones y conclusiones supone el paso del análisis a
la comprensión e interiorización profunda de los problemas. Estas han de ajustarse a la lógica
del discurso: correctamente argumentadas, bien fundamentadas, alejadas de falacias y
correctamente expuestas y defendidas. Para ello, el alumnado ha de basar sus razonamientos
en premisas bien fundadas, desarrollarlas a través de inferencias correctas evitando
razonamientos engañosos o sesgados y ajustándose a la verdad de los hechos. No se trata, en
cualquier caso, de una mera reformulación o repetición de lo trabajado, sino de la explicación y
la justificación de su propio punto de vista y de la posición moral desde la que se aborda el
análisis y la propuesta de actuación. Cualquier pensamiento que no se traduzca en una
propuesta práctica que impregne la vida cotidiana del alumnado no habrá cumplido con su
función transformadora.

Por otro lado, esa función transformadora del pensamiento no puede circunscribirse a la
esfera individual o la mejora personal. Todos los desafíos para el siglo XXI interpelan a las
personas de manera individual, pero la comprometen en respuestas y trabajos colectivos. Una
respuesta individual a dichos retos revela una comprensión insuficiente de su magnitud y su
relevancia. El fomento del crecimiento personal no puede estar desvinculado del compromiso
social, la participación democrática activa y la promoción y defensa del bien común.

3. Conexiones de las competencias específicas entre sí, con las competencias de otras
materias y con las competencias clave

3.1. Relaciones o conexiones con las otras CE del área

Las cuatro competencias específicas de la materia guardan una estrecha relación entre
sí puesto que todas ellas conforman los elementos mínimos necesarios para el trabajo filosófico
que el alumnado puede desarrollar. Partiendo de la identificación de los problemas y conflictos
de valores susceptibles de ser sometidos a análisis filosófico (CE1); se pasa por la comprensión
de cuál es la estructura interna de los mismos y el desmontaje de las argumentaciones falaces
que puedan llevar a engaño (CE2); se sigue por la identificación de la diversidad de motivos que
pueden llevar a una decisión u otra; y se concluye con la elaboración de algún documento,
discurso, o similar, que exponga la postura adquirida y justifique su decisión (CE4).

3.2. Relaciones o conexiones con las CE de otras materias de la etapa

Las lenguas, vehículos para la comprensión y expresión de emociones, hechos,
conceptos y pensamientos, materia primera de producciones textuales escritas, orales y
multimodales que informan y sirven de punto de partida para el abordaje de los saberes
esenciales, vías de acceso al conocimiento de otras realidades lingüísticas, sociales y culturales
y herramientas para la planificación de acciones transformadoras, ponen sus prácticas
comunicativas al servicio de la construcción de la conciencia ética individual y del compromiso
social (CE1-CE4 de la materia de Filosofía).

La materia de Filosofía comparte con la de Geografía e Historia cuestiones axiológicas
fundamentales y el interés por las cuestiones éticas más relevantes del mundo actual. En
concreto, las competencias CE4, CE5, CE6, CE7 y CE8 de Geografía e Historia con CE1, CE2,
CE3 y CE4 de Filosofía en la medida en que se refieren al análisis crítico de las normas; a la
diferencia entre legalidad y legitimidad; al análisis de hechos históricos y de la actividad
económica;  al reconocimiento, denuncia y combate de los estereotipos y roles sociales que
permite un saber y una práctica igualitarios e inclusivos; a  la construcción de una ciudadanía

global; al compromiso con los valores democráticos y con la lucha para conseguir justicia social
y a la importancia de los desafíos que plantean los Objetivos de Desarrollo Sostenible.

También se dan estas coincidencias, desde el análisis del origen y la génesis de nuestra
concepción actual del mundo, con las competencias CE1, CE2 y CE5 de la materia de Cultura
Clásica.

Con respecto a Educación Plástica y Visual, las CE1, CE2, CE3, CE4 y CE5 guardan
relación con las competencias CE1, CE2, CE3 y CE4 de Filosofía, puesto que se refieren a la
capacidad de hacer un análisis crítico de la realidad y proponer soluciones creativas; a compartir
y defender ideas diversas de forma asertiva y a trabajar las emociones y construir una identidad
propia de forma consciente y crítica. Estas mismas relaciones se pueden establecer con las
competencias CE1, CE4 y CE5 de la materia de Música.

Coinciden Biología y Filosofía en los planteamientos referidos a la valoración crítica de
la información; la promoción de hábitos saludables; el respeto por diferentes formas de vida y
diversas identidades de género; el fomento de la responsabilidad y el análisis crítico del efecto
de la acción humana y la propuesta de soluciones ecosociales. En concreto las competencias
CE3, CE5, CE6, CE7, CE10 y CE11 de Biología con CE1 y CE4 de Filosofía.

La relación con las competencias CE3 y CE4 de Física con CE1 y CE4 de Filosofía se
circunscribe a la defensa del pensamiento crítico y del uso preciso de los conceptos y los
argumentos.

Por último, coinciden en la necesidad de analizar las repercusiones sociales de la acción
humana y plantearse la sostenibilidad, así como en la necesidad de que el alumnado sea capaz
de proponer acciones responsables, justas y comprometidas frente a los desafíos del mundo
actual las competencias CE4 y CE7 de Tecnología y Digitalización con CE1 y CE4 de Filosofía.

3.3. Relaciones o conexiones con las competencias clave

El cuadro adjunto muestra la existencia de una relación especialmente significativa y
relevante entre las siete competencias específicas de esta materia y algunas competencias clave
incluidas en el perfil de salida del alumnado al finalizar la educación básica.

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 |  |  |  | X | X | X |  |  |
| CE2 | X |  |  | X |  | X |  |  |
| CE3 |  |  |  |  | X | X |  | X |
| C·4 | X |  |  | X | X | X |  |  |

Competencias específicas del área:

•
CE1:   Analizar problemas cotidianos desde una perspectiva filosófica y con una
mirada crítica, constructiva y éticamente comprometida.

•
CE2: Identificar y diferenciar las premisas, estrategias argumentativas y
conclusiones de textos o discursos, distinguiendo los usos correctos de las argumentaciones
falaces.

•
CE3: Explicar las diferencias entre elementos racionales y emocionales en la
justificación de decisiones a propósito de conflictos de valores.

•
CE4: Elaborar y exponer de una manera clara, ordenada y argumentada ideas y
propuestas filosóficas prácticas que fomenten el crecimiento personal y el compromiso social.

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

•
CCL: competencia en comunicación lingüística

•
CP: competencia plurilingüe

•
CMCT: competencia matemática, ciencia y tecnológica

•
CD: competencia digital

•
CPSAA: competencia personal, social y de aprender a aprender

•
CC: competencia ciudadana

•
CE: competencia emprendedora

•
CCEC: competencia en conciencia y expresión cultural

En primer lugar, la CE1, está relacionada con la CD en la medida en que el alumnado
tiene la oportunidad de afrontar los conflictos de acuerdo con los principios de un marco ético
digital.  Está conectada, también, con la CPSAA dado que el trabajo con conflictos de valores
implica el reconocimiento de las demás personas desde la horizontalidad y el cuidado mutuo, la
comunicación no violenta y la capacidad de cooperar, permite el establecimiento de relaciones
que propician la regulación y expresión de las emociones desde la autoeficacia y la resiliencia

En segundo lugar, la CE2 se relaciona con la CCL a través de la necesidad de detectar
y rechazar usos sesgados y falaces de los argumentos y promover un uso legítimo de la palabra.
También se relaciona con la CD puesto que para el análisis de los documentos, textos o
producciones diversas debe acceder a informaciones de diversas fuentes, comprender e
interpretar de forma crítica esas producciones para construir conocimiento, y contrastar la
información para evaluar su fiabilidad y poder comunicarla de manera veraz y crítica.

En tercer lugar, la CE3 está conectada con la CPSAA dado que el análisis de los
elementos que intervienen en las decisiones y la comprensión del papel de lo emocional en las
mismas, propician la regulación y expresión de las emociones desde la autoeficacia y la
resiliencia. Por otra parte, la libre expresión de ideas, opiniones, sentimientos y emociones de
manera creativa la asocia con la CCEC.

Por último, la CE4 se relaciona con la CCL dado que se trata de que el alumnado sea
capaz de comprender y exponer de manera clara, argumentada y razonada las propias ideas.
Además, se relaciona con la CPSAA, puesto que está muy conectada con la capacidad de
entender las experiencias, emociones e ideas ajenas, incorporarlas al propio aprendizaje y
comprometerse con la mejora social. Asimismo, con la CD, ya que para la preparación y defensa
de la argumentación también es importante analizar informaciones de diversas fuentes,
comprender e interpretar de forma crítica textos para construir conocimiento, y contrastar la
información para evaluar su fiabilidad y poder comunicarla de manera veraz y crítica.

Cabe destacar que todas las competencias de la materia están directamente vinculadas
con la CC puesto que el objetivo último es el de preparar una ciudadanía crítica, reflexiva,
consciente y capaz de dar razón de los motivos de sus acciones.

4. Saberes básicos

4.1. Introducción

Los saberes que se proponen como básicos en la presente materia recogen, de manera
genérica, alguna de las grandes preguntas de las que se ocupa la filosofía, incluyen, también,
los planteamientos de los desafíos para el siglo XXI que se desprenden de los Objetivos de
Desarrollo Sostenible, pero planteados en forma de dilema. Estos desafíos se refieren a muchas
de las preocupaciones que en la adolescencia empiezan a plantearse y que son, además,
preguntas filosóficas. Las preguntas alrededor del sentido de la existencia y del lugar que se
ocupa en el mundo son las que subyacen y alrededor de las que pivotan el resto de inquietudes.

Afrontar y profundizar en todo aquello que los desafíos plantean requiere una actitud
abierta y crítica además de un trabajo colaborativo. La inquietud que supone la búsqueda del
bienestar personal no está separada, en este caso, de la búsqueda del bien común puesto que
ninguno de los retos que nos plantean los Objetivos de Desarrollo Sostenible pueden abordarse
únicamente de manera individual. Es por ello que el alumnado ha de ir más allá de su propia
preocupación individual y adquirir un compromiso global. Un trabajo así exige del alumnado una
reflexión amplia y sistémica, la capacidad de empatizar con situaciones de injusticia y dificultades
que aparentemente no le conciernen y la aceptación de un alto grado de incertidumbre.

La reflexión y la mirada empática implica que la respuesta a los desafíos pasa por el
compromiso y éste, a su vez, exige adquirir una posición moral clara frente a las situaciones de
injusticia y exclusión. La discusión filosófica, la reflexión y el conocimiento adquieren un papel
relevante si se traducen en acción. Todos los desafíos guardan una estrecha relación entre sí,
con lo cual la reflexión y la consecuente acción que supone no puede darse de forma aislada o
parcelada, sino de forma interrelacionada. Esta dimensión práctica muestra al alumnado el valor
del conocimiento y su función como palanca de cambio y transformación social.

Así, los saberes se presentan, en primer lugar, como preguntas que orientan la reflexión
filosófica y que recogen las grandes preocupaciones del ser humano y, por otra, en forma de
dilema o conflicto entre dos polos para incidir en cuatro ideas fundamentales. En primer lugar,
que la reflexión que los desafíos plantean sobre lo que pasa en nuestro entorno nos interpela y
nos afecta; en segundo, que es necesaria la adopción de una postura moral producto de esa
reflexión, puesto que nadie escapa a las consecuencias de los mismos; en tercero, que sólo a
través del compromiso y la acción es posible tener una vida buena; por último, que si no se da el
compromiso la consecuencia es la pérdida, que puede llegar a ser definitiva, de alguno de los
aspectos que configuran nuestra humanidad.

4.2. Bloque 1:

¿Qué es la filosofía? Especificidad y función de la filosofía.

¿Qué es ser humano? Naturaleza humana, identidad y sociedad.

¿Qué es real? Apariencia y realidad.

¿Qué puedo saber? Verdad, opinión y saber.

¿Qué es actuar como una persona? Libertad y responsabilidad.

4.3. Bloque 2: Retos y desafíos contemporáneos: Objetivos de Desarrollo Sostenible.

Uso correcto de los argumentos o muerte del diálogo.

Respeto al medio ambiente o muerte del planeta.

Diversidad personal y cultural o muerte de la diferencia.

Consumo responsable o muerte por asfixia.

Lucha contra las injusticias o muerte de la equidad.

Aceptación y manejo de la incertidumbre o muerte de la creatividad.

Compromiso y participación ciudadana o muerte de la democracia.

Responsabilidad digital o muerte de las relaciones.

5. Situaciones de aprendizaje para el conjunto de las competencias de la materia

Lo primero que hay que tener en cuenta en el desarrollo de las situaciones de
aprendizaje es que se trata de una materia con un carácter eminentemente práctico que tiene
que convertir el aula en un laboratorio de ideas y de discusiones vivo y activo.

En una materia que pretende vincular la reflexión del alumnado a los problemas actuales
del mundo y promover el compromiso activo con la transformación de la realidad, las situaciones
de aprendizaje recomendables trascienden los espacios propios del centro y se desarrollan
también en entornos naturales y urbanos.

Es fundamental que estimulen la reflexión, el pensamiento divergente y el espíritu crítico
mediante la práctica frecuente del diálogo y el debate. Es clave la organización de debates en el
aula a partir de experiencias o noticias de actualidad que permiten más de una postura y que
pueden relacionarse fácilmente con los conflictos y situaciones cotidianas del entorno habitual
del alumnado. Con el debate, además, se fomenta la discrepancia, la duda y la legitimidad de las
opciones minoritarias. Es especialmente útil, también, el trabajo con dilemas morales que se
relacionen de manera directa con los desafíos para el siglo XXI que plantean los Objetivos de
Desarrollo Sostenible.

Al hilo de los debates, dilemas y discusiones planteados, es importante ir mostrando al
alumnado el tipo de argumentaciones que de forma espontánea utilizan y la manera de centrar
los argumentos en los temas planteados evitando distracciones y falacias.

La capacidad de diálogo y el trato respetuoso al resto de participantes se ejercitan
haciendo uso de un lenguaje inclusivo e igualitario en todas las situaciones que implican
acuerdos y trabajo en grupo como, por ejemplo, en asambleas de delegadas y delegados,
debates sobre noticias de actualidad, experiencias y sucesos, contenido de textos presentados
en formatos convencional y multimodal y de producciones audiovisuales documentales y de
ficción, o durante las rutinas del trabajo cooperativo.

Asimismo, deben impulsar aprendizajes valiosos y significativos. Por una parte, facilitan
la comprensión y progresiva asimilación de los saberes de la humanidad, y por otra, promueven
el aprendizaje significativo con ejemplos y modelos vinculados a los intereses del alumnado, a
propuestas de acciones y servicios relevantes para mejorar el entorno más cercano y la sociedad
en general, y al análisis de su relación con dispositivos digitales, internet y las redes sociales. En
este sentido cabe destacar que el juego y las diversas manifestaciones de la expresión artística
contribuyen a hacer más significativos los procesos de aprendizaje.

Garantizar el acceso de todo el alumnado a instalaciones y materiales del centro y las
aulas, actividades y saberes, así como su participación académica y emocionalmente
satisfactoria en la experiencia escolar son retos ineludibles del sistema educativo y de todas las
personas involucradas en su funcionamiento. Por ello, la detección y eliminación de barreras de
todo tipo y la aplicación de los principios del Diseño Universal de Aprendizaje a lo largo del
proceso educativo son requisitos imprescindibles.

Las situaciones de aprendizaje en que intervienen metodologías activas como el
trabajo cooperativo o el basado en retos, tareas y proyectos, entre otros, fomentan la autonomía
y la responsabilidad del alumnado, pues le ofrecen la posibilidad de gestionar su tiempo, decidir
entre diferentes propuestas de trabajo, resolver los desafíos y problemas de diversas formas y
elegir la manera de demostrar sus aprendizajes.

El bienestar emocional es premisa indiscutible para el éxito del aprendizaje y de la
convivencia y un factor que lo condiciona es la capacidad de expresar emociones y sentimientos
propios y de identificar y comprender los ajenos. Diálogos, debates, producciones textuales
orales y escritas, análisis de situaciones lúdicas y de convivencia, y especialmente de aquellas
en que el alumnado no ve satisfechas sus expectativas, ejercitan la expresión de emociones,
opiniones y posicionamientos, promueven la autorregulación emocional y refuerzan el respeto,
la tolerancia y la empatía.

La resolución dialogada de los conflictos surgidos en la convivencia diaria con
compañeras y compañeros, profesorado y personal no docente, en todos los espacios educativos
de dentro y fuera del centro y en las redes sociales, y la aplicación de programas de mediación
facilitan la convivencia y promueven la cultura de la paz y la “noviolencia”.

La interiorización de los valores democráticos y de la universalidad de los derechos
humanos y la dignidad de la persona se promueve mediante el conocimiento, discusión y debate
de las situaciones que suponen discriminaciones en ámbitos ya no sólo locales, sino también
nacionales e internacionales. La investigación y estudio de personajes relevantes históricos y
actuales que han trascendido por la denuncia de sus experiencias personales o su compromiso
con la transformación social ayudan al alumnado a descubrir la necesidad y el alcance de la
acción individual frente a las injusticias globales y a adquirir modelos de referencia en el camino
de su desarrollo moral. También son interesantes las iniciativas que suscitan la implicación en la
mejora de la sociedad a partir de la toma de conciencia de las necesidades existentes en el
entorno próximo.

La implicación reflexiva y activa en acciones que celebran los derechos humanos y de la
infancia y los valores democráticos facilita la identificación y apreciación de los mismos, al igual
que las visitas a instituciones, la comparación del disfrute de los derechos humanos en distintas
sociedades y la investigación y reflexión a propósito de conceptos clave ligados a los principios
y sistemas democráticos.

El compromiso del sistema educativo con la construcción de una ciudadanía global,
responsable y consciente de su potencial transformador implica el reconocimiento de la
diversidad como fuente de aprendizaje y enriquecimiento personal. Reconocimiento que
promueven la convivencia inclusiva diaria en el aula y el centro, la observación de costumbres,
procedencias y lenguas familiares de compañeras y compañeros de clase, la investigación y
comparación de diferentes realidades políticas en el mundo y sus consecuencias en la vida de
las personas, y las acciones y proyectos de centro de carácter académico, festivo o lúdico que
celebran la multiculturalidad.

En consonancia con uno de los desafíos que se desprenden de los Objetivos de
Desarrollo Sostenible, la lucha contra las injusticias, se proponen situaciones de aprendizaje
enfocadas a la detección, denuncia y atención de las mismas, especialmente del acoso escolar,
a partir del análisis de casos de la vida real y de los reflejados en producciones textuales
narrativas, periodísticas y audiovisuales. También se invita a la formulación de propuestas de
actuaciones a propósito del análisis de conflictos históricos y actuales y de las migraciones de
millones de personas provocadas por catástrofes naturales, guerras, hambre o pobreza. La

comparación de la situación de los derechos en diferentes partes del mundo propicia la
identificación de las personas más vulnerables.

Asimismo, en el marco de la lucha contra las injusticias y de la emergencia derivada de
los dramáticos datos estadísticos, se revela como prioritaria la promoción de la igualdad entre
mujeres y hombres. Se incorpora la perspectiva de género de manera transversal a lo largo de
toda la etapa y en todas las materias y tiempos escolares, prestando especial atención, entre
otros, al uso del lenguaje y de los espacios del centro, a la participación equilibrada de las y los
adolescentes en todas las actividades, a las aportaciones de las mujeres a los saberes de la
humanidad, a la presencia de estereotipos en libros, canciones, anuncios publicitarios,
producciones audiovisuales, mensajes de los medios de comunicación, al tratamiento visual del
cuerpo de mujeres y hombres en el arte, pintura, escultura, cine, o al tratamiento de las mujeres
en el deporte y en los modelos de belleza. De manera explícita, se puede trabajar la educación
afectivosexual, el lenguaje igualitario, la diversidad familiar, sexual y de género, la violencia
machista, la ciberviolencia y los abusos sexuales en talleres abiertos, en la medida de lo posible,
a la participación de otros miembros de la comunidad educativa y local, y proponer proyectos
colaborativos que estimulen la construcción de personalidades autónomas y libres de prejuicios
y estereotipos sociales.

Es necesario poner el foco sobre aquellas situaciones y colectivos invisibilizados
mediante el análisis crítico de materiales didácticos, mensajes publicitarios e informaciones de
los medios de comunicación y redes sociales y con metodologías que requieren la investigación
social y conducen al diseño y realización de campañas de visibilización en el centro y en la
localidad.

Además de contribuir a la consolidación de hábitos de vida sostenibles como la
conservación y el cuidado del material, equipamiento e infraestructuras del centro, la selección
de residuos del aula para el reciclaje y el consumo racional del agua y de la electricidad, las
situaciones de aprendizaje deben trascender el espacio próximo y cotidiano y fomentar la
comprensión del alcance de las acciones humanas en el planeta. Es recomendable plantear
situaciones de aprendizaje que impulsen la interiorización de la perspectiva sostenible.

Se promueve la participación en campañas para planificar y aplicar de forma colectiva
acciones innovadoras que fomenten la sostenibilidad, como, por ejemplo, cambios en los
espacios de la ciudad para facilitar la movilidad de las personas o el diseño de itinerarios seguros
y sostenibles para escolares, y la colaboración con ONGs, asociaciones e instituciones
comprometidas con causas medioambientales y sociales. Son especialmente recomendables las
metodologías que vinculan las dimensiones de servicio y aprendizaje, ya que impulsan el
compromiso real con la sociedad.

Las tecnologías de la información y comunicación pueden amplificar el impacto de todo
tipo de acciones, y el uso de redes y recursos como el podcast, la radio y la televisión online
escolar son especialmente eficaces para difundir mensajes de sensibilización, implicar al resto
de la comunidad educativa y promover compromisos y alianzas institucionales.

Además de las situaciones de aprendizaje conviene tener en cuenta las situaciones que
facilitan la evaluación competencial.

La propia dinámica de las aulas ofrece múltiples escenarios para observar la evolución
del alumnado y valorar la adquisición de las competencias. Se trata de situaciones como las que
se generan en la convivencia diaria con compañeras y compañeros del centro, profesorado y
personal no docente, y también durante la elaboración de textos sencillos en formato analógico
o digital, en las exposiciones orales y en los debates o tertulias. Resulta especialmente útil el

análisis de materiales didácticos, anuncios y lenguaje publicitario, videojuegos, producciones
audiovisuales y redes sociales.

Asimismo,
la
elaboración
individual
y
colectiva
de
producciones
textuales
convencionales o multimodales en que se utilizan conceptos clave del currículo y que implican
los procesos de síntesis, reformulación, análisis e investigación facilitan la comprobación de la
adquisición de los mismos.

El trabajo en equipo es un escenario óptimo para valorar si el alumnado asume diferentes
roles con eficiencia y responsabilidad, muestra empatía y respeta las aportaciones de
compañeros y compañeras.

Es especialmente relevante el trabajo que se desarrolla de forma colectiva, bien sea en
grupos de trabajo, debates, exposiciones orales, discusión de propuestas u otras situaciones y
actividades porque permite que entren en juego muchos de los aspectos que se valoran en las
diferentes competencias específicas.

Finalmente, el uso de instrumentos de autoevaluación y coevaluación como dianas,
rúbricas, escalas de observación, porfolios, diarios, entre otros, presenta muchas ventajas, y
entre ellas la oportunidad de reflexionar sobre los saberes y los procesos de aprendizaje.

6. Criterios de evaluación

Competencia específica 1. Criterios de evaluación

CE1. Analizar problemas cotidianos desde una perspectiva filosófica y con una mirada
crítica, constructiva y éticamente comprometida.

4º curso

1.1 Explicar intenciones, causas y consecuencias de los problemas sociales relacionados con los
desafíos.

1.2 Utilizar la crítica como herramienta positiva.

1.3 Formular preguntas referidas a la vida cotidiana desde una perspectiva filosófica.

Competencia específica 2. Criterios de evaluación

CE2. Identificar y diferenciar las premisas, estrategias argumentativas y conclusiones de
textos o discursos, distinguiendo los usos correctos de las argumentaciones falaces.

4º curso

2.1. Diferenciar premisas, argumentos y conclusiones y explicar sus características.

2.2. Identificar y explicar las premisas que sirven como fundamento en la defensa de una idea o
hipótesis.

2.3. Identificar y analizar críticamente los usos incorrectos de las estrategias argumentativas
y plantear alternativas que se ajusten a la lógica del discurso.

2.4. Analizar críticamente las consecuencias del uso incorrecto de los argumentos.

Competencia específica 3. Criterios de evaluación

CE3. Explicar las diferencias entre elementos racionales y emocionales en la justificación
de decisiones a propósito de conflictos de valores.

4º curso

3.1. Confrontar elementos racionales y emocionales y explicar sus diferencias.

3.2. Explicar de forma clara el valor de las emociones en la toma de decisiones.

3.3. Identificar y exponer todos los elementos contrapuestos que forman parte de un dilema.

Competencia específica 4. Criterios de evaluación

CE4. Elaborar y exponer de una manera clara, ordenada y argumentada ideas y
propuestas filosóficas prácticas que fomenten el crecimiento personal y el compromiso social.

4º curso

4.1. Elaborar textos o discursos con una argumentación clara y ordenada.

4.2. Utilizar de forma correcta los argumentos en la defensa de una idea o propuesta y para
aclarar las dudas y malentendidos que se planteen.

4.3. Exponer y argumentar la posición moral que se adopta frente a los desafíos de la vida
cotidiana trabajados.
