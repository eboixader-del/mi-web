# CREATIVIDAD MUSICAL

> Fuente: Secundaria.pdf, páginas 1073-1085 (versión en castellano).

CREATIVIDAD MUSICAL

1. Presentación

La materia Creatividad Musical desarrolla la percepción y la expresión musical mediante la
exploración y la experimentación sonora en estrecha relación con otros lenguajes artísticos, y facilita
al alumnado conectar sus conocimientos, imaginación y sensibilidad con las posibilidades creativas del
sonido. Esta materia se presenta como optativa en 3º curso de la ESO y pretende consolidar los
conocimientos adquiridos en niveles anteriores en la materia obligatoria de Música, fomentar procesos
creativos en conexión con otros lenguajes, analizar el entorno sonoro que nos rodea y sus posibilidades
para la creación artística, así como profundizar en estilos y corrientes artísticas presentes a lo largo del
siglo XX y hasta la actualidad.

La creatividad musical, concebida como la capacidad de generar asociaciones entre los
elementos que configuran los procesos creativos sonoros y otros lenguajes artísticos, permite formas
distintas de acercarse al conocimiento y a las posibilidades del sonido, tanto por parte del alumnado
como del profesorado, y promueve la participación, el esfuerzo y el respeto frente a las propuestas
propias y ajenas. A partir de estos valores se desarrolla el proceso de aprendizaje mediante propuestas
que estimulen la iniciativa y la originalidad a partir de procesos compositivos sencillos y abiertos, desde
diferentes perspectivas, traspasando así los límites de la partitura convencional y estableciendo
conexiones con otros lenguajes artísticos, fomentando la reflexión e investigación sonora.

La creación musical sitúa al alumnado como protagonista de la producción de propuestas
artísticas, que van desde la composición de piezas con acompañamientos tonales sencillos hasta la
experimentación y creación sonora o multidisciplinar con un marcado carácter conceptual y de
vanguardia.

Partiendo de los conocimientos sobre elementos estructurales y técnicos adquiridos en niveles
anteriores, el alumnado debería investigar y explorar sonoramente, traspasando las fronteras de
elementos convencionales como la instrumentación, la música tonal o la partitura, para favorecer la
composición e improvisación guiada a partir de otros lenguajes artísticos.

El uso de la voz, el cuerpo y los instrumentos musicales, tanto convencionales como no
convencionales, son los elementos que permitirán la creación musical, pudiéndose apoyar en recursos
digitales para la producción y creación musical.

En este documento se presentan los diferentes apartados que conforman el currículo de la
materia de Creatividad Musical: competencias específicas, conexiones de la materia, saberes básicos,
situaciones de aprendizaje y criterios de evaluación.

Las competencias específicas son aquellas que el alumnado debería adquirir al finalizar la
materia optativa de Creatividad Musical en 3º curso de la ESO y se presentan con su correspondiente
descripción. Seguidamente, se analizan las conexiones con las CE de otras materias de la etapa y con
las competencias clave.

El apartado de saberes básicos se plantea desde la perspectiva propia del contexto social y
cultural actual y se presenta en dos bloques interrelacionados, que deben ser trabajados de forma
integrada con sus correspondientes subbloques. En el primero, Percepción y análisis, se recogen los
contextos musicales y culturales de las principales corrientes de vanguardia de los siglos XX y XXI, así

como los elementos del sonido que configuran el entorno del alumnado y la estructura musical que
conforman las composiciones de música urbana y música contemporánea. En el segundo bloque,
Interpretación y creación, se aborda el fenómeno musical en la vertiente más vivencial, basada en la
improvisación, la experimentación, la interpretación y la creación, mediante la expresión vocal,
instrumental y corporal, y la realización de proyectos artísticos y multidisciplinares, con el apoyo de las
nuevas tecnologías.

En el apartado sobre las situaciones de aprendizaje, se presenta un conjunto de principios que
orientan la organización de actividades dirigidas a facilitar el desarrollo competencial.

Por último, en el apartado referente a los criterios de evaluación, se establece el grado de
aprendizaje que se espera que haya logrado el alumnado a partir de las distintas competencias
específicas. Cada competencia conlleva diferentes criterios de evaluación con el objetivo de evidenciar
su desarrollo y adquisición.

2. Competencias específicas

2.1. Competencia específica 1

Identificar los elementos compositivos, estructurales y comunicativos de creaciones sonoras e
interdisciplinares contemporáneas, y valorar críticamente su dimensión estética.

2.1.1.
Descripción de la competencia 1

La presencia del arte en las aulas como herramienta de transformación educativa y social
requiere de compromiso por parte de toda la comunidad educativa. Por ello resulta indispensable el
análisis perceptivo de diferentes propuestas artísticas, existentes o generadas por el propio alumnado,
a partir de los elementos que las constituyen, desde un punto de vista técnico y crítico, y de las
funciones comunicativas que presentan. Sobre la base de los aprendizajes adquiridos en niveles
educativos anteriores, esta competencia profundiza en el reconocimiento y relación de los elementos
estructurales y técnicos que configuran las propuestas artísticas trabajadas. La materia de Creatividad
Musical aborda perspectivas experimentales, de vanguardia y contemporáneas, que exigen un cambio
de mirada determinado por la ruptura con las formas musicales convencionales y la tonalidad.

El desarrollo de esta competencia supone una oportunidad para descubrir y valorar las
manifestaciones de vanguardia, las intenciones artísticas que las fundamentan y las instituciones
culturales que las producen y las promueven. En el proceso de análisis de los elementos que configuran
estas propuestas, a través de su escucha o visionado, adquiere relevancia la capacidad para
argumentar de manera crítica y respetuosa para poder configurar una valoración estética.

En este sentido, es necesaria una reflexión sobre la perspectiva de género, de manera que se
identifiquen los mitos, los estereotipos y los diferentes roles transmitidos a través de las propuestas
analizadas y producidas.

El alumnado debería encontrarse ante creaciones donde los instrumentos musicales y el
lenguaje musical conviven con otros objetos y paisajes sonoros, así como partituras y representaciones
gráficas que en ocasiones poco tienen que ver con la notación convencional y que suponen un punto
de encuentro entre las artes visuales y la música.

2.2. Competencia específica 2

Analizar los elementos sonoros del entorno más cercano mediante la escucha activa y explorar
las posibilidades que ofrecen para la creación artística.

2.2.1. Descripción de la competencia 2

El desarrollo de esta competencia exige una conciencia del entorno sonoro donde identificar
elementos que sirvan de inspiración en la creación musical y artística, así como sensibilizar y proponer
soluciones a las diversas agresiones acústicas del mismo, mediante una terminología adecuada.

En este contexto se debe fomentar la escucha activa y el análisis de los elementos sonoros
que configuran el entorno cercano para explorar las posibilidades que ofrece en la creación artística, a
través de la investigación, experimentación y transformación sonora de sus elementos. Para dichos
procesos, la utilización de recursos digitales será fundamental y posibilitará su grabación y edición.

Asimismo, el entorno que envuelve al alumnado ofrece una oportunidad para tomar conciencia
medioambiental. En el desarrollo de esta competencia, se deben identificar las posibilidades que
ofrecen los objetos y materiales de nuestro entorno en la creación sonora y artística. De este modo,
existen objetos que pueden ser reutilizados o transformados para convertirse en instrumentos
musicales no convencionales. En el mismo sentido, se pueden fabricar instrumentos propios u objetos
sonoros, explorando sus posibilidades acústicas e incorporando, además, la perspectiva de desarrollo
sostenible.

2.3. Competencia específica 3

Interpretar piezas de música urbana y creaciones sonoras e interdisciplinares propias,
mediante el uso de la voz, el cuerpo, instrumentos convencionales y no convencionales, con el apoyo
del lenguaje musical y partituras gráficas, de manera individual y colectiva.

2.3.1. Descripción de la competencia

La dimensión referida a la interpretación musical constituye un pilar fundamental para el
aprendizaje de la materia. En el desarrollo de esta competencia, se incidirá en la interpretación musical
de piezas de música urbana cercanas al contexto del alumnado a partir del análisis técnico, crítico y
estético desarrollado en la competencia específica 1.

Por otra parte, la interpretación de piezas y creaciones sonoras e interdisciplinares generadas
por el propio alumnado (CE 5) exige de su interpretación escolar, individual y colectiva para que puedan
ser analizadas de un modo crítico y enriquecedor

En la interpretación, el lenguaje musical facilita la lectura a través de la partitura. El repertorio
de música urbana exige, además, la integración de sistemas de notación que incorporen el cifrado
anglosajón (o americano).

Las partituras gráficas y sistemas de notación no convencional posibilitan la representación de
propuestas sonoras y artísticas tonales y atonales. De este modo, las representaciones gráficas no
convencionales del sonido facilitan la comprensión de la organización y la interpretación de las
propuestas artísticas basadas en la experimentación sonora, que habitualmente no se ajustan a
modelos de formas musicales convencionales.

2.4. Competencia específica 4

Realizar improvisaciones guiadas musicales o interdisciplinares, utilizando lenguajes gestuales
y gráficos, a través de procesos individuales y colectivos.

2.4.1. Descripción de la competencia

En la práctica creativa, el alumnado profundiza en el mundo sonoro mediante la improvisación
con la voz, el cuerpo, los instrumentos musicales o los objetos sonoros, y se adentra en su
conocimiento a través de la exploración y la experimentación.

Esta competencia presenta un carácter experimental basado en la improvisación, que debe
ser entendida como una creación original individual o colectiva de un material artístico que en la
mayoría de las ocasiones resulta irrepetible. En su aprendizaje se tiene que posibilitar un entorno de
confianza en el que el alumnado pueda expresarse libremente sin penalizar el error, y generar
oportunidades para crear nuevas propuestas. Para ello, es fundamental que el proceso de
improvisación sea guiado o acompañado de recursos o elementos que faciliten su realización,
especialmente en las fases iniciales. Entre los elementos que pueden servir de apoyo en este
acompañamiento, destacan los lenguajes gestuales y gráficos que facilitan la conexión entre los
diferentes códigos artísticos con la improvisación musical e interdisciplinar.

El desarrollo de esta competencia favorece la interacción, la empatía y el respeto entre los
participantes, a la vez que fomenta la reflexión crítica acerca de las creaciones producidas y la propia
identidad cultural.

2.5. Competencia específica 5

Crear y poner en escena proyectos sonoros e interdisciplinares, individuales y colectivos,
mediante el uso de diversos lenguajes artísticos, asumiendo diferentes roles en sus fases y valorando
tanto el proceso como el resultado.

2.5.1. Descripción de la competencia

La creación de proyectos musicales e interdisciplinares en el aula a través de los ejes propios
de la materia, así como de otras disciplinas, implica seguir las fases del proceso creativo que se basan
en la planificación, investigación, creación y difusión, pudiéndose apoyar en recursos digitales y las
TIC.

El alumnado asume diferentes roles relacionados con las profesiones asociadas a la creación
de manera colaborativa y activa, desde una distribución inclusiva e igualitaria de tareas. A su vez, se
promueve la toma de decisiones autónomas y compartidas, así como la capacidad crítica en la
realización y valoración del producto final. Esta reflexión continuada durante todo el proceso creativo
lleva implícita una evaluación continua de los procesos para establecer los ajustes necesarios,
aceptando la diversidad de opiniones y fomentando el respeto y la empatía.

El producto final y su difusión son partes fundamentales en el desarrollo de esta competencia,
pues permiten crear un espacio para dinamizar o materializar saberes adquiridos en la materia de
Música hasta 2º de la ESO, a la vez que proporcionan una oportunidad para utilizar y combinar los
saberes básicos y las competencias específicas de otras materias.

El desarrollo de esta competencia implica el reconocimiento del potencial comunicativo que
ofrece el mundo sonoro, tanto de forma individual como grupal, donde los medios digitales representan
una oportunidad para desarrollar y enriquecer las propuestas artísticas y en el que el alumnado se
puede expresar libremente con el apoyo de lenguajes musicales, corporales, textuales, gestuales,
plásticos, visuales y audiovisuales.

La producción musical e interdisciplinar implica el reconocimiento del potencial expresivo y
comunicativo que ofrece el entorno sonoro, la expresión corporal, el lenguaje visual, audiovisual y
digital, de manera tanto individual como grupal. Actualmente, la capacidad generalizada de acceder a
los medios y herramientas digitales supone para el alumnado la posibilidad de desarrollar la creación,
expresión y difusión de proyectos sonoros, y también de incorporar matices y posibilidades que
enriquecen y propician la multidisciplinariedad de las producciones.

El uso original e innovador del sonido, mediante la práctica con instrumentos convencionales
y no convencionales construidos en el aula, favorece la utilización y transformación de los materiales,
al mismo tiempo que favorece una exploración tímbrica desde una perspectiva de desarrollo sostenible.

2.6. Competencia específica 6

Emplear recursos digitales en procesos de creación sonora e interdisciplinar, incorporando las
posibilidades expresivas, comunicativas y artísticas, con actitud reflexiva y respetando la normativa
vigente de uso y difusión.

2.6.1. Descripción de la competencia

El desarrollo de la competencia digital dentro de la materia Creatividad Musical adquiere una
especial importancia por formar parte de la realidad contextual del alumnado, en sus comunicaciones
y en el consumo diario que hacen de la información, hábitos que condicionan su modo de aprendizaje.
El uso de recursos, aplicaciones, redes y plataformas audiovisuales conviven con diferentes lenguajes
y elementos. En este contexto, se generan espacios de investigación y experimentación que favorecen
procesos de creación y el tratamiento de contenidos digitales.

Esta competencia específica tiene un carácter transversal en los procesos de análisis y
creación, ya que favorece las posibilidades expresivas, comunicativas y artísticas en las que los
recursos digitales se presentan como un medio y no como un fin en sí mismo, a través del uso
adecuado de aplicaciones, webs y programas de edición de partituras, grabación y edición de audio,
respetando los derechos de propiedad intelectual y escogiendo las licencias de uso pertinentes.

3. Conexiones de las competencias específicas entre sí, con las competencias de otras materias
y con las competencias clave

3.1. Relaciones o conexiones con las otras CE de la materia

En este apartado presentamos las conexiones más significativas entre las competencias
específicas (CE) de la materia de Creatividad Musical.

El proceso de enseñanza-aprendizaje de la materia Creatividad Musical exige el desarrollo e
integración de las distintas competencias específicas de manera simultánea.

La CE 1 está relacionada con la CE 3, CE 4 y CE 5, al exigir un análisis de los elementos que
caracterizan todas aquellas propuestas expresivas trabajadas en la materia y basadas en la
interpretación, improvisación y composición.

La CE 2 está directamente conectada con la CE 1 por abordar la dimensión de percepción y
análisis sonoro para generar detonantes artísticos que sirvan como base para los procesos de
creación. En el proceso de grabación y registro de elementos del entorno sonoro, el empleo de recursos
digitales (CE 6) suponen un gran apoyo para su desarrollo.

La CE 3, CE 4 y CE 5, que desarrollan los procesos expresivos de interpretación,
improvisación, creación y producción escénica respectivamente, están conectadas con la CE 1 al
realizar un análisis a partir de la dimensión perceptiva. Además, la CE 5 pone en acción el resto de
competencias mediante procesos de planificación, investigación, creación y difusión, así como con el
apoyo de los recursos digitales y las TIC.

Por último, la CE 6, referida al empleo de recursos digitales, está conectada de manera
transversal al resto de competencias, lo que favorece su desarrollo y adquisición. De esta manera, se
plantea como un medio y no como un fin en sí mismo, ya que adquiere un peso distinto según el
planteamiento de la práctica educativa.

3.2. Relaciones o conexiones con las CE de otras materias de la etapa

Las competencias específicas de la materia Creatividad Musical se relacionan con las
competencias propias de otras materias de la etapa.

Las materias científicas se relacionan con el estudio del sonido en cuanto a su naturaleza
acústica, así como los parámetros físicos interválicos o aspectos referidos a la duración, intensidad y
timbre. Por otra parte, comparten metodología en la elaboración de los proyectos, a través de sus
distintas fases. La materia de Tecnología y Digitalización comparte la construcción de instrumentos en
el aula, el estudio de los materiales que los componen o el uso de recursos digitales para el registro,
edición y difusión musical.

En cuanto a la relación con la materia de Educación Plástica, Visual y Audiovisual, se destaca
la producción y utilización de partituras gráficas que sirven de apoyo en la interpretación y análisis de
propuestas contemporáneas sonoras e interdisciplinares en las que el lenguaje musical convencional
no resulta eficiente. Esta correspondencia entre elementos visuales y sonoros que se da a la partitura
gráfica supone una oportunidad para establecer conexiones y trabajar conjuntamente entre las
materias de 3º de la ESO de Educación Plástica y Visual y la materia optativa de Creatividad Musical.
Además, existe una clara intención expresiva en la producción de propuestas artísticas
interdisciplinares basadas en el uso de lenguajes plásticos, gráficos o audiovisuales. Por último, cobran
importancia los saberes relacionados referidos a las vanguardias artísticas de los siglos XX y XXI.

En la línea del aprendizaje de las vanguardias comentadas, existe una conexión con la materia
de Geografía e Historia al relacionar históricamente las corrientes artísticas analizadas y producidas
desde una visión cultural y social.

En lo referente a la conexión con la materia de Educación Física, destaca la expresión corporal
en los procesos de creación interdisciplinar.

La materia de Creatividad Musical establece una clara conexión con las materias de Biología
y Geología al analizar elementos sonoros del entorno para la creación musical. Este aprendizaje
favorece un mejor conocimiento del mismo y se presenta como fuente de inspiración en procesos
creativos. Por otra parte, el uso de objetos sonoros, así como su construcción o transformación desde
una perspectiva sostenible, representa una oportunidad para establecer un encuentro entre disciplinas.

La conexión con las materias lingüísticas es necesaria desde cualquier materia. En el caso de
Creatividad Musical, se generan espacios de producción creativa contemporánea, mediante la
improvisación y experimentación con la palabra y el gesto, desde un enfoque que aborde con apertura
el terreno de lo desconocido e imprevisible.

Por último, cabe mencionar la oportunidad que se plantea en relación a la producción de
proyectos escenográficos interdisciplinares entre materias optativas: Laboratorio de Artes Escénicas
de 1º de la ESO, y Artes Escénicas y Expresión Artística de 4º de la ESO.

3.3. Relaciones o conexiones con las competencias clave

Conexiones de las competencias específicas de la materia con las competencias clave del
perfil de salida del alumnado al término de la educación básica.

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 | x | x |  |  | x |  |  | x |
| CE2 |  |  | x |  | x x |  |  | x |
| CE3 |  |  |  |  | x x |  | x | x |
| CE4 |  |  | x |  | x x |  |  | x |
| CE5 | x | x | x |  | x x | x | x | x |
| CE6 |  |  | x |  | x |  |  | x |

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica

CCL. Competencia en comunicación lingüística

CP. Competencia plurilingüe

CMCT. Competencia matemática y en ciencia, tecnología e ingeniería

CD. Competencia digital

CPSAA. Competencia personal, social y de aprender a aprender

CC. Competencia ciudadana

CE. Competencia emprendedora

CCEC. Competencia en conciencia y expresión culturales

El cuadro adjunto anterior muestra la existencia de una relación especialmente significativa y
relevante entre las seis competencias específicas de la materia Creatividad Musical y las competencias
clave incluidas en el perfil de salida del alumnado al finalizar la educación básica.

La competencia en comunicación lingüística tiene una relación directa con la CE 1 al analizar
las diversas propuestas mediante su análisis y expresando opiniones, argumentaciones y sentimientos,
de manera oral y escrita. Del mismo modo, existe una conexión con la CE 5 al realizar valoraciones
críticas acerca del proceso y resultado en la creación y producción escénica.

En cuanto a la competencia plurilingüe, se relaciona con la CE 1 al analizar referentes artísticos
y contenidos culturales contemporáneos de distintos orígenes geográficos y culturales. Del mismo
modo, se relaciona con la CE 5 en el acceso a la información en lenguas diferentes en fases de
investigación.

Por otra parte, la competencia matemática y en ciencia, tecnología e ingeniería guarda relación
con la CE 2, CE 4 y CE 5 al utilizar metodologías de razonamiento matemático en la creación y
experimentación sonora, así como con la CE 6 al emplear recursos digitales en la creación sonora e
interdisciplinar.

La competencia digital está directamente relacionada con la CE 6 basada en la selección y
empleo de recursos digitales, así como en el respeto a las licencias de uso y normativa vigente en los
procesos creativos.  Se relaciona, además, con el resto de competencias como un medio o apoyo en
el análisis (CE 1), en el registro de elementos del entorno sonoro (CE 2), en la utilización de
instrumentos electrónicos en la interpretación (CE 3) y en la improvisación (CE 4). Asimismo, existe
relación con la CE 5 al utilizar los lenguajes audiovisuales en la producción de proyectos.

La competencia personal, social y de aprender a aprender está relacionada con la CE 2 al
explorar las posibilidades que ofrece el entorno en la creación sonora, con la CE 3 en la elaboración y
uso de partituras gráficas y con la CE 4 al estar basada en la improvisación guiada. Del mismo modo,
existe una relación con la CE 5 al participar en la creación de proyectos, de forma individual y colectiva,
ya que comprende la diversidad de aportaciones para incorporarlas al propio aprendizaje del alumnado
y establecer juicios críticos personales.

La competencia ciudadana fomenta la participación en procesos colectivos expresivos
basados en la interpretación, improvisación y creación. Por esta razón, se puede afirmar que existe
una relación con diversas competencias específicas de la materia, pero en especial con la CE 5, ya
que en la creación y puesta en escena de proyectos sonoros e interdisciplinares se establecen
relaciones grupales, en las que es necesaria una actitud respetuosa y democrática, fundamentada en
los Derechos Humanos, la diversidad cultural, la igualdad de género y la cohesión social.

La competencia emprendedora está relacionada con la CE 3 en la exploración de las
posibilidades que ofrece el entorno sonoro en la creación artística. Esta acción emprendedora se
presenta, al mismo tiempo, en la CE 5, al desarrollar procesos creativos mediante tareas, toma de
decisiones, así como la asunción de diferentes roles.

Por último, la competencia clave en conciencia y expresión cultural está implícita en el
desarrollo de todas las competencias específicas de la materia Creatividad Musical, por la propia
naturaleza expresiva de la misma. La CE 1 favorece su desarrollo mediante el análisis de las
propuestas artísticas contemporáneas. Por otra parte, facilita la experimentación a través del proceso
de expresión creativa implícito en las competencias CE 2, CE 3, CE 4, CE 5 y CE 6, en las que los
recursos digitales se presentan como medios facilitadores para desarrollar procesos creativos.

4. Saberes básicos

4.1. Introducción

En este apartado se presentan los saberes básicos de la materia de Creatividad Musical.

Los saberes básicos son el conjunto de conocimientos necesarios para garantizar la
adquisición y desarrollo de las competencias específicas, pudiendo ser ampliados y adaptados por el
profesorado en función del perfil del alumnado y del contexto escolar. Estos saberes básicos se
distribuyen en dos bloques que, a su vez, se dividen en subbloques (SB).

El primer bloque, Percepción y análisis, hace referencia a los saberes que se trabajarán desde
la vertiente perceptiva del sonido, detallados en el subbloque Contextos musicales y culturales con el
análisis de obras, estilos y corrientes de vanguardia, la evolución de su notación, así como con
propuestas artísticas inspiradas en el entorno sonoro, con el apoyo de notaciones gráficas

convencionales y no convencionales. El subbloque Elementos del sonido y estructura musical recoge
los saberes relacionados con las posibilidades que ofrece el tratamiento del sonido y los objetos
sonoros del entorno para la producción de creaciones artísticas.

El segundo bloque, Interpretación y creación, hace referencia al uso de diferentes lenguajes
para la improvisación, la experimentación, la interpretación y la creación. Estos saberes se recogen,
en primer lugar, en el subbloque Expresión individual y colectiva, que abarca los saberes relacionados
con la lectura musical, sonorización, creación de letras, composición, improvisación guiada y
experimentación; y, en segundo lugar, en el subbloque Proyectos artísticos, dedicado a la elaboración
de producciones artísticas y a la participación activa del alumnado en todas sus fases.

Cabe destacar que los dos bloques se interrelacionan y pueden trabajarse de forma integrada,
lo que permite un enfoque global necesario para su desarrollo y adquisición.

Bloque 1. Percepción y análisis

SB. 1.1. Contextos musicales y culturales

Las vanguardias musicales: música concreta, música electrónica, minimalismo musical y
música aleatoria. La evolución de la notación musical en los siglos XX y XXI.

La música valenciana contemporánea.

Características y cualidades expresivas y comunicativas de los formatos, soportes y materiales
de las prácticas artísticas contemporáneas.

Lenguajes gestuales y gráficos para la composición artística.

Paisajes sonoros.

Perspectiva de género, estereotipos y expresiones de violencia en relación a la música.

Propuestas sonoras y multidisciplinares desde una perspectiva contemporánea: actuaciones
en vivo y registradas por medios audiovisuales.

SB.1.2. Elementos del sonido y estructura musical

La organización y transformación de los elementos del sonido y la estructura musical en la
creación sonora.

Objetos sonoros del entorno próximo.

Agresiones acústicas del entorno sonoro.

Terminología musical. Argumentación oral y escrita.

Bloque 2: Interpretación y creación

SB.2.1. Expresión individual y colectiva

Pautas de creación e interpretación musical con acompañamientos básicos.

Cifrado anglosajón (o americano). Rueda de acordes.

La creación artística como proceso de investigación: conexión con otras áreas de
conocimiento.

Notación musical convencional y no convencional. Partituras gráficas.

La creación musical y multidisciplinar a partir de instrumentos, objetos sonoros y la
experimentación sonora.

Sonorización de audiovisuales, imágenes y textos. El foley.

Mecanismos de creación de letras para piezas musicales.

La composición e improvisación guiada a partir del lenguaje gestual y/o gráfico.

La construcción y transformación de objetos sonoros e instrumentos musicales. Pautas básicas
de cuidado y mantenimiento de espacios y materiales de trabajo.

Recursos digitales para la interpretación y creación sonora, la edición de partituras, la
grabación y la edición de audio.

Normativa vigente en el uso y difusión de propuestas artísticas.

SB.2.2. Proyectos artísticos

Fundamentos teóricos de la producción creativa. Fases del proceso creativo y puesta en
escena.

Estudios, profesiones y oportunidades relacionados con la creación e interpretación musical.

Pautas de atención, percepción y memoria para la creación musical y artística.

Respeto y empatía con las aportaciones del grupo en el proceso de trabajo colectivo.

Recursos digitales y de las TIC aplicados a la creación y difusión de proyectos artísticos.

5. Situaciones de aprendizaje para el conjunto de las competencias de la materia

Las situaciones de aprendizaje en la materia de Creatividad Musical exigen disponer de
espacios, tiempos y formas de organización apropiados para realizar un conjunto de actividades
articuladas que promuevan la adquisición y desarrollo de las competencias específicas. Es
fundamental prestar atención al entorno pedagógico en el que se produce el proceso de enseñanza-
aprendizaje para establecer determinados principios en su diseño.

La actuación del profesorado debe estar orientada a impulsar el desarrollo de las competencias
específicas de manera progresiva y secuenciada, a partir de la consolidación gradual de los saberes
básicos propuestos.

Del mismo modo, estas situaciones y acciones deben favorecer el descubrimiento a partir de
la exploración personal y colectiva, así como contribuir a su adaptación al contexto particular de cada
centro educativo. Se debe favorecer la autoconfianza del alumnado y, en consecuencia, no se debe
penalizar el error, sino más bien identificarlo como una oportunidad para generar nuevos
planteamientos o propuestas creativas. Resulta especialmente interesante plantear aprendizajes en
forma de retos, proyectos e investigaciones a partir de la experimentación o producciones artísticas
que faciliten la aplicación de los conocimientos adquiridos, de manera individual y colectiva, y que
promuevan la transferencia de saberes en relación con otras materias.

En el entorno pedagógico en el que se desarrolla el alumnado se debe fomentar una variedad
de tipos de agrupamiento que incluya tanto propuestas individuales de desarrollo autónomo que
permitan un análisis y reflexión propio, como también la formación de pequeñas agrupaciones i el gran
grupo. Unos espacios de aprendizaje donde el alumnado muestre iniciativa y pueda asumir riesgos,
así como expresar sus propias ideas y consensuar acuerdos.

Los espacios para desarrollar el aprendizaje de la materia deben favorecer el trabajo
experimental y colaborativo con recursos materiales y digitales adecuados. Estos recursos no siempre
son posibles y, por tanto, no siempre deben estar ligados a los últimos desarrollos tecnológicos. Más

bien se trata de buscar detonantes y elementos con los que trabajar e inspirarse, a partir de la realidad
del centro y del entorno directo del alumnado.

El profesorado adquiere un papel determinante acompañando durante los procesos de
percepción, análisis, interpretación y creación, al aportar sus propias experiencias y facilitar la reflexión
e intercambio de ideas. El alumnado debería ir adquiriendo autonomía y responsabilidad, para
conseguir un equilibrio entre sus propuestas y las valoraciones orientativas realizadas sobre las
mismas.

Desde el punto de vista pedagógico, la creación implica participar activamente en la
construcción y expresión del conocimiento. Para ello, se profundizará en la música mediante la
exploración, la manipulación, la improvisación y la producción artística en general y sonora en
particular, estableciendo un vínculo entre lo didáctico y lo artístico.

Diseñar situaciones significativas de aprendizaje implica inspirarse en los intereses, referentes
culturales y experiencias del alumnado para poder establecer estos vínculos. Esta circunstancia
requiere despertar su interés y compromiso, estimular su pensamiento y dar respuesta a posibles
situaciones problemáticas.

El proceso de creación y su materialización en forma de proyectos no siempre es un proceso
lineal, concreto y cerrado, ya que se puede presentar de manera circular o siguiendo diferentes
direcciones simultáneas para obtener los resultados deseados.

Las situaciones de aprendizaje deben promover la utilización de lenguajes gestuales, gráficos
o audiovisuales que posibiliten y estimulen la creatividad y la imaginación del alumnado, así como el
desarrollo de capacidades musicales e interdisciplinares.

La notación gráfica como recurso didáctico se presenta como un punto de encuentro entre las
artes visuales y la música. La correspondencia entre elementos visuales y sonoros que se da en la
partitura gráfica favorece relaciones entre diferentes ámbitos y una visión interdisciplinar para el
alumnado. Es una oportunidad para establecer conexiones entre las materias de 3º de la ESO de
Educación Plástica y Visual y Creatividad Musical, acostumbradas a ser planteadas de forma
independiente y especializada.

Las prácticas asociadas al aprendizaje formal adquirido en niveles anteriores y al aprendizaje
informal en un entorno sonoro y musical característico de la sociedad actual se han de tener en cuenta
para que el alumnado aprenda y reflexione acerca de la música que escucha a través de diversos
medios de comunicación, en el manejo de apps musicales o en la visualización de vídeos y
videotutoriales en la red, entre otros.

Así mismo, es importante implicar al alumnado en la conservación del material, equipamiento
e infraestructuras escolares del aula, a partir de la reflexión sobre la necesidad de establecer normas
y valores que presidan sus acciones.

El uso de diversos tipos de evaluación como la heteroevaluación, la autoevaluación y la
coevaluación permiten evaluar tanto el proceso de aprendizaje como el producto final. Se debería
disponer de diversidad de instrumentos de evaluación acordes al devenir de la materia que ayuden a
comprobar el grado de adquisición del aprendizaje para poder establecer los ajustes pertinentes
durante el proceso.

Es fundamental la atención a la diversidad personal y cultural, por lo que se deberían
proporcionar espacios educativos que favorezcan la ampliación de referentes y posibiliten la apertura

de miradas frente a los retos educativos planteados, así como abordar cuestiones referidas a los roles
de género, estereotipos y expresiones de violencia en relación a la música, dentro y fuera del aula.

Los procesos de enseñanza-aprendizaje y las actividades basadas en la interpretación y
creación artística se deberán realizar siguiendo los principios del Diseño Universal de Aprendizaje.
Asimismo, se fomentará la tolerancia y el respeto a las diferentes propuestas y opiniones, reconociendo
la diversidad cultural y artística. Del mismo modo, se debe favorecer la igualdad de oportunidades en
el aprendizaje de la materia y el acceso a todo el alumnado. Todas las actividades que se realicen
deben garantizar la convivencia y los valores democráticos. Además, se debe promocionar la
participación activa en el centro y fuera de él, dando a conocer el trabajo de aula desde una perspectiva
sostenible y contribuyendo así a la consecución de los retos y desafíos del siglo XXI.

6. Criterios de evaluación

CE 1.  Identificar los elementos compositivos, estructurales y comunicativos de creaciones
sonoras e interdisciplinares contemporáneas, valorando críticamente su dimensión estética.

CE 1.1. Reconocer los elementos compositivos y estructurales de las piezas musicales e
interdisciplinares contemporáneas estudiadas, a través de la escucha y el visionado, relacionándolos
entre sí y describiéndolos mediante una terminología musical adecuada.

CE 1.2. Identificar la finalidad comunicativa de las creaciones sonoras e interdisciplinares, y
valorar su calidad artística mediante la emisión de juicios críticos y estéticos, de manera oral y escrita.

CE 1.3. Valorar la diversidad artística y cultural de las propuestas estudiadas y respetar las
aportaciones del resto del grupo.

CE 2. Analizar los elementos sonoros del entorno más cercano mediante la escucha activa, i
explorar las posibilidades que ofrecen para la creación artística.

CE 2.1. Analizar los diferentes elementos que configuran los paisajes sonoros del entorno
próximo mediante una escucha activa, proponiendo soluciones a las agresiones acústicas que lo
envuelven.

CE 2.2. Explorar las posibilidades que ofrecen los objetos y materiales del entorno en la
creación artística mediante la investigación, experimentación y transformación sonora de los elementos
que lo constituyen, con el apoyo de recursos digitales y desde una perspectiva de desarrollo sostenible.

CE 3. Interpretar piezas de música urbana y creaciones sonoras e interdisciplinares propias,
mediante el uso de la voz, el cuerpo, instrumentos convencionales y no convencionales, con el apoyo
del lenguaje musical y partituras gráficas, de manera individual y colectiva.

CE 3.1. Interpretar piezas de música urbana con el apoyo del lenguaje musical, de manera
individual y colectiva.

CE 3.2. Interpretar creaciones sonoras e interdisciplinares propias, mediante el uso de la voz,
el cuerpo, instrumentos convencionales y objetos sonoros, con el apoyo de partituras gráficas y
recursos digitales.

CE 3.3. Elaborar partituras gráficas y representaciones de notación no convencional como
apoyo a las interpretaciones y creaciones desarrolladas, para favorecer su comprensión y producción.

CE 4. Realizar improvisaciones guiadas musicales o interdisciplinares, utilizando lenguajes
gestuales y gráficos, a través de procesos individuales y colectivos.

CE 4.1. Relacionar diferentes códigos artísticos con la improvisación musical e interdisciplinar.

CE 4.2. Realizar improvisaciones guiadas musicales o interdisciplinares, mediante el uso de
lenguajes gestuales y gráficos, mostrando autoconfianza y valorando las propuestas del resto del
grupo.

CE 5. Crear y poner en escena proyectos sonoros e interdisciplinares, individuales y colectivos,
mediante el uso de diversos lenguajes artísticos, asumiendo diferentes roles en sus fases y valorando
tanto el proceso como el resultado.

CE 5.1. Participar activamente en los procesos de planificación, creación, edición y difusión de
proyectos sonoros e interdisciplinares, aportando valoraciones críticas acerca del proceso y el
resultado.

CE 5.2.  Relacionar los roles experimentados durante las fases del proceso creativo y su puesta
en escena, con las profesiones y oportunidades de desarrollo personal.

CE 5.3. Producir proyectos sonoros e interdisciplinares, mediante el uso de diversos lenguajes
musicales, corporales, gráficos, visuales, audiovisuales y/o plásticos, incorporando y relacionando
saberes adquiridos en otras materias de forma individual y colectiva.

CE 6. Emplear recursos digitales en procesos de creación sonora e interdisciplinar, mediante
la incorporación de las posibilidades expresivas, comunicativas y artísticas, con actitud reflexiva,
respetando la normativa vigente de uso y difusión.

CE 6.1. Seleccionar la información relevante y los recursos necesarios en diferentes medios
digitales durante los procesos de investigación, de manera reflexiva, crítica y contrastada.

CE 6.2. Emplear recursos digitales que favorezcan las posibilidades expresivas, comunicativas
y artísticas en procesos de creación sonora e interdisciplinar.

CE 6.3. Respetar las licencias de uso y la normativa vigente de protección de datos y autoría
durante los procesos de investigación, experimentación, interpretación, creación y difusión de las
propuestas y proyectos desarrollados.
