# EDUCACIÓN EN VALORES CÍVICOS Y ÉTICOS

> Fuente: Secundaria.pdf, páginas 699-719 (versión en castellano).

EDUCACIÓN EN VALORES CÍVICOS Y ÉTICOS

1. Presentación

La educación en valores cívicos y éticos constituye un requisito necesario tanto
para el ejercicio activo y responsable de la ciudadanía, como para el desarrollo de la autonomía
moral y la personalidad del alumnado. No hay duda de que estos dos propósitos se encuentran
relacionados entre sí, en cuanto que no es posible un ejercicio activo y responsable de la
ciudadanía democrática sin un compromiso ético personal, libre y fundamentado, con
determinados principios y valores. De ahí la necesidad de que toda educación cívica o en valores
esté traspasada por el ejercicio reflexivo y crítico sobre la moral individual y colectiva que
representa la ética filosófica.

La materia de Educación en Valores Cívicos y Éticos está vinculada a un buen
número de los objetivos considerados como necesarios de la educación secundaria. Así, con el
fin de que el alumnado sea capaz de asumir responsablemente sus deberes, se plantea la
obligación de conocer y ejercer sus derechos en el respeto a las demás personas, practicar el
diálogo, la tolerancia, la cooperación y la solidaridad entre las personas y grupos, reconocer los
derechos humanos como valores comunes de una sociedad plural y prepararse para el ejercicio
de la ciudadanía democrática. El ejercicio de dicha ciudadanía implica rechazar los estereotipos
que supongan discriminación por razón de sexo y valorar y defender la igualdad de derechos y
oportunidades de mujeres y hombres.

El aprendizaje del respeto se refiere, además, al cuidado y aceptación del propio
cuerpo y del de las demás personas, a la adopción de rutinas personales saludables y a la
valoración crítica de hábitos sociales relacionados con la salud.

Esta materia, a la vez que pone el foco de atención sobre los estereotipos y las
desigualdades, resalta la consideración de la diversidad como oportunidad de enriquecimiento
personal. Contribuye, también, a fortalecer las capacidades afectivas del alumnado en todos los
ámbitos de la personalidad y en las relaciones con las demás personas, así como a rechazar la
violencia, los prejuicios de cualquier tipo y los comportamientos sexistas, a resolver
pacíficamente los conflictos, y a adoptar pautas de comportamiento acordes con el cuidado del
planeta y los animales.

También fomenta la consolidación de hábitos de disciplina, estudio y trabajo
individual y en equipo como condición necesaria para la realización eficiente de las tareas del
aprendizaje y como vía de crecimiento personal. Además, la práctica del diálogo y el debate
impulsa la correcta comprensión y expresión de textos y mensajes complejos. Asimismo, es
relevante el dominio de destrezas básicas que permiten la utilización crítica de las fuentes de
información y comunicación y la adquisición y producción de conocimientos. Así como el poder
para potenciar las capacidades de aprender a aprender, aprender a hacer, aprender a convivir y
aprender a ser y preparar para el ejercicio de derechos y obligaciones de la ciudadanía.

En términos generales, y de acuerdo con los objetivos educativos y el perfil de
salida del alumnado al término de la enseñanza básica, la formación en valores cívicos y éticos
implica movilizar el conjunto de conocimientos, destrezas, actitudes y valores que permiten al
alumnado tomar conciencia de su identidad personal y cultural, afrontar cuestiones éticas
fundamentales, y adoptar una actitud consecuente con el carácter interconectado y
ecodependiente de su vida en relación con el entorno. Todo ello con objeto de que puedan
apreciar y aplicar con autonomía de criterio las normas y valores que rigen la convivencia en una
sociedad libre, plural, justa y pacífica.

El tipo de trabajo propuesto en esta materia se orienta a favorecer la autonomía
y los diferentes ritmos de aprendizaje del alumnado, así como a promover el trabajo en equipo.

La educación en valores cívicos y éticos es una herramienta clave para trabajar
la inclusión educativa de todo el alumnado. Asimismo, se ocupa de forma explícita de aspectos
tratados transversalmente en las otras áreas: los efectos de las tecnologías de la información y
la comunicación, el fomento de la creatividad y del espíritu crítico, la educación para la salud
afectiva y sexual, y la educación emocional y en valores. También de forma transversal conecta
con la comprensión lectora, la expresión oral y escrita y la comunicación audiovisual.

Por su especificidad, esta área reúne, destila y da consistencia a los saberes que
tienen que ver con los valores que nos convierten en seres humanos y a las habilidades, actitudes
y destrezas que han ido desgranándose a lo largo de la etapa en todas las demás áreas. El
alcance de la reflexión y el análisis ético trasciende las esferas más próximas a la vida cotidiana
del alumnado, las de los ámbitos familiar y doméstico y de los grupos sociales con los que se
relaciona más propios de primaria, y se embarca en una reflexión superior que permite ubicar al
ser humano en un contexto global con unas responsabilidades y una capacidad de acción
mayores de las imaginadas.

La materia de Educación en Valores Cívicos y Éticos plantea siete competencias
específicas que todo el alumnado debe adquirir para la culminación de los objetivos de la etapa
y del perfil de salida del alumnado de la educación básica. Dichas competencias son una
ampliación de las adquiridas en primaria y giran alrededor de la capacidad de dialogar y del uso
correcto de los argumentos para llegar a acuerdos; del reconocimiento y gestión de las
emociones para hallar soluciones desde la cultura de la paz; del análisis de la legitimidad de las
normas a la luz de los derechos humanos; del rechazo de los estereotipos; de la comprensión
de la importancia global de los valores democráticos; de la lucha contra las desigualdades e
injusticias; y del compromiso con la transformación del planeta a partir de los Objetivos de
Desarrollo Sostenible.

La formulación de cada competencia específica va acompañada de una
descripción detallada del sentido y la fundamentación de lo que se espera que el alumnado sea
capaz de movilizar para su consecución y desarrollo. Además de la descripción, se señalan las
conexiones de cada una de las competencias con otras materias del currículo, que ayudan al
docente a plantear el trabajo de manera coordinada, incrementándose así el carácter significativo
del aprendizaje y la eficiencia del proceso de enseñanza.

Todas las competencias aquí planteadas adquieren un mayor grado de
concreción a la luz de los criterios de evaluación diseñados a tal efecto. Criterios que facilitan la
observación y la valoración del progreso del alumnado en el transcurso de su adquisición.

Todo ello puede ponerse en juego a partir de las sugerencias y recomendaciones
recogidas en las situaciones de aprendizaje, que presentan escenarios y posibilidades
organizativas propicias para el trabajo competencial y su observación y seguimiento.

Los saberes básicos considerados esenciales para el trabajo competencial del
alumnado están planteados de acuerdo con los cinco ejes que ordenan y organizan los Objetivos
de Desarrollo Sostenible. De este modo, es mucho más fácil relacionar el trabajo del aula con
los retos que inducen a colaborar en la mejora del planeta y aumenta el arco de posibilidades
didácticas del profesorado. Esos cinco ejes, conocidos como las 5 “pes” son: Persona, Paz,
Prosperidad, Planeta y Participación.

El bloque Persona contiene los saberes que promueven la reflexión a propósito
del bienestar físico y emocional propio y ajeno, la diversidad, la igualdad entre mujeres y hombres
y el valor de la educación.

En el bloque Paz, se hallan los saberes que permiten abordar la resolución de
conflictos y los derechos y deberes de las personas.

En el bloque Prosperidad, se incluyen la Agenda 2030 y los Objetivos de
Desarrollo Sostenible, en su vertiente relacionada con la sostenibilidad, el análisis y reducción
de las desigualdades y discriminaciones que se generan por diversos motivos, la función social
de los impuestos y la justicia fiscal.

En el bloque Planeta se hace referencia a los contenidos de la Agenda 2030 y
los Objetivos de Desarrollo Sostenible más relacionados con la ciudadanía global, el consumo
responsable y el uso sostenible de la tecnología.

El bloque Participación se centra en las habilidades, por un lado, y en los
ámbitos, por otro, que hacen posibles los procesos participativos en los ámbitos local, nacional
e internacional.

Finalmente, tanto la aplicación de los criterios de evaluación como las
actividades de aprendizaje deben estar metodológicamente orientadas en función de principios
coherentes con los valores que pretende transmitir el área. Por lo tanto, se invita al alumnado a
la participación activa y razonada, al diálogo respetuoso y la cooperación, a la libre expresión de
ideas, al pensamiento crítico y autónomo, al respeto de las normas y valores comunes, a la
gestión asertiva de sus emociones y relaciones afectivas, a la mediación y resolución pacífica de
los conflictos, al desarrollo de hábitos de vida saludables y sostenibles, y al uso seguro de las
tecnologías de la información y la comunicación. Además, se contribuye al reconocimiento del
vínculo imprescindible entre teoría y práctica, procurando integrar las actividades del aula en
contextos de aprendizaje más amplios e interdisciplinares del centro y su entorno. Todo ello para
promover el desarrollo de una ciudadanía global, consciente, libre, participativa y comprometida
con los retos del siglo XXI.

2. Competencias específicas

2.1. Competencia específica 1

Dialogar y debatir de forma asertiva, respetuosa y correctamente argumentada
sobre problemas morales planteados en cualquier situación de la vida diaria para poder llegar a
acuerdos o consensos.

2.1.1. Descripción de la competencia 1

La capacidad de mantener un diálogo respetuoso, razonado y constructivo es una de las
habilidades esenciales para enfrentarse con garantías a situaciones que se generan tanto en la
esfera de la vida pública como de la privada.

El diálogo que se constituye en debate, además, implica la escucha activa de todas las
partes en discusión, el uso correcto de los argumentos centrados en el problema, de los turnos
de palabra y de un lenguaje no sexista, respetuoso e igualitario. Todo esto pasa por la
consideración como interlocutoras válidas de todas y cada una de las personas que participan
en el mismo.

Ejercido en estos términos, el sentido del debate se transforma. El alumnado entiende
que el objetivo ya no es tener razón, sino ser capaz de exponer de manera clara y razonada la
propia postura o pensamiento y acceder, a través de la escucha de las aportaciones del resto de
participantes, a una comprensión más completa de situaciones complejas.

Este diálogo se nutre de todas las experiencias, preocupaciones e intereses que se
desprenden del proceso que vive el alumnado en su intento de ubicarse en el mundo.

Dialogar comporta la capacidad de analizar e interpretar hechos, emociones o
situaciones, ordenar la información, someterla a crítica y seleccionarla, establecer relaciones y
extraer conclusiones a partir de valores asumidos de forma reflexiva. Además, la capacidad
crítica necesaria para todo diálogo y debate implica la no aceptación de ideas contrarias a los
valores contenidos en la Declaración Universal de los Derechos Humanos y que atenten contra
la dignidad de otras personas.  El requisito del uso correcto de los enunciados supone el
conocimiento de la lógica del discurso y la aplicación adecuada de las reglas, tanto formales
como de contenido, evitando caer en falacias argumentativas que alejan el discurso del problema
real que se está planteando.

La adolescencia es el momento en que los problemas morales adquieren mayor
relevancia y en el que el alumnado empieza a definir su posición frente al mundo. Es el momento
también de que tome conciencia de la evolución moral que ha ido experimentando a lo largo de
la etapa.

La consecución de acuerdos y consensos requiere empatía, tolerancia y capacidad
crítica para poder modificar el propio punto de vista en base a otras aportaciones.

Durante toda la secundaria el alumnado desarrolla y va consolidando progresivamente
las habilidades propias de esta competencia a través del trabajo cooperativo, actividades de
debate, exposiciones orales en todas las materias y en el tiempo dedicado a la tutoría.

2.2. Competencia específica 2

Gestionar las emociones en situaciones de conflicto para poder afrontarlas desde la
cultura de la paz y explorar y proponer soluciones equitativas y creativas.

2.2.1. Descripción de la competencia 2

El reconocimiento de las propias emociones es esencial para el desarrollo y crecimiento
personal y para la identificación y comprensión de las emociones ajenas, así como para su
gestión en la vida cotidiana y, especialmente, en situaciones de conflicto inherentes a todos los
ámbitos de las relaciones humanas.

Las relaciones interpersonales implican la compleja relación con proyectos de vida en
los que las posiciones, intereses y necesidades de las personas no coinciden necesariamente, y
en los que la gestión de las emociones es esencial porque permite afrontar los conflictos
mediante el diálogo, la asertividad y la empatía.

Para lograr una convivencia más pacífica, en el entono educativo y social, hace falta que
el alumnado sea suficientemente competente para convertirse en personas constructoras de la
paz, tanto por lo que se refiere a las habilidades personales de relación y convivencia, como a
las de análisis de conflictos y situaciones complejas en los ámbitos personal, educativo y social.
Eso conlleva la construcción de relaciones desde el reconocimiento de las demás personas, la
horizontalidad y el cuidado mutuo, la comunicación no violenta y la capacidad de cooperar. Es
necesario, por tanto, la revisión crítica de la cultura de la violencia que impregna cualquier ámbito
social, incluido el educativo. El conocimiento, el reconocimiento y el análisis de los diferentes
tipos de violencia –directa, cultural y estructural- contribuirán a la consecución de este fin.

En esta etapa educativa el reto consiste en adquirir las capacidades individuales y
colectivas para afrontar y transformar los conflictos sin violencia. Canalizar la agresividad,
entendida como fuerza vital, prepara al alumnado para este propósito y ofrece un abanico de
oportunidades para impulsar la creatividad, la resiliencia y el desarrollo personal. Aceptar el
conflicto como un hecho inevitable y natural en las relaciones humanas es un ejercicio
democrático y, sobre todo, de respeto a la diversidad.

En definitiva, la cultura de la paz aporta el reconocimiento de que la paz debe formar

parte de la cultura y al mismo tiempo prepara para una ciudadanía proactiva frente a las
situaciones de injusticia, discriminación y exclusión.

La cultura de la paz se construye con prácticas cotidianas: igualdad de género, justicia,
participación democrática, respeto a los derechos humanos, libre circulación de la información,
desarrollo económico y social sostenible, etc., conectando con los Objetivos de Desarrollo
Sostenible de la Agenda 2030.

En primaria, el alumnado se ejercita en la identificación y autorregulación de las
emociones básicas propias y en el reconocimiento de las ajenas, lo cual facilita el uso de
estrategias sencillas para abordar pacíficamente los conflictos. En secundaria, se profundiza en
la gestión de las emociones y en las estrategias de resolución de conflictos. El alumnado también
debe ser capaz de diferenciar y separar los conflictos de las personas. Además, se potencia la
capacidad de explorar y proponer soluciones equitativas y creativas mediante el estudio y análisis
de las causas y consecuencias de los conflictos personales e históricos, actuales, nacionales e
internacionales.

2.3. Competencia específica 3

Analizar de forma crítica las normas y leyes vigentes en el marco de la Declaración
Universal de los Derechos Humanos y adecuarse a ellas valorando su legitimidad.

2.3.1. Descripción de la competencia 3

La comprensión de las normas que regulan la convivencia y la manera de interactuar con
las demás personas es el punto de partida para que el alumnado sea capaz de entender su
necesidad y de analizarlas de manera crítica.

La comprensión de las normas posibilita varias cosas. Por un lado, facilita su
interiorización y asunción y el compromiso con el hecho de respetarlas con responsabilidad. Por
otro, promueve la participación activa y la reflexión asociada a la misma y prepara para el
ejercicio de una ciudadanía crítica capaz de cuestionar aquellas normas que se consideren
injustas o ilegítimas. La comprensión de las normas se refuerza si ese análisis va referido a
diferentes contextos sociopolíticos y culturales. Esa conciencia, permite plantear soluciones o
alternativas creativas.  Todo ello se desarrolla haciendo uso de un lenguaje inclusivo e igualitario
que dota de coherencia a todo el proceso.

Esta competencia específica se ejercita a lo largo de la etapa de primaria mediante la
participación del alumnado en la elaboración de las reglas de convivencia escolar. En secundaria,
se aborda desde una perspectiva diferente, entrando en juego el análisis de los marcos
normativos que regulan la convivencia social y en cuya elaboración el alumnado no ha
participado directamente. El hecho de que en las diferentes materias de los primeros cursos se
estudien otras realidades históricas, políticas y culturales facilita la comprensión de que los
códigos normativos, al igual que las estructuras políticas, son realidades temporales vinculadas
a la historia.

2.4. Competencia específica 4

Reconocer, denunciar y combatir los estereotipos y roles asociados a partir de una
reflexión personal y crítica.

2.4.1. Descripción de la competencia 4

En un mundo globalizado y cambiante como el actual, las sociedades cada vez son más
diversas y plurales. En este contexto, las conductas y acciones que pueden conducir hacia un
desarrollo personal autónomo y libre se sustentan en el análisis crítico previo de los estereotipos
sociales de la cultura propia y de otras culturas. El respeto a cualquier identidad personal, con

independencia de que se ajuste o no a los estereotipos sociales, implica tener en cuenta la
dignidad de las personas y sus derechos individuales. Ahora bien, respetar no significa asumir
de un modo acrítico las ideas, opiniones, creencias e identidades de las personas. Especialmente
si se basan en prejuicios y estereotipos que generan discriminaciones y exclusión a todas
aquellas personas que no se ajustan a los modelos imperantes.

La dignidad humana, la condición del ser humano y los derechos individuales están
reconocidos en la Declaración Universal de los Derechos Humanos, resultado de la evolución
histórica de la humanidad y marco para la convivencia aceptado por la mayoría de estados del
mundo. Por ello, el análisis crítico comporta entender que los modelos sociales y las diferentes
expresiones culturales son discutibles y renovables. Eso permitirá la propuesta y desarrollo de
acciones y conductas que deben favorecer un desarrollo autónomo y libre y contribuir a la cultura
de la paz y a la construcción de sociedades inclusivas.

Esta competencia potencia la autonomía y la libertad del alumnado a la hora de tomar
decisiones y de definir su identidad personal en todos sus ámbitos (religiosa, de género, estética,
estilo de vida, entre otras), ya que permite la duda en relación a las ideas mayoritarias y la libertad
de definirse y expresarse en contra y de discrepar respecto a lo que nos encasilla en un marco
predeterminado por una estructura patriarcal y etnocéntrica. También facilita proponer y
desarrollar acciones que contribuyen a la construcción de identidades y personalidades
saludables que tienen como origen y meta la dignidad humana.

Además, la discusión, el diálogo y el debate fomentan la libertad de expresión y de
definición personal, y son la esencia de la participación democrática.

En primaria se ha trabajado el análisis de estereotipos con el objeto de propiciar el
reconocimiento y la aceptación de las emociones y sentimientos propios y ajenos, y la
interiorización de conductas igualitarias entre el alumnado para luchar contra la discriminación y
cualquier trato injusto por razones de etnia, sexo, género, pobreza, pertenencia a un colectivo
minoritario, diversidad funcional u otras. En esta etapa, se profundiza en este análisis y se amplía
desde el reconocimiento de la dignidad humana y la comprensión de que los derechos
individuales son el resultado de la evolución histórica y están recogidos en la Declaración
Universal de los Derechos Humanos. Eso posibilita su revisión crítica desde una perspectiva
interseccional, que se refiere a la confluencia de diversas desigualdades en la misma persona, y
la propuesta y desarrollo de acciones libres de discriminaciones de acuerdo con su marco ético.

2.5. Competencia específica 5

Identificar, analizar y valorar en el ámbito internacional los beneficios de los valores
democráticos promovidos por leyes e instituciones para la construcción de una ciudadanía
global.

2.5.1. Descripción de la competencia 5

Los seres humanos somos animales sociales, nos definimos por nuestra relación con las
demás personas. Esa relación con los otros miembros de la especie no está determinada, como
sucede en otras especies, por la genética, sino que se construye a partir de diferentes valores e
ideales que producen distintas sociedades con culturas distintas y distintos sistemas de
organización política. Tal y como se ha señalado a lo largo de la historia de la filosofía, solo en
el contexto de la convivencia política puede el ser humano desarrollarse de forma plena. Es por
ello que la comprensión de las relaciones sociales que construimos y de la democracia como
contexto de dichas relaciones cobra una relevancia enorme.

La democracia aboga por el respeto y la defensa de los derechos de la ciudadanía,
entiende que todas las personas son iguales en dignidad y derechos, y dispone de mecanismos
de control para los abusos del poder tanto político como económico. Este sistema permite,

también, la discusión y el debate que hacen posible que esos valores que determinan la sociedad
sean consensuados y compartidos. Pero la democracia, para ser activa, requiere de la
participación de una ciudadanía formada y crítica capaz de identificar los elementos que
destruyen la convivencia igualitaria, respetuosa y justa. Requiere, también, del compromiso
social para producir las mejoras y transformaciones necesarias que conduzcan a una sociedad
equitativa en la que cualquier ciudadana o ciudadano disfrute de manera plena de sus derechos.
Ese compromiso toma forma a partir del rechazo de los prejuicios y estereotipos que generan
situaciones de discriminación y violencia.

El alumnado comprende que su participación es motor fundamental de la mejora y el
cambio social y que tomar parte en los procesos sociales se convierte, por tanto, en un derecho
y una responsabilidad. Este compromiso abarca tanto la esfera académica como la familiar,
pasando por todos los círculos de relaciones (amistades, equipos deportivos, etc.) que establece
en la vida diaria. Es por esto que tener una actitud y comportamiento democráticos se convierte
en eje de una personalidad saludable, justa e igualitaria.

Dado que vivimos en un mundo global e hiperconectado, las acciones y los compromisos
que el alumnado es capaz de emprender y contraer en la lucha contra todo tipo de desigualdades
e injusticias tienen, a su vez, un efecto global; no quedan circunscritos a su entorno próximo. Por
tanto, la acción moral responsable adquiere una mayor relevancia.

También los retos de la democracia se globalizan. Esto supone la existencia de leyes e
instituciones internacionales encargadas de velar por la defensa de los valores democráticos a
escala planetaria. En este contexto adquieren una importancia esencial la Declaración Universal
de los Derechos Humanos y la consideración de la intrínseca dignidad de toda persona más allá
de cualquier diferencia.

A lo largo de la educación secundaria multitud de aprendizajes contribuyen a la
adquisición de esta competencia, puesto que para llegar a ella son necesarios el desarrollo de
otras habilidades y la adquisición de numerosos conocimientos que ayuden al alumnado a
ubicarse en el mundo actual. Desde el trabajo con las emociones, la asertividad, la comunicación
no violenta o la resolución dialogada de los conflictos, hasta los conocimientos que permiten
entender la interrelación de múltiples realidades políticas, económicas, sociales, etc., en un
mundo globalizado.

2.6. Competencia específica 6

Proponer y desplegar acciones responsables y justas comprometidas con la
transformación social y la lucha efectiva contra las desigualdades e injusticias en cualquier
situación real de acuerdo con los principios de una sociedad igualitaria e inclusiva.

2.6.1. Descripción de la competencia 6

El hecho de vivir en un mundo globalizado e hiperconectado pone al alcance todo un
horizonte de experiencias y escenarios que también implica una mayor exposición a situaciones
de desigualdad e injusticia. La existencia de normas, leyes y marcos reguladores no es garantía
de justicia social. Es por ello que el alumnado debe ser especialmente sensible a las situaciones
de injusticia, promover el cambio mediante acciones responsables y justas y adquirir, en
definitiva, un compromiso moral de transformación basado en la dignidad intrínseca de todo ser
humano y en la conciencia de que la acción comprometida genera el bien común.

Educar para una conciencia crítica y el fomento de la colaboración con aquello que
consideramos justo y la no colaboración con aquello que consideramos injusto, está en la base
de la “noviolencia” y la cultura de la paz. La “noviolencia” entendida como estrategia de
empoderamiento para desmontar la creencia de que no se puede hacer nada para cambiar las
cosas y promover acciones proactivas enmarcadas en los derechos humanos.

Otro objetivo esencial es que el alumnado sea capaz de entender que los hechos locales
y los globales guardan una estrecha conexión y que, por lo tanto, la denuncia de las injusticias y
desigualdades de su entorno y la acción sobre las mismas tienen repercusiones globales. El
estudio y visibilización de personas cuya defensa de los derechos humanos o denuncia de sus
propias vivencias ha trascendido a la esfera global, convirtiéndose en referentes, ponen el foco
en la importancia de la implicación individual en la transformación social.

Para poder lograr y desarrollar esta competencia específica, el alumnado necesita
capacidad y conciencia crítica ante las situaciones que comportan discriminación y trato injusto
por razón de sexo, género, pobreza, pertenencia a un colectivo minoritario, diversidad funcional
u otras. También debe ser capaz, por un lado, de proponer e involucrarse en iniciativas y
acciones que reajusten los desequilibrios de poder que se dan en las circunstancias
mencionadas, y por otro, de promover la no cooperación con las injusticias. Cabe prestar especial
atención, por su relevancia social y dramáticas consecuencias, a la prevención de la violencia
machista y al fomento de la igualdad entre mujeres y hombres.

Las contribuciones que realiza la ciudadanía son esenciales para garantizar los derechos
de todas las personas. Es por ello que el alumnado ha de aprender el valor social de los
impuestos y su vinculación con el gasto público para favorecer la consecución de una sociedad
más justa y entender su papel solidario. Ha de ser consciente también de que la evasión fiscal y
sus conductas defraudadoras generan desigualdad y unos costes sociales perjudiciales para la
sociedad en su conjunto.

Asumir un papel activo, en la propuesta de acciones transformadoras comporta
reconocer los indicios de discriminación e inequidad, diseñar estrategias con pasos concretos y
factibles que permitan conseguir los hitos propuestos, negociar para determinar las acciones a
llevar a cabo, denunciar los casos de acoso y exclusión en los ámbitos escolar, local y social y
no colaborar como espectadoras o espectadores pasivos con ningún tipo de acoso producido en
el centro escolar o difundido en las redes sociales o por los medios de comunicación.

El reconocimiento, denuncia y gestión de las desigualdades e injusticias se trabajan a lo
largo de toda la etapa de manera explícita en los planes de acción tutorial, programas de
prevención del acoso y de ayuda entre iguales, talleres, etc., y, de manera transversal, en las
diversas materias a través de contenidos relacionados con antecedentes históricos de
discriminación, con la posición de la mujer a lo largo de la historia, etc.

2.7. Competencia específica 7

Explicar los desafíos ecológicos planteados por los Objetivos de Desarrollo Sostenible y
actuar de manera comprometida con la transformación de la situación medioambiental del
planeta.

2.7.1. Descripción de la competencia 7

El alumnado forma parte de un entorno con el que se relaciona a diferentes niveles, pero
en todos ellos hay una interacción con el medio ambiente que tiene que ser respetuosa y
sostenible y promover la asunción de compromisos que conduzcan a ese fin y a la consecución
de los Objetivos de Desarrollo Sostenible.

Para la adquisición de esos compromisos, debe producirse previamente una reflexión
crítica que permita entender que cada acción cotidiana individual tiene un efecto global. Esa
comprensión estimula el cambio de hábitos alimentarios y de consumo y la adopción de acciones
en pro del ahorro y la eficiencia energéticos e impulsa el avance en el camino de la sostenibilidad
ecológica tal como marca la Agenda 2030.

Esta competencia fomenta, por tanto, el activismo cotidiano con actuaciones que tienen
lugar dentro y fuera del centro escolar. Por una parte, promocionando el reciclaje, la reducción y
la reutilización; el cuidado del material, equipamiento y espacios; el uso racional de los recursos,
etc., y por otra, mediante la interacción con los diversos organismos y entidades sociales
proactivos con respecto al medio ambiente, participando en campañas municipales y de
diferentes asociaciones de mejora del entorno urbano y natural; en proyectos sociales y
humanitarios, etc.

Así, el alumnado comprende que, además de modificar los hábitos de conducta poco
sostenibles relacionados con el consumo y el uso abusivo de recursos, tiene que implicarse en
la protección de la naturaleza y conservación de la diversidad de los ecosistemas, y que hay que
transformar la relación que como especie hemos establecido con el resto de especies animales,
cambiando la perspectiva de dominación por otra de convivencia y respeto. Entiende, en
definitiva, que es vital para nuestra supervivencia establecer una relación saludable con el
planeta y que al cuidarlo nos cuidamos.

A lo largo de la etapa de primaria, el alumnado ha adquirido hábitos ecológicamente
sostenibles y con repercusiones en su entorno cercano y en la lucha contra el cambio climático
y desarrollando una conciencia crítica del impacto de sus acciones. Ahora consolida la adopción
de hábitos sostenibles y compromisos proactivos no sólo en el ámbito local, sino también en el
global.  Además, reflexiona y analiza la información que le llega por diferentes canales para
interiorizar y aplicar esas acciones y entender que las mismas pueden ser transferibles a otros
ámbitos.

3. Conexiones de las competencias específicas entre sí, con las competencias de otras
materias y con las competencias clave

3.1. Relaciones o conexiones con las otras CE del área

El carácter instrumental de la CE1 la vincula de forma directa con el resto de
competencias específicas de esta materia puesto que el trabajo se lleva a cabo a través de la
cooperación, el diálogo y el debate asertivo y respetuoso.

La CE2 está relacionada también con la CE4 porque la gestión razonada y crítica de los
conflictos desde la perspectiva de la cultura de la paz contribuye a la construcción de un modelo
de relaciones igualitarias.

La CE3 conecta con las CE1 y CE2 en la medida en que ambas preparan en el proceso
madurativo del autoconocimiento para la interacción con las demás personas, en sintonía con
los procesos democráticos y con el objetivo de llegar a acuerdos de manera dialogada en el
marco de la cultura de la paz.

La CE4, puesto que se refiere a los estereotipos y los roles que se derivan de ellos, se
vincula con la lucha contra cualquier tipo de injusticia que se propone en la CE6.

La CE5 se relaciona con todas las demás, pues el compromiso con el desarrollo de una
sociedad democrática, justa, igualitaria e inclusiva precisa del diálogo constructivo, la resolución
de conflictos desde la asunción de la cultura de la paz, el análisis crítico de las normas y su
fundamentación en la Declaración Universal de los Derechos Humanos, la construcción de una
identidad crítica con los estereotipos y el compromiso con el desarrollo sostenible.

La CE6 conecta con las cinco anteriores. Con la CE1 porque el diálogo y debate asertivos
y respetuosos vehiculan las propuestas de actuaciones ante situaciones de desigualdad e
injusticia social. Con la CE2 y la CE4 ya que requiere la gestión de las emociones durante los
conflictos generados por discriminaciones, maltratos y estereotipos. Con la CE3 y la CE5 porque
solo el análisis crítico de las desigualdades e injusticias en el marco de los derechos humanos,

leyes e instituciones internacionales puede conducir a acciones realmente transformadoras.

La CE7 se relaciona con la CE1 y CE2 puesto que prepara para llegar a consensos y
afrontar situaciones de conflicto a propósito de la sostenibilidad del planeta a través del diálogo
y el debate democrático. Asimismo, se relaciona con la CE3 en la medida en que la revisión
crítica de los marcos normativos que regulan la convivencia comprende la legislación vigente en
relación a la sostenibilidad del planeta. También conecta con la CE6, dado que las desigualdades
e injusticias a menudo se derivan del deterioro natural provocado por la acción humana.

3.2. Relaciones o conexiones con las CE de otras materias de la etapa

Las competencias CE1 y CE2, por los saberes esenciales que movilizan, constituyen el
fundamento sobre el que se construyen las competencias que se trabajan en el resto de materias.
La capacidad de argumentar, la escucha activa, la gestión de las emociones y la resolución
dialogada de los conflictos son necesarias tanto en la discusión sobre hipótesis, como durante la
organización de un equipo en una actividad física o en el trabajo en un proyecto de cualquier
materia.

La adquisición de las competencias de esta materia depende tanto del trabajo transversal
como de los aprendizajes que se llevan a cabo en todas las materias de la etapa.

Las lenguas (vehículos para la comprensión y expresión de emociones, hechos,
conceptos y pensamientos, materia primera de producciones textuales escritas, orales y
multimodales que informan y sirven de punto de partida para el abordaje de los saberes
esenciales, vías de acceso al conocimiento de otras realidades lingüísticas, sociales y culturales
y herramientas para la planificación de acciones transformadoras) ponen sus prácticas
comunicativas al servicio de la construcción de la conciencia ética individual y de la convivencia
democrática (CE1-CE7 de la materia de Educación en Valores Cívicos y Éticos).

La materia de Educación en Valores Cívicos y Éticos comparte con la de Geografía e
Historia cuestiones axiológicas fundamentales y el interés por las cuestiones éticas más
relevantes del mundo actual. En concreto, las competencias CE4, CE5, CE6, CE7 y CE8 de
Geografía e Historia con CE1, CE2, CE, CE6 y CE7 de Educación en Valores Cívicos y Éticos
en la medida en que se refieren al análisis crítico de las normas; a la diferencia entre legalidad y
legitimidad; al análisis de hechos históricos y de la actividad económica;  al reconocimiento,
denuncia y combate de los estereotipos y roles sociales que permite un saber y una práctica
igualitarios e inclusivos; a  la construcción de una ciudadanía global; al compromiso con los
valores democráticos y con la lucha para conseguir justicia social; y a la importancia de los
desafíos que plantean los Objetivos de Desarrollo Sostenible.

También se dan estas coincidencias, desde el análisis del origen y la génesis de nuestra
concepción actual del mundo, con las competencias CE1, CE2 y CE5 de la materia de Cultura
Clásica.

Con respecto a Educación Plástica y Visual, las CE1, CE2, CE3, CE4 y CE5 guardan
relación con las competencias CE1, CE2, CE4, CE5 y CE6 de Educación en Valores Cívicos y
Éticos, puesto que se refieren a la capacidad de hacer un análisis crítico de la realidad y proponer
soluciones creativas; a compartir y defender ideas diversas de forma asertiva, y a trabajar las
emociones y construir una identidad propia de forma consciente y crítica. Estas mismas
relaciones se pueden establecer con las competencias CE1, CE4 y CE5 de la materia de Música.

Por lo que toca a Educación Física, las competencias CE1, CE4 y CE5 guardan relación
directa con las competencias CE1, y CE4 de Educación en Valores Cívicos y Éticos en la medida
en que fomentan el bienestar físico y emocional; el autoconocimiento a partir de la crítica de los
estereotipos que afectan a la percepción del propio cuerpo y a la construcción de la identidad
personal; el respeto a las diferencias culturales; el uso responsable de los dispositivos

electrónicos y el desarrollo de la conciencia ecológica.

Coinciden Biología y Educación en Valores Cívicos y Éticos en los planteamientos
referidos a la valoración crítica de la información; la promoción de hábitos saludables; el respeto
por diferentes formas de vida y diversas identidades de género; el fomento de la responsabilidad
y el análisis crítico del efecto de la acción humana y la propuesta de soluciones ecosociales. En
concreto las competencias CE3, CE5, CE6, CE7, CE10 y CE11 de Biología con CE4, CE5, CE6
y CE7 de Educación en Valores Cívicos y Éticos.

La relación con las competencias CE3 y CE4 de Física con CE1 y CE4 de Educación en
Valores Cívicos y Éticos se circunscribe a la defensa del pensamiento crítico y del uso preciso
de los conceptos y los argumentos.

También la importancia que se da en las competencias CE1 y CE2 de Educación en
Valores Cívicos y Éticos al reconocimiento y gestión de las emociones y al trabajo asertivo y
respetuoso en grupo, las vincula con la competencia CE8 de Matemáticas.

Por último, coinciden en la necesidad de analizar las repercusiones sociales de la acción
humana y plantearse la sostenibilidad, así como en la necesidad de que el alumnado sea capaz
de proponer acciones responsables, justas y comprometidas frente a los desafíos del mundo
actual las competencias CE4 y CE7 de Tecnología y Digitalización con CE6 y CE7 de Educación
en Valores Cívicos y Éticos.

3.3. Relaciones o conexiones con las competencias clave

El cuadro adjunto muestra la existencia de una relación especialmente significativa y
relevante entre las siete competencias específicas de esta materia y algunas competencias clave
incluidas en el perfil de salida del alumnado al finalizar la educación básica.

|  | CCL | CP | CMCT | CD | CPSAA | CC | CE | CE |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 | X | X |  | X |  | X |  |  |
| CE2 |  |  |  | X | X | X |  | X |
| CE3 |  |  |  | X | X | X |  |  |
| CE4 | X | X |  |  | X | X |  |  |
| CE5 | X |  |  | X | X | X |  | X |
| CE6 | X |  |  | X | X | X | X |  |
| CE7 |  |  | X | X | X | X | X |  |

Competencias específicas del área:

•
CE1: Dialogar y debatir de forma asertiva, respetuosa y correctamente
argumentada sobre problemas morales planteados en cualquier situación de la vida diaria para
poder llegar a acuerdos o consensos.

•
CE2: Gestionar las emociones en situaciones de conflicto para poder afrontarlas
desde la cultura de la paz y explorar y proponer soluciones equitativas y creativas.

•
CE3: Analizar de forma crítica las normas y leyes vigentes en el marco de la
Declaración Universal de los Derechos Humanos y adecuarse a ellas valorando su legitimidad.

•
CE4: Reconocer, denunciar y combatir los estereotipos y roles asociados a partir
de una reflexión personal y crítica.

•
CE5: Identificar, analizar y valorar en el ámbito internacional los beneficios de los
valores democráticos promovidos por leyes e instituciones para la construcción de una
ciudadanía global.

•
CE6: Proponer y desplegar acciones responsables y justas comprometidas con
la transformación social y la lucha efectiva contra las desigualdades e injusticias en cualquier
situación real de acuerdo con los principios de una sociedad igualitaria e inclusiva.

•
CE7: Explicar los desafíos ecológicos planteados por los Objetivos de Desarrollo
Sostenible y actuar de manera comprometida con la transformación de la situación
medioambiental del planeta.

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

•
CCL: competencia en comunicación lingüística
•
CP: competencia plurilingüe
•
CMCT: competencia matemática, ciencia y tecnológica
•
CD: competencia digital
•
CPSAA: competencia personal, social y de aprender a aprender
•
CC: competencia ciudadana
•
CE: competencia emprendedora
•
CCEC: competencia en conciencia y expresión cultural

En primer lugar, la CE1 se relaciona con la CCL, dado que se trata de que el alumnado
sea capaz de comprender y exponer de manera clara, argumentada y razonada las propias ideas.
Además, se relaciona con la CPSAA, puesto que está muy conectada con la capacidad de
entender las experiencias, emociones e ideas ajenas e incorporarlas al propio aprendizaje.
Asimismo, con la CD, ya que, para la preparación y defensa de la argumentación, también es
importante analizar informaciones de diversas fuentes, comprender e interpretar de forma crítica
textos para construir conocimiento, y contrastar la información para evaluar su fiabilidad y poder
comunicarla de manera veraz y crítica.

En segundo lugar, la CE2 está conectada con la CPSAA, dado que el reconocimiento de
las demás personas desde la horizontalidad y el cuidado mutuo, la comunicación no violenta y la
capacidad de cooperar, permite el establecimiento de relaciones que propician la regulación y
expresión de las emociones desde la autoeficacia y la resiliencia. Por otra parte, la libre expresión
de ideas, opiniones, sentimientos y emociones de manera creativa la asocia con la CCEC. Se
refuerza la CD en la medida en que el alumnado tiene la oportunidad de afrontar los conflictos
de acuerdo con los principios de un marco ético digital.

En tercer lugar, la CE3 se vincula especialmente con la CD pues se hacen necesarios el
conocimiento y el respeto de un marco normativo regulador de las interacciones del alumnado
en el uso de Internet, que fomenta la convivencia democrática en los entornos digitales.  Además,
la maduración personal que esta competencia específica supone y su transferencia a las
relaciones que se establecen, la conectan también con la CPSAA.

En cuarto lugar, la CE4 está vinculada con la CCL a través de la necesidad de detectar
y rechazar usos sexistas, racistas y clasistas de la lengua y los abusos a través de la palabra.
También con la CP en la medida en que valora y respeta la diversidad lingüística y cultural
favoreciendo la cohesión social. La CPSAA impregna esta competencia específica, ya que
fortalece el optimismo y la resiliencia y la gestión de los retos y cambios que van surgiendo.

En quinto lugar, la CE5 conecta con la CCL en la medida en que se pone la práctica
comunicativa al servicio de la convivencia democrática. También con la CCEC puesto que

considera beneficiosos para la convivencia democrática el fomento y la protección de la
diversidad lingüística y cultural. La CD cobra especial relevancia a través del análisis de la forma
en que los canales de comunicación y difusión influyen en la construcción de una democracia
igualitaria, participativa y responsable. La CPSAA entronca con la intención de construir espacios
de vida justos y democráticos.

En sexto lugar, la CE6 se vincula con la CCL, porque la lengua es un elemento clave al
servicio de la lucha contra las desigualdades y de la transformación social. La capacidad de
analizar de manera crítica las situaciones de injusticia asocia esta competencia específica a la
CPSAA. El diseño de estrategias concretas y factibles para luchar contra las injusticias en el
entorno cercano y en la sociedad en general refuerza la CE. El contexto digital, tan presente en
la vida del alumnado, es también un canal para la detección y denuncia de actitudes
discriminatorias e injustas y, a la vez, una vía de difusión de acciones para combatirlas.

Por último, la CE7 conecta con la CMCT puesto que las actuaciones para la
transformación sostenible del entorno deben tener en cuenta su impacto global y estar
científicamente fundamentadas. También con la CPSAA, que permite los procesos de
maduración que harán posible la deseada sostenibilidad y el equilibrio ecológico, y entronca con
la CE pues moviliza la implicación activa del alumnado y su compromiso con la
transformación. Asimismo, se vincula con la CD, planteando la reflexión acerca de los límites de
los entornos digitales por razones de sostenibilidad medioambiental.

4. Saberes básicos

4.1. Introducción

La estructura de la organización de los saberes básicos que se presenta a continuación
se corresponde con la agrupación en cinco dimensiones de los objetivos de la Agenda 2030, ya
que éstas dan respuesta a las exigencias planteadas por las siete competencias específicas del
área y, a la vez, están en consonancia con el contenido de los planes de atención a la diversidad,
acción tutorial e igualdad y convivencia de los proyectos educativos de los centros. A partir de
los aspectos que trabajan la individualidad equilibrada, se avanza hacia el desarrollo de las
interacciones de los diferentes momentos y espacios de la esfera social.

El primer bloque trata de las personas, de los factores que inciden en su bienestar físico
y emocional, del valor de la diversidad, del papel de la reflexión y la educación y de la
coeducación que aspira a sentar las bases para la igualdad real entre mujeres y hombres.

El segundo se refiere básicamente a la convivencia, especialmente a la cultura de la paz
y la “noviolencia”. Y también a los deberes y derechos esenciales para la construcción de una
sociedad justa e inclusiva y una ciudadanía global, consciente, democrática, responsable y
proactiva.

La prosperidad no se entiende en un mundo de desigualdades e injusticias, y por ello la
lucha contra las mismas y el compromiso con su erradicación y con la transformación social y la
responsabilidad fiscal son los ejes de la tercera dimensión.

En el cuarto bloque se aborda el impacto del ser humano en el planeta, las implicaciones
de la propia conducta en el entorno, las consecuencias globales de la acción individual, las
desigualdades e injusticias sociales producidas por el desarrollo no sostenible y la adopción de
acciones y compromisos para la transformación.

Finalmente, en el quinto bloque se incluyen el ejercicio dialógico, las instituciones
internacionales, la intervención en los procesos participativos y el activismo como claves para la
configuración de alianzas trasformadoras a nivel global.

4.2. Bloque 1: Persona

- El bienestar físico y emocional

Crítica, autocrítica, aceptación y disconformidad

Autorregulación emocional, estrés y resiliencia

Educación afectivosexual

- La diversidad

Identidad de género, sexo biológico, expresión de género y orientación sexual

Diversidad social y cultural

Prejuicios

- La igualdad entre mujeres y hombres

Estereotipos y roles que se derivan

Androcentrismo, patriarcado y feminismos

Prevención del abuso sexual y la violencia machista

Responsabilidad compartida en todos los ámbitos de la vida

- Educación

Relativismo moral o universalidad de los valores. Dilemas morales

Autonomía y heteronomía moral

4.3. Bloque 2: Paz

- Resolución de conflictos

Violencias: directa, cultural y estructural

Cultura de la violencia versus cultura de la paz. “Noviolencia”. Paz positiva

versus paz negativa

Maltrato, acoso y exclusión. Respeto y tolerancia

Conductas adictivas

- Los deberes y los derechos de las personas

Derechos y deberes

“Netiqueta” para dispositivos, aplicaciones, herramientas informáticas y redes

sociales

Declaración Universal de Derechos Humanos y de la Infancia

Valores democráticos y ciudadanía global

Legalidad y legitimidad. Dignidad y justicia

4.4. Bloque 3: Prosperidad

- Agenda 2030 y Objetivos de Desarrollo Sostenible

Sostenibilidad y reducción de las desigualdades

- La desigualdad

Situaciones de marginación, discriminación e injusticia social

Interseccionalidad de las desigualdades y las discriminaciones

- Función social de los impuestos y justicia fiscal

Los servicios públicos

Conductas defraudadoras y evasión fiscal

4.5. Bloque 4: Planeta

- Agenda 2030 y Objetivos de Desarrollo Sostenible

La Agenda 2030 como oportunidad para transformar el planeta

Impacto del ser humano en el planeta y cambio climático

Desarrollo sostenible y ciudadanía global

Consumo responsable y economía circular

Tecnología y entorno natural. Basura digital y sostenibilidad

Bienestar animal

4.6. Bloque 5: Participación

- Habilidades

Estrategias para el diálogo convertido en debate: asertividad, argumentación,

contraargumentación y pruebas. Tipos de argumentos

- Ámbitos

Procesos participativos en los ámbitos local, nacional e internacional

Marco ético del diálogo

Activismo ciudadano y solidaridad internacional. ONG

La ONU como sociedad de naciones

La UNESCO como elemento clave para establecer alianzas de progreso

Europa como unidad política. El Tribunal Europeo de Derechos Humanos

5. Situaciones de aprendizaje para el conjunto de las competencias de la materia

En una materia que pretende vincular la reflexión del alumnado a los problemas actuales
del mundo y promover el compromiso activo con la transformación de la realidad, las situaciones
de aprendizaje recomendables trascienden los espacios propios del centro y se desarrollan
también en entornos naturales y urbanos. Además, sacan el máximo provecho educativo del
tiempo empleado en entradas y salidas, desplazamientos, ocio y descanso. Asimismo, involucran
no sólo a profesorado y alumnado, sino también a toda la comunidad educativa, especialmente
a las familias, y a representantes de las instituciones y asociaciones locales.

Es fundamental que se estimule la reflexión, el pensamiento divergente y el espíritu
crítico mediante la práctica frecuente del diálogo y el debate. Es clave la organización de debates
en el aula a partir de experiencias o noticias de actualidad que permiten más de una postura y
que pueden relacionarse fácilmente con los conflictos y situaciones cotidianas del entorno
habitual del alumnado. Con el debate, además, se fomenta la discrepancia, la duda y la
legitimidad de las opciones minoritarias. Es especialmente útil, también, el trabajo con dilemas
morales.

Al hilo de los debates, dilemas y discusiones planteados, es importante ir mostrando al

alumnado el tipo de argumentaciones que de forma espontánea utilizan y la manera de centrar
los argumentos en los temas planteados evitando distracciones y falacias.

La capacidad de diálogo y el trato respetuoso al resto de participantes se ejercitan
haciendo uso de un lenguaje inclusivo e igualitario en todas las situaciones que implican
acuerdos y trabajo en grupo como, por ejemplo, en asambleas de delegadas y delegados,
debates sobre noticias de actualidad, experiencias y sucesos, contenido de textos presentados
en formatos convencional y multimodal y de producciones audiovisuales documentales y de
ficción, o durante las rutinas del trabajo cooperativo.

Asimismo, se deben impulsar aprendizajes valiosos y significativos. Por una parte,
facilitan la comprensión y progresiva asimilación de los saberes de la humanidad, y por otra,
promueven el aprendizaje significativo con ejemplos y modelos vinculados a los intereses del
alumnado, a propuestas de acciones y servicios relevantes para mejorar el entorno más cercano
y la sociedad en general, y al análisis de su relación con dispositivos digitales, internet y las redes
sociales. En este sentido cabe destacar que el juego y las diversas manifestaciones de la
expresión artística contribuyen a hacer más significativos los procesos de aprendizaje.

Garantizar el acceso de todo el alumnado a instalaciones y materiales del centro y las
aulas, actividades y saberes, así como su participación académica y emocionalmente
satisfactoria en la experiencia escolar son retos ineludibles del sistema educativo y de todas las
personas involucradas en su funcionamiento. Por ello, la detección y eliminación de barreras de
todo tipo y la aplicación de los principios del Diseño Universal de Aprendizaje a lo largo del
proceso educativo son requisitos imprescindibles.

Las situaciones de aprendizaje en que intervienen metodologías activas como el
trabajo cooperativo o el basado en retos, tareas y proyectos, entre otros, fomentan la autonomía
y la responsabilidad del alumnado, pues le ofrecen la posibilidad de gestionar su tiempo, decidir
entre diferentes propuestas de trabajo, resolver los desafíos y problemas de diversas formas y
elegir la manera de demostrar sus aprendizajes. También, son muy adecuadas las iniciativas que
implican la relación de alumnado de distintas edades, ya que estimulan la responsabilidad
individual y colectiva y, además, propician la adquisición de valores democráticos esenciales
como la solidaridad y el sentido del bien común.

El bienestar emocional es premisa indiscutible para el éxito del aprendizaje y de la
convivencia y un factor que lo condiciona es la capacidad de expresar emociones y sentimientos
propios y de identificar y comprender los ajenos. Diálogos, debates, producciones textuales
orales y escritas, análisis de situaciones lúdicas y de convivencia, y especialmente de aquellas
en que el alumnado no ve satisfechas sus expectativas, ejercitan la expresión de emociones,
opiniones y posicionamientos, promueven la autorregulación emocional y refuerzan el respeto,
la tolerancia y la empatía.

La resolución dialogada de los conflictos surgidos en la convivencia diaria con
compañeras y compañeros, profesorado y personal no docente, en todos los espacios educativos
de dentro y fuera del centro y en las redes sociales, y la aplicación de sistemas de mediación
facilitan la convivencia y promueven la cultura de la paz y la “noviolencia”.

La interiorización de los valores democráticos y de la universalidad de los derechos
humanos y la dignidad de la persona se promueve mediante el conocimiento, discusión y debate
de las situaciones que suponen discriminaciones en ámbitos ya no solo locales, sino también
nacionales e internacionales. La investigación y estudio de personajes relevantes históricos y
actuales que han trascendido por la denuncia de sus experiencias personales o su compromiso
con la transformación social ayudan al alumnado a descubrir la necesidad y el alcance de la
acción individual frente a las injusticias globales y a adquirir modelos de referencia en el camino
de su desarrollo moral. También son interesantes las iniciativas que suscitan la implicación en la

mejora de la sociedad a partir de la toma de conciencia de las necesidades existentes en el
entorno próximo.

La implicación reflexiva y activa en acciones que celebran los derechos humanos y de la
infancia y los valores democráticos facilita su identificación y apreciación, al igual que las visitas
a instituciones, la comparación del disfrute de los derechos humanos en distintas sociedades y
la investigación y reflexión a propósito de conceptos clave ligados a los principios y sistemas
democráticos.

El compromiso del sistema educativo con la construcción de una ciudadanía global,
responsable y consciente de su potencial transformador implica el reconocimiento de la
diversidad como fuente de aprendizaje y enriquecimiento personal. Reconocimiento que
promueven la convivencia inclusiva diaria en el aula y el centro, la observación de costumbres,
procedencias y lenguas familiares de compañeras y compañeros de clase, la investigación y
comparación de diferentes realidades políticas en el mundo y sus consecuencias en la vida de
las personas, y las acciones y proyectos de centro de carácter académico, festivo o lúdico que
celebran la multiculturalidad.

En consonancia con uno de los objetivos fijados en la Agenda 2030 de la ONU para el
Desarrollo Sostenible, la lucha contra las injusticias, se proponen situaciones de aprendizaje
enfocadas a la detección, denuncia y atención de las mismas, especialmente del acoso escolar,
a partir del análisis de casos de la vida real y de los reflejados en producciones textuales
narrativas, periodísticas y audiovisuales. También, a propósito del análisis de conflictos históricos
y actuales y de las migraciones de millones de personas provocadas por catástrofes naturales,
guerras, hambre o pobreza. Se invita a la formulación de propuestas de actuaciones. La
comparación de la situación de los derechos en diferentes partes del mundo propicia la
identificación de las personas más vulnerables.

Asimismo, en el marco de la lucha contra las injusticias y de la emergencia derivada de
los dramáticos datos estadísticos, se revela como prioritaria la promoción de la igualdad entre
mujeres y hombres. Se incorpora la perspectiva de género de manera transversal a lo largo de
toda la etapa y en todas las materias y tiempos escolares, prestando especial atención, entre
otros, al uso del lenguaje y de los espacios del centro, a la participación equilibrada de las y los
adolescentes en todas las actividades, a las aportaciones de las mujeres a los saberes de la
humanidad, a la presencia de estereotipos en libros, canciones, anuncios publicitarios,
producciones audiovisuales, mensajes de los medios de comunicación, al tratamiento visual del
cuerpo de mujeres y hombres en el arte, pintura, escultura, cine, o al tratamiento de las mujeres
en el deporte y en los modelos de belleza. De manera explícita, se puede trabajar la educación
afectivosexual, el lenguaje igualitario, la diversidad familiar, sexual y de género, la violencia
machista, la ciberviolencia y los abusos sexuales en talleres abiertos, en la medida de lo posible,
a la participación de otros miembros de la comunidad educativa y local, y proponer proyectos
colaborativos que estimulen la construcción de personalidades autónomas y libres de prejuicios
y estereotipos sociales.

Es necesario poner el foco sobre aquellas situaciones y colectivos invisibilizados
mediante el análisis crítico de materiales didácticos, mensajes publicitarios e informaciones de
los medios de comunicación y redes sociales; y con metodologías que requieren la investigación
social y conducen al diseño y realización de campañas de visibilización en el centro y en la
localidad.

La Agenda 2030 también contempla el objetivo prioritario de combatir el cambio
climático, y es por ello recomendable plantear situaciones de aprendizaje que impulsen la
interiorización de la perspectiva sostenible.

Además de contribuir a la consolidación de hábitos de vida sostenibles como la
conservación y el cuidado del material, equipamiento e infraestructuras del centro, la selección
de residuos del aula para el reciclaje y el consumo racional del agua y de la electricidad; las
situaciones de aprendizaje deben trascender el espacio próximo y cotidiano y fomentar la
comprensión del alcance de las acciones humanas en el planeta.

Se promueve la participación en campañas para planificar y aplicar de forma colectiva
acciones innovadoras que fomenten la sostenibilidad, como, por ejemplo, cambios en los
espacios de la ciudad para facilitar la movilidad de las personas o el diseño de itinerarios seguros
y sostenibles para escolares, y la colaboración con ONG, asociaciones e instituciones
comprometidas con causas medioambientales y sociales. Son especialmente recomendables las
metodologías que vinculan las dimensiones de servicio y aprendizaje, ya que impulsan el
compromiso real con la sociedad.

Las tecnologías de la información y comunicación pueden amplificar el impacto de todo
tipo de acciones, y el uso de redes y recursos como el podcast, la radio y la televisión online
escolar son especialmente eficaces para difundir mensajes de sensibilización, implicar al resto
de la comunidad educativa y promover compromisos y alianzas institucionales.

Además de las situaciones de aprendizaje conviene tener en cuenta las situaciones que
facilitan la evaluación competencial.

La propia dinámica de las aulas ofrece múltiples escenarios para observar la evolución
del alumnado y valorar la adquisición de las competencias. Se trata de situaciones como las que
se generan en la convivencia diaria con compañeras y compañeros del centro, profesorado y
personal no docente, y también durante la elaboración de textos sencillos en formato analógico
o digital, en las exposiciones orales y en los debates o tertulias. Resulta especialmente útil el
análisis de materiales didácticos, anuncios y lenguaje publicitario, videojuegos, producciones
audiovisuales y redes sociales.

Asimismo,
la
elaboración
individual
y
colectiva
de
producciones
textuales
convencionales o multimodales en que se utilizan conceptos clave del currículo y que implican
los procesos de síntesis, reformulación, análisis e investigación facilitan la comprobación de la
adquisición de los mismos.

El trabajo en equipo es un escenario óptimo para valorar si el alumnado asume diferentes
roles con eficiencia y responsabilidad, muestra empatía y respeta las aportaciones de
compañeros y compañeras.

Es especialmente relevante el trabajo que se desarrolla de forma colectiva, bien sea en
grupos de trabajo, debates, exposiciones orales, discusión de propuestas u otras situaciones y
actividades porque permite que entren en juego muchos de los aspectos que se valoran en las
diferentes competencias específicas.

Finalmente, el uso de instrumentos de autoevaluación y coevaluación como dianas,
rúbricas, escalas de observación, portfolios, diarios, etc. presenta muchas ventajas, y entre ellas
la oportunidad de reflexionar sobre los saberes y los procesos de aprendizaje.

6. Criterios de evaluación

Competencia específica 1. Criterios de evaluación

CE1. Dialogar y debatir de forma asertiva, respetuosa y correctamente argumentada
sobre problemas morales planteados en cualquier situación de la vida diaria para poder llegar a
acuerdos o consensos.

2º Ciclo (4º)

1.1 Participar en los debates planteados en clase de manera asertiva, escuchando de forma
activa y respetando el turno de palabra tanto en la aportación de argumentos, fundamentados en
información fiable, como al exponer su acuerdo o desacuerdo.

1.2 Utilizar los conceptos y los argumentos de forma rigurosa para exponer sus propias ideas
y razonamientos y para aclarar las dudas y malentendidos que se planteen.

1.3 Utilizar un lenguaje oral y escrito inclusivo e igualitario en cualquier situación de
aprendizaje.

1.4 Participar en equipos de trabajo para conseguir metas comunes asumiendo roles con
eficiencia y responsabilidad.

Competencia específica 2. Criterios de evaluación

CE2. Gestionar las emociones en situaciones de conflicto para poder afrontarlas desde
la cultura de la paz y explorar y proponer soluciones equitativas y creativas.

2º Ciclo (4º)

2.1. Reconocer las diferentes violencias que constituyen la cultura de la violencia y analizar
críticamente sus consecuencias para la convivencia democrática.

2.2. Proponer y llevar a cabo acciones encaminadas a la construcción de la cultura de la paz
en la vida diaria del centro y en el entorno social.

2.3. Llegar a un punto de entendimiento integrando las intervenciones y planteamientos del
resto de la clase a través del diálogo colectivo y el consenso.

Competencia específica 3. Criterios de evaluación

CE3. Analizar de forma crítica las normas y leyes vigentes en el marco de la Declaración
Universal de los Derechos Humanos y adecuarse a ellas valorando su legitimidad.

2º Ciclo (4º)

3.1. Explicar y ejemplificar con claridad la diferencia entre legitimidad y legalidad.

3.2. Analizar críticamente la relación entre las normas y leyes vigentes y la Declaración
Universal de los Derechos Humanos.

3.3. Aplicar el aprendizaje sobre la legitimidad de normas a otras situaciones que requieran
ser reguladas.

Competencia específica 4. Criterios de evaluación

CE4. Reconocer, denunciar y combatir los estereotipos y roles asociados a partir de una
reflexión personal y crítica.

2º Ciclo (4º)

4.1. Identificar los valores que sustentan los estereotipos y los prejuicios presentes en
debates, producciones escritas, literatura, música, videojuegos, publicidad, redes sociales, etc.

4.2. Analizar críticamente las consecuencias de adoptar los estereotipos y prejuicios como
patrón de comportamiento y relación con las demás personas y denunciar las desigualdades e
injusticias que generan.

4.3. Proponer conductas y desplegar acciones para combatir la discriminación y no inclusión
de las personas víctimas de los estereotipos sociales en el aula, el centro y la sociedad.

Competencia específica 5. Criterios de evaluación

CE5. Identificar, analizar y valorar en el ámbito internacional los beneficios de los valores
democráticos promovidos por leyes e instituciones para la construcción de una ciudadanía
global.

2º Ciclo (4º)

5.1 Buscar, seleccionar y exponer información de fuentes fiables referida a la situación de
los valores democráticos en el mundo.

5.2 Participar en el debate sobre los beneficios de los valores democráticos en el ámbito
internacional con aportaciones razonadas.

5.3 Analizar y explicar las consecuencias sociales que se desprenden del respeto o no de
los principios de la Declaración Universal de los Derechos Humanos y de las instituciones y leyes
internacionales que velan por su cumplimiento.

Competencia específica 6. Criterios de evaluación

CE6. Proponer y desplegar acciones responsables y justas comprometidas con la
transformación social y la lucha efectiva contra las desigualdades e injusticias, en cualquier
situación real, de acuerdo con los principios de una sociedad igualitaria e inclusiva.

2º Ciclo (4º)

6.1. Identificar con claridad los polos de un conflicto generado por una situación de
desigualdad.

6.2. Exponer y argumentar la posición moral que se adopta frente a la desigualdad y la
injusticia social.

6.3. Proponer y desplegar acciones que luchen contra las desigualdades e injusticias

sociales identificadas en cualquier situación.

Competencia específica 7. Criterios de evaluación

CE7. Explicar los desafíos ecológicos planteados por los Objetivos de Desarrollo
Sostenible y actuar de manera comprometida con la transformación de la situación
medioambiental del planeta.

2º Ciclo (4º)

7.1 Evaluar el impacto de las propias acciones en las esferas local y global en relación a la
sostenibilidad ecológica.

7.2 Explicar de forma clara y precisa los desafíos planteados por los Objetivos de Desarrollo
Sostenible.

7.3 Idear, planificar y evaluar en grupos colaborativos acciones innovadoras encaminadas al
cuidado del planeta.

7.4 Explicar los conflictos y las consecuencias que generan las políticas de desarrollo no
sostenibles.
