# TALLER DE ECONOMÍA

> Fuente: Secundaria.pdf, páginas 1188-1202 (versión en castellano).

TALLER DE ECONOMÍA

1. Presentación

La importancia creciente que tienen los asuntos económicos en los distintos ámbitos de nuestra
sociedad y la forma tan directa en que nos afectan individual y colectivamente plantean la necesidad de que
el alumnado reciba en la enseñanza obligatoria una formación básica en economía y con un conocimiento de
su realidad socioeconómica más cercana.

La economía proporciona los conceptos e instrumentos básicos para que el alumnado comprenda
mejor su entorno social, con lo que se contribuye a mejorar la transparencia y la responsabilidad en el ejercicio
de sus derechos y deberes. A partir del estudio de dichos saberes, el alumnado será capaz de diseñar, en su
realidad más cercana, propuestas que sirvan para elaborar un proyecto de colaboración con un servicio a la
comunidad.

El estudio de esta materia potencia las competencias clave, y proporciona herramientas para
desarrollar una visión crítica de nuestra sociedad tan presente en los objetivos de la etapa secundaria
obligatoria y en los retos del siglo XXI. Esta materia facilita la comprensión de conceptos habituales del ámbito
económico, tales como el desempleo, la inflación, producción sostenible, consumo responsable, agotamiento
de recursos naturales, distribución de la renta y las consecuencias sociales de la globalización. Además, su
enfoque competencial permite que el alumnado de tercero de la ESO se acerque a su realidad económica y
social y se implique y participe en el desarrollo y progreso de su entorno más cercano con el proyecto de
colaboración con un servicio a la comunidad, con la finalidad de que su acción se convierta en motor de
cambio desde la perspectiva social y sostenible que impregnan los Objetivos de Desarrollo Sostenible.

La materia se asocia con los estudios previos realizados en la Educación Secundaria Obligatoria y
guarda especial relación con las materias comunes de Matemáticas, Geografía e Historia, Lengua Castellana,
Valenciana e Inglés, así como con la materia optativa de Emprendimiento Social y Sostenible ofertada en
segundo de la ESO. Ambas optativas de segundo y tercero de la ESO contribuirán a adquirir unos
conocimientos económicos y de emprendimiento básicos en la etapa obligatoria que podrán ser ampliados en
las materias de opción de Economía y Emprendimiento y Formación y Orientación Personal y Profesional
cursadas en cuarto de la ESO.

El desarrollo de la materia promueve las distintas competencias clave. En primer lugar, la materia
tiene relación con la competencia personal, social y de aprender a aprender puesto que el alumnado utilizará
los conocimientos adquiridos y actitudes frente a diferentes contextos sociales, como futuros productores y
consumidores. Las competencias en comunicación lingüística y plurilingüe están presentes en la materia ya
que estas competencias permiten al individuo comportarse como agente comunicativo, que produce y recibe
mensajes con distintas finalidades. El desarrollo de la materia favorece que el alumnado sea capaz de explicar
fenómenos sociales que conocía anteriormente, pero ahora usando un lenguaje propio, técnico y preciso, y
también promueve la concepción del diálogo como herramienta primordial para la convivencia y la resolución
de conflictos.

La competencia matemática y competencias en ciencia y tecnología está presente en la materia
puesto que permiten aplicar el razonamiento matemático para describir, interpretar y predecir distintos
fenómenos en su contexto. La competencia emprendedora tiene gran relevancia en la materia puesto que
permite transformar las ideas en actos, favoreciendo el aprovechamiento de nuevas oportunidades. Por tanto,
el alumnado va a poder evaluar sus posibilidades de decisión en situaciones determinadas, valorando las
consecuencias que tienen tanto para su situación personal como para toda la sociedad. La competencia digital

también está presente puesto que los principales medios de comunicación ofrecen continuamente información
referida al ámbito económico. Finalmente, la competencia ciudadana hace reflexionar desde la ética y la
responsabilidad, las diferentes actuaciones y sucesos que se dan en la actualidad y la competencia en
conciencia y expresiones culturales nos facilita valorar la diversidad en cada contexto histórico, económico,
social y personal.

Por lo que respecta a las competencias específicas, en esta materia se aprenderá el funcionamiento
los problemas básicos de la economía, se mostrarán las principales actuaciones que los agentes económicos
tienen en la economía (las familias, las empresas, el sector público y el tercer sector), se reflexionará sobre
las cualidades sociales necesarias para trabajar en equipo buscando nuevas oportunidades de mejora del
entorno, se establecerán los objetivos económicos más relevantes asociados al trabajo digno, el crecimiento
sostenible, la estabilidad de precios y la igualdad efectiva y se enseñarán los elementos esenciales de
diferentes metodologías para obtener fuentes de información fiables, para finalmente proponer actuaciones
de mejora del entorno más próximo acorde a los principios acordados por la sociedad en un proyecto de
colaboración con un servicio a la comunidad. Así pues, la competencia específica 7 es posible gracias a la
puesta en marcha de las competencias previas.

Los saberes básicos de esta materia se agrupan en cuatro bloques. Un primer bloque introductorio
sobre conceptos económicos básicos y las principales herramientas para emprender desde la perspectiva
social y sostenible. En un segundo bloque se analizarán los diferentes agentes económicos que forman la
sociedad actual, centrándonos en el papel de las economías domésticas, de las empresas, del sector público
y el tercer sector, así como las decisiones que estos agentes realizan y los efectos de las mismas.
Concretamente en el caso del sector público es necesario comprender de dónde proceden los ingresos
públicos y a qué se destinan, poniendo en valor los diferentes tributos que existen en el sistema actual. En un
tercer bloque se presentan diferentes variables macroeconómicas que hacen comprender los retos y
problemas de la sociedad actual. En un cuarto bloque, se abordan las tendencias económicas más relevantes
asociadas a la economía circular, los Objetivos de Desarrollo Humano y la Economía del Bien Común que
sirven para poder diseñar un proyecto de colaboración con un servicio a la comunidad en el que el alumnado
se implique con su entorno más cercano.

En el apartado de situaciones de aprendizaje se presentan criterios para diseñar el contexto y las
actividades de aprendizaje de acuerdo a un enfoque metodológico basado en estrategias de exposición,
indagación o descubrimiento, activas y participativas, en las que con el apoyo de documentos, artículos de
prensa y presentaciones el alumnado se enfrente al diseño de un proyecto social al servicio de la comunidad
en el cual tienen que movilizar reflexivamente conceptos, procedimientos y actitudes, y favorecer así su
aprendizaje significativo.

Los criterios de evaluación de esta materia van dirigidos a comprobar el grado de adquisición de las
competencias específicas, esto es, el nivel en el que el alumnado es capaz de movilizar los saberes,
conceptuales, procedimentales y relativos a actitudes y valores en situaciones o actividades del ámbito
personal, social y académico con una futura proyección profesional.

2. Competencias específicas

2.1. Competencia específica 1.

Identificar los problemas económicos básicos vinculados con la escasez y la necesidad de elegir,
relacionándolos con situaciones del entorno más cercano.

2.1.1. Descripción de la competencia

Adquirir formación económica básica es importante para conocer y entender la realidad
socioeconómica más cercana y así poder adoptar posturas de participación y compromiso. El hecho de que
el alumnado se aproxime a contenidos económicos por primera vez les permitirá conocer y cuestionar el
funcionamiento de los mercados, las principales variables económicas y valorar las soluciones que se dan a
los problemas económicos de su entorno más cercano.

Asimismo, es necesaria la adquisición de la terminología económica básica, así como comprender los
aspectos fundamentales del funcionamiento del sistema económico actual. Conocer el problema de la
escasez y la necesidad de elegir, hace posible que el alumnado detecte las limitaciones actuales de la
economía y la necesidad de la búsqueda de soluciones que ayuden a alcanzar con éxito los retos del entorno
más cercano del alumnado reflejándolo en su propio proyecto de mejora social.

2.2. Competencia específica 2.
Analizar las cualidades individuales y colectivas que caracterizan una actitud emprendedora y
ponerlas en práctica, mediante el trabajo cooperativo, para encontrar nuevas oportunidades de mejora en el
entorno social y económico más próximo basadas en principios de equidad, coeducación e igualdad.

2.2.1. Descripción de la competencia

El punto de partida en el desarrollo de una propuesta de mejora del entorno, siempre debe ser
conocerse a uno mismo y determinar cuáles son las cualidades, debilidades y fortalezas que cada uno tiene,
incidiendo fundamentalmente en aquellas que favorecen el trabajo en equipo.

El papel del emprendimiento es determinante para conseguir una transformación social que va mucho
más allá de lo económico. El alumnado comprenderá cómo el emprendimiento contribuye a dichos cambios
sociales, reconociendo el papel que desempeñan y valorando al mismo tiempo la importancia de un
comportamiento ético, incorporando los valores de equidad y solidaridad que subyacen en el Estado del
bienestar.

El alumnado identificará el perfil y el papel de quien emprende un proyecto desde el punto de vista
del concepto de ciudadanía global, cuyo objetivo se encuentra esencialmente en un fin social, compartido con
el respeto a los valores democráticos, de igualdad y de respeto al medio ambiente, y analizar en qué medida
reconoce esas características como propias. Así pues, el objetivo es que la juventud se conozca a sí misma,
fortalezca sus capacidades de liderazgo y de autonomía y mejore sus aptitudes para el trabajo en equipo,
destacando el valor social del emprendimiento y la innovación como motor de progreso social, que
implementará en un proyecto cooperativo.

2.3. Competencia específica 3.
Describir la importancia del papel de las familias, las empresas y el Estado en el funcionamiento de
la economía, analizando la realidad socioeconómica del entorno más cercano del alumnado.

2.3.1. Descripción de la competencia

Conocer la realidad socioeconómica más cercana, con sus características y aspectos claves es
necesario para comprender el funcionamiento de la sociedad. Así, el alumnado descubrirá que los agentes
económicos actúan de forma conjunta en la economía, ya que intervienen directamente en la producción,
distribución y el consumo de bienes y servicios.

La importancia de los agentes económicos radica en la relación que éstos mantienen entre sí al
depender uno del otro, y en el aporte que éstos brindan al desarrollo y crecimiento económico de una

sociedad. Ante la ausencia de algún agente o la falta de cumplimiento de una función, el sistema económico
de una sociedad se ve afectado sufriendo consecuencias negativas en la economía.

Los alumnos y las alumnas deben ser conscientes de las decisiones básicas que toman los agentes
económicos y sus consecuencias. Conocer las actividades que realizan los diferentes sectores económicos,
haciendo hincapié en las actividades más próximas al alumnado, va a propiciar la posibilidad de adoptar
actitudes de responsabilidad e implicación con la sociedad a través de su proyecto de servicio de comunidad.
Al mismo tiempo, reflexionar sobre el papel del Estado en la economía y sus funciones e identificar el
funcionamiento del tercer sector como una forma más de comportamiento económico es vital para conocer el
funcionamiento de la sociedad actual.

2.4. Competencia específica 4.
Identificar los principales indicadores macroeconómicos relacionados con el mercado de trabajo, la
redistribución de la renta, el crecimiento y los precios que le hagan comprender su realidad, utilizando fuentes
y herramientas básicas de análisis.

2.4.1. Descripción de la competencia

El análisis de las principales variables macroeconómicas será fundamental para que el alumnado
comprenda los principales problemas que afectan a la sociedad. Los resultados de este análisis tratan de
describir cómo está siendo la actividad económica de un país y cómo se prevé que vaya a evolucionar. Para
ello, se analizan ciertos indicadores que nos ayudan a conocer la situación de la economía, su evolución y las
consecuencias e implicaciones en la sociedad.

El alumnado realizará un análisis básico de diferentes variables macroeconómicas tales como la tasa
de paro, producto interior bruto, inflación, déficit público, deuda pública, tipo de interés, economía sumergida,
para conocer la situación actual y buscará posibles soluciones.

El alumnado adquirirá las herramientas y conocimientos económicos elementales, a partir de las
cuales se desarrollarán las competencias cívicas y sociales, y actitudes críticas y personales sobre la realidad
económica más cercana que aplicarán en su proyecto de colaboración de servicio a la comunidad.

2.5. Competencia específica 5.
Explicar la conexión entre la actividad del Estado y la necesidad de financiación pública para el
cumplimiento de sus objetivos, así como, identificar las principales figuras tributarias, valorando la función
social y el papel redistributivo de los impuestos en la sociedad.

2.5.1. Descripción de la competencia

El alumnado analizará la información de las principales partidas derivada de los presupuestos del
Estado con el objetivo de que relacione las políticas de gasto con la necesidad de obtener ingresos para
financiarlas. Dentro de la parte de financiación pública, analizará las principales fuentes de ingresos públicos,
centrándose en los distintos tipos de tributos y sus características, y los relacionará con la capacidad
redistributiva de los mismos con la finalidad de que el alumnado comprenda la importancia de los mismos
para mantener el Estado de Bienestar.

Al mismo tiempo, el alumnado debería analizar el destino de los diferentes tributos en la sociedad,
valorando la importancia de que todas las personas y empresas contribuyan a mantener los servicios públicos.
Además, comprender la interrelación de los impuestos y los niveles de gobierno es esencial para que el

alumnado sea consciente de la relevancia de las actividades de las distintas administraciones públicas y de
las vías para su financiación.

Por otro lado, la educación fiscal tiene como objetivo primordial transmitir ideas, valores y actitudes
favorables a la responsabilidad fiscal y contrarios a las conductas defraudadoras. Así pues, se persigue el
desarrollo de actitudes de compromiso frente al bien común y a las normas que regulan la convivencia
democrática, poniendo de relevancia el sentido social de los impuestos y su vinculación con el gasto público,
y el perjuicio que comporta el fraude fiscal y la corrupción.

En definitiva, el alumnado conocerá el funcionamiento del sistema tributario, entenderá la función
social y solidaria de los impuestos y comprenderá los costes sociales y económicos del incumplimiento de las
obligaciones tributarias.

2.6. Competencia específica 6.
Recopilar información de diferentes fuentes económicas seleccionando datos fiables que den rigor a
las propuestas de mejora del proyecto de colaboración con un servicio a la comunidad.

2.6.1. Descripción de la competencia

El alumnado debe aprender a recopilar información de su entorno a través de fuentes secundarias y
fuentes primarias, con la finalidad de conseguir datos que le permitirán dar respuesta a situaciones que se
estén desarrollando en su entorno más cercano. Dicha información debe ser contrastada y fiable para
conseguir un rigor científico en las propuestas que el alumnado propone.

La recopilación y análisis de información permitirá que el alumnado pueda comprender la situación
social y económica de su entorno y poder desarrollar comportamientos responsables y éticos colaborando y
participando en la mejora y progreso de su localidad. Dicha información será aplicada al proyecto de
colaboración con un servicio a la comunidad al que se alude en la competencia específica 7.

2.7. Competencia específica 7.
Diseñar un proyecto sencillo de colaboración con un servicio a la comunidad que posibilite la mejora
de la calidad de vida de las personas y el medio ambiente, basándose en los principios recogidos en los
Objetivos de Desarrollo Sostenible.

2.7.1. Descripción de la competencia

En el siglo XXI la economía mundial ha progresado de una manera rápida y ha supuesto que las
empresas en particular y la sociedad en general, se adapten a estos cambios de la misma forma. Esto provoca
unos desequilibrios y desigualdades que hace necesario la reflexión en el ámbito económico y social.

Es relevante concienciar al alumnado de la importancia que tiene el progreso social, económico,
tecnológico y medioambiental y que éste se lleva a cabo de una forma sostenible. Deben entender las ventajas
de la globalización económica y el progreso económico, pero también sus inconvenientes y las medidas que
existen para reducir las externalidades. El uso de las nuevas tecnologías es fundamental para encontrar
empresas y/o entidades, cercanas al alumnado, comprometidas con los ODS, la Agenda 2030 y al desarrollo
sostenible, con el fin de analizar las causas de su decisión y las acciones que llevan a cabo para lograr mejorar
la calidad de vida de las personas y el medio ambiente desde punto de vista crítico y ético.

Todo este análisis permitirá al alumnado realizar un proyecto de servicio a la comunidad que le haga
partícipe de su propio aprendizaje y que permita colaborar con diferentes tipos de asociaciones y
administración local que tengan como objetivo la mejora del entorno desde la perspectiva social y
medioambiental.

3. Conexiones de las competencias específicas entre sí, con las competencias específicas de otras
materias y con las competencias clave.

3.1.  Relaciones o conexiones entre las competencias específicas

Conexiones Competencia Específica 1

Se relaciona con la CE2 por la necesidad de desarrollar las cualidades personales y el trabajo en
equipo que permite identificar los problemas económicos, asimismo con la CE3 a la hora de analizar el papel
de los agentes económicos en la realidad económica. También se relaciona con la CE4 ya que identifica
variables macroeconómicas, con la CE6 ya que es importante recopilar información para identificar los
problemas económicos, y también de diseñar el proyecto de servicio a la comunidad como se ve en la CE7.

Conexiones Competencia Específica 2

Cabe destacar su relación con la CE3 al tener en cuenta las cualidades personales y del grupo cuando
analizamos el comportamiento de los agentes económicos y con la CE4 cuando identificamos los objetivos
macroeconómicos.  Esta competencia también se relaciona con la CE6 por la importancia del
autoconocimiento y el trabajo en equipo a la hora de diseñar propuestas para el proyecto. En el punto anterior
vimos también su relación con la CE1.

Conexiones Competencia Específica 3

Es destacable su conexión con la CE4 ya que, no podemos obviar la influencia de los agentes
económicos en las variables macroeconómicas. Asimismo, con la CE6 puesto que no se puede plantear un
análisis de los agentes económicos sin recopilar información. También con la CE 7, ya que los agentes
económicos son la base para que el proyecto responda a sus necesidades y con la CE5 por la necesidad de
conocer el sistema tributario y su finalidad en la sociedad. Con la CE 2, se ha visto la importancia que tiene
para un buen análisis de los agentes, la identificación de las cualidades individuales y de grupo y con la CE1
existe una relación evidente.

Conexiones Competencia Específica 4

Esta competencia se relaciona con la CE6 y la CE7 ya que recopilar información fiable es necesario
para analizar los objetivos macroeconómicos y diseñar el proyecto. Hemos visto también la relación de esta
competencia con la CE3 a la hora de analizar la realidad socioeconómica, con la CE 1 cuando identificamos
los problemas económicos básicos y con la CE5 por la necesidad de que el sistema tributario tenga un papel
redistributivo en la sociedad.

Conexiones Competencia Específica 5

Se relaciona con la CE3, ya que se deriva de la comprensión del sistema económico formado por
diferentes agentes. También con la CE4, tanto por su papel redistributivo como su relación con el crecimiento

y la política de estabilización.  Al mismo tiempo, es imprescindible plasmar en el proyecto de servicio a la
comunidad la necesidad de cumplir con las obligaciones fiscales y por ello hay una estrecha relación con la
CE7.

Conexiones Competencia Específica 6

Se relaciona con la CE7 debido a la importancia que tiene recopilar información de fuentes fiables
para diseñar propuestas con impacto social positivo. Asimismo, se analiza la relación de esta competencia
con la CE4 a la hora de estudiar los objetivos macroeconómicos y con la CE 3 en el análisis del entorno
socioeconómico. Del mismo modo, ya se ha comentado la relación con la CE2 y la CE1.

Conexiones Competencia Específica 7

Se relaciona con la CE6 porque a la hora de diseñar propuestas para el proyecto de servicio a la
comunidad de acuerdo a los ODS es importante contar con fuentes de información rigurosas. Analizamos
anteriormente también las relaciones con la CE5, CE4, CE3, CE2 y CE1.

3.2. Relaciones o conexiones con competencias específicas de otras áreas

Las competencias específicas de la materia de Taller de Economía tienen especial relación con las
áreas lingüísticas, artísticas, tecnológicas, científicas, así como las ciencias sociales que el alumnado estudia
durante el primer ciclo de la ESO. El carácter práctico de la materia hace posible que se apliquen a la vida
real aquellas competencias más abstractas de otros ámbitos.

La competencia 1 tiene relación con las materias de Geografía e Historia y Biología y Geología:

•
Geografía e Historia: las competencias de la materia de Geografía e Historia tienen un nexo
común con la materia. Concretamente, la competencia 5 explica las interrelaciones
económicas y su repercusión en la sociedad tan necesaria para poder dar respuesta mediante
propuestas de mejora social que tengan impacto en el entorno más cercano que se realizan
en la materia de Taller de Economía.
•
Biología y Geología: la competencia específica de la materia trabaja la adopción de hábitos
de comportamiento en la actividad cotidiana responsables con el entorno (CE10).

Las competencias 3, 4 y 5 tienen relación con la materia de Matemáticas, Física y Química, así como
la materia de Geografía e Historia, puesto que es necesario el uso del método científico para que las
herramientas utilizadas en la materia de Taller de Economía tengan una base fundamentada y al mismo
tiempo se necesitan conceptos básicos del funcionamiento de la sociedad y los problemas relevantes a los
cuales se enfrenta.

•
Matemáticas: algunas de sus competencias son necesarias para resolver problemas
relacionados con situaciones diversas del ámbito social (CE1), construir modelos
matemáticos funcionales con el objetivo de interpretar problemas relevantes (CE3) e
interpretar mensajes orales y escritos complejos de manera formal, empleando el lenguaje
matemático (CE6).

•
Física y Química: desde la materia se trabaja la resolución de problemas científicos a partir
de trabajos de investigación abordables en el ámbito experimental (CE1), analizar fenómenos
naturales (CE5) y la utilización de representaciones gráficas (CE7).
•
Geografía e Historia: la materia trabaja los diferentes problemas sociales relevantes
asumiendo valores democráticos y desde una perspectiva crítica (CE7).

La competencia 2 y 6 tiene relación con las competencias comunicativas de las lenguas estudiadas
en el currículo por parte de todo el alumnado necesarias para la búsqueda de fuentes.

•
Lengua Castellana y Literatura y Valencià: LLengua i Literatura, ya que ambas lenguas
permiten una acción comunicativa y son de gran ayuda para expresar los principios
económicos y la interacción en los grupos de trabajo necesarios en la materia. Así pues,
competencias como la comprensión oral (CE2), comprensión escrita (CE3), expresión oral
(CE4), la expresión escrita (CE5), la mediación (CE7) y la lectura (CE8) y son fundamentales
para conseguir los objetivos del curso.
•
Primera Lengua Extranjera: la competencia 2 (comprensión oral) y la competencia 3
(comprensión escrita) son de gran relevancia para comprender mejor los diferentes aspectos
de la economía global.

La competencia 7 tiene relación con las asignaturas de Tecnología y Digitalización, Educación
Plástica, Visual y Audiovisual, así como Biología y Geología, puesto que en estas materias se aprende a
gestionar proyectos y a trabajar la sostenibilidad y el consumo responsable.

•
Tecnología y Digitalización: la competencia 1 resuelve problemas sencillos aplicando el
método de proyectos de manera similar al de la materia.
•
Biología y Geología: la materia trabaja aspectos relacionados con la sostenibilidad como la
conservación con responsabilidad de todas las formas de vida y el planeta (CE7).
•
Educación Plástica, Visual y Audiovisual: la materia trabaja la selección de recursos digitales
desarrollando criterios de consumo responsable y sostenible (CE4).

3.3. Relaciones o conexiones con las competencias clave

La competencia específica CE1 se vincula con la competencia en comunicación lingüística (CCL),
con la competencia digital (CD), con la competencia personal, social y de aprender a aprender (CPSAA), con
la competencia ciudadana (CC) y con la competencia en conciencia y expresión culturales (CCEC) pues al
identificar los problemas económicos básicos relacionados con la escasez y la necesidad de elegir,
reflexionando sobre su relación con el entorno, el alumnado expresa y regula sus emociones desde una
perspectiva social y ciudadana utilizando para ello herramientas de comunicación oral y escrita en las
diferentes lenguas del currículo, igualmente la CE1 se vincula con la competencia emprendedora (CE) al
reflexionar sobre la relación de los problemas económicos básicos en el entorno.

La competencia específica CE2 se relaciona con la competencia en comunicación lingüística (CCL),
la comunicación plurilingüe (CP), la competencia digital (CD), la competencia personal, social y de aprender
a aprender (CPSAA) y la competencia ciudadana (CC), todas ellas contribuyen a la hora de desarrollar
cualidades individuales y sociales que favorecen el trabajo cooperativo. Al mismo tiempo también se relaciona
con la competencia emprendedora (CE) al buscar nuevas oportunidades de mejorar el entorno local y social.

La competencia específica CE3 tiene conexión con la competencia en comunicación lingüística (CCL),
la competencia digital (CD), la competencia personal, social y de aprender a aprender (CPSAA) y la
competencia ciudadana (CC), todas ellas básicas para describir la importancia del papel de las familias, las
empresas y el Estado en el funcionamiento de la economía, del mismo modo se relaciona con la competencia
emprendedora (CE) al buscar nuevas oportunidades de mejorar el entorno local.

La competencia específica CE4 se vincula con la competencia en comunicación lingüística (CCL) y
la competencia digital (CD) pues son necesarias para identificar las principales variables macroeconómicos,
con la competencia personal, social y de aprender a aprender (CPSAA) y la competencia matemática y
competencia en ciencia, tecnología e ingeniería (STEM) al utilizar el pensamiento científico para entender las
herramientas de análisis básicas utilizadas y con la competencia ciudadana (CC) y la competencia
emprendedora (CE) al incorporar estos aprendizajes para comprender su realidad desde una perspectiva
crítica.

La CE5, que relaciona la conexión entre la actividad del Estado y la necesidad de financiación pública
para el cumplimiento de sus objetivos, se relaciona con la competencia en comunicación lingüística (CCL) y
la competencia digital (CD) pues son necesarias para comprender, interpretar y valorar con actitud crítica
distintos textos, así como para realizar búsquedas en internet atendiendo a diferentes criterios, con la
competencia personal, social y de aprender a aprender (CPSAA), la competencia matemática y competencia
en ciencia, tecnología e ingeniería (STEM) al utilizar métodos inductivos y deductivos matemáticos en
situaciones conocidas, de mismo modo se relaciona con la competencia ciudadana (CC) y la competencia
emprendedora (CE) al analizar ideas relativas a la dimensión social y ciudadana del alumnado valorando el
impacto que sus acciones pueden suponer en el entorno.

La CE6 que implica la recopilación de información de diferentes fuentes económicas se relaciona con
la competencia de comunicación lingüística (CCL), la competencia digital (CD), la competencia personal,
social y de aprender a aprender (CPSAA), con la competencia ciudadana (CC) y la competencia
emprendedora (CE), todas ellas necesarias a la hora de seleccionar los datos obtenidos de forma que estos
sean fiables y den rigor a las propuestas proyectadas.

Para finalizar, la competencia específica 7 que plantea diseñar un proyecto sencillo de servicio a la
comunidad que posibilite la mejora de la calidad de vida de las personas y del medio ambiente se relaciona
con la competencia en comunicación lingüística (CCL), con la competencia plurilingüe (CP) y la competencia
digital (CD) por la importancia de las comunicaciones orales y escritas así como de los medios técnicos para
dar a conocer su proyecto, con la competencia matemática  y competencia en ciencia, tecnología e ingeniería
(STEM) al emplear diferentes estrategia para resolver problemas, con la competencia personal, social y de
aprender a aprender (CPSAA), con la competencia ciudadana (CC) y con la competencia emprendedora (CE)
al analizar las acciones que llevarán a cabo para lograr mejorar la calidad de vida de las personas y el medio
ambiente desde punto de vista crítico y ético

|  | CCL | CP | STEM | CD | CPSAA | CC | CE | CCEC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE1 | X |  |  | X |  | X | X |  |
| CE2 | X | X |  | X | X | X | X |  |

| CE3 | X |  | X | X | X | X | X |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CE4 | X |  | X | X | X | X | X |  |
| CE5 | X |  | X | X | X | X | X |  |
| CE6 | X |  |  | X | X | X | X |  |
| CE7 | X | X | X | X | X | X | X | X |

Competencias clave del perfil de salida del alumnado al término de la enseñanza básica:

•
CCL. Competencia en comunicación lingüística
•
CP. Competencia plurilingüe
•
STEM. Competencia matemática y competencia en ciencia, tecnología e ingeniería
•
CD. Competencia digital
•
CPSAA. Competencia personal, social y de aprender a aprender
•
CC. Competencia ciudadana
•
CE. Competencia emprendedora
•
CCEC. Competencia en conciencia y expresión culturales

4. Saberes básicos

4.1. Introducción

Hoy en día estamos inmersos en un mundo con continuos cambios tanto económicos como sociales.
La juventud no es ajena a estos cambios, y es por ello que necesitan herramientas y conocimientos
económicos que les permitan entender qué provoca esta inestabilidad. Aprender cómo administrar
adecuadamente nuestros recursos resulta tan importante como aprender a leer o escribir. Que asimilen el
valor del dinero o la importancia de un consumo responsable, el cooperar más que competir, no es un juego
sino una realidad que debe darse en todo nuestro aprendizaje.

En el Taller de Economía el alumnado va a encontrar los saberes básicos para conseguir el
aprendizaje necesario que dará respuesta, desde un punto de vista esencialmente práctico, a ciertas
conductas que detectan en la sociedad.

Los saberes básicos de esta materia se agrupan en cuatro bloques que contribuirán a la adquisición
de las siete competencias específicas analizadas previamente.

4.2.  Bloques

BLOQUE 1 LA ECONOMÍA Y HERRAMIENTAS EMPRENDEDORAS (CE1, CE2, CE3, CE7)

GRUPO DE SABERES 1.1 LA IMPORTANCIA DE LA ECONOMÍA

•
La economía y su impacto en la vida de la ciudadanía.
•
La escasez, elección y asignación de recursos. Necesidades económicas en las etapas
de la vida.
•
Acercamiento a los sistemas económicos.
•
Los agentes económicos y aproximación al flujo circular de la renta.

GRUPO DE SABERES 1.2 HERRAMIENTAS PARA EMPRENDER

•
El trabajo en equipo, la inteligencia emocional, la comunicación y el liderazgo.
•
Técnicas para desarrollar la creatividad. Innovación al servicio de la sociedad.
•
El desarrollo de iniciativas emprendedoras.

BLOQUE 2 LOS AGENTES ECONÓMICOS (CE1, CE3, CE4, CE5, CE7)

GRUPO DE SABERES 2.1 LAS PERSONAS CONSUMIDORAS: CONSUMO RESPONSABLE

•
Las personas consumidoras y sus derechos.
•
Valoración del modelo de consumo actual. Despilfarro alimentario.
•
El poder del consumo responsable: ahorro energético, uso de transporte sostenible,
comercio justo, comercio de proximidad y de empresas sostenibles.

GRUPO DE SABERES 2.2 LAS EMPRESAS Y LAS PERSONAS EMPRENDEDORAS

•
Las empresas y la economía circular.
•
La creación de valor compartido: económico, social y medioambiental.
•
Cooperativismo y emprendimiento social. Pymes, startups y viveros de empresas.

GRUPO DE SABERES 2.3 EL ESTADO

•
Aproximación al sector público. Funciones y Estado de Bienestar.
•
Los servicios públicos: educación, sanidad y servicios sociales. Asignación de los
servicios por niveles de gobierno.
•
Funciones básicas de la Seguridad Social.

BLOQUE 3 VARIABLES ECONÓMICAS Y SOCIALES (CE1, CE3, CE4, CE5, CE6, CE7)

GRUPO DE SABERES 3.1 EL ENTORNO LABORAL

•
El mercado de trabajo. Ocupación y desempleo.
•
Búsqueda de trabajo: currículum y entrevista laboral.
•
Desigualdad de género en el mundo laboral. La brecha salarial y el techo de cristal.
•
Derechos de las personas trabajadoras.

GRUPO DE SABERES 3.2 ESTABILIDAD DE PRECIOS

•
El dinero y los diferentes medios de pago. Monedas sociales.
•
Falsos mitos de las monedas virtuales.
•
Tipos de interés e inflación.

GRUPO DE SABERES 3.3 EL SISTEMA TRIBUTARIO. HERRAMIENTA DE IGUALDAD Y

EQUIDAD

•
Introducción a la Educación cívico-tributaria. Sensibilidad ante los efectos negativos
derivados del fraude fiscal y la evasión fiscal.
•
El pago de impuestos y los valores de justicia, equidad y solidaridad.
•
Principios tributarios. La necesidad de los ingresos públicos.
•
Principales medidas públicas como instrumentos de redistribución de la renta.

GRUPO DE SABERES 3.4 PRODUCCIÓN Y CRECIMIENTO SOSTENIBLE

•
Globalización: ventajas e inconvenientes.
•
Introducción a los indicadores del crecimiento.
•
Alternativas al crecimiento.

BLOQUE 4 LA NUEVA ECONOMÍA (CE1, CE2, CE3, CE4, CE5, CE6, CE7)

•
Objetivos de Desarrollo Sostenible. Agenda 2030.
•
Nuevas tendencias económicas: la Economía del Bien Común y la Economía Circular.
•
Diseño de un proyecto de colaboración con un servicio a la comunidad: una solución
cercana.

5. Situaciones de aprendizaje

En este apartado se presentan algunos principios para diseñar situaciones de aprendizaje acordes
con el enfoque competencial de la materia.

En primer lugar, hay que recordar que la capacidad de actuación del alumnado al enfrentarse a una
situación de aprendizaje requiere movilizar todo tipo de saberes implicados en las competencias específicas:
conceptos, procedimientos, actitudes y valores.

Las situaciones de aprendizaje deberían conectarse con los principales retos del siglo XXI, recogidos
en el perfil de salida. El Taller de Economía contribuye a formar personas críticas y responsables ante los
problemas actuales relativos al medio ambiente, degradación del planeta y exceso de consumo, para ser
conscientes de la importancia de sus acciones y su repercusión negativa en el bien común. Al mismo tiempo,
la materia contribuye a dar respuesta a problemas del entorno próximo poniendo de manifiesto su compromiso
en el ámbito local y global, valorando las competencias, cualidades y hábitos que debe tener una persona
emprendedora consciente de los retos del siglo XXI.

Para ello, es necesario hacer reflexionar al alumnado ante situaciones de inequidad y exclusión que
generen un sentimiento de empatía y justicia social desde una perspectiva colectiva, una resolución pacífica
de los conflictos con soluciones creativas que tengan como premisa la cooperación. Igualmente, el alumnado
debe reflexionar sobre la importancia del emprendimiento en el desarrollo económico y la creación de valor,
el análisis de nuevos modelos de negocio más sostenibles con el entorno.

Algunos criterios para diseñar situaciones de aprendizaje desde esta perspectiva serían los
siguientes:

•
Estar relacionadas con actividades del ámbito local y próximo al alumnado que establezca relaciones
los Objetivos de Desarrollo Sostenible que incorporan los desafíos globales a los que nos enfrentamos
día a día, tales como la desigualdad, medio ambiente, empleo, escasez, propiedad intelectual,
permitiendo descubrir el funcionamiento de la economía y la actividad empresarial.

•
Conectarlas con otras materias para adquirir una visión integral de la economía y asumir
responsabilidades y compromisos, desde una perspectiva interdisciplinar.
•
Diseñarlas para incentivar la reflexión, promover la competencia clave de aprender a aprender, y
desarrollar un enfoque crítico, con la finalidad de conseguir actitudes sensibles, comportamientos
responsables y proactivos que permitan aprovechar las oportunidades sociales y económicas.
•
Tienen que estimular el fomento de la lectura y la escritura a través de diferentes canales que les
permitan ser ciudadanos críticos y respetuosos ante diferentes argumentos y opiniones, así como
remarcar la necesidad de potenciar las habilidades comunicativas necesarias a la hora de emprender
un proyecto personal.
•
Permitir que sean abordadas tanto de manera individual como grupal, incorporando un enfoque
inclusivo, coeducativo, dando visibilidad a la relevancia del papel de las mujeres en la actividad
empresarial, y con el uso de técnicas de trabajo tanto cooperativo como colaborativo, a través de
actividades dialógicas, de debate, de explicación de resultado de tareas.
•
Conectar los contenidos con experiencias y sentimientos personales del alumnado que han tenido
lugar en otros contextos, movilizando la capacidad de argumentación mediante el lenguaje verbal y
no verbal.
•
Potenciar los talentos individuales utilizando herramientas que posibiliten el estímulo de la creatividad,
la participación activa del alumnado, para afrontar los problemas desde diferentes perspectivas según
su diversidad personal y cultural.
•
Favorecer la aceptación y el manejo de la incertidumbre tratada desde el aula y que dé respuesta a
cuestiones que le servirán para enfocar su futuro de trabajo o estudios e incluso la posibilidad de, a
partir de una iniciativa diseñada en el aula, poder trasladarlas fuera de la misma.
•
Permitir la inclusión del conjunto del alumnado y para ello utilizarían los principios del Diseño Universal
de Aprendizaje.
•
Impulsar un buen uso de las nuevas tecnologías en el aula, aprendiendo nuevos programas,
aplicaciones y herramientas informáticas para fomentar la alfabetización digital y audiovisual del
alumnado y la gamificación en el aula para incrementar su motivación, autonomía y el abanico de
recursos necesarios para el correcto análisis de la disciplina.

6. Criterios de evaluación

Competencia específica 1. Identificar los problemas económicos básicos vinculados con la escasez y
la necesidad de elegir, relacionándolos con situaciones del entorno más cercano.

1.1. Identificar el problema básico de la escasez a partir de experiencias vividas en su
entorno comparándolo con las necesidades económicas que haya tenido en cada etapa de su
vida.

1.2. Identificar el coste de oportunidad en la toma de decisiones, analizando situaciones
cotidianas de su realidad más próxima.

1.3. Describir la realidad económica actual, analizando cómo repercute en el bienestar
social de su entorno más cercano.

Competencia específica 2. Analizar las cualidades individuales y colectivas que caracterizan una
actitud emprendedora y ponerlas en práctica, mediante el trabajo cooperativo, para encontrar nuevas
oportunidades de mejora en el entorno social y económico más próximo basadas en principios de equidad,
coeducación e igualdad.

2.1. Poner en práctica habilidades sociales, de motivación, liderazgo y de cooperación en
distintos contextos de trabajo en equipo, utilizando diferentes estrategias comunicativas basadas
en principios de equidad, coeducación e igualdad.

2.2. Analizar los resultados alcanzados en su trabajo diario con conciencia del esfuerzo
personal aplicado y los logros obtenidos, realizando propuestas de mejora.

2.3. Identificar las fortalezas y debilidades personales, relacionándolas con los diferentes
ámbitos del desarrollo personal y la vida diaria y aplicándolas en la elaboración de las propuestas
de mejora con creatividad y hábitos de estudio y trabajo.

Competencia específica 3. Describir la importancia del papel de las familias, las empresas y el Estado
en el funcionamiento de la economía, analizando la realidad socioeconómica del entorno más cercano del
alumnado.

3.1 Identificar cómo se produce el desarrollo económico y el bienestar social evaluando,
con sentido crítico, el papel de los distintos agentes económicos y sus relaciones, estableciendo
su conexión con hechos relevantes.

3.2 Describir los principales costes y beneficios que supone para la sociedad los
comportamientos en el mercado por parte de los agentes económicos, manifestando actitudes de
respeto e interés y debatiendo sobre ello para desarrollarla autonomía y el espíritu crítico.

3.3. Representar el flujo circular de la renta señalando el papel de los distintos agentes
económicos.

3.4. Identificar el papel del Estado a través de algunas de sus principales actuaciones,
reflexionando sobre su impacto económico y social.

Competencia específica 4 Identificar los principales indicadores macroeconómicos relacionados con
el mercado de trabajo, la redistribución de la renta, el crecimiento y los precios que le hagan comprender su
realidad, utilizando fuentes y herramientas básicas de análisis.

4.1 Identificar algunos indicadores macroeconómicos básicos de la economía, analizando
datos contrastados y valorando aquellos que tienen en cuenta aspectos redistributivos y sociales.

4.2 Describir los mecanismos básicos del funcionamiento del mercado de trabajo,
identificando los signos de desigualdad de género de forma crítica.

4.3 Definir la inflación y sus efectos sobre los consumidores, las empresas y la economía
en general, mediante la interpretación de datos facilitados.

4.4 Analizar aquellos indicadores básicos que le ayuden a conocer la situación de la
economía, su estructura, su nivel de competitividad y hacia dónde se dirige para conseguir un
mundo más sostenible, equitativo e igualitario.

Competencia específica 5. Explicar la conexión entre la actividad del Estado y la necesidad de
financiación pública para el cumplimiento de sus objetivos, así como, identificar las principales figuras
tributarias, valorando la función social y el papel redistributivo de los impuestos en la sociedad.

5.1. Diferenciar los diferentes tipos de ingresos públicos, especialmente los impuestos,
reflexionando sobre su necesidad y su papel en el mantenimiento del Estado de Bienestar.

5.2. Relacionar los distintos tributos con los niveles de administraciones públicas,
identificándolos con las políticas de gasto.

5.3. Relacionar el fraude fiscal con la igualdad y la redistribución de la renta y la riqueza,
valorando la importancia del comportamiento cívico como contribuyentes.

Competencia específica 6. Recopilar información de diferentes fuentes económicas seleccionando
datos fiables que den rigor a las propuestas de mejora del proyecto de colaboración con un servicio a la
comunidad.

6.1 Resumir textos económicos sencillos utilizando correctamente la terminología
económica adaptada al nivel educativo en actividades orales y escritas del ámbito personal,
académico, social o profesional, en las distintas lenguas del currículo, utilizando un lenguaje no
discriminatorio.

6.2 Seleccionar noticias de actualidad económica, que den respuesta a las propuestas
de mejora del proyecto de servicios a la comunidad.

6.3 Diferenciar hechos y opiniones de la información obtenida, generando un
comportamiento crítico hacia las fuentes consultadas.

Competencia específica 7. Diseñar un proyecto sencillo de colaboración con un servicio a la
comunidad que posibilite la mejora de la calidad de vida de las personas y el medio ambiente, basándose en
los principios recogidos en los Objetivos de Desarrollo Sostenible.

7.1 Señalar iniciativas en su entorno más próximo, relacionadas con los ODS que
identifiquen oportunidades para mejorar el ámbito local y global, desde una perspectiva crítica y
constructiva.

7.2 Diseñar un proyecto sencillo de colaboración con un servicio a la comunidad, dando
respuesta a necesidades detectadas en su entorno local.

7.3 Analizar las oportunidades que el proyecto de colaboración con un servicio a la
comunidad diseñado ofrece a su realidad más próxima, reforzando la autoestima, la creatividad
y el sentido de pertenencia.
