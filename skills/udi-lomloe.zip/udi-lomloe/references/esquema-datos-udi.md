# Esquema del JSON de la UDI

`scripts/generar_udi.py` lee un único fichero JSON y produce las dos plantillas en .docx.
Ejemplo completo y válido: `ejemplos/ejemplo-udi-biologia-3eso.json`.

Todos los campos son opcionales salvo `area` y `udi`: lo que falte, se deja en blanco en la
plantilla. Cualquier campo de texto acepta también una **lista de cadenas** (se escribe una por
línea) y los saltos de línea `\n` dentro de una cadena se respetan.

```jsonc
{
  "etapa": "Educación Secundaria Obligatoria",
  "curso": "3.º ESO",
  "area": "Biología y Geología",          // da nombre al fichero de salida

  "udi": {
    "numero": 1,
    "titulo": "Alerta epidemiológica en el barrio",
    "situacion_aprendizaje": "Contexto, reto y producto final (3-6 líneas)."
  },

  // ── PLANTILLA 2 ───────────────────────────────────────────────────────────
  "competencias": [                        // un bloque de color por competencia específica
    {
      "oge": "5, 6, 7",                    // números de Objetivos Generales de Etapa
      "perfil_salida": "STEM1\nSTEM2\nCD1",// descriptores operativos (uno por línea o lista)
      "codigo": "CE1",
      "competencia": "Enunciado literal de la competencia específica.",
      "criterios": [
        {
          "codigo": "1.1",
          "texto": "Criterio de evaluación literal del curso correspondiente.",
          "instrumento": "Rúbrica del informe\n(20 %)"
        }
      ],
      "saberes": [                          // lista → se escribe con viñetas
        "Bloque A. Proyecto científico: hipótesis, preguntas y conjeturas.",
        "Bloque C. Salud y enfermedad: agentes infecciosos y prevención."
      ]
    }
  ],

  "justificacion_competencial": "Párrafo sobre la contribución al desarrollo competencial.",

  "ponderacion": [                          // tabla resumen; los pesos deben sumar 100 %
    { "instrumento": "Rúbrica del producto final", "criterios": "1.2, 3.2, 6.2",
      "momento": "Sesiones 8-9", "peso": "45 %" }
  ],

  // ── PLANTILLA 3 ───────────────────────────────────────────────────────────
  "vision_general": "Resumen de las fases, el producto final y la audiencia.",

  "secuencia": [                            // en el orden real de la secuencia
    {
      "n": 1,
      "titulo": "Llega el aviso",           // opcional; se escribe en negrita
      "actividad": "Qué hace el alumnado, con detalle.",
      "modelo_ensenanza": "Indagación",
      "metodologia": "Aprendizaje basado en retos",
      "organizacion_aula": "Gran grupo y equipos de 4",
      "sesiones": "1",
      "escenarios": "Aula ordinaria",
      "materiales": "Comunicado, mural, post-its, proyector"
    },
    { "prueba_objetiva": "PRUEBA OBJETIVA 1 (20 %) · Contenidos evaluados" }
  ],

  // ── ANEXOS de la Plantilla 3 ──────────────────────────────────────────────
  "anexos": {
    "dua": {
      "representacion":   ["…", "…"],
      "implicacion":      ["…", "…"],
      "accion_expresion": ["…", "…"]
    },
    "diversidad": {
      "refuerzo":        ["…"],
      "profundizacion":  ["…"],
      "otras":           ["…"]              // opcional
    },
    "rubrica": {
      "titulo": "Informe epidemiológico",
      "escala": ["1 · En inicio", "2 · En desarrollo", "3 · Adquirido", "4 · Avanzado"],
      "indicadores": [
        {
          "criterio": "CE1 · 1.2",          // criterio de evaluación al que responde
          "indicador": "Rigor metodológico.",
          "niveles": ["Descriptor nivel 1", "Nivel 2", "Nivel 3", "Nivel 4"],
          "peso": "15 %"
        }
      ]
    },
    "ods": [
      { "meta": "ODS 3 · Meta 3.3",
        "concrecion": "Cómo se trabaja en esta UDI.",
        "valores": "Pensamiento crítico y valores asociados." }
    ]
  }
}
```

## Comprobaciones que hace el script

Al terminar imprime avisos si:

- los pesos de `ponderacion` no suman 100 %;
- indica siempre el total de sesiones planificadas, para contrastarlo con lo pedido por el docente.

## Detalles de formato

- El número de bloques de competencia no está limitado; los colores se repiten a partir del noveno.
- El número de niveles de la rúbrica es libre (3, 4, 5…): se toma de `escala`.
- Si `anexos` no existe, la Plantilla 3 se genera solo con la secuencia (fiel al original en papel).
