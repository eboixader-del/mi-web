# Plantillas del centro: estructura y contenido de cada casilla

Los originales están en `assets/`:

- `PLANTILLA 2 CONCRECIÓN CURRICULAR.pdf`
- `PLANTILLA 3 TRANSPOSICIÓN DIDÁCTICA.pdf`

Ambas van en **A4 apaisado**, con el logotipo «Udi · Unidad didáctica integrada» y el título en azul
en la cabecera de cada página. El script `scripts/generar_udi.py` reproduce ese diseño en .docx.

---

## PLANTILLA 2 · CONCRECIÓN CURRICULAR

### Cabecera (fondo amarillo `FFE599`)

| Casilla | Qué se escribe |
| --- | --- |
| ETAPA | Educación Secundaria Obligatoria / Bachillerato |
| CURSO | 1.º-4.º ESO o 1.º-2.º Bachillerato |
| ÁREA | Materia o ámbito (si es interdisciplinar, la materia principal y entre paréntesis las afines) |
| UDI n | Número y título de la unidad |
| SITUACIÓN DE APRENDIZAJE | Descripción del contexto, el reto y el producto final (3-6 líneas) |

### Bloque por competencia específica

Se repite un bloque **por cada competencia específica** trabajada, cada uno con un color distinto
(verde `CDE4BE`, rosa `FFB7FF`, gris `CCCCCC`, amarillo `FFFF93`, morado `D9B3FF`, menta `BDFFDE`,
melocotón `FFD7AF`, lima `D8FF8B`). Estructura de cada bloque:

```
┌────────┬───────────────────┬───────────────────────────────────────────────┐
│  OGE   │ PERFIL DE SALIDA  │            COMPETENCIAS ESPECÍFICAS           │
├────────┼───────────────────┼───────────────────────────┬───────────────────┤
│ 5, 6,7 │ STEM1 STEM2 CD1   │ CE1. Texto literal…       │                   │
│        │                   ├───────────────────────────┼───────────────────┤
│        │                   │ CRITERIOS DE EVALUACIÓN   │   INSTRUMENTO     │
│        │                   │ 1.1. Texto literal…       │ Rúbrica … (20 %)  │
│        │                   │ 1.2. …                    │ …                 │
│        │                   ├───────────────────────────┴───────────────────┤
│        │                   │              SABERES BÁSICOS                  │
│        │                   │ Bloque A. …                                   │
└────────┴───────────────────┴───────────────────────────────────────────────┘
```

- **OGE**: números de los Objetivos Generales de Etapa (`references/objetivos-etapa.md`) a los que
  contribuye esa competencia específica. Habitualmente 2-4.
- **PERFIL DE SALIDA**: códigos de los descriptores operativos (`references/perfil-de-salida.md`).
  El currículo de cada materia indica, junto a cada competencia específica, con qué descriptores se
  vincula: úsalos como fuente y selecciona los que la UDI desarrolla realmente.
- **COMPETENCIAS ESPECÍFICAS**: código + enunciado **literal** del currículo.
- **CRITERIOS DE EVALUACIÓN**: los del **curso** correspondiente (el currículo los presenta en
  tablas de dos columnas, una por curso: no mezcles cursos), literales y con su numeración.
- **INSTRUMENTO**: instrumento con el que se evalúa ese criterio y su peso (%) sobre la nota de la
  UDI. Los pesos de todos los criterios deben sumar 100 %.
- **SABERES BÁSICOS**: los saberes implicados, indicando el bloque oficial (Bloque A, B, C…).

### Añadidos que genera el script

Después de los bloques, el .docx incluye dos apartados que la plantilla en papel no contempla pero
que el protocolo exige: **contribución al desarrollo competencial** (párrafo justificativo) y una
tabla de **ponderación de los instrumentos de evaluación** (instrumento · criterios asociados ·
momento · peso). Si el docente prefiere la plantilla estricta, se omiten dejando esos campos vacíos
en el JSON.

---

## PLANTILLA 3 · TRANSPOSICIÓN DIDÁCTICA Y PLANIFICACIÓN DEL DESARROLLO DE LA UDI

### Visión general (fondo amarillo)

«VISIÓN GENERAL DE LA SECUENCIA DIDÁCTICA DE LA TAREA:» + párrafo que resume las fases
(motivación → desarrollo → aplicación → evaluación), el producto final y la audiencia.

### Bloque por actividad/sesión

Se repite por cada actividad, alternando azul `C5D3ED` y verde `C5E0B3`:

```
┌────┬──────────────────────────┬──────────────────┬──────────────┬───────────────────┐
│    │    ACTIVIDAD DESCRITA    │ MODELO DE ENSEÑ. │ METODOLOGÍA  │ ORGANIZACIÓN AULA │
│ n  │ Título y descripción     │ Indagación       │ ABP          │ Equipos de 4      │
├────┴──────────┬───┬───────────┼──────────┬───────┴──────┬────────────────────────┬─┘
│ NÚM. SESIONES │ 1 │ ESCENARIOS│ Aula …   │  MATERIALES  │ Rúbrica, tabletas…     │
└───────────────┴───┴───────────┴──────────┴──────────────┴────────────────────────┘
```

- **ACTIVIDAD DESCRITA**: título breve en negrita y descripción de lo que **hace el alumnado**.
  Indica entre paréntesis la fase (motivación, desarrollo, aplicación, evaluación) si ayuda.
- **MODELO DE ENSEÑANZA** y **METODOLOGÍA**: ver `references/metodologias-dua-evaluacion.md`.
- **ORGANIZACIÓN AULA**: agrupamiento (individual, parejas, equipos de 4, gran grupo, grupos
  flexibles…).
- **NÚMERO DE SESIONES**, **ESCENARIOS** (aula ordinaria, laboratorio, aula de informática, patio,
  salida, entorno virtual) y **MATERIALES** (recursos y TIC).

### Filas de prueba objetiva (fondo amarillo)

La plantilla original reserva filas del tipo «PRUEBA OBJETIVA 1 ( %)» intercaladas en la secuencia.
Colócalas en el punto de la secuencia donde se aplican, con su peso: `PRUEBA OBJETIVA 1 (20 %)`.

### Anexos que añade el script (páginas finales)

1. **DUA**: tabla con los tres principios (representación, implicación, acción y expresión).
2. **Atención a la diversidad**: refuerzo y apoyo / profundización y enriquecimiento.
3. **Rúbrica del producto final**: indicador de logro × niveles (por defecto 4) + peso.
4. **Valores, ODS y ciudadanía**: meta ODS · concreción en la UDI · pensamiento crítico y valores.
