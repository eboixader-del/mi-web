---
name: auditar-programacion-fp-cv
description: Audita una programación didáctica de módulo de FP ya redactada frente a los apartados obligatorios de la Comunitat Valenciana, el PCCF y la Orden 8/2025 de evaluación, señalando huecos y contradicciones sin inventar una nota oficial.
---

# Auditar una programación de FP

Esta skill es de solo lectura salvo que el docente pida explícitamente que corrijas el documento.

## Lista de comprobación (apartados obligatorios)
Verifica que la programación contiene, con contenido real y no solo el título del epígrafe:
1. Datos identificativos, marco normativo y contextualización del módulo.
2. Relación entre resultados de aprendizaje (RA) y competencias/estándares del ciclo.
3. Contribución del módulo a las competencias generales del título.
4. Esquema general y secuenciación de unidades de programación, con su distribución horaria.
5. Metodología de enseñanza-aprendizaje.
6. Recursos, espacios y equipamiento necesarios.
7. Medidas de atención a la diversidad.
8. Evaluación del aprendizaje: ponderación de RA, calificación, sesiones, recuperación — coherente con la Orden 8/2025 (ver la skill disenar-evaluacion-fp-cv).
9. Actividades complementarias y extraescolares.
10. Criterios y procedimientos para evaluar el desarrollo de la programación y la práctica docente, y los criterios de calificación.

## Procedimiento
1. Fija alcance (programación completa o un apartado) y versión del documento auditado; identifica qué falta de fuentes (decreto de currículo, PCCF, acuerdos de departamento) para verificar cada punto, y qué queda "no verificable" por falta de esas fuentes.
2. Para cada apartado de la lista, evalúa como cumple / parcial / no cumple / no verificable, citando la ubicación exacta en el documento (apartado, página o epígrafe) y la evidencia.
3. Revisa especialmente: que los RA y CE citados sean literales del decreto de currículo, que los pesos de evaluación sumen 100 %, que la calificación sea numérica 1-10 sin decimales, que las convocatorias no superen el máximo legal, y que la programación no contradiga lo ya fijado en el PCCF del ciclo.
4. Entrega los hallazgos como una tabla con: apartado, estado, evidencia/ubicación, diagnóstico, acción propuesta y responsable. No emitas una calificación global oficial de la programación — eso corresponde al procedimiento de aprobación del centro/departamento.
5. Si el docente pide corrección, aplícala solo sobre lo detectado y sin reescribir apartados no auditados.

## Límites
No certifiques conformidad institucional ni sustituyas la aprobación del departamento o la dirección del centro. No inventes una versión de la Orden 8/2025 o del decreto de currículo si no la tienes disponible: pide el documento o marca el punto como no verificable.
