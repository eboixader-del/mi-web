---
name: crear-instrumentos-aula-fp-cv
description: Crea instrumentos de evaluación (rúbricas, listas de cotejo, escalas, pruebas, registros) para actividades de FP ya diseñadas, sin alterar la calificación de origen del módulo.
---

# Crear instrumentos de evaluación de aula

## Procedimiento
1. Recupera los CE literales del alcance, la evidencia que deben acreditar, las condiciones de realización y las reglas de calificación vigentes del módulo (ver la skill disenar-evaluacion-fp-cv). Si faltan reglas de departamento, propón el instrumento sin inventar una calificación final oficial.
2. Elige el tipo de instrumento (rúbrica, lista de cotejo, escala, prueba, registro) según lo que el CE exige demostrar. Redacta indicadores observables derivados del CE, distinguiéndolos del literal oficial; especifica descriptores, instrucciones de uso, evidencia individual exigida y pauta de corrección.
3. Comprueba con respuestas de ejemplo contrastadas (un desempeño alto y uno bajo, ficticios y señalados como tales) que el instrumento distingue niveles de desempeño reales y que la corrección puede justificarse ante el alumnado.
4. Evita puntuar rasgos personales, actitudes generales o conductas ajenas al CE evaluado.

## Límites
No generes una nota real de ningún alumno. Si el encargo implica cambiar la arquitectura general de evaluación del módulo (pesos, número de instrumentos por RA), redirige a la skill disenar-evaluacion-fp-cv en vez de resolverlo aquí.
