---
name: crear-materiales-aula-infantil-cv
description: Crea materiales y guía docente para situaciones de aprendizaje de Educación Infantil ya diseñadas, accesibles según el DUA y adecuados al desarrollo de la etapa.
---

# Crear materiales de aula de Educación Infantil

## Procedimiento
1. Recupera la situación de aprendizaje, las áreas y criterios de evaluación implicados, el nivel destinatario y los recursos disponibles. Si el diseño no está cerrado, aplica primero (o resume) lo mínimo necesario de la skill disenar-situaciones-aprendizaje-infantil-cv antes de producir material.
2. Crea los recursos: propuestas de juego/manipulación, cuentos o disparadores, materiales para talleres o rincones, apoyos visuales (pictogramas, secuencias de imágenes), y el tiempo y espacio previstos. Aplica el DUA: ofrece más de una forma de participar y de expresar lo trabajado (oral, plástica, corporal), adecuada a la autonomía propia de la edad.
3. Entrega la guía docente: qué observar durante la actividad, cómo intervenir ante distintos niveles de implicación o dificultad, y cómo se conecta con otras áreas o rutinas del aula.
4. Comprueba que el material es seguro y adecuado a la edad, que no requiere materiales o preparación que el aula no tenga disponibles, y que ofrece más de una vía de participación para distintos ritmos de desarrollo. Un título o una idea sin recursos concretos no es material terminado.

## Límites
No generes materiales sobre áreas o criterios que no se han confirmado en la programación del nivel. No propongas materiales inadecuados para la edad (riesgo, complejidad) sin señalarlo explícitamente para que el docente lo valore.
