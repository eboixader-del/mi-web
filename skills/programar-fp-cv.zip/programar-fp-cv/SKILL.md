---
name: programar-fp-cv
description: Coordina la elaboración de una programación didáctica de módulo de FP en la Comunitat Valenciana, desde el contexto y el currículo hasta la evaluación, la secuenciación de unidades y el cierre, ajustada al PCCF del ciclo y a la normativa vigente.
---

# Programar un módulo de FP en la Comunitat Valenciana

## Marco normativo de referencia
- Ley Orgánica 3/2022, de ordenación e integración de la Formación Profesional; Real Decreto 659/2023 (marco estatal).
- Decreto autonómico de currículo del ciclo formativo correspondiente (uno distinto por título; pide al docente el suyo si no se ha aportado).
- Orden 8/2025, de 22 de abril, de evaluación del proceso de enseñanza-aprendizaje en ciclos formativos (modificada por la Orden 6/2026): calificación, sesiones de evaluación, recuperación, promoción.
- Proyecto Curricular de Ciclo Formativo (PCCF) del centro: la programación de módulo debe ajustarse a él y a las directrices de la Comisión de Coordinación Pedagógica, sin duplicar lo que el PCCF ya fija. Apóyate en la "Guía práctica para el docente" del PCCF (Conselleria d'Educació) y en la "Propuesta fundamentada" (libro de programación en la nueva FP, con ejemplos por familia profesional) para completar cada apartado con criterio pedagógico.
- Instrucciones de inicio de curso vigentes del año en cuestión (se publican cada curso y pueden variar plazos y detalles).

Este marco está verificado a fecha de esta skill (curso 2025-2026). Antes de dar por buena una programación, contrasta fechas, convocatorias y plazos con la instrucción de inicio de curso vigente y con el PCCF del propio centro; no cites artículos de memoria si tienes duda.

## Entradas
Pide al docente: ciclo formativo, módulo, curso académico, decreto de currículo del ciclo (RA, CE, contenidos), PCCF vigente si existe, programación anterior si la hay, perfil de grupo, entorno productivo del centro/comarca, horario y recursos disponibles. Empieza con lo disponible; marca como pendiente lo que falte y no inventes acuerdos del departamento (ponderaciones, RA clave, calendario) que no se hayan confirmado.

## Procedimiento
1. **Contexto y currículo.** Fija curso, grado y modalidad; localiza RA, CE y contenidos literales del decreto de currículo del ciclo. Recoge contexto del centro y del grupo solo desde fuentes o respuestas del docente.
2. **Evaluación.** Aplica la skill disenar-evaluacion-fp-cv para fijar ponderación de RA, calificación, recuperación y comunicación al alumnado conforme a la Orden 8/2025.
3. **Unidades y secuenciación.** Organiza el módulo en unidades de programación con su distribución horaria, relacionando cada una con RA/CE. Distingue horas en el centro y, si aplica, en formación en empresa (FCT/proyecto intermodular).
4. **Redacción.** Integra los apartados obligatorios en un documento único, siguiendo el índice de tu centro si existe una plantilla propia; si no, usa como esqueleto: datos identificativos y marco normativo; contextualización del módulo; relación entre resultados de aprendizaje y competencias del ciclo; contribución del módulo a las competencias generales; secuenciación de unidades de programación; metodología de enseñanza-aprendizaje; recursos, espacios y equipamiento; medidas de atención a la diversidad; evaluación del aprendizaje; actividades complementarias y extraescolares; criterios y procedimientos para evaluar el desarrollo de la programación y la práctica docente.
5. **Revisión.** Aplica la skill auditar-programacion-fp-cv sobre el borrador antes de entregarlo. Corrige lo detectado y deja explícitos los pendientes que dependan de acuerdos de departamento o del PCCF.
6. Entrega la programación con lo confirmado, lo propuesto y lo pendiente claramente diferenciado; no presentes una propuesta propia como acuerdo institucional ya tomado.

## Límites
No inventes normativa, ponderaciones de departamento ni fechas de convocatorias. Cuando falte un dato de centro (PCCF, acuerdos de familia profesional), declára pendiente en vez de rellenarlo con un valor plausible.
