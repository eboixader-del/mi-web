---
name: disenar-evaluacion-eso-cv
description: Diseña el sistema de evaluación de una materia de ESO en la Comunitat Valenciana (instrumentos por criterio de evaluación, calificación, recuperación y reglas de promoción/titulación) conforme a la Orden 19/2023 y la normativa de evaluación vigente.
---

# Diseñar la evaluación de una materia de ESO

## Normativa de referencia
- Decreto 107/2022, de 5 de agosto (currículo de ESO en la Comunitat Valenciana), **modificado por el Decreto 66/2024, de 21 de junio**: su artículo 21 y concordantes son la base de la evaluación y la promoción.
- Orden 19/2023, de 29 de junio, de procedimientos derivados de los Decretos 107/2022 y 108/2022, también afectada por el Decreto 66/2024.
- Real Decreto 984/2021 como marco estatal de referencia.
- Instrucciones de inicio de curso vigentes cada año (pueden precisar plazos, sesiones de evaluación y criterios de departamento).

No cites la Resolución de 20 de abril de 2022 como norma de evaluación vigente: era la concreción transitoria del Real Decreto 984/2021 para el curso 2021-2022, anterior a los decretos LOMLOE valencianos, y ha quedado desplazada.

Puntos fijados por la normativa que debes respetar, no reinterpretar (verifícalos contra la instrucción del curso vigente antes de aplicarlos):
- La evaluación toma como referente los criterios de evaluación de cada competencia específica, no los saberes básicos por sí solos.
- Promoción: con evaluación negativa en una o dos materias, el alumnado promociona; con más de dos, decide el equipo docente de forma colegiada considerando el grado de adquisición de las competencias y las medidas de progreso adoptadas — no hay un número fijo de suspensas que impida promocionar automáticamente. El tutor o tutora tiene voto de calidad en caso de empate.
- Repeticiones: el Decreto 107/2022 establece que no se puede repetir más de dos veces en la etapa de ESO ni dos veces el mismo curso. El cómputo de un máximo de dos repeticiones en el conjunto de la enseñanza obligatoria (Primaria + ESO) es regla estatal del Real Decreto 984/2021: cítala como tal, no como texto del decreto valenciano.
- Titulación en 4º de ESO: por decisión colegiada del equipo docente sobre el logro de los objetivos de la etapa y las competencias del perfil de salida. **No apliques ninguna regla de titulación con materias pendientes basada en una nota media mínima**: ese esquema procede del marco LOMCE derogado y no consta en la normativa LOMLOE valenciana. Si el centro dice tener un criterio de ese tipo, pide su base normativa exacta antes de reflejarlo.

## Lo que decide el centro/departamento, no la normativa
La normativa no fija instrumentos concretos, ni la ponderación entre criterios de evaluación de una misma competencia específica, ni el número de situaciones de aprendizaje evaluables por trimestre: eso lo decide el departamento y debe quedar reflejado en la programación y en los acuerdos de la Comisión de Coordinación Pedagógica. No lo inventes; pide el acuerdo o propónlo explícitamente como pendiente de validar.

## Procedimiento
1. Recupera los criterios de evaluación literales del curso y materia, agrupados por competencia específica.
2. Define, para cada criterio de evaluación, qué instrumento(s) lo evalúan y con qué peso dentro de la competencia específica; especifica cómo se combinan las competencias específicas en la calificación final de la materia.
3. Describe el procedimiento de recuperación durante el curso y, si aplica, en la evaluación final/extraordinaria del centro.
4. Redacta cómo se comunican al alumnado y a las familias los resultados de cada evaluación.
5. Añade el apartado de evaluación de la propia programación y de la práctica docente.
6. Comprueba coherencia: todos los criterios de evaluación del curso quedan cubiertos por al menos un instrumento; no hay pesos que sumen algo distinto de lo declarado; las reglas de recuperación no contradicen los acuerdos de centro.

## Límites
No fijes una regla de promoción/titulación más estricta o más laxa que la vigente (por ejemplo, no inventes un número máximo de suspensas). No inventes acuerdos de ponderación de departamento si no existen: márcalos como propuesta.
