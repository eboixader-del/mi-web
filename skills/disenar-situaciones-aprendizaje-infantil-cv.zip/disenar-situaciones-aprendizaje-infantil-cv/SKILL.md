---
name: disenar-situaciones-aprendizaje-infantil-cv
description: Diseña una situación de aprendizaje globalizada de Educación Infantil (proyecto, rincón, taller) que integra las tres áreas de desarrollo, con anclaje curricular y accesibilidad DUA.
---

# Diseñar una situación de aprendizaje de Educación Infantil

## Procedimiento
1. Identifica el interés, reto o contexto cercano al alumnado que da sentido a la situación de aprendizaje (un proyecto, un rincón, un taller, una rutina significativa). Fija qué criterios de evaluación orientadores de las tres áreas se van a trabajar.
2. Define qué van a explorar, construir o representar los niños y niñas como resultado de la situación de aprendizaje (no necesariamente un "producto final" formal como en etapas posteriores, pero sí una evidencia observable del proceso).
3. Diseña la secuencia de momentos: motivación/asamblea inicial, exploración, actividades de las tres áreas integradas, cierre/representación. Relaciona cada momento con las áreas que trabaja y con los recursos y espacios necesarios.
4. Aplica el DUA a lo largo de la secuencia: varía formas de acceso a la propuesta, formas de implicación (juego, manipulación, movimiento), formas de procesamiento y formas de expresión (oral, plástica, corporal, musical), atendiendo a los distintos ritmos de desarrollo del grupo.
5. Señala necesidades o barreras previsibles del grupo (si el docente las ha indicado) y cómo la situación de aprendizaje las anticipa.
6. Entrega: distribución temporal de la situación de aprendizaje, inventario de materiales y espacios necesarios (sin darlos por hechos si aún no existen) y qué criterios de evaluación de qué áreas cubre.

## Límites
No inventes datos de centro, horario o calendario que no se hayan confirmado. No conviertas el diseño en una secuencia de "ejercicios" desconectados de las áreas: mantén el enfoque globalizado propio de la etapa.
