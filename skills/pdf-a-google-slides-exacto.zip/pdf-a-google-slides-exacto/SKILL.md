---
name: "pdf-a-google-slides-exacto"
description: "Convierte un PDF (por ejemplo una exportación de Genially, un PDF interactivo, o cualquier presentación en PDF) en una copia visualmente exacta en formato de Google Slides, y la sube directamente al Google Drive del usuario. Usa siempre este skill cuando el docente pida \"pasar/convertir un PDF a Google Slides\", \"pasar esta presentación a Google\", \"necesito esto como Slides\", suba un PDF de Genially u otra herramienta y pida convertirlo, o mencione que debe ser una \"copia exacta\" de una presentación en PDF. No uses el skill de pptx genérico para esto: aquí NO se recrean textos ni diseños, se reproduce cada página del PDF como imagen a máxima fidelidad."
---


# PDF a Google Slides (copia exacta)

## Cuándo se usa

El docente recibe presentaciones interactivas (a menudo exportadas desde Genially, pero puede ser cualquier PDF de una presentación) y necesita una copia **visualmente exacta** en Google Slides para poder editarlas, compartirlas o usarlas en clase. Esto se repite con frecuencia, así que el objetivo es un flujo rápido y fiable, no una recreación "bonita" con plantillas — el usuario quiere que se vea IDÉNTICO al original.

## Por qué el enfoque es "imagen por diapositiva" y no recrear texto/diseño

Los PDF exportados de Genially suelen tener capas, fuentes incrustadas, efectos y posiciones absolutas que son casi imposibles de reproducir de forma editable con fidelidad 1:1. Intentar reconstruir el texto y las formas en pptx nativo casi siempre produce diferencias (fuentes, posiciones, colores). La solución fiable: renderizar cada página del PDF como una imagen de alta resolución y colocarla a sangre completa en su propia diapositiva. El resultado es una copia exacta, aunque el texto no sea editable dentro de Slides (si el docente necesita editar texto, avísale de esta limitación y pregunta si aun así quiere continuar).

## Flujo

### 1. Localizar el PDF y medir la página

```bash
pdfinfo "input.pdf"
```

Anota `Pages` y `Page size` (en pt). El tamaño de las diapositivas del pptx debe coincidir exactamente:
- `widthIn = page_width_pt / 72`
- `heightIn = page_height_pt / 72`

### 2. Renderizar cada página como imagen

Usa JPEG (no PNG) para mantener el archivo ligero — esto es crítico porque el paso de subida automática a Drive (más abajo) solo admite hasta 10 MB por archivo:

```bash
mkdir -p pages
pdftoppm -jpeg -jpegopt quality=85 -r 120 "input.pdf" pages/slide
```

Comprueba el tamaño total: `du -ch pages/*.jpg | tail -1`. Si el pptx resultante (aprox. el tamaño de las imágenes + un pequeño margen) va a superar ~9 MB, repite con menor resolución/calidad (prueba `-r 100` o `quality=75`) antes de continuar. Con 120dpi y calidad 85 una presentación típica de 5-10 páginas ronda 1-3 MB, muy por debajo del límite.

Si el usuario pide explícitamente máxima calidad y el archivo no se va a subir automáticamente (solo entregar el .pptx), puedes usar `-r 250` y PNG — pero entonces omite el paso de subida automática por Chrome (el archivo superará 10 MB) y entrega el archivo para que lo suba él manualmente.

### 3. Construir el .pptx

`pptxgenjs` está preinstalado en `/usr/local/lib/node_modules_global/lib/node_modules` — en este sandbox necesitas exportar `NODE_PATH` apuntando ahí para que `require("pptxgenjs")` funcione (un `npm install pptxgenjs` normal falla por política del registro).

Escribe este script (ajusta los parámetros) y ejecútalo:

```js
// build_pptx.js
// Uso: node build_pptx.js <imagesDir> <numSlides> <widthIn> <heightIn> <outputFile>
const pptxgen = require("pptxgenjs");
const path = require("path");
const fs = require("fs");

const [, , imagesDir, numSlidesArg, widthArg, heightArg, outputFile] = process.argv;
const numSlides = parseInt(numSlidesArg, 10);
const widthIn = parseFloat(widthArg);
const heightIn = parseFloat(heightArg);

let pres = new pptxgen();
pres.defineLayout({ name: "EXACTCOPY", width: widthIn, height: heightIn });
pres.layout = "EXACTCOPY";

for (let i = 1; i <= numSlides; i++) {
  const jpg = path.join(imagesDir, `slide-${i}.jpg`);
  const png = path.join(imagesDir, `slide-${i}.png`);
  const imgPath = fs.existsSync(jpg) ? jpg : png;
  const slide = pres.addSlide();
  slide.addImage({ path: imgPath, x: 0, y: 0, w: widthIn, h: heightIn });
}

pres.writeFile({ fileName: outputFile }).then(() => console.log("Creado " + outputFile));
```

```bash
NODE_PATH=/usr/local/lib/node_modules_global/lib/node_modules node build_pptx.js pages 7 12.5 7.032 presentacion.pptx
```

### 4. Verificación rápida

- Convierte a PDF con LibreOffice (`soffice --headless --convert-to pdf`) y compara 1-2 páginas visualmente contra el PDF original (usa Read para ver las imágenes) — deben ser indistinguibles.
- Comprueba que el número de diapositivas coincide con `Pages` del PDF original.
- Comprueba el tamaño del archivo final: si supera 10 MB y se va a subir automáticamente, vuelve al paso 2 con menor resolución.

### 5. Copiar a una ruta CORTA antes de subir (importante)

`file_upload` de la extensión de Chrome falla de forma silenciosa ("paths expected array received undefined") cuando la ruta es muy larga (rutas anidadas de ~150-200 caracteres, típicas de la carpeta de outputs de la sesión). Antes de subir, copia el .pptx final a una ruta corta — la raíz de la carpeta de outputs o la carpeta de trabajo del usuario funciona bien. No uses la ruta larga original directamente en `file_upload`.

### 6. Subir automáticamente a Google Drive

1. Carga las tools de Chrome si están diferidas: `ToolSearch("select:mcp__claude-in-chrome__tabs_context_mcp,mcp__claude-in-chrome__navigate,mcp__claude-in-chrome__computer,mcp__claude-in-chrome__find,mcp__claude-in-chrome__file_upload,mcp__claude-in-chrome__tabs_create_mcp")`.
2. `tabs_context_mcp` (createIfEmpty: true) y navega a `https://drive.google.com/drive/my-drive`.
3. Si aparece una pantalla de inicio de sesión de Google ("Demuestra que eres tú" o similar): **no introduzcas la contraseña**. Pide al docente que inicie sesión él mismo y espera su confirmación antes de continuar.
4. Con `find`, localiza el botón "Nuevo" y haz clic.
5. Con `find`, localiza el elemento de menú "Subir archivo" y haz clic (esto puede abrir un diálogo nativo del sistema operativo que no puedes ver ni controlar — no intentes interactuar con él).
6. Vuelve a llamar a `find` con una consulta como "input type file element for choosing files to upload" — tras el clic anterior, Drive expone un `<input type=file>` oculto en la página. Usa el `ref` que te devuelva.
7. Llama a `file_upload` con ese `ref` y la ruta CORTA del paso 5 (nunca hagas clic directamente sobre el input ni sobre el botón de subida con `computer` — eso abre el diálogo nativo inutilizable).
8. Confirma con una captura o `read_page` que la subida terminó (aparece una notificación "Subidas completadas" o el archivo en la lista).
9. Cierra las pestañas que hayas creado con `tabs_close_mcp` si ya no se necesitan.

Si el archivo supera el límite de 10 MB del `file_upload` (por ejemplo porque el usuario pidió máxima calidad), omite este paso y en su lugar entrega el .pptx explicando que debe subirlo él mismo a Drive (arrastrar el archivo a drive.google.com, luego doble clic para abrirlo con Slides).

### 7. Entregar

- Guarda una copia del .pptx final en la carpeta de trabajo del usuario y preséntala con `present_files`.
- Indica que el archivo ya está en su Google Drive (si la subida automática funcionó) y que basta con abrirlo con doble clic — Google Slides lo abre de forma nativa. Si quiere una copia 100% en formato Slides (no PowerPoint), puede hacer Archivo → Guardar como Google Slides desde el editor.

## Notas

- Si el PDF tiene páginas con proporciones distintas entre sí (poco común), avisa al docente — este flujo asume que todas las páginas comparten el mismo tamaño (lo habitual en exportaciones de Genially).
- El resultado no tiene texto seleccionable/editable — es una copia visual exacta. Si el docente necesita editar contenido de texto, coméntaselo antes de invertir tiempo en la subida automática.

