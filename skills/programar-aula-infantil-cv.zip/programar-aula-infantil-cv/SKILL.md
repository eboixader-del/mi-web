---
name: programar-aula-infantil-cv
description: Coordina la programación de aula de un nivel de Educación Infantil (una situación de aprendizaje o una secuencia completa de curso) a partir de una programación didáctica existente, con diseño accesible según el DUA.
---

# Programar aula de un nivel de Educación Infantil

Usa esta skill cuando el encargo sea "prográmame el aula de este nivel/curso" de principio a fin; para una pieza aislada (solo materiales, solo instrumentos de observación, solo revisión), ve directamente a la skill correspondiente.

## Procedimiento
1. Recupera la programación didáctica vigente del nivel (áreas, criterios de evaluación orientadores, situaciones de aprendizaje previstas) — si no está disponible, pide al docente el mínimo imprescindible y continúa con lo demás como propuesta pendiente de confirmar.
2. Para diseñar una situación de aprendizaje nueva, aplica la skill disenar-situaciones-aprendizaje-infantil-cv.
3. Según el encargo, aplica crear-materiales-aula-infantil-cv y/o crear-instrumentos-aula-infantil-cv.
4. Integra los productos y aplica auditar-aula-infantil-cv; corrige lo detectado dentro del alcance del encargo.
5. Entrega la situación de aprendizaje, los materiales, los instrumentos de observación y las comprobaciones realizadas, dejando explícitos los pendientes.

## Nota sobre accesibilidad
Todo el diseño de aula sigue el DUA (Diseño Universal para el Aprendizaje): un único itinerario con múltiples formas de acceso, implicación, procesamiento y expresión, adaptado a la autonomía y el desarrollo propios de la edad. Documenta también, cuando el docente lo indique, medidas de atención a la diversidad específicas del centro (apoyo, adaptaciones de acceso) sin inventar el nombre del plan o programa si no te lo han confirmado.
