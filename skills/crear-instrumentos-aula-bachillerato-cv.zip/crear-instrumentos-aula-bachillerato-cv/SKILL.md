---
name: crear-instrumentos-aula-bachillerato-cv
description: Crea instrumentos de evaluación (rúbricas, listas de cotejo, escalas, pruebas) para actividades de 1º o 2º de Bachillerato ya diseñadas, por criterio de evaluación y en la escala de 0 a 10 sin decimales, sin alterar los acuerdos de calificación del departamento.
---

# Crear instrumentos de evaluación de aula (Bachillerato)

## Procedimiento
1. Recupera los criterios de evaluación literales del alcance, la evidencia que deben acreditar y las reglas de calificación vigentes de la materia (ver la skill disenar-evaluacion-bachillerato-cv). Si faltan acuerdos del departamento, propón el instrumento sin inventar una calificación final oficial.
2. Elige el tipo de instrumento (rúbrica, lista de cotejo, escala, prueba escrita o práctica, registro) según lo que el criterio exige demostrar. Redacta indicadores observables derivados del criterio, distinguiéndolos del literal oficial; especifica descriptores por nivel de logro, instrucciones de uso, evidencia individual exigida y pauta de corrección.
3. Asegura que el instrumento traduce a la escala vigente: calificaciones numéricas **de 0 a 10 sin decimales**, siendo negativas las inferiores a 5 (art. 39.2 del Decreto 108/2022). Si el instrumento puntúa sobre otra escala, explicita la conversión.
4. Comprueba con respuestas de ejemplo contrastadas (un desempeño alto y uno bajo, ficticios y señalados como tales) que el instrumento distingue niveles reales y que la corrección puede justificarse ante el alumnado y ante una reclamación.
5. Evita puntuar rasgos personales, actitudes generales o conductas ajenas al criterio de evaluación.

## Límites
No generes una calificación real de ningún alumno. Si el encargo implica cambiar la arquitectura de evaluación de la materia (ponderaciones, número de instrumentos por competencia específica) o afecta a promoción o titulación, redirige a la skill disenar-evaluacion-bachillerato-cv en vez de resolverlo aquí. Ten presente que en Bachillerato las calificaciones tienen efectos académicos serios —nota media de la etapa y acceso a la universidad—, así que un instrumento debe poder defenderse por escrito.
