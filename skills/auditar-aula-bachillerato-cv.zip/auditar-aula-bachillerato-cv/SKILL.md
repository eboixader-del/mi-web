---
name: auditar-aula-bachillerato-cv
description: Audita situaciones de aprendizaje, materiales e instrumentos de aula de 1º o 2º de Bachillerato ya creados, frente a los criterios de evaluación que deben cubrir, la escala de calificación de 0 a 10 y los criterios DUA de accesibilidad.
---

# Auditar aula de Bachillerato

Auditoría interna de aula: distinta de auditar la programación de la materia o la propuesta pedagógica del departamento (para eso usa la skill auditar-programacion-bachillerato-cv).

## Procedimiento
1. Fija el alcance y las versiones de los productos a revisar (situación de aprendizaje, materiales, instrumentos) e identifica la programación de referencia.
2. Revisa cada criterio de evaluación del alcance: literal, desempeño exigido, evidencia esperada, instrumento asociado y regla de calificación. Señala criterios sin evidencia individual, instrumentos que no miden lo que dicen medir, y exigencias de autonomía incoherentes con los apoyos ofrecidos.
3. Comprueba que la calificación resultante encaja en la escala de 0 a 10 sin decimales y que ninguna regla del material contradice los acuerdos de evaluación del departamento.
4. Comprueba que los materiales están completos (con soluciones, no solo enunciados), que los tiempos son realistas para las sesiones disponibles, que los recursos citados existen o constan como pendientes, y que el DUA se aplica de forma real y no solo declarada.
5. **Verifica los datos y fuentes** que aparezcan en los materiales, o señala los que no hayas podido comprobar: en Bachillerato un dato erróneo presentado como real es un defecto de calidad, no un detalle.
6. Entrega los hallazgos con estado (cumple / parcial / no cumple / no verificable), evidencia con archivo y sección, impacto, acción propuesta y responsable. No certifiques la eficacia real en el aula: eso solo se comprueba usándolo con alumnado.

## Límites
No inventes una puntuación oficial de calidad del material ni calificaciones de alumnado. No modifiques los originales salvo que el docente pida corrección explícita.
