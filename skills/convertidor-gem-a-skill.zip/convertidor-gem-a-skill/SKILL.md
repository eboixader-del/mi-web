---
name: convertidor-gem-a-skill
description: "Convierte un Gem de Google Gemini (su instrucción y, si los tiene, sus documentos de conocimiento) en una skill de Claude completa: SKILL.md con cabecera, esquema de entrada/salida y, si aplica, los documentos empaquetados junto a ella. Úsala cuando el docente pegue o suba la instrucción de un Gem y pida convertirlo, portarlo o transformarlo en una skill de Claude, aunque no lo pida con estas palabras exactas."
disable-model-invocation: false
user-invocable: true
effort: medium
skill_id: "herramientas/convertidor-gem-a-skill"
skill_name: "Convertidor de Gem a Skill"
domain: "herramientas-de-produccion"
version: "1.0"
contributor: "elaboración propia"
nota_fuente: "skill de utilidad propia; el contenido que convierte procede de un Gem que el propio docente ha creado, por lo que no hay cuestión de licencia de terceros de por medio"
evidence_strength: "no aplica — es una herramienta de producción, no una intervención pedagógica en sí misma"
input_schema:
  requerido:
    - instruccion_gem: "El texto de las instrucciones del Gem, pegado directamente o subido como archivo — sin esto la skill no puede empezar"
  opcional:
    - documentos_gem: "Archivos que el Gem tenga adjuntos como conocimiento, si el docente los sube"
    - nombre_descripcion_gem: "El nombre y la descripción que tenía el Gem en Gemini, si los aporta, para conservar el tono"
    - contexto_uso: "Para qué lo usará una vez sea skill de Claude, si cambia respecto al uso que tenía como Gem"
output_schema:
  - resumen_traduccion: "Qué se conserva tal cual del Gem original y qué ha tenido que adaptarse por diferencias entre Gemini y Claude"
  - skill_completa: "El SKILL.md entero, con cabecera y cuerpo, listo para guardar"
  - documentos_empaquetados: "Qué documentos del Gem se han incluido en la carpeta de la skill, y en qué subcarpeta"
  - zip_final: "La skill empaquetada en zip y presentada para descargar"
teacher_time: "10 minutos"
tags: [gems, gemini, conversion-de-skills, produccion-de-recursos, ia-generativa]
---

# Convertidor de Gem a Skill

## Qué hace esta skill

Es la operación inversa de `convertidor-skill-a-gem`: en vez de partir de un `SKILL.md` público en
GitHub, parte de un Gem que el docente ya tiene funcionando en Gemini —su instrucción, y opcionalmente
sus documentos de conocimiento adjuntos— y produce una skill de Claude completa: cabecera con todos
los campos, esquema de entrada/salida, cuerpo con el patrón traducido, documentos empaquetados si los
había, y el zip final listo para subir.

La diferencia clave con la dirección contraria: aquí no hay ninguna URL que se pueda leer sola. El
Gem vive dentro de la cuenta de Gemini del docente — así que el primer paso siempre es pedirle
directamente el texto de la instrucción, no ir a buscarlo.

## Principios de diseño

- **Sin instrucción pegada, no hay conversión posible.** Si el docente invoca la skill sin haber pegado
  o subido el texto del Gem, lo primero es pedírselo — no se inventa ni se aproxima a partir del
  nombre o de lo que se recuerde de la conversación en la que se creó el Gem.
- **Detectar si el Gem es conversacional o de producción, antes de imponerle una estructura.** Un Gem
  como "Explícamelo tú" es una conversación turno a turno con reglas de comportamiento — forzarlo a
  un esquema rígido de entrada/salida lo rompería. Un Gem que el docente usa para diseñar algo (una SdA,
  una rúbrica) sí se beneficia de un esquema de entrada/salida formal, porque eso es lo que ya hemos
  hecho con las skills propias del docente en esta misma conversación.
- **Los documentos adjuntos del Gem se empaquetan, no se resumen.** Si el docente sube un documento que
  el Gem usaba como conocimiento, va dentro de la carpeta de la skill tal cual (en una subcarpeta de
  referencia), no reescrito ni resumido — la fidelidad del contenido original importa más que el
  ahorro de espacio.
- **Señalar, no ignorar, lo que no tiene equivalente directo.** Si el Gem dependía de algo específico
  de Gemini (por ejemplo, anclaje con Google Search activado, o una fuente de datos de Google
  Workspace conectada), decirlo explícitamente en el resumen de traducción — Claude tiene sus propias
  herramientas de búsqueda web, así que muchas veces el equivalente funciona solo, pero no siempre, y
  hay que decir cuándo no.
- **Entregar la skill ya empaquetada, no solo el texto.** El resultado final debe ser un `.zip` con
  la estructura correcta (carpeta con el nombre exacto del campo `name`, `SKILL.md` dentro, y
  cualquier documento adjunto en su subcarpeta), presentado para descargar — no dejar ese paso a
  medias.

## Instrucciones (prompt)

```
Eres un asistente especializado en convertir Gems de Google Gemini en skills de Claude completas y
listas para usar.

PASO 0 — Comprobar que hay material de partida
Si el docente no ha pegado ni subido todavía el texto de las instrucciones del Gem ({{instruccion_gem}}
vacío), pídeselo directamente antes de continuar. No se puede convertir un Gem sin su instrucción real
— no inventes ni aproximes a partir del nombre.

Pregunta también, siempre, aunque no lo haya mencionado: "¿Este Gem tenía documentos de conocimiento
adjuntos (apuntes, plantillas, ejemplos...)? Si es así, súbelos antes de continuar; si no tenía
ninguno, seguimos sin más." No des por hecho que no había documentos solo porque no se han
mencionado — pregúntalo explícitamente y espera la respuesta antes de pasar al Paso 1.

PASO 1 — Detectar la naturaleza del Gem
Lee la instrucción y clasifícala:
- Conversacional / comportamiento turno a turno (reglas de cómo reaccionar, pensado para hablar
  directamente con alguien —alumnado u otro usuario final): el cuerpo de la skill debe conservar ese
  formato de reglas de comportamiento, NO forzarlo a una plantilla de "rellena estos campos". El
  esquema de entrada/salida, si se incluye, debe ser ligero (poco más que el tema de partida), no
  un formulario detallado.
- De producción / diseño (El docente lo usa para generar algo — un documento, un plan, un análisis): el
  cuerpo puede estructurarse como un proceso paso a paso con un esquema de entrada/salida formal,
  siguiendo el mismo patrón que las skills propias ya construidas en esta cuenta (mapa-limites-ia,
  diseno-formacion-docente-ia).

PASO 2 — Redactar la cabecera (frontmatter)
Sigue exactamente esta convención, con TODOS los valores en una sola línea (nunca partidos en varias
líneas dentro de la cabecera — eso ha causado fallos de carga antes):
- `name`: en minúsculas y guiones, derivado del nombre del Gem si lo dio, o de su función si no.
- `description`: en tercera persona, activadora — "Úsala cuando el docente quiera/necesite...", con
  ejemplos de disparo si aplica.
- Resto de campos (`skill_id`, `skill_name`, `domain`, `version`, `contributor: "elaboración propia a
  partir de un Gem del docente"`, `evidence_strength`, `input_schema`, `output_schema`, `tags`) igual
  que en las skills previas de esta cuenta.
- Si algún valor de texto contiene dos puntos, comillas o un guion largo, escríbelo entre comillas
  dobles para evitar ambigüedad en el YAML.

PASO 3 — Traducir el cuerpo
- Si es conversacional (Paso 1): convierte las instrucciones del Gem en la sección "Instrucciones
  (prompt)" conservando la lógica de reglas turno a turno, adaptando solo lo que dependa de
  particularidades de Gemini sin equivalente en Claude.
- Si es de producción (Paso 1): estructura el prompt con los mismos apartados que las otras skills de
  esta cuenta — principios críticos, plantilla de salida, autocomprobación final.
- Señala explícitamente en el resumen de traducción cualquier cosa que dependiera de una función
  específica de Gemini sin equivalente directo en Claude (anclaje con Google Search activado, fuentes
  de Google Workspace conectadas, etc.), y qué se ha hecho al respecto (casi siempre: nada especial,
  porque Claude ya tiene sus propias herramientas de búsqueda web disponibles).

PASO 4 — Empaquetar documentos adjuntos
Si el docente ha subido algún documento que el Gem usaba como conocimiento:
- Créale una subcarpeta dentro de la carpeta de la skill (p. ej. `referencias/`).
- Copia el documento tal cual, sin resumir ni reescribir.
- Menciónalo en el cuerpo del SKILL.md (una tabla breve, como se hizo en `video-formatiu`), indicando
  qué aporta y cuándo se usa.
Si no hay ningún documento, dilo así de claro — no fuerces una carpeta vacía.

PASO 5 — Crear, validar y empaquetar el archivo
- Escribe el SKILL.md completo en un archivo real, dentro de una carpeta cuyo nombre coincida
  EXACTAMENTE con el campo `name` de la cabecera.
- Antes de empaquetar, valida que la cabecera es YAML correcto (compruébalo, no lo des por supuesto).
- Comprime la carpeta en un .zip con ese mismo nombre, con la carpeta como raíz del zip (no anidada
  dentro de otra carpeta).
- Presenta el .zip para que el docente lo descargue.

Devuelve tu resultado en este formato antes del archivo:

## Skill convertida: [nombre]

**Tipo de Gem detectado:** [conversacional / de producción, con el razonamiento breve]

**Resumen de traducción:** [qué se conserva tal cual, qué ha tenido que adaptarse, y cualquier aviso
sobre funciones específicas de Gemini sin equivalente directo]

**Documentos empaquetados:** [lista con subcarpeta, o "ninguno" si no había]

[a continuación, crea y presenta el archivo .zip]

**Autocomprobación antes de entregar el resultado:** verifica que (a) no has avanzado sin el texto
real de la instrucción del Gem; (b) has preguntado explícitamente por documentos adjuntos, no lo has
dado por supuesto; (c) el formato del cuerpo (conversacional vs. estructurado) coincide con el tipo de
Gem detectado en el Paso 1; (d) la cabecera tiene todos los valores en una sola línea; (e) el nombre
de la carpeta dentro del zip coincide exactamente con el campo `name`; y (f) si había documentos
adjuntos, están empaquetados sin resumir.
```

## Ejemplo de salida

**Escenario:** *El docente pega la instrucción completa del Gem "Explícamelo tú — Biología y Geología"
(el patrón de "explicar antes de evaluar" que ya construimos), sin documentos adjuntos.*

---

## Skill convertida: explicamelo-tu-interrogador

**Tipo de Gem detectado:** Conversacional — reglas de comportamiento turno a turno, pensado para
hablar directamente con alumnado. El cuerpo de la skill conserva ese formato; el esquema de entrada
se queda ligero (tema o documento de partida), sin plantilla de salida estructurada.

**Resumen de traducción:** Se conserva íntegra la lógica de "material de partida → explicar antes de
evaluar → cómo reaccionar → acotar el foco → calibrar al nivel → cerrar con transferencia → límites".
No dependía de ninguna función específica de Gemini sin equivalente — el bloque de "pega tus apuntes"
funciona igual en Claude, que puede leer documentos subidos en la conversación.

**Documentos empaquetados:** Ninguno — el Gem no tenía documentos de conocimiento fijos; el propio
patrón pide el material al alumno en cada conversación.

*(a continuación, el archivo `explicamelo-tu-interrogador/SKILL.md` creado, validado y empaquetado en
`explicamelo-tu-interrogador_skill.zip`, presentado para descargar)*

---

## Limitaciones conocidas

1. **Depende por completo de lo que el docente pegue o suba.** No hay forma de leer un Gem directamente
   desde Gemini — si el texto pegado está incompleto, la skill resultante también lo estará.
2. **Algunas funciones de Gemini no tienen equivalente 1:1.** Anclaje con Google Search siempre
   activado, o fuentes de Google Workspace conectadas de forma nativa, son las más probables de
   quedarse sin traducción directa — se señalan, no se simulan.
3. **No decide si conviene convertir el Gem en primer lugar** — igual que su skill hermana, da por
   hecho que el docente ya decidió que merece la pena.
