---
name: auditar-programacion-bachillerato-cv
description: Audita una propuesta pedagógica de departamento o una programación de materia de Bachillerato ya redactada, frente al Decreto 108/2022, su modificación por el Decreto 103/2026 y los acuerdos de centro, señalando huecos y contradicciones sin inventar exigencias normativas.
---

# Auditar una programación de Bachillerato

Esta skill es de solo lectura salvo que el docente pida explícitamente que corrijas el documento.

## Antes de auditar: identifica qué documento tienes delante
La normativa valenciana distingue la **propuesta pedagógica de departamento** (art. 22 del Decreto 108/2022, integrada en la concreción curricular del centro) de la **programación de aula** (art. 23.4). Cada una tiene su propio contenido mínimo normativo: audita cada documento con el rasero que le corresponde y no le reproches a una lo que la norma exige a la otra.

## Comprobaciones con respaldo normativo
Para una **propuesta pedagógica de departamento**, el art. 22.5 (redacción del Decreto 103/2026) exige que concrete los elementos del currículo de la materia establecidos en los **anexos II y III**, los **instrumentos de recogida de información** sobre el nivel de logro del alumnado, los **criterios de calificación cualitativa y cuantitativa**, y las **medidas de respuesta educativa para la inclusión**. Verifica los cuatro: su ausencia sí es un incumplimiento, no una simple recomendación.

Para una **programación de aula**, el art. 23.4 (redacción del Decreto 103/2026) exige: situaciones de aprendizaje, criterios de evaluación, espacios, distribución temporal, recursos, medidas de inclusión e instrumentos de evaluación. Verifica los siete, con contenido real y no solo el epígrafe. En la redacción original de 2022 eran seis (sin instrumentos de evaluación): si auditas un documento anterior, tenlo en cuenta.

En cualquiera de los dos documentos, comprueba además:
1. Que las competencias específicas, los criterios de evaluación y los saberes básicos citados sean **literales del anexo II vigente para ese curso** — para 1º en 2026-2027, en la redacción del Decreto 103/2026.
2. Que la calificación descrita sea numérica de 0 a 10 sin decimales, con lo inferior a 5 como negativo (art. 39.2).
3. Que, si la materia tiene continuidad en los dos cursos (anexo VI, "Continuidad entre materias de bachillerato"), se recoja la incompatibilidad (IC) del art. 39.3, que afecta a quien tiene **cursada y no superada** la de primero. El supuesto distinto de matricularse en la de segundo **sin haber cursado** la de primero lo regula el art. 46, modificado por el Decreto 103/2026: no los confundas.
4. Que no aparezca ninguna regla de promoción distinta del máximo de dos materias con evaluación negativa (art. 43), ni una vía de titulación distinta de la del art. 22 del Real Decreto 243/2022.
5. Que las materias citadas existan con su denominación vigente: el Decreto 103/2026 sustituyó "Programación, Redes y Sistemas Informáticos I y II" por **"Informática I y II"** y creó la optativa **"Unión Europea"**. Una programación que aún use la denominación antigua está desactualizada.
6. Que la modalidad y, en Artes, la vía estén bien nombradas: según el art. 10 del Decreto 108/2022, las modalidades son **Artes, Ciencias y Tecnología, General, y Humanidades y Ciencias Sociales**, y Artes se organiza en las vías de **Artes Plásticas, Imagen y Diseño** y de **Música y Artes Escénicas**.
7. Que no contradiga la concreción curricular ni el proyecto educativo del centro.

## Procedimiento
1. Fija alcance y versión del documento, e identifica qué fuentes te faltan (currículo de la materia, plantilla o concreción del centro, acuerdos de departamento) para poder verificar cada punto.
2. Evalúa cada comprobación como cumple / parcial / no cumple / no verificable, citando la ubicación exacta en el documento y la evidencia.
3. Entrega los hallazgos en una tabla: elemento, estado, evidencia, diagnóstico, acción propuesta y responsable.
4. No emitas una calificación global oficial del documento: la aprobación corresponde al departamento, al claustro y a la dirección según el procedimiento del centro.
5. Si el docente pide corrección, aplícala solo sobre lo detectado.

## Límites
Distingue lo exigido de lo recomendable: los contenidos de los arts. 22.5 y 23.4 sí son exigibles, pero la normativa valenciana **no fija la estructura de apartados y epígrafes** de estos documentos, así que no reproches como incumplimiento que falte un epígrafe que solo viene de una plantilla o de la costumbre. Si echas en falta algo por buena práctica, dilo como recomendación. No cites artículos de la Orden 19/2023: su articulado no está verificado aquí. No inventes una versión del decreto que no tengas disponible; marca el punto como no verificable.
