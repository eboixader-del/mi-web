---
name: crear-materiales-aula-fp-cv
description: Crea materiales del alumnado y guía docente para actividades de FP ya diseñadas, accesibles según el DUA.
---

# Crear materiales de aula de FP

## Procedimiento
1. Recupera la secuencia, los CE, la evidencia esperada, el destinatario y los recursos disponibles. Si el diseño no está cerrado, aplica primero (o resume) lo mínimo necesario de la skill disenar-secuencias-aula-fp-cv antes de producir material.
2. Crea los recursos: consignas completas, datos o casos necesarios (marca como ficticios los que lo sean, y verifica los datos técnicos reales cuando la actividad los use), ejemplos, apoyos y el tiempo y producto esperado. Aplica el DUA: ofrece más de una forma de acceder a la consigna y de expresar el resultado, sin diluir el CE.
3. Entrega dos versiones separadas: la del alumnado y la guía docente, con soluciones o respuestas admisibles, errores previsibles del alumnado, orientaciones de corrección y cómo retirar apoyos progresivamente para quien no los necesite.
4. Comprueba que el alumnado tiene toda la información necesaria para completar la actividad sin acudir a otra fuente no indicada, y que los apoyos no revelan la respuesta en una prueba que deba medir autonomía. Un título o un enlace a un recurso que no existe no es material terminado.

## Límites
No generes materiales sobre un CE o RA que no se ha confirmado en la programación del módulo. No inventes datos técnicos de un proceso o sector productivo real: verifícalos o márcalos como ficticios con fines didácticos.
