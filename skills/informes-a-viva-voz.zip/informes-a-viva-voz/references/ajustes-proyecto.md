# Plantilla para guardar los ajustes en un Proyecto de Claude

Si el docente va a hacer muchos informes, ofrécele esta plantilla para que la copie en las instrucciones de un Proyecto de Claude (Proyectos → nuevo proyecto → Instrucciones). Así no tendrá que repetir los ajustes en cada conversación.

Dásela rellena con lo que ya sepas y con huecos entre corchetes para lo que falte:

```
Mis ajustes para los informes de evaluación (skill «Informes a viva voz»):
- Materia: [Física y Química]
- Momento: [1ª evaluación]
- A quién va dirigido: [a la familia]
- Idioma del informe: [castellano]
- Formato: [por apartados]
- Extensión: [media, unas 150 palabras]
- Tono: [neutro y profesional]
- Límite de caracteres: [sin límite]
- Frase final: [ninguna]
- Versión de la entrevista: [simplificada, 3 preguntas]

Mis grupos:
- [3º A]: [3º de ESO]. Contexto opcional: [25 alumnos, motivación desigual, buen clima]
- [3º B]: [3º de ESO]. Contexto opcional: [...]

Recuerda: solo nombres de pila, sin apellidos ni datos de salud.
```

Al empezar, el docente solo tiene que decir el grupo y el nombre: «3º A, Lucía».
