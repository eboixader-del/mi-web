# Preguntas de la entrevista

Sustituye [nombre] por el nombre de pila. Haz una pregunta por mensaje.
Las ideas son solo para cuando el docente se quede en blanco o las pida: ofrece 3 o 4, no la lista entera.

## Versión simplificada (3 preguntas)

1. **Lo que hace bien.** ¿Qué hace bien [nombre]? Piensa en lo que aprende, en su actitud y en cómo trabaja.
   Ideas: comprende los conceptos clave · aplica lo aprendido a problemas nuevos · participa y comparte sus ideas · trabaja bien en equipo · cumple tareas y plazos · se esfuerza mucho · trabaja de forma autónoma · respeta las normas y contribuye a un buen clima.

2. **Lo que debe mejorar.** ¿Qué debe mejorar [nombre]?
   Ideas: tiene lagunas en conocimientos básicos · memoriza sin llegar a comprender · participa poco · entrega trabajos tarde o incompletos · olvida el material · estudia a última hora · necesita supervisión constante · se rinde con facilidad · interrumpe o distrae a otros.

3. **Evolución y recomendaciones.** ¿Qué le recomiendas a [nombre] para la próxima evaluación? Si quieres, añade cómo ha evolucionado o su calificación.
   Ideas: ha mejorado respecto a la evaluación anterior · se mantiene estable · ha empeorado · recomendar seguir así · planificar el estudio semanal · repasar a diario · pedir ayuda en clase · leer más.

## Versión extensa (7 preguntas)

1. **Aprendizaje de la materia.** ¿Cómo va [nombre] con los contenidos de la materia? ¿Qué domina y dónde tiene más dificultades?
   A favor: comprende los conceptos clave · aplica lo aprendido a problemas nuevos · hace preguntas que muestran comprensión · investiga por iniciativa propia · relaciona unos temas con otros.
   A mejorar: lagunas en conocimientos básicos · memoriza sin comprender · no relaciona unos temas con otros · depende solo de lo visto en clase.

2. **Participación y comunicación.** ¿Cómo participa [nombre] en clase? ¿Cómo se expresa y cómo escucha?
   A favor: muestra interés · comparte sus ideas · contribuye a los debates · se expresa con claridad · escucha con atención.
   A mejorar: participa poco · le cuesta expresar sus ideas · habla fuera de turno · monopoliza la conversación · comentarios fuera de lugar.

3. **Trabajo en equipo.** ¿Y cuando trabaja en grupo? ¿Qué papel suele tener [nombre]?
   A favor: escucha y valora las ideas de los demás · cumple con su parte · ayuda a sus compañeros · lidera de forma positiva · promueve la colaboración.
   A mejorar: no contribuye de forma equitativa · le cuesta integrarse · lidera de forma autoritaria · se queda en un papel pasivo.

4. **Responsabilidad y hábitos de estudio.** ¿Cómo es [nombre] con las tareas, los plazos, el material y el estudio en casa?
   A favor: cumple tareas y plazos · trae el material · sigue bien las instrucciones · material organizado · estudia con constancia · es puntual.
   A mejorar: entrega tarde o incompleto · olvida el material · llega tarde · estudia a última hora · se distrae al estudiar · sin método de estudio.

5. **Actitud, motivación y autonomía.** ¿Qué actitud muestra [nombre]? ¿Trabaja con autonomía, se esfuerza, persevera?
   A favor: entusiasmo por aprender · persevera ante las dificultades · trabaja de forma autónoma · toma la iniciativa · pide ayuda cuando la necesita · se esfuerza mucho.
   A mejorar: necesita supervisión constante · se rinde con facilidad · muestra desinterés · hace solo lo mínimo · le cuesta valorar sus capacidades.

6. **Convivencia y bienestar.** ¿Cómo es su comportamiento y su relación con los demás? ¿Has notado algo en cómo se siente [nombre]?
   A favor: respeta las normas · es amable con compañeros y profesorado · contribuye a un buen clima · es empático · gestiona bien sus emociones.
   A mejorar: interrumpe o distrae · comentarios inapropiados · le cuesta expresar sus emociones · culpa a otros de sus errores · tiende a aislarse.

7. **Evolución y propuestas.** Para terminar: ¿cómo ha evolucionado [nombre] y qué le recomendarías? Si quieres, añade la calificación o las medidas de apoyo.
   Ideas: ha mejorado · se mantiene estable · ha empeorado · tiene medidas de apoyo o adaptación · destacar su esfuerzo · seguir así · planificar el estudio semanal · repasar a diario · pedir ayuda en clase · leer más.

## Versión libre

Una sola pregunta: Cuéntame cómo va [nombre] en tu materia: lo que hace bien, lo que debe mejorar y lo que le recomendarías.
Después, como mucho 2 preguntas concretas si falta algo importante.
