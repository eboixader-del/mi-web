# Esquema del JSON de datos para `fill_template.py`

Este documento describe la estructura JSON que hay que construir antes de
ejecutar `scripts/fill_template.py`. Cada clave corresponde a un campo de la
plantilla oficial "Situación de Aprendizaje" de la Fundación Flors.

Todos los campos de texto son opcionales: si faltan, la celda correspondiente
de la plantilla se deja en blanco (tal y como quedaría en la plantilla vacía).
No inventes contenido para un campo que no esté en el documento de origen —
es preferible dejarlo vacío a rellenarlo con una suposición.

```json
{
  "unidad_programacion_num": "1",
  "situacion_aprendizaje_num": "1",
  "curso_academico": "2026/2027",

  "titulo_sa": "...",
  "etapa_educativa": "...",
  "area_materia_ambito": "...",
  "docentes": "...",
  "curso_grupo": "...",
  "num_sesiones": "...",
  "lengua_vehicular": "...",
  "temporizacion": "...",
  "vinculacion_otras_areas": "...",
  "descripcion_finalidad": "...",
  "producto_final": "...",

  "descriptores_operativos": "...",
  "objetivos_etapa": "...",
  "competencias": [
    {"competencia": "...", "criterios": "...", "saberes": "..."}
  ],
  "ods": "...",
  "genero_diversidad": "...",
  "competencia_digital_lectura": "...",

  "metodo_trabajo": "...",
  "modelos_pedagogicos": "...",
  "tecnicas_didacticas": "...",
  "estrategias_dua": "...",
  "organizacion_espacio": "...",
  "distribucion_tiempo": "...",
  "agrupamientos": "...",
  "recursos_materiales": "...",

  "sesiones": [
    {
      "titulo": "...",
      "actividad1": "...", "recursos1": "...", "productos1": "...",
      "actividad2": "...", "recursos2": "...", "productos2": "...",
      "actividad3": "...", "recursos3": "...", "productos3": "..."
    }
  ],

  "evaluacion_diagnostica": "...",
  "evaluacion_formativa": "...",
  "evaluacion_sumativa": "...",
  "criterios_calificacion": [
    {"criterio": "...", "instrumento": "...", "peso": "30"}
  ],
  "criterios_recuperacion": "...",

  "medidas_diversidad": "...",
  "aneae": "...",
  "altas_capacidades": "...",

  "eval_diseno": "",
  "eval_implementacion": "",
  "eval_mejora": "",

  "referencias_bibliograficas": "...",
  "recursos_web": "..."
}
```

## Notas sobre campos con listas (estructuras repetibles)

- **`competencias`**: una entrada por cada competencia específica (CE1, CE2…).
  El script duplica filas automáticamente si hay más de 3 (las que trae la
  plantilla en blanco); si hay menos de 3, las filas sobrantes quedan vacías.
  Dentro de `criterios` y `saberes`, usa `\n` para separar líneas — cada línea
  se convierte en un párrafo (en `saberes` además se añade viñeta "•").

- **`sesiones`**: una entrada por sesión de clase. El script añade o quita
  bloques automáticamente para que el número de bloques coincida exactamente
  con `len(sesiones)` (la plantilla trae 3 de partida). Numera "Sesión 1",
  "Sesión 2"… automáticamente — no hace falta incluir el número en `titulo`.

- **`criterios_calificacion`**: una entrada por criterio de calificación con
  su peso en `peso` (número o texto, ej. `"30"` o `"30 %"`). Comprueba que la
  suma de los pesos sea 100 antes de generar el documento; si no lo es,
  avisa al docente en vez de generar el documento silenciosamente.

- **`eval_diseno` / `eval_implementacion` / `eval_mejora`**: corresponden al
  apartado 7 (Evaluación de la práctica docente), que normalmente se rellena
  *después* de impartir la SA, no al diseñarla. Si el documento de origen no
  trae esta información (lo habitual), déjalos vacíos — el script omite ese
  apartado automáticamente si los tres están vacíos.
