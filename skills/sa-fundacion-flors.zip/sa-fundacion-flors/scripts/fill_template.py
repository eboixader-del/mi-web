#!/usr/bin/env python3
"""
fill_template.py — Rellena la plantilla de Situación de Aprendizaje (SA) de la
Fundación Flors a partir de un JSON con el contenido ya extraído/clasificado.

Uso:
    python3 fill_template.py --template PLANTILLA.docx --data datos.json --output salida.docx

El JSON de entrada debe seguir el esquema descrito en SKILL.md (references/schema.json).
"""
import argparse
import copy
import json
import re
import sys
from docx import Document
from docx.oxml.ns import qn


def set_cell_answer(cell, value, bullets=False):
    """Añade `value` como texto de respuesta en una celda que ya contiene una
    etiqueta en negrita. Reutiliza el último párrafo si está vacío; si no,
    añade párrafo(s) nuevos. Soporta multilínea (una línea = un párrafo)."""
    if value is None:
        return
    value = str(value).strip()
    if value == "":
        return

    lines = [l.strip() for l in value.split("\n") if l.strip() != ""]
    if not lines:
        return

    paras = cell.paragraphs
    last = paras[-1] if paras else None

    def add_run(paragraph, text):
        r = paragraph.add_run(("• " if bullets else "") + text)
        r.bold = False
        r.font.name = "Calibri"

    first_line = lines[0]
    rest = lines[1:]

    if last is not None and last.text.strip() == "" and len(last.runs) <= 1:
        for r in list(last.runs):
            r.text = ""
        add_run(last, first_line)
    else:
        p = cell.add_paragraph()
        add_run(p, first_line)

    for line in rest:
        p = cell.add_paragraph()
        add_run(p, line)


def find_row_index(table, label, col=0, start=0):
    label_norm = label.strip().lower()
    for i in range(start, len(table.rows)):
        cell = table.rows[i].cells[col]
        if not cell.paragraphs or not cell.paragraphs[0].runs:
            continue
        run_text = cell.paragraphs[0].runs[0].text.strip().lower()
        if run_text.startswith(label_norm):
            return i
    raise ValueError(f"No se encontró la etiqueta: {label!r}")


def fill_simple(table, label, value, col=0, bullets=False):
    idx = find_row_index(table, label, col=col)
    set_cell_answer(table.rows[idx].cells[col], value, bullets=bullets)


def replace_placeholder_run(cell, new_text):
    p = cell.paragraphs[0]
    if len(p.runs) >= 2:
        p.runs[-1].text = new_text
    else:
        r = p.add_run(new_text)
        r.bold = False


def duplicate_row_after(table, row_index):
    src_tr = table.rows[row_index]._tr
    new_tr = copy.deepcopy(src_tr)
    src_tr.addnext(new_tr)
    return row_index + 1


def duplicate_block_after(table, start_index, block_len):
    trs = [table.rows[start_index + i]._tr for i in range(block_len)]
    anchor = trs[-1]
    for tr in trs:
        new_tr = copy.deepcopy(tr)
        anchor.addnext(new_tr)
        anchor = new_tr
    return start_index + block_len


def remove_row(table, row_index):
    tr = table.rows[row_index]._tr
    tr.getparent().remove(tr)


def fill_competencias(table, competencias):
    header_idx = find_row_index(table, "Competencias específicas y descriptores")
    first_empty = header_idx + 1
    end = first_empty
    while True:
        c0 = table.rows[end].cells[0]
        text0 = c0.paragraphs[0].runs[0].text.strip() if c0.paragraphs[0].runs else ""
        if text0.lower().startswith("elementos transversales"):
            break
        end += 1
    n_available = end - first_empty

    n_needed = len(competencias)
    while n_available < n_needed:
        duplicate_row_after(table, first_empty + n_available - 1)
        n_available += 1

    for i, comp in enumerate(competencias):
        row = table.rows[first_empty + i]
        set_cell_answer(row.cells[0], comp.get("competencia", ""))
        set_cell_answer(row.cells[1], comp.get("criterios", ""), bullets=False)
        set_cell_answer(row.cells[2], comp.get("saberes", ""), bullets=True)


def fill_sesiones(table, sesiones):
    session_rows = []
    for i, row in enumerate(table.rows):
        c0 = row.cells[0]
        if c0.paragraphs and c0.paragraphs[0].runs:
            t = c0.paragraphs[0].runs[0].text.strip()
            if re.match(r"^Sesión\s+\d+\s*:", t, re.IGNORECASE):
                session_rows.append(i)

    block_len = 5
    n_blocks = len(session_rows)
    n_needed = len(sesiones)

    if n_needed > n_blocks:
        last_block_start = session_rows[-1]
        for _ in range(n_needed - n_blocks):
            new_start = duplicate_block_after(table, last_block_start, block_len)
            session_rows.append(new_start)
            last_block_start = new_start
    elif n_needed < n_blocks:
        for start in reversed(session_rows[n_needed:]):
            for r in range(block_len):
                remove_row(table, start)
        session_rows = session_rows[:n_needed]

    try:
        aviso_idx = find_row_index(table, "[ Duplicar el bloque de sesión")
        remove_row(table, aviso_idx)
    except ValueError:
        pass

    for i, (start, ses) in enumerate(zip(session_rows, sesiones), start=1):
        title_cell = table.rows[start].cells[0]
        p = title_cell.paragraphs[0]
        p.runs[0].text = f"Sesión {i}: "
        if len(p.runs) >= 2:
            p.runs[-1].text = ses.get("titulo", "")
        else:
            r = p.add_run(ses.get("titulo", ""))
            r.bold = False

        act_map = [
            ("actividad1", "recursos1", "productos1"),
            ("actividad2", "recursos2", "productos2"),
            ("actividad3", "recursos3", "productos3"),
        ]
        for j, (ka, kr, kp) in enumerate(act_map):
            act_row = table.rows[start + 2 + j]
            set_cell_answer(act_row.cells[0], ses.get(ka, ""))
            set_cell_answer(act_row.cells[1], ses.get(kr, ""))
            set_cell_answer(act_row.cells[2], ses.get(kp, ""))


def fill_criterios_calificacion(table, criterios):
    header_idx = find_row_index(table, "Criterio de evaluación")
    total_idx = find_row_index(table, "TOTAL")
    first_empty = header_idx + 1
    n_available = total_idx - first_empty

    n_needed = len(criterios)
    while n_available < n_needed:
        duplicate_row_after(table, first_empty + n_available - 1)
        n_available += 1
        total_idx += 1

    for i, crit in enumerate(criterios):
        row = table.rows[first_empty + i]
        set_cell_answer(row.cells[0], crit.get("criterio", ""))
        set_cell_answer(row.cells[1], crit.get("instrumento", ""))
        set_cell_answer(row.cells[2], str(crit.get("peso", "")))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--template", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    with open(args.data, encoding="utf-8") as f:
        data = json.load(f)

    doc = Document(args.template)
    table = doc.tables[0]

    row0 = table.rows[1]
    replace_placeholder_run(row0.cells[0], data.get("unidad_programacion_num", ""))
    replace_placeholder_run(row0.cells[1], data.get("situacion_aprendizaje_num", ""))
    replace_placeholder_run(row0.cells[2], data.get("curso_academico", ""))

    fill_simple(table, "Título de la SA:", data.get("titulo_sa"))
    fill_simple(table, "Etapa educativa:", data.get("etapa_educativa"))
    fill_simple(table, "Área / Materia", data.get("area_materia_ambito"))
    fill_simple(table, "Docente/s responsable/s:", data.get("docentes"))

    idx = find_row_index(table, "Curso y grupo:")
    set_cell_answer(table.rows[idx].cells[0], data.get("curso_grupo"))
    set_cell_answer(table.rows[idx].cells[1], data.get("num_sesiones"))
    set_cell_answer(table.rows[idx].cells[2], data.get("lengua_vehicular"))

    fill_simple(table, "Temporización", data.get("temporizacion"))
    fill_simple(table, "Vinculación con otras áreas", data.get("vinculacion_otras_areas"))
    fill_simple(table, "Descripción y finalidad", data.get("descripcion_finalidad"))
    fill_simple(table, "Producto final de la SA:", data.get("producto_final"))

    fill_simple(table, "Descriptores operativos de las competencias", data.get("descriptores_operativos"))
    fill_simple(table, "Objetivos de etapa:", data.get("objetivos_etapa"))

    fill_competencias(table, data.get("competencias", []))

    idx = find_row_index(table, "Educación para la sostenibilidad")
    set_cell_answer(table.rows[idx].cells[0], data.get("ods"))
    set_cell_answer(table.rows[idx].cells[1], data.get("genero_diversidad"))
    set_cell_answer(table.rows[idx].cells[2], data.get("competencia_digital_lectura"))

    fill_simple(table, "Método/s de trabajo", data.get("metodo_trabajo"))
    fill_simple(table, "Modelos pedagógicos:", data.get("modelos_pedagogicos"))
    fill_simple(table, "Técnicas didácticas:", data.get("tecnicas_didacticas"))
    fill_simple(table, "Estrategias de inclusión", data.get("estrategias_dua"))

    idx = find_row_index(table, "Organización del espacio:")
    set_cell_answer(table.rows[idx].cells[0], data.get("organizacion_espacio"))
    set_cell_answer(table.rows[idx].cells[1], data.get("distribucion_tiempo"))
    set_cell_answer(table.rows[idx].cells[2], data.get("agrupamientos"))

    fill_simple(table, "Recursos materiales y digitales:", data.get("recursos_materiales"))

    fill_sesiones(table, data.get("sesiones", []))

    idx = find_row_index(table, "Evaluación diagnóstica:")
    set_cell_answer(table.rows[idx].cells[0], data.get("evaluacion_diagnostica"))
    set_cell_answer(table.rows[idx].cells[1], data.get("evaluacion_formativa"))
    set_cell_answer(table.rows[idx].cells[2], data.get("evaluacion_sumativa"))

    fill_criterios_calificacion(table, data.get("criterios_calificacion", []))

    idx = find_row_index(table, "Criterios de recuperación:", col=1)
    set_cell_answer(table.rows[idx].cells[1], data.get("criterios_recuperacion"))

    fill_simple(table, "Medidas ordinarias y extraordinarias", data.get("medidas_diversidad"))
    idx = find_row_index(table, "Adecuaciones para ANEAE:")
    set_cell_answer(table.rows[idx].cells[0], data.get("aneae"))
    set_cell_answer(table.rows[idx].cells[1], data.get("altas_capacidades"))

    if any(data.get(k) for k in ("eval_diseno", "eval_implementacion", "eval_mejora")):
        idx = find_row_index(table, "Evaluación del diseño de la SA")
        ans_idx = idx + 1
        set_cell_answer(table.rows[ans_idx].cells[0], data.get("eval_diseno"))
        set_cell_answer(table.rows[ans_idx].cells[1], data.get("eval_implementacion"))
        set_cell_answer(table.rows[ans_idx].cells[2], data.get("eval_mejora"))

    fill_simple(table, "Referencias bibliográficas", data.get("referencias_bibliograficas"))
    fill_simple(table, "Recursos web y digitales:", data.get("recursos_web"))

    doc.save(args.output)
    print(f"OK: guardado en {args.output}")


if __name__ == "__main__":
    main()
