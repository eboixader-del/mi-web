---
name: sa-fundacion-flors
description: Convierte un documento con el contenido de una Situación de Aprendizaje (SA) de la Fundación Flors — por ejemplo la salida de un GEM/asistente, un boceto en Word, PDF o texto pegado en el chat — al formato oficial de la plantilla "Plantilla_SA_Fundacion_Flors_v3.docx" del centro (Decreto 107/2022 CV · Orden 19/2023), generando un .docx final con el diseño corporativo (logo, colores, tablas). Utiliza siempre este skill cuando el docente mencione "situación de aprendizaje", "SA", "pasar a la plantilla", "plantilla del centro/Fundación Flors", o suba/pegue un documento de programación didáctica que haya que formatear con la plantilla oficial, aunque no lo pida explícitamente con esas palabras.
---

# Rellenar la plantilla de Situación de Aprendizaje (Fundación Flors)

## Qué hace este skill

El docente (o el GEM que usa para generar borradores) redacta el contenido de una
Situación de Aprendizaje (SA) con las mismas secciones que la plantilla
oficial del centro, pero sin el formato de tabla/diseño corporativo. Este
skill traslada ese contenido a `assets/Plantilla_SA_Fundacion_Flors_v3.docx`
manteniendo el diseño exacto (logo, cabeceras de color, bordes de tabla),
duplicando automáticamente los bloques que se repiten (sesiones,
competencias, criterios de calificación) según haga falta.

La mecánica de relleno (búsqueda de celdas por su etiqueta, duplicado de
filas, etc.) ya está resuelta en `scripts/fill_template.py`. Tu trabajo es
la parte que requiere criterio: leer el documento de origen y traducirlo a
los datos estructurados que el script espera.

## Procedimiento

1. **Lee el documento de origen** (puede ser .docx, .pdf, texto pegado en el
   chat, o incluso una lista de ideas sueltas). Identifica el contenido para
   cada campo de la plantilla. Los nombres de los campos y su significado
   están en `references/schema.md` — léelo antes de construir el JSON.

   Los documentos que el docente suele pasar ya siguen aproximadamente el mismo
   orden y las mismas secciones que la plantilla (título, etapa educativa,
   competencias, sesiones, evaluación…), pero la redacción exacta de las
   etiquetas puede variar ligeramente. Usa tu comprensión del contenido, no
   una búsqueda literal de texto, para decidir qué va en cada campo.

2. **No inventes contenido.** Si un campo no aparece en el documento de
   origen, déjalo vacío en el JSON en lugar de rellenarlo con una suposición.
   Si falta algo importante y crítico (p. ej. no hay ninguna sesión, o no se
   entiende cuántas hay), pregunta al docente en vez de adivinar.

3. **Construye el JSON** siguiendo el esquema de `references/schema.md` y
   guárdalo como archivo temporal (p. ej. `datos_sa.json`) en tu carpeta de
   trabajo.

4. **Ejecuta el script de relleno**:

   ```bash
   python3 scripts/fill_template.py \
     --template assets/Plantilla_SA_Fundacion_Flors_v3.docx \
     --data datos_sa.json \
     --output "SA_<título breve>.docx"
   ```

   (Instala `python-docx` con `pip install python-docx --break-system-packages`
   si no está disponible.)

5. **Verifica el resultado antes de entregarlo.** Abre el .docx generado
   (por ejemplo volcando el texto de la tabla con `python-docx`, o
   convirtiéndolo a PDF con `soffice --headless --convert-to pdf` y mirando
   las páginas) y comprueba que:
   - No queda ningún campo importante vacío que sí tenía contenido en el
     origen.
   - El número de bloques de sesión coincide con el número de sesiones del
     documento de origen.
   - Los pesos de los criterios de calificación suman 100 (si no, avisa a
     el docente en la respuesta en vez de dejarlo pasar en silencio).

6. **Entrega el .docx final** al usuario (guárdalo en la carpeta de salidas
   y compártelo). No hace falta explicar los detalles internos del relleno,
   basta con confirmar que está listo y señalar cualquier campo que se haya
   quedado vacío por falta de información en el origen.

## Notas técnicas sobre la plantilla

- La plantilla es una única tabla de 3 columnas. Las filas "etiqueta" tienen
  el texto de la etiqueta en negrita seguido, en la misma celda, de un
  párrafo (a veces ya vacío y reservado, a veces hay que añadirlo) donde va
  la respuesta.
- Tres bloques se duplican dinámicamente según el contenido:
  - **Competencias** (CE1, CE2…): 3 filas vacías de partida.
  - **Sesiones**: bloques de 5 filas (título + cabecera fija + 3 actividades),
    3 bloques de partida. El script añade o quita bloques completos y
    renumera "Sesión N" automáticamente.
  - **Criterios de calificación**: 4 filas vacías de partida, sobre la fila
    TOTAL.
- El aviso interno `[ Duplicar el bloque de sesión según la duración de la
  SA ]` se elimina automáticamente del documento final.
- El apartado 7 (Evaluación de la práctica docente) normalmente se deja en
  blanco al diseñar la SA — solo se rellena si el documento de origen trae
  explícitamente esa reflexión posterior a la implementación.

Si en algún momento cambia la plantilla oficial del centro (nueva versión,
v4, etc.), sustituye `assets/Plantilla_SA_Fundacion_Flors_v3.docx` y revisa
`references/schema.md` y `scripts/fill_template.py` por si cambia la
estructura de filas/columnas — usa el mismo método de inspección con
python-docx (imprimir tabla, `gridSpan`, runs de cada párrafo) para
entender la nueva plantilla antes de tocar el script.
