---
name: disenar-situaciones-aprendizaje-eso-cv
description: Diseña una situación de aprendizaje de ESO con anclaje curricular literal (competencias específicas, criterios de evaluación, saberes básicos), producto final y accesibilidad DUA.
---

# Diseñar una situación de aprendizaje de ESO

## Procedimiento
1. Fija las competencias específicas, los criterios de evaluación (código y literal) y los saberes básicos del alcance; identifica el reto o contexto real que da sentido a la situación de aprendizaje.
2. Define el producto final que el alumnado debe elaborar y la evidencia que acreditará cada criterio de evaluación trabajado.
3. Diseña la secuencia de actividades desde ese producto: activación, desarrollo, práctica, síntesis y evaluación. Relaciona cada actividad con su(s) criterio(s) de evaluación y con los recursos necesarios; distingue claramente qué es práctica y qué es evaluación.
4. Aplica el DUA a lo largo de la secuencia: varía formas de acceso a la información, formas de implicación/motivación, formas de procesamiento y formas de expresión del aprendizaje, sin bajar el nivel de exigencia del criterio de evaluación. Documenta apoyos y cómo se retiran progresivamente.
5. Señala barreras de aprendizaje previsibles del grupo (si el docente las ha indicado) y cómo la situación de aprendizaje las anticipa.
6. Entrega: cronograma de sesiones, inventario de materiales/instrumentos necesarios (sin darlos por hechos si aún no existen) y cobertura curricular del alcance.

## Límites
No inventes datos de centro, horario o calendario que no se hayan confirmado. Un cronograma de diseño no acredita que los recursos ya existan: dilo explícitamente si aún faltan.
