---
name: disenar-evaluacion-infantil-cv
description: Diseña el sistema de observación y evaluación de un nivel del segundo ciclo de Educación Infantil en la Comunitat Valenciana (instrumentos de observación, seguimiento del progreso e informes a las familias), sin calificación acreditativa.
---

# Diseñar la evaluación en Educación Infantil

## Naturaleza de la evaluación en esta etapa
A diferencia de Primaria y ESO, en Educación Infantil:
- La evaluación es **continua, global y formativa**, y se basa en la **observación directa y sistemática**, no en pruebas ni calificaciones.
- Los criterios de evaluación del currículo **no tienen valor acreditativo**: son referentes para identificar el ritmo y las características del progreso de cada niño o niña, no un umbral de aprobado/suspenso.
- No existe calificación numérica ni concepto de promoción o titulación en el sentido de Primaria/ESO. La permanencia extraordinaria un curso más en la etapa es una medida excepcional, sujeta a normativa y procedimiento específicos del centro/inspección: no la apliques ni la sugieras sin que el docente confirme que procede.
- La finalidad declarada de la evaluación incluye la prevención, detección e intervención temprana de necesidades educativas, no solo constatar el progreso.

## Procedimiento
1. Recupera los criterios de evaluación orientadores de las tres áreas (Crecimiento en Armonía; Descubrimiento y Exploración del Entorno; Comunicación y Representación de la Realidad) para el nivel.
2. Define los instrumentos de observación: registro anecdótico, diario de aula, listas de control, escalas de observación, portafolio o carpeta de evidencias (dibujos, fotos, producciones). Relaciona cada instrumento con lo que permite observar de cada área.
3. Establece la periodicidad de la observación y del volcado a un registro (p. ej. semanal) y de los informes formales a las familias (habitualmente trimestral), diferenciando avance individual de comparación entre niños (que debe evitarse).
4. Describe cómo se identifican indicios de posibles necesidades específicas de apoyo educativo para activar el protocolo de detección temprana del centro, sin diagnosticar ni etiquetar.
5. Añade el apartado de evaluación de la propia programación y de la práctica docente.
6. Comprueba coherencia: cada área tiene al menos un instrumento de observación asociado; el lenguaje de los informes a familias es descriptivo y evita comparaciones o etiquetas.

## Límites
No inventes una calificación, nota o "aprobado" para Infantil: esta etapa no se califica. No apliques criterios de evaluación de Infantil como si fueran acreditativos. No decidas ni sugieras una permanencia extraordinaria de curso sin que el docente confirme que el procedimiento del centro lo contempla.
