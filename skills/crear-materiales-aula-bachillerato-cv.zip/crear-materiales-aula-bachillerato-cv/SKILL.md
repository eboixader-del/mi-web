---
name: crear-materiales-aula-bachillerato-cv
description: Crea materiales del alumnado y guía docente para actividades de 1º o 2º de Bachillerato ya diseñadas, accesibles según el DUA y con el nivel de exigencia y autonomía propio de la etapa.
---

# Crear materiales de aula de Bachillerato

## Procedimiento
1. Recupera la situación de aprendizaje, los criterios de evaluación implicados, la evidencia esperada, el curso y la modalidad, y los recursos disponibles. Si el diseño no está cerrado, aplica primero (o resume) lo mínimo necesario de la skill disenar-situaciones-aprendizaje-bachillerato-cv antes de producir material.
2. Crea los recursos: consignas completas, textos, datos, casos o fuentes necesarios, ejemplos resueltos, apoyos, y el tiempo y producto esperado. Aplica el DUA ofreciendo más de una forma de acceder a la consigna y de expresar el resultado, sin diluir el criterio de evaluación.
3. Ajusta el registro y la exigencia a Bachillerato: terminología propia de la materia, fuentes citadas correctamente, y demanda cognitiva de análisis, argumentación o modelización, no solo de reproducción.
4. Entrega dos versiones separadas: la del alumnado y la guía docente, con soluciones o respuestas admisibles, errores previsibles, orientaciones de corrección y cómo retirar apoyos progresivamente.
5. Comprueba que el alumnado dispone de toda la información necesaria y que los apoyos no revelan la respuesta en una tarea que deba medir autonomía. Un título o un enlace a un recurso inexistente no es material terminado.

## Límites
No generes materiales sobre un criterio de evaluación que no se haya confirmado en la programación de la materia. **Verifica los datos, hechos, citas y fuentes reales que uses**, o márcalos explícitamente como ficticios con fines didácticos: en Bachillerato el alumnado trabaja con fuentes y un dato inventado que se presenta como real es un error grave. No reproduzcas textos protegidos por derechos de autor: usa fragmentos breves con su referencia, o material propio.
