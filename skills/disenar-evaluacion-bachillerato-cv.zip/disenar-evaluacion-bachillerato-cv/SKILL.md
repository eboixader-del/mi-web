---
name: disenar-evaluacion-bachillerato-cv
description: Diseña el sistema de evaluación de una materia de 1º o 2º de Bachillerato en la Comunitat Valenciana (calificación de 0 a 10, instrumentos por criterio de evaluación, recuperación) y aplica correctamente las reglas de promoción, permanencia y titulación del Decreto 108/2022 y del Real Decreto 243/2022.
---

# Diseñar la evaluación de una materia de Bachillerato

## Normativa de referencia (verificada a septiembre de 2026)
- **Decreto 108/2022, de 5 de agosto, del Consell** (DOGV 9404, de 12.08.2022): evaluación (art. 39), promoción (art. 43), permanencia (arts. 5.2 y 49), título (art. 50), matrícula de honor (art. 53) y cálculo de la calificación final del alumnado que homologa el primer curso (art. 52). La regla general de la nota media de la etapa no está en el art. 52, sino en la normativa básica estatal.
- **Real Decreto 243/2022, de 5 de abril** (BOE-A-2022-5521): marco estatal; contiene las condiciones literales de la titulación excepcional (art. 22) y el cálculo de la nota media.
- **Orden 19/2023, de 29 de junio**: procedimientos derivados, incluido el Bachillerato nocturno y a distancia. **No cites artículos concretos de esta Orden**: su articulado no está verificado aquí; si necesitas uno, pide al docente que lo consulte en el DOGV.
- El **Decreto 103/2026** no modificó los artículos 39 a 45 (evaluación y promoción), 49 (permanencia), 50 y 51 (titulación) ni 53 (matrícula de honor): no le atribuyas cambios en ellos. Sí modificó, en cambio, el art. 46 (matrícula en materia de continuidad sin haber cursado la de primero) y la disposición adicional 1ª (cómputo de las calificaciones de religión), que sí afectan a decisiones de evaluación.

## Reglas fijadas por la normativa — respétalas, no las reinterpretes

**Calificación** (art. 39.2 del Decreto 108/2022, texto literal): "Los resultados de evaluación se deben expresar con calificaciones numéricas de 0 a 10, sin decimales. Se consideran negativas las calificaciones inferiores a 5." Si el alumnado no se presenta a las pruebas extraordinarias se consigna "no presentado" (NP) (art. 39.5).

**Materias con continuidad** (art. 39.3, texto literal): "En el caso de las materias con continuidad en los dos cursos, indicadas en el anexo VI, el alumnado que tenga cursada y no superada la materia de primer curso no puede ser calificado de la materia de segundo curso. Esta circunstancia se debe consignar en las actas finales como «incompatible» (IC)." Tenlo en cuenta al diseñar la evaluación de una materia de 2º con continuidad. Es un supuesto distinto del de matricularse en la materia de segundo **sin haber cursado** la de primero, que regula el art. 46 (modificado por el Decreto 103/2026): no los mezcles.

**Promoción de 1º a 2º**: se promociona habiendo superado todas las materias o con **evaluación negativa en dos materias como máximo** (art. 43 del Decreto 108/2022; art. 21 del Real Decreto 243/2022). Con más de dos, se repite el curso completo.

**Permanencia**: se puede permanecer cursando Bachillerato en régimen ordinario **cuatro años, consecutivos o no** (arts. 5.2 y 49). Agotado ese límite, solo cabe continuar en régimen de personas adultas, nocturno o a distancia.

**Titulación**: la regla general es evaluación positiva en todas las materias de los dos cursos (art. 50 del Decreto 108/2022; art. 22 del Real Decreto 243/2022). **Sí existe** la vía excepcional de titulación con **una** materia suspensa, por decisión del equipo docente. Sus condiciones literales están en el **art. 22 del Real Decreto 243/2022** —el art. 50 del decreto valenciano se limita a remitir a la normativa básica— y deben cumplirse **todas a la vez**:
- que el equipo docente considere que el alumno o alumna ha alcanzado los objetivos y competencias vinculados a ese título;
- que no se haya producido una inasistencia continuada y no justificada **en esa materia** (la condición se refiere a la materia suspensa, no a la asistencia general: no la endurezcas);
- que se haya presentado a las pruebas y realizado las actividades necesarias para su evaluación, **incluidas las de la convocatoria extraordinaria**;
- que la **media aritmética de las calificaciones obtenidas en todas las materias de la etapa sea igual o superior a cinco**.

Al citarla, atribúyela al Real Decreto 243/2022, no al Decreto 108/2022.

**Nota media de la etapa**: media aritmética de las calificaciones de todas las materias cursadas, redondeada a la centésima (dos decimales). Esta regla es **estatal** (Real Decreto 243/2022) y así conviene citarla; no consta en esa formulación en los artículos verificados del decreto valenciano. Por la disposición adicional 1ª del Decreto 108/2022 en la redacción del Decreto 103/2026, las calificaciones de las enseñanzas de religión **no computan en la nota media a efectos de acceso a la universidad ni para la obtención de becas**.

**Matrícula de honor**: el art. 53 del Decreto 108/2022 la regula, pero **sus requisitos concretos no están verificados en esta skill**. No afirmes una nota media mínima ni un cupo por número de alumnado: pide al docente que consulte el art. 53 y trabaja con lo que diga.

## Lo que decide el centro o el departamento, no la normativa
La normativa no fija instrumentos concretos, ni la ponderación entre criterios de evaluación de una misma competencia específica, ni el número de pruebas por trimestre. Eso lo acuerda el departamento y debe reflejarse en la programación. No lo inventes: pide el acuerdo o proponlo marcándolo como pendiente de validar.

## Procedimiento
1. Recupera los criterios de evaluación literales del curso y materia, agrupados por competencia específica, en la redacción del anexo II vigente para ese curso.
2. Asigna a cada criterio de evaluación el instrumento o instrumentos que lo evalúan, y define cómo se combinan para una calificación de 0 a 10 sin decimales.
3. Define el plan de recuperación durante el curso y para la convocatoria extraordinaria, y —si la materia tiene continuidad— cómo se gestiona el alumnado de 2º con la de 1º pendiente, respetando la regla de incompatibilidad (IC).
4. Redacta cómo se comunican los resultados de cada evaluación al alumnado y, cuando proceda, a las familias.
5. Añade el apartado de evaluación de la propia programación y de la práctica docente.
6. Comprueba coherencia: todos los criterios de evaluación quedan cubiertos por al menos un instrumento; ninguna calificación se sale de la escala 0-10; ninguna regla contradice la promoción con dos materias como máximo ni la vía de titulación descrita.

## Límites
No inventes una regla de promoción o titulación distinta de la vigente, ni endurezcas la vía excepcional de titulación añadiendo requisitos que no están en el art. 22 del Real Decreto 243/2022. No generes calificaciones reales de alumnado. Si el centro afirma tener un criterio propio que contradiga lo anterior, pide su base normativa antes de reflejarlo.
