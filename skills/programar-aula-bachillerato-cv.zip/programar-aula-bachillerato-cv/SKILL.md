---
name: programar-aula-bachillerato-cv
description: Coordina la programación de aula de una materia de 1º o 2º de Bachillerato (una situación de aprendizaje o una secuencia completa de curso) a partir de la programación de la materia, cubriendo los siete elementos que exige el artículo 23.4 del Decreto 108/2022 y con diseño accesible según el DUA.
---

# Programar aula de una materia de Bachillerato

Usa esta skill cuando el encargo sea "prográmame el aula de esta materia/curso" de principio a fin; para una pieza aislada (solo materiales, solo instrumentos, solo revisión), ve directamente a la skill correspondiente.

## Contenido mínimo exigido
El art. 23.4 del Decreto 108/2022, en la redacción dada por el Decreto 103/2026, exige que la programación de aula incluya: **situaciones de aprendizaje, criterios de evaluación, espacios, distribución temporal, recursos, medidas de inclusión e instrumentos de evaluación**. Cúbrelos los siete. (En la redacción original de 2022 eran seis, sin instrumentos de evaluación.)

## Procedimiento
1. Recupera la programación vigente de la materia (competencias específicas, criterios de evaluación, saberes básicos, secuencia prevista, acuerdos de evaluación del departamento). Si no está disponible, pide el mínimo imprescindible —curso, modalidad, materia y criterios de evaluación del alcance— y continúa con lo demás como propuesta pendiente de confirmar.
2. Para diseñar una situación de aprendizaje nueva, aplica la skill disenar-situaciones-aprendizaje-bachillerato-cv.
3. Según el encargo, aplica crear-materiales-aula-bachillerato-cv y/o crear-instrumentos-aula-bachillerato-cv.
4. Integra los productos y aplica auditar-aula-bachillerato-cv; corrige lo detectado dentro del alcance del encargo.
5. Entrega la programación de aula con los siete elementos del art. 23.4 cubiertos, más los materiales e instrumentos que se hayan pedido, dejando explícitos los pendientes.

## Notas propias de la etapa
- **Accesibilidad**: el diseño sigue el DUA (Diseño Universal para el Aprendizaje), con un único itinerario y múltiples formas de acceso, implicación, procesamiento y expresión, sin rebajar la exigencia del criterio de evaluación. En Bachillerato, las medidas de inclusión son además un elemento exigido expresamente por el art. 23.4.
- **2º curso**: si programas 2º, ten presente que muchas materias preparan a la vez las pruebas de acceso a la universidad. Puedes tenerlo en cuenta en la secuenciación si el docente lo pide, pero **no afirmes nada sobre la estructura o el contenido de la PAU**: no está verificado en estas skills y cambia por convocatoria.
- **Materias con continuidad**: en 2º puede haber alumnado con la materia de 1º cursada y no superada, que no puede ser calificado en la de 2º (incompatible, IC, art. 39.3). Distinto es el alumnado que se matricula en la de 2º sin haber cursado la de 1º, supuesto que regula el art. 46 (modificado por el Decreto 103/2026). Si alguno de los dos casos afecta al grupo, contémplalo al planificar.
