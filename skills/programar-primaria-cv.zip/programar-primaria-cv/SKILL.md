---
name: programar-primaria-cv
description: Coordina la elaboración de una programación didáctica de área de Educación Primaria en la Comunitat Valenciana, desde el currículo hasta la evaluación, la secuenciación de situaciones de aprendizaje y el cierre, conforme al Decreto 106/2022.
---

# Programar un área de Educación Primaria en la Comunitat Valenciana

## Marco normativo de referencia
- Real Decreto 157/2022, de 1 de marzo (ordenación y enseñanzas mínimas de Educación Primaria, marco estatal) y Real Decreto 984/2021 (evaluación, promoción, marco estatal).
- Decreto 106/2022, de 5 de agosto, del Consell, de ordenación y currículo de la etapa de Educación Primaria en la Comunitat Valenciana.
- Resolución de 20 de abril de 2022, que concreta en la Comunitat Valenciana la evaluación y promoción derivadas del Real Decreto 984/2021 (común a Primaria y ESO).
- Instrucciones de inicio de curso vigentes cada año, que pueden precisar plazos, sesiones de evaluación y documentos del centro. No hay, a fecha de esta skill, una orden autonómica de "procedimientos" específica para Primaria equivalente a la Orden 19/2023 de ESO/Bachillerato: si el centro cita una, pide su referencia exacta antes de aplicarla.
- Proyecto Educativo de Centro (PEC) y concreción curricular: la programación de área debe ajustarse a lo fijado por el centro (Comisión de Coordinación Pedagógica / equipos de ciclo), sin duplicarlo.

Este marco está verificado a fecha de esta skill (curso 2025-2026). Verifica siempre la instrucción de inicio de curso vigente antes de aplicar un plazo o procedimiento concreto.

## Entradas
Pide al docente: curso (1º a 6º) y ciclo, área, currículo oficial (competencias específicas, criterios de evaluación, saberes básicos del curso), concreción curricular o programación anterior del centro si existe, perfil de grupo, y acuerdos de ciclo sobre evaluación. Empieza con lo disponible; marca como pendiente lo que falte y no inventes acuerdos que no se hayan confirmado.

## Procedimiento
1. **Currículo.** Localiza competencias específicas, criterios de evaluación y saberes básicos literales del Decreto 106/2022 para el curso y área.
2. **Evaluación.** Aplica la skill disenar-evaluacion-primaria-cv para fijar instrumentos y criterios de calificación del área.
3. **Situaciones de aprendizaje.** Organiza el curso en situaciones de aprendizaje secuenciadas, relacionando cada una con las competencias específicas y criterios de evaluación que trabaja; distribuye la carga horaria del curso entre ellas.
4. **Redacción.** Integra los apartados habituales de una programación de área: contextualización y marco normativo; competencias específicas y su contribución al perfil de salida de la etapa; criterios de evaluación y saberes básicos por curso; secuenciación de situaciones de aprendizaje; metodología; recursos y materiales; medidas de atención a la diversidad; procedimientos e instrumentos de evaluación y criterios de calificación; actividades complementarias; procedimiento de evaluación de la propia programación y de la práctica docente.
5. **Revisión.** Aplica la skill auditar-programacion-primaria-cv sobre el borrador. Corrige lo detectado y deja explícitos los pendientes que dependan de acuerdos de ciclo o del centro.
6. Entrega la programación diferenciando lo confirmado, lo propuesto y lo pendiente; no presentes una propuesta propia como acuerdo institucional ya tomado.

## Límites
No inventes acuerdos de ciclo, calendario de evaluaciones ni normativa. Cuando falte un dato de centro, declara pendiente en vez de rellenarlo con un valor plausible.
