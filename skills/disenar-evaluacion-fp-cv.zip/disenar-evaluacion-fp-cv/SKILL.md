---
name: disenar-evaluacion-fp-cv
description: Diseña el sistema de evaluación de un módulo de FP en la Comunitat Valenciana (ponderación de resultados de aprendizaje, calificación, sesiones, recuperación y comunicación al alumnado) conforme a la Orden 8/2025.
---

# Diseñar la evaluación de un módulo de FP

## Normativa de referencia
Orden 8/2025, de 22 de abril, de evaluación del proceso de enseñanza-aprendizaje en ciclos formativos y cursos de especialización (modificada por la Orden 6/2026). Verifica siempre la versión vigente, ya que esta orden se ha modificado al menos una vez desde su publicación.

Puntos fijados por la orden que debes respetar, no reinterpretar:
- Evaluación objetiva, continua, formativa e integradora, tomando como referencia los resultados de aprendizaje (RA) y sus criterios de evaluación asociados en el decreto de currículo del ciclo.
- Calificación numérica de 1 a 10 sin decimales por módulo; se supera con nota igual o superior a 5. La nota final del ciclo es la media aritmética con dos decimales de todos los módulos.
- Sesiones de evaluación: inicial (antes del segundo mes, sin calificaciones), parciales (mínimo dos, fin de primer y segundo trimestre), ordinaria (fin de las actividades lectivas) y extraordinaria (posterior a la ordinaria). Las preside el tutor o tutora de grupo con el equipo educativo.
- Máximo cuatro convocatorias por módulo (dos en cursos de especialización); renuncia a convocatoria posible hasta 10 días hábiles antes con justificación; existe una convocatoria extraordinaria de gracia por módulo agotadas las demás por causa justificada.
- Promoción de primer a segundo curso: debe tenerse superados todos los módulos de primero, salvo que las horas de módulos pendientes no superen un límite fijado por la orden (redacción modificada por la Orden 6/2026: confírmalo contra el texto vigente antes de aplicarlo).

## Lo que decide el centro, no la orden
La orden no fija cómo ponderar los RA dentro de un módulo: esa decisión corresponde al departamento/familia profesional y debe quedar reflejada en la programación. No la inventes; pide el acuerdo de departamento o, si no existe, propónla explícitamente como propuesta pendiente de validar.

## Procedimiento
1. Recupera RA y criterios de evaluación literales del decreto de currículo del módulo. No los parafrasees de forma que cambie su alcance.
2. Propón o recupera la ponderación de cada RA (y, si el departamento lo pide, de cada CE dentro de su RA); los pesos de RA deben sumar 100 %. Si no hay acuerdo de departamento, marca la ponderación como propuesta.
3. Define instrumentos y evidencias por RA, criterios de calificación, y cómo se combinan para la nota del módulo en cada sesión de evaluación.
4. Describe el procedimiento de recuperación (dentro de curso y en convocatoria extraordinaria) y cómo se comunica al alumnado el resultado de cada sesión.
5. Añade el apartado de evaluación de la propia programación y de la práctica docente que exige la Orden 8/2025 (criterios y procedimientos, no solo la nota del alumnado).
6. Comprueba que las reglas resultantes son coherentes: pesos = 100 %, ninguna calificación fuera de escala 1-10, ninguna convocatoria por encima del máximo permitido.

## Límites
No fijes una ponderación de RA como definitiva si no hay acuerdo de departamento; no inventes una convocatoria de gracia adicional; no cites artículos de la orden de memoria si tienes duda — indica al docente que lo confirme en el texto vigente (DOGV) o en las instrucciones de inicio de curso.
