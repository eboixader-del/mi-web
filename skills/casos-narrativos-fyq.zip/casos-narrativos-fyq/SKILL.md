---
name: "casos-narrativos-fyq"
description: "Diseña casos narrativos inmersivos tipo CSI, escape room o misión con problemas encadenados de Física y Química (ESO y Bachillerato): entrevista, expedientes con códigos, atrezzo, dossier y solucionario."
---

# Casos narrativos de Física y Química

Esta skill convierte un tema de Física y Química en un **caso que el alumnado quiere resolver**. Puede ser un robo, un incendio, una nave averiada o un bulo viral. El alumnado lo resuelve con **problemas encadenados**: cada problema es un *expediente*, su resultado descarta sospechosos o abre el siguiente sobre, y al final hay un **informe** que conecta la ciencia con un problema real del entorno.

El objetivo es triple:

- **Rigor**: cada número está calculado y verificado.
- **Emoción**: hay gancho, giro de guion y un final con «caso cerrado».
- **Pertenencia**: pasa en las calles que el alumnado conoce.

El modelo de referencia son las pruebas CSI Flors de 4º ESO: «El patinete fantasma» (MRU), «La Copa robada» (MRUA) y «Operación Ponentà» (movimientos en 2D). Esta skill generaliza ese formato a cualquier docente, tema, curso y localidad.

**Alcance:** Física y Química de 2º ESO a 2º Bachillerato. Funciona tanto con temas de cálculo (cinemática, dinámica, energía, química cuantitativa...) como con temas conceptuales (modelos atómicos, enlace, formulación...), que usan las **mecánicas sin cálculo** de esta skill. No está pensada para Primaria.

## Qué se entrega

1. **Dossier del alumnado**, maquetado como un expediente real: portada, historia, fichas de sospechosos, expedientes, casillas de solución e informe final.
2. **Solucionario con guía docente**:
   - soluciones desarrolladas y tabla de códigos;
   - trampas previstas;
   - guion de puesta en escena;
   - temporalización, roles, pistas y conversión a nota.
3. **Kit de inmersión** (según el nivel de puesta en escena elegido):
   - gancho de apertura y boletines de última hora;
   - credenciales de rol y portadas de los sobres;
   - pistas selladas y certificado o rango final.

---

## Paso 1 · Entrevista inicial (siempre antes de diseñar)

No diseñes nada sin estas respuestas. Si el docente ya ha dado información, **no la vuelvas a preguntar**: pregunta solo lo que falte.

Usa AskUserQuestion si está disponible, con rondas de 4 preguntas como máximo y opciones cerradas (el docente siempre puede responder libremente). Si no está disponible, haz las preguntas en un único mensaje numerado.

### Ronda 1 · Contenido y aula

1. **Tema y curso**: qué saberes trabaja el caso y en qué curso. Pregunta también **qué NO se ha visto todavía**, para no usarlo.
2. **Uso**: actividad gamificada de aula, prueba escrita evaluable, repaso antes del examen o reto para casa.
3. **Agrupamiento**:
   - Individual.
   - Parejas con roles que se intercambian (A, analista; B, cartógrafo/a y portavoz).
   - Equipos de 3-4 con roles (analista, cartógrafo/a, verificador/a, portavoz).
   - Gran grupo con el docente como narrador.
4. **Duración y tamaño**: número de sesiones y minutos por sesión, y número de expedientes (por defecto, 3 expedientes + informe + reto; aproximadamente 15-20 minutos por expediente).

### Ronda 2 · La historia

5. **Narrativa**. Ofrece ejemplos con una línea cada uno, sin limitarte a ellos:
   - **CSI / investigación policial**: un robo o sabotaje, sospechosos y coartadas que se desmontan con cálculos.
   - **Emergencias 112**: un incendio, un rescate o una inundación con tiempos de llegada, trayectorias o caudales.
   - **Escape room**: un grupo encerrado en el instituto, el museo o el laboratorio, con candados de código.
   - **Misión espacial**: una nave averiada, con maniobras, órbitas, combustible y otra g.
   - **Agencia de espías**: mensajes cifrados, persecuciones y lanzamientos de paquetes.
   - **VAR deportivo**: analizar una jugada, un chut o una carrera para decidir una polémica.
   - **Arqueología o museo**: una pieza falsificada que se delata por su densidad o su composición.
   - **Periodismo de investigación**: un bulo viral que se desmonta con datos.
   - **Supervivencia** (zombis, isla desierta): racionar energía, agua y recursos.
   - **Viaje en el tiempo**: Galileo, Newton, Marie Curie o Lavoisier piden ayuda.

   Pregunta también por el **tono**: serio, con humor o de suspense.
6. **Lugar**: ciudad, pueblo o comarca, y lugares que el alumnado reconozca (calles, plaza, río, ermita, estadio, fiestas, el propio centro). Pregunta si las distancias tienen que ser **reales aproximadas** o **inventadas pero verosímiles**.
7. **Personajes**:
   - Nombres inventados (opción por defecto).
   - Nombres del alumnado.
   - Personajes del centro.

   Si elige nombres del alumnado, recuérdale en una línea que conviene pactarlo con la clase y no convertir en culpable a nadie que no lo haya aceptado.
8. **Nivel de puesta en escena**:
   - **Básico**: solo el dossier.
   - **Atrezzo**: dossier + sobres, credenciales y boletines impresos.
   - **Inmersivo**: todo lo anterior + gancho dramatizado, giro de guion, ceremonia de «caso cerrado» y, opcionalmente, candados digitales.

### Ronda 3 · Formato (breve)

9. **Idioma**: castellano, valenciano/catalán, inglés, gallego, euskera...
10. **Formato de entrega**: documento editable, Word o PDF.
11. **Tipo de dossier**:
    - **Completo**: los cálculos se hacen en el dossier.
    - **Compacto**: en el dossier solo van las soluciones finales con unidades, y los cálculos se entregan en una hoja aparte indicando el número del apartado.
12. **Versión digital**: ¿quiere candados con Google Forms (validación de respuesta) o códigos QR entre expedientes?

### Detalles opcionales

Pregúntalos en texto libre, en una sola línea, solo si son relevantes:

- Constantes: g = 9,8 o 10 m/s², cifras significativas.
- Moneda del juego: florines, créditos, XP...
- ¿Mensaje cifrado extra?
- ¿Pistas que se compran con puntos?
- Alumnado con necesidades específicas (DUA).
- Nombre del centro, colores o logo.

### Valores por defecto

Si el docente dice «tú mismo» o no responde, usa estos valores y explícalo en una línea:

- Parejas con roles A/B.
- 2 sesiones de 55 minutos.
- 3 expedientes + informe + reto.
- 1.000 puntos + 100 de reto.
- g = 9,8 m/s².
- Puesta en escena de nivel atrezzo.
- Sobres con códigos.
- Nombres inventados.
- Localidad del docente si la conoces; si no, una localidad verosímil.

---

## Paso 2 · Esqueleto para validar

Presenta un esqueleto breve y espera el visto bueno: rehacer un dossier es caro y cambiar el esqueleto es barato. Si el docente trabaja sin supervisión, sigue y anota tus decisiones al principio del solucionario.

El esqueleto incluye:

- **Sinopsis** (3-4 líneas): qué ha pasado, dónde, cuándo (día y hora exactos) y qué hay que averiguar.
- **Sospechosos u opciones** (3-4):
  - el **culpable**;
  - la **trampa**: el sospechoso al que se llega con un error típico concreto;
  - el **falso culpable** del giro de guion (si hay giro).
- **Tabla de expedientes**:

| Expediente | Contenido | Resultado clave | Código | Trampa | Puntos |
| --- | --- | --- | --- | --- | --- |

- **Arco dramático**: gancho → primer sospechoso → giro → revelación.
- **Informe final**: la conexión real (seguridad vial, incendios, energía, salud, medio ambiente, consumo...).
- **Reto extra** para el alumnado de alta capacidad.

---

## Paso 3 · Diseño inverso de los números (el corazón de la skill)

1. **Primero el resultado limpio**. Elige resultados redondos o reconocibles (t = 2 s, x = 120 m, 60°, 54 km/h = 15 m/s, pH = 3, 0,25 mol) y construye los datos a partir de ellos. Por ejemplo: h = 19,6 m con g = 9,8 m/s² da t = 2 s exactos.
2. **Cada dato discrimina**. Cada sospechoso u opción queda descartado por **un resultado concreto**, nunca por intuición. El culpable es único.
3. **La trampa es un error concreto**. El sospechoso trampa coincide exactamente con el resultado de un error típico (consulta el banco de trampas). En el solucionario explica qué error lleva hasta él.
4. **Coherencia global**. Comprueba que encajan:
   - las horas del reloj con los tiempos calculados;
   - las posiciones con el origen;
   - las velocidades con los límites reales (un ciclomotor de 50 cc no supera 45 km/h; una persona corre como mucho a unos 10 m/s);
   - los datos de un expediente con los del siguiente.
5. **Sistema de referencia explícito**: origen, sentido positivo y t = 0 en cada expediente. Si el origen cambia, se dice en el enunciado.
6. **Distractores con moderación**: uno o dos por expediente, y verosímiles dentro de la historia.
7. **Verosimilitud**. Si hay búsqueda web, verifica las distancias reales aproximadas y **siempre** las cifras reales del informe (DGT, 112, normativa, consumo...). Lo que no se pueda verificar se presenta como estimación.
8. **Calcula todo con código**. Resuelve con Python cada apartado, la trampa y el reto. Ningún número llega al dossier sin pasar por la tabla de control.

---

## Paso 4 · Mecánicas sin cálculo (temas conceptuales)

Cuando el tema no da resultados numéricos encadenables, el motor del caso es la **deducción a partir de propiedades y evidencias**. Se mantienen las mismas reglas: cada evidencia descarta a alguien, hay una trampa basada en una concepción errónea concreta y cada expediente termina con un código.

| Tema | Mecánica sugerida |
| --- | --- |
| Propiedades de la materia, mezclas y separación | **Sustancias del laboratorio**: una tabla con puntos de fusión y ebullición, densidad, solubilidad y conductividad. La muestra encontrada en la escena solo coincide con una sustancia, que solo un sospechoso tenía. Separar la mezcla de la escena revela la pista. |
| Modelos atómicos | **Testigos de distintas épocas**: cada «declaración» solo es compatible con un modelo (Dalton, Thomson, Rutherford, Bohr). Hay que ordenar los documentos y detectar al impostor que cita un modelo anterior a su época. |
| Configuración electrónica y tabla periódica | **Huella electrónica**: las pistas dan configuraciones, grupos o propiedades periódicas, y el elemento identificado da la letra (inicial del símbolo) o el número (Z) del código. Funciona bien con mensajes cifrados. |
| Espectros y test a la llama | **Fuegos artificiales sospechosos**: el color de la llama o las líneas del espectro identifican el metal presente en los restos (Na amarillo, Sr rojo, Cu verde azulado...). |
| Enlace químico | **Muestra de la escena**: sus propiedades (¿conduce fundida o en disolución?, ¿dura o frágil?, ¿se disuelve en agua?) delatan si es iónica, covalente molecular, covalente reticular o metálica, y con eso qué sospechoso la tenía. |
| Formulación y nomenclatura | **Etiquetas borradas**: frascos con la etiqueta dañada que hay que reconstruir (fórmula ↔ nombre). Una etiqueta falsificada tiene un nombre que no corresponde a la fórmula. |
| Reacciones y ajuste | **Receta saboteada**: la reacción mal ajustada del cuaderno del sospechoso viola la conservación de la masa. Hay que encontrar qué coeficiente se ha alterado. |
| Método científico | **Experimento trucado**: el diseño del sospechoso tiene variables mal controladas. Hay que detectarlo y rediseñar el experimento. |
| Química orgánica (Bachillerato) | **El perfume falsificado**: los grupos funcionales y la isómería distinguen la molécula original de la copia. |

También puedes usar estas mecánicas como **expediente bisagra** dentro de un caso de cálculo, para variar el ritmo.

---

## Paso 5 · Capa de impacto (lo que lo hace memorable)

Ajústala al nivel de puesta en escena elegido. Aquí la física no se toca: la capa de impacto envuelve los problemas, nunca los sustituye.

**Gancho de apertura (primeros 3-5 minutos)**

Empieza con una «prueba» en lugar de una explicación:

- la transcripción de la llamada al 112 con la hora exacta;
- un mensaje filtrado de un grupo de mensajería;
- un ticket de compra;
- un fotograma esquemático de una dashcam;
- una carta urgente del comisario, del comandante de la misión o de la directora del museo.

Incluye un **guion de un minuto** para que el docente lo lea con tono dramático o lo grabe en audio.

**Atrezzo imprimible**

- Portada de cada sobre con el sello «EVIDENCIA N.º X · NO ABRIR SIN CÓDIGO».
- Fichas de sospechosos en formato ficha policial: nombre, vehículo o medio, posición, coartada y un detalle personal que luego importa.
- Credenciales de agente por rol, con un espacio para el nombre.
- Mapa esquemático de la localidad con cuadrícula, escala y rosa de los vientos.

Usa siempre unidades y emblemas **ficticios** («Unidad Científica del IES...», «Agencia Espacial del Mediterráneo»). Nunca imites placas, logotipos ni documentos oficiales reales de Policía, Guardia Civil, 112 u otras instituciones.

**Giro de guion**

A mitad del caso, un resultado parece señalar a un sospechoso (el falso culpable). En el siguiente expediente, un dato nuevo y calculable lo desmonta. El giro siempre se basa en la física o la química, nunca en un dato que «aparece» sin más.

**Boletines de última hora**

Incluye 2-3 mensajes breves que el docente lee entre expedientes para mantener el ritmo y la tensión. Por ejemplo: «La patrulla confirma que el sospechoso no llevaba casco» o «Quedan 10 minutos de oxígeno».

**Tablero de progreso**

Una plantilla para la pizarra o el proyector con los equipos, los sobres abiertos y los puntos. Añade un cronómetro visible si la narrativa lo pide.

**Ceremonia de «caso cerrado» (últimos 10 minutos)**

- Reconstrucción de los hechos en una línea temporal.
- Confesión breve del culpable (con humor; una imprudencia, nunca violencia).
- «Rueda de prensa»: los portavoces leen el informe final.
- Rangos según los puntos (p. ej., Cadete < 500, Agente 500-749, Inspector/a 750-949, Comisario/a ≥ 950).
- Certificado imprimible.

**Versión digital opcional**

- Candados con Google Forms: una sección por expediente y validación de respuesta con el código. En la guía, explica cómo configurarlo paso a paso.
- Códigos QR que apuntan al siguiente expediente.
- El caso debe poder jugarse igual sin la versión digital.

**Mensaje cifrado (opcional)**

Cada resultado da una letra (número atómico → inicial del símbolo, posición en el abecedario...). El conjunto forma una frase relacionada con la ciencia, que se revela en la ceremonia final.

---

## Paso 6 · Dossier del alumnado

1. **Portada**:
   - título del caso con estética de expediente (sello de confidencial, número de caso, fecha y hora);
   - la historia (máximo media página, en presente y con detalles locales);
   - normas: roles, puntos, sobres, dónde van los cálculos, pistas;
   - fichas de sospechosos.
2. **Un expediente por hoja o pareja de hojas**:
   - título evocador («La dashcam del semáforo», «La bolsa del puente»);
   - texto narrativo breve;
   - evidencia: tabla, esquema, gráfica, registro GPS, declaración o fotograma esquemático;
   - apartados numerados (1.1, 1.2...) con los puntos y el rol que lidera cada uno;
   - casillas de solución con espacio para la unidad;
   - casilla del **código** al final.
3. **Progresión dentro de cada expediente**: comprensión → cálculo o deducción → representación (gráfica, esquema o mapa) → decisión (quién queda descartado) → una pregunta de razonamiento sin números («¿qué pasaría si...?»).
4. **Informe final**: comunicación con un destinatario real (Policía Local, Bomberos, Ayuntamiento, familias, prensa local). Incluye:
   - un cálculo comparativo;
   - un dato real verificado;
   - propuestas (p. ej., 2 medidas preventivas + 2 correctivas).

   Es donde se trabajan el pensamiento crítico y la dimensión CTS.
5. **Reto extra** (voluntario): una pregunta inversa o de optimización (velocidad mínima, ángulo óptimo, punto de cruce, reactivo mínimo...).

**Reglas de redacción**

- Lenguaje adecuado al curso, frases cortas y vocabulario científico preciso.
- Unidades del SI, con coma decimal y punto para los miles.
- Ninguna pregunta revela la respuesta de otra.
- La historia nunca contradice la ciencia.
- Personajes diversos y sin estereotipos. Sin violencia gráfica: los culpables son imprudentes o traviesos.

**Diseño visual**

- Estética coherente de expediente: tipografía tipo máquina de escribir para los documentos «oficiales», legible para el resto.
- Sellos, clips o cinta dibujados.
- Esquemas limpios en lugar de fotos.
- Mucho espacio en blanco en las casillas y contraste suficiente.
- Nada de fotos de personas reales.

---

## Paso 7 · Solucionario y guía docente

- **Soluciones desarrolladas** por apartado: planteamiento, ecuación, sustitución y resultado con unidades. Incluye gráficas y esquemas resueltos.
- **Tabla de códigos** para validar sobres de un vistazo.
- **Trampas**: qué respuesta errónea sale, qué error la provoca y una pregunta socrática para reconducir sin dar la solución.
- **Guion de puesta en escena**: textos del gancho, de los boletines y de la ceremonia, y cuándo usar cada uno.
- **Puntuación**: reparto de puntos, conversión a nota (p. ej., 1.000 puntos = 10) y tratamiento del reto.
- **Temporalización** y gestión de los equipos rápidos (reto) y lentos (pistas).
- **Roles** y cuándo se intercambian.
- **Pistas selladas** (DUA): graduadas de una orientación conceptual a un paso concreto, nunca el resultado, con su coste en puntos.
- **Anclaje curricular** breve (saberes, competencias específicas y criterios), si la prueba es evaluable o el docente lo pide.

---

## Paso 8 · Formato y entrega

- Si el docente pide Word o PDF, carga la skill docx o pdf **después** de tener el contenido cerrado y verificado.
- Si no pide formato y la sesión ofrece tipos de documento o diseño editables, úsalos: diseño para el dossier y el atrezzo, y documento para el solucionario.
- Respeta el nombre, el logo y los colores del centro si se han facilitado.
- El dossier del alumnado, el solucionario y el kit de inmersión son **archivos separados**. El solucionario nunca va dentro del dossier.

---

## Paso 9 · Verificación final (obligatoria)

- [ ] Todos los números coinciden con la tabla de control calculada con código.
- [ ] Cada sospechoso queda descartado por un resultado o evidencia concreta, y el culpable es único.
- [ ] La trampa sale exactamente con el error descrito, y el giro de guion se desmonta con un dato calculable.
- [ ] Las horas, las posiciones y los orígenes son coherentes entre expedientes.
- [ ] No se usa ningún contenido que el docente dijo que no se había visto.
- [ ] Los puntos suman el total anunciado y los rangos encajan con ese total.
- [ ] Los códigos del dossier, de la tabla de códigos y de los candados digitales coinciden.
- [ ] Los datos reales del informe están verificados o marcados como estimaciones.
- [ ] No se imita ningún emblema ni documento oficial real.
- [ ] Has abierto o renderizado los documentos y la maquetación es correcta: las casillas caben y las gráficas son legibles.

---

## Banco de trampas

### ESO

| Contenido | Error típico que alimenta la trampa |
| --- | --- |
| MRU | No convertir km/h ↔ m/s. Olvidar un tramo del recorrido (ida y vuelta, subida y bajada). Ignorar la posición inicial. |
| Encuentros (MRU/MRUA) | Signo del móvil que viene de frente. Usar orígenes distintos para cada móvil. Confundir tiempo de encuentro con hora del reloj. |
| MRUA | Usar v = x/t con aceleración. Olvidar el ½ en ½·a·t². Confundir la distancia de frenada con la de detención (sin tiempo de reacción). Signo de a en la frenada. |
| Caída libre | Mezclar criterios de signo para g. Pensar que los objetos pesados caen antes. |
| Composición de movimientos / tiro horizontal | Sumar velocidades como escalares. Olvidar la velocidad del lanzador (inercia). Usar la velocidad horizontal para calcular el tiempo de caída. |
| Tiro parabólico | Comprobar el alcance pero no la altura en el obstáculo. Creer que 45° siempre gana. Calculadora en radianes. |
| MCU | Confundir rpm con rad/s. Confundir período y frecuencia. |
| Dinámica | Olvidar el rozamiento o la componente del peso en el plano inclinado. Pensar que hace falta fuerza para mantener la velocidad. Confundir masa y peso. |
| Presión / hidrostática | Unidades de superficie (cm² ↔ m²). Medir la profundidad desde el fondo. |
| Energía | Olvidar la energía potencial inicial. Confundir potencia y energía (kW vs kWh). |
| Calor | Confundir calor y temperatura. Olvidar el calor latente en el cambio de estado. |
| Densidad | Unidades (g/cm³ ↔ kg/m³). Confundir el volumen del objeto con el del líquido desplazado. |
| Estequiometría | Reacción sin ajustar. Proporción en gramos en lugar de en moles. Ignorar el reactivo limitante. |
| Disoluciones / gases | Volumen de disolución vs de disolvente. Temperatura en °C en lugar de K. |

### Bachillerato

| Contenido | Error típico que alimenta la trampa |
| --- | --- |
| Gravitación y satélites | Usar g = 9,8 m/s² en altura. Tomar la altura como radio orbital (olvidar R_T). Confundir la velocidad orbital con la de escape. |
| Campo eléctrico | Sumar módulos en lugar de vectores. Olvidar el signo de la carga en el potencial. Confundir campo y potencial. |
| Magnetismo / inducción | Sentido de la fuerza sobre una carga negativa. Olvidar la ley de Lenz al dar el sentido de la corriente inducida. |
| Circuitos | Combinar mal serie y paralelo. Creer que la intensidad «se gasta» a lo largo del circuito. |
| Ondas y sonido | Confundir la velocidad de propagación con la de vibración. Pensar que la frecuencia cambia al cambiar de medio. Escala logarítmica de los dB (sumar decibelios). |
| Óptica | Criterio de signos de las distancias. Confundir imagen real y virtual. |
| Termodinámica | Criterio de signos del trabajo. Confundir ΔU y ΔH. Pensar que ΔG < 0 implica una reacción rápida. |
| Cinética y equilibrio | Incluir sólidos en Kc. Creer que un catalizador desplaza el equilibrio. Kc vs Kp. |
| Ácido-base | Calcular el pH de un ácido débil como si fuera fuerte. Diluir sin recalcular la concentración. |
| Redox | Números de oxidación. Ajustar sin la semirreacción en medio ácido o básico. Confundir oxidante y reductor. |
| Química orgánica | Elegir mal la cadena principal. Confundir isómeros. |

## Errores a evitar

- Empezar sin la entrevista o sin validar el esqueleto.
- Datos que no encajan con la historia (horas imposibles, velocidades irreales).
- Números «feos» que no aportan nada al aprendizaje.
- Una narrativa o un atrezzo que se comen el tiempo de ciencia: la historia acompaña, la ciencia manda.
- Giros de guion que no se pueden deducir con lo que el alumnado sabe.
- Cifras reales sin verificar, o emblemas oficiales imitados.
- Solucionario y dossier en el mismo archivo.