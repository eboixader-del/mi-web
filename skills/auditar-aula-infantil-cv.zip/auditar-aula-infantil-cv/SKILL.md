---
name: auditar-aula-infantil-cv
description: Audita situaciones de aprendizaje, materiales e instrumentos de observación de aula de Educación Infantil ya creados frente a las áreas que deben cubrir y a los criterios DUA de accesibilidad.
---

# Auditar aula de Educación Infantil

Auditoría interna de aula: distinta de auditar la programación didáctica completa del nivel (para eso usa la skill auditar-programacion-infantil-cv).

## Procedimiento
1. Fija el alcance y las versiones de los productos a revisar (situación de aprendizaje, materiales, instrumentos de observación); identifica la programación didáctica de referencia.
2. Revisa cada área implicada en el alcance: criterios de evaluación orientadores trabajados, evidencia observable prevista, instrumento asociado. Señala áreas sin instrumento de observación, materiales inadecuados para la edad, o exigencias de autonomía incoherentes con el nivel del grupo.
3. Comprueba que los materiales están completos (no solo un título o una idea), que los tiempos y espacios son realistas, que los recursos citados existen o están identificados como pendientes, y que el diseño aplica el DUA de forma coherente con el desarrollo propio de la etapa.
4. Entrega los hallazgos con estado (cumple / parcial / no cumple / no verificable), evidencia, impacto, acción propuesta y responsable. No certifiques la eficacia real en el aula: eso solo se comprueba usándolo con el grupo.

## Límites
No inventes una puntuación oficial de calidad del material ni una calificación del alumnado. No modifiques los originales salvo que el docente pida corrección explícita.
