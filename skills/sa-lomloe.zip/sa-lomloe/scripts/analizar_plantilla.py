# -*- coding: utf-8 -*-
"""
Analiza la plantilla que aporta el centro y describe su estructura para poder
rellenarla después con `rellenar_plantilla.py`.

Uso:
    python analizar_plantilla.py plantilla.docx [--max 70]
    python analizar_plantilla.py plantilla.pdf  [--imagenes carpeta]

.docx  → imprime el mapa de tablas, filas, columnas y celdas con sus coordenadas
         [tabla, fila, columna], el texto de cada celda, su color de fondo y las
         combinaciones de celdas. Esas coordenadas son las que se usan en el
         fichero de mapeo.
.pdf   → imprime el texto y las tablas detectadas y genera una imagen por página
         para poder verla. Un PDF no se puede rellenar conservando el formato:
         pide al docente el .docx original o reproduce la plantilla.

Requisitos: pip install python-docx pymupdf
"""
import sys
from pathlib import Path

try:  # consola de Windows en cp1252
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except AttributeError:
    pass


def texto_celda(celda, maximo):
    t = " | ".join(p.text.strip() for p in celda.paragraphs if p.text.strip())
    t = t.replace("\n", " ")
    if len(t) > maximo:
        t = t[:maximo - 3] + "..."
    return t


def color_celda(celda):
    from docx.oxml.ns import qn
    tcPr = celda._tc.tcPr
    if tcPr is None:
        return ""
    shd = tcPr.find(qn("w:shd"))
    if shd is None:
        return ""
    fill = shd.get(qn("w:fill"))
    return "" if fill in (None, "auto") else fill


def continuacion_vertical(celda):
    """True si la celda es la continuación de una combinación vertical."""
    from docx.oxml.ns import qn
    tcPr = celda._tc.tcPr
    if tcPr is None:
        return False
    vmerge = tcPr.find(qn("w:vMerge"))
    if vmerge is None:
        return False
    return vmerge.get(qn("w:val")) in (None, "continue")


def analiza_docx(ruta, maximo):
    from docx import Document
    from docx.enum.section import WD_ORIENT

    doc = Document(ruta)
    print("PLANTILLA: " + str(ruta))
    for i, sec in enumerate(doc.sections):
        orient = "apaisada" if sec.orientation == WD_ORIENT.LANDSCAPE else "vertical"
        print("Sección %d: %s, %.1f x %.1f cm, márgenes izq/der %.1f/%.1f cm"
              % (i, orient, sec.page_width.cm, sec.page_height.cm,
                 sec.left_margin.cm, sec.right_margin.cm))
        for p in sec.header.paragraphs:
            if p.text.strip():
                print("  Cabecera: " + p.text.strip())
        if sec.header.tables:
            print("  Cabecera: contiene %d tabla(s)" % len(sec.header.tables))
    print()

    parrafos = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
    if parrafos:
        print("PÁRRAFOS FUERA DE TABLAS (%d con texto):" % len(parrafos))
        for j, t in enumerate(parrafos[:40]):
            print("  P%-3d %s" % (j, t[:maximo]))
        print()

    print("TABLAS: %d" % len(doc.tables))
    for ti, tabla in enumerate(doc.tables):
        filas = len(tabla.rows)
        cols = len(tabla.columns)
        print("\n=== TABLA %d — %d filas x %d columnas ===" % (ti, filas, cols))
        # Se guardan referencias fuertes a los elementos XML: comparar por
        # identidad es lo que detecta las celdas combinadas.
        vistas = []
        for fi, fila in enumerate(tabla.rows):
            for ci, celda in enumerate(fila.cells):
                origen = None
                for tc_visto, posicion in vistas:
                    if tc_visto is celda._tc:
                        origen = posicion
                        break
                if origen is not None and origen != (fi, ci):
                    print("  [%d,%d,%d] = combinada con [%d,%d,%d]"
                          % (ti, fi, ci, ti, origen[0], origen[1]))
                    continue
                if origen is None:
                    vistas.append((celda._tc, (fi, ci)))
                if continuacion_vertical(celda):
                    print("  [%d,%d,%d] = continuacion vertical de la fila anterior"
                          % (ti, fi, ci))
                    continue
                texto = texto_celda(celda, maximo)
                color = color_celda(celda)
                etiqueta = "VACÍA" if not texto else texto
                extra = ("  fondo #" + color) if color else ""
                print("  [%d,%d,%d] %s%s" % (ti, fi, ci, etiqueta, extra))
    print("\nLas coordenadas [tabla, fila, columna] son las que se usan en el mapeo.")
    print("Las celdas VACÍAS son las casillas que hay que rellenar; las que tienen")
    print("texto suelen ser rótulos de la plantilla (no los borres).")


def analiza_pdf(ruta, carpeta_imagenes):
    import pymupdf

    doc = pymupdf.open(ruta)
    print("PLANTILLA (PDF, no rellenable directamente): " + str(ruta))
    print("Páginas: %d" % doc.page_count)
    destino = Path(carpeta_imagenes) if carpeta_imagenes else Path(ruta).with_suffix("")
    destino.mkdir(parents=True, exist_ok=True)
    for i in range(doc.page_count):
        pagina = doc[i]
        img = destino / ("pagina-%02d.png" % (i + 1))
        pagina.get_pixmap(dpi=110).save(img)
        print("\n=== PÁGINA %d — imagen: %s ===" % (i + 1, img))
        try:
            tablas = list(pagina.find_tables().tables)
        except Exception:
            tablas = []
        if tablas:
            for k, t in enumerate(tablas):
                print("  Tabla %d:" % k)
                for fila in t.extract():
                    celdas = [(c or "").replace("\n", " ").strip()[:40] for c in fila]
                    print("    | " + " | ".join(celdas))
        texto = pagina.get_text().strip()
        if texto:
            print("  Texto:")
            for linea in texto.split("\n")[:40]:
                if linea.strip():
                    print("    " + linea.strip()[:100])
    print("\nAbre las imágenes para ver el diseño real (colores, logotipo, disposición).")
    print("Para conservar el formato del centro, pide el .docx original.")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    ruta = Path(sys.argv[1])
    maximo = 70
    if "--max" in sys.argv:
        maximo = int(sys.argv[sys.argv.index("--max") + 1])
    carpeta = None
    if "--imagenes" in sys.argv:
        carpeta = sys.argv[sys.argv.index("--imagenes") + 1]

    if not ruta.exists():
        print("No existe el fichero: " + str(ruta))
        sys.exit(2)

    sufijo = ruta.suffix.lower()
    if sufijo == ".docx":
        analiza_docx(ruta, maximo)
    elif sufijo == ".pdf":
        analiza_pdf(ruta, carpeta)
    elif sufijo in (".doc", ".odt"):
        print("Formato %s no soportado. Pide al docente que lo guarde como .docx." % sufijo)
        sys.exit(3)
    else:
        print("Formato %s no reconocido. Si es una imagen de la plantilla, ábrela y" % sufijo)
        print("reproduce su estructura con generar_sa.py.")
        sys.exit(3)


if __name__ == "__main__":
    main()
