# -*- coding: utf-8 -*-
"""
Rellena la plantilla .docx del propio centro conservando su formato (logotipo,
colores, tipografías, márgenes): abre el documento original, escribe en las
celdas indicadas y guarda una copia. La plantilla nunca se modifica.

Uso:
    python rellenar_plantilla.py mapeo.json
    python rellenar_plantilla.py mapeo.json --solo-estructura   # duplica/elimina, sin escribir
    python rellenar_plantilla.py mapeo.json --mapa              # imprime el mapa resultante
    python rellenar_plantilla.py mapeo.json --previsualizar     # no guarda nada

Estructura del fichero de mapeo (todas las claves salvo plantilla/salida son
opcionales). Las coordenadas son [tabla, fila, columna] tal como las imprime
`analizar_plantilla.py`:

{
  "plantilla": "PLANTILLA CONCRECION.docx",
  "salida":    "SA1_rellenada.docx",

  "duplicar_tablas": [ {"tabla": 1, "veces": 2},
                       {"tablas": [1, 2], "veces": 3} ],  // bloque de tablas contiguas
  "duplicar_filas":  [ {"tabla": 2, "fila": 3, "veces": 4} ],

  "celdas": [
    {"tabla": 0, "fila": 0, "col": 1, "texto": "3.º ESO", "modo": "misma_linea"},
    {"tabla": 1, "fila": 1, "col": 2, "texto": "CE1. …\\n1.1. …"}
  ],

  "eliminar_filas":  [ {"tabla": 2, "filas": [8, 9, 10]} ],
  "eliminar_tablas": [5, 6],
  "eliminar_tablas_sin_escribir": true   // borra los bloques que no se han usado
}

Modos de escritura:
  "reemplazar"   (por defecto) borra el contenido de la celda y escribe el texto.
  "misma_linea"  añade el texto al final de lo que ya hay (rótulos tipo "CURSO:").
  "anexar"       añade el texto como párrafo(s) nuevo(s) debajo de lo existente.

ORDEN DE APLICACIÓN: primero se duplican tablas, después filas, después se
escriben las celdas y por último se eliminan filas y tablas sobrantes. Por tanto
las coordenadas de "celdas" y de "eliminar_*" se refieren al documento **ya
duplicado**. Con `--solo-estructura` puedes hacer las duplicaciones, volver a
analizar el resultado y escribir después con las coordenadas definitivas.

Requisitos: pip install python-docx
"""
import copy
import json
import sys
from pathlib import Path

try:  # consola de Windows en cp1252
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except AttributeError:
    pass

from docx import Document
from docx.oxml.ns import qn


# --------------------------------------------------------------------------
def formato_de_referencia(celda):
    """Primer run de la celda: sirve de modelo tipográfico."""
    for p in celda.paragraphs:
        if p.runs:
            return p.runs[0]
    return None


def copia_formato(origen, destino):
    if origen is None:
        return
    destino.font.name = origen.font.name
    destino.font.size = origen.font.size
    destino.font.bold = origen.font.bold
    destino.font.italic = origen.font.italic
    try:
        if origen.font.color is not None and origen.font.color.rgb is not None:
            destino.font.color.rgb = origen.font.color.rgb
    except (AttributeError, ValueError):
        pass


def parrafo_clonado(celda, modelo):
    """Añade un párrafo a la celda copiando el formato de párrafo del modelo."""
    nuevo = celda.add_paragraph()
    if modelo is not None and modelo._p.pPr is not None:
        nuevo._p.insert(0, copy.deepcopy(modelo._p.pPr))
    return nuevo


def escribe_celda(celda, texto, modo="reemplazar"):
    lineas = str(texto).split("\n")
    referencia = formato_de_referencia(celda)
    modelo = celda.paragraphs[0] if celda.paragraphs else None

    if modo == "misma_linea":
        p = celda.paragraphs[-1]
        separador = " " if p.text and not p.text.endswith((" ", ":")) else (
            " " if p.text.endswith(":") else "")
        r = p.add_run(separador + lineas[0])
        copia_formato(referencia, r)
        r.bold = False
        pendientes = lineas[1:]
    elif modo == "anexar":
        pendientes = lineas
    else:  # reemplazar
        for p in list(celda.paragraphs[1:]):
            p._p.getparent().remove(p._p)
        p = celda.paragraphs[0]
        for r in list(p.runs):
            r._r.getparent().remove(r._r)
        r = p.add_run(lineas[0])
        copia_formato(referencia, r)
        pendientes = lineas[1:]

    for linea in pendientes:
        p = parrafo_clonado(celda, modelo)
        r = p.add_run(linea)
        copia_formato(referencia, r)


# --------------------------------------------------------------------------
def duplica_filas(doc, tabla_idx, fila_idx, veces):
    tabla = doc.tables[tabla_idx]
    tr = tabla.rows[fila_idx]._tr
    for _ in range(veces):
        tr.addnext(copy.deepcopy(tr))


def duplica_tabla(doc, indices, veces):
    """Duplica una tabla o un bloque de tablas contiguas (con lo que haya
    entre ellas), insertando las copias justo detrás del bloque original."""
    primero = doc.tables[indices[0]]._tbl
    ultimo = doc.tables[indices[-1]]._tbl

    bloque = []
    elemento = primero
    while elemento is not None:
        bloque.append(elemento)
        if elemento is ultimo:
            break
        elemento = elemento.getnext()

    siguiente = ultimo.getnext()
    es_parrafo_vacio = (siguiente is not None
                        and siguiente.tag == qn("w:p")
                        and not siguiente.findall(".//" + qn("w:t")))
    ancla = siguiente if es_parrafo_vacio else ultimo
    for _ in range(veces):
        for elemento in bloque:
            copia = copy.deepcopy(elemento)
            ancla.addnext(copia)
            ancla = copia
        if es_parrafo_vacio:
            hueco = copy.deepcopy(siguiente)
            ancla.addnext(hueco)
            ancla = hueco


def elimina_filas(doc, tabla_idx, indices):
    tabla = doc.tables[tabla_idx]
    for fi in sorted(indices, reverse=True):
        if fi < len(tabla.rows):
            tr = tabla.rows[fi]._tr
            tr.getparent().remove(tr)


def elimina_tabla(doc, tabla_idx):
    tbl = doc.tables[tabla_idx]._tbl
    siguiente = tbl.getnext()
    tbl.getparent().remove(tbl)
    if (siguiente is not None and siguiente.tag == qn("w:p")
            and not siguiente.findall(".//" + qn("w:t"))):
        siguiente.getparent().remove(siguiente)


# --------------------------------------------------------------------------
def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    mapeo = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    solo_estructura = "--solo-estructura" in sys.argv
    previsualizar = "--previsualizar" in sys.argv
    con_mapa = "--mapa" in sys.argv

    plantilla = Path(mapeo["plantilla"])
    if not plantilla.exists():
        print("No se encuentra la plantilla: " + str(plantilla))
        sys.exit(2)
    salida = Path(mapeo.get("salida") or (plantilla.stem + "_rellenada.docx"))

    doc = Document(plantilla)
    avisos = []

    # 1) duplicaciones (de mayor a menor índice para no invalidar coordenadas)
    def indices_de(item):
        if "tablas" in item:
            return sorted(int(i) for i in item["tablas"])
        return [int(item["tabla"])]

    for item in sorted(mapeo.get("duplicar_tablas", []),
                       key=lambda x: indices_de(x)[0], reverse=True):
        indices = indices_de(item)
        if indices[-1] < len(doc.tables):
            duplica_tabla(doc, indices, int(item.get("veces", 1)))
            print("Tabla(s) %s duplicada(s) x%d"
                  % (indices if len(indices) > 1 else indices[0], item.get("veces", 1)))
        else:
            avisos.append("No existe la tabla %d (duplicar_tablas)" % indices[-1])

    for item in sorted(mapeo.get("duplicar_filas", []),
                       key=lambda x: (x["tabla"], x["fila"]), reverse=True):
        try:
            duplica_filas(doc, item["tabla"], item["fila"], int(item.get("veces", 1)))
            print("Tabla %d, fila %d duplicada x%d"
                  % (item["tabla"], item["fila"], item.get("veces", 1)))
        except IndexError:
            avisos.append("No existe [%d,%d] (duplicar_filas)" % (item["tabla"], item["fila"]))

    # 2) escritura de celdas
    escritas = 0
    tablas_escritas = set()
    if not solo_estructura:
        for item in mapeo.get("celdas", []):
            ti, fi, ci = item["tabla"], item["fila"], item["col"]
            try:
                celda = doc.tables[ti].cell(fi, ci)
            except IndexError:
                avisos.append("No existe la celda [%d,%d,%d]" % (ti, fi, ci))
                continue
            texto = item.get("texto", "")
            modo = item.get("modo", "reemplazar")
            previo = " ".join(p.text.strip() for p in celda.paragraphs).strip()
            if modo == "reemplazar" and previo:
                avisos.append("La celda [%d,%d,%d] contenía \"%s\" y se ha sobrescrito. "
                              "Si era un rótulo de la plantilla, usa modo \"misma_linea\"."
                              % (ti, fi, ci, previo[:40]))
            escribe_celda(celda, texto, modo)
            escritas += 1
            tablas_escritas.add(ti)
            resumen = str(texto).replace("\n", " / ")
            if len(resumen) > 60:
                resumen = resumen[:57] + "..."
            print("  [%d,%d,%d] <- %s" % (ti, fi, ci, resumen))

    # 3) eliminaciones
    for item in sorted(mapeo.get("eliminar_filas", []),
                       key=lambda x: x["tabla"], reverse=True):
        if item["tabla"] < len(doc.tables):
            elimina_filas(doc, item["tabla"], item.get("filas", []))
            print("Tabla %d: eliminadas las filas %s" % (item["tabla"], item.get("filas")))
        else:
            avisos.append("No existe la tabla %d (eliminar_filas)" % item["tabla"])

    a_eliminar = set(int(t) for t in mapeo.get("eliminar_tablas", []))
    if mapeo.get("eliminar_tablas_sin_escribir") and not solo_estructura:
        vacias = set(range(len(doc.tables))) - tablas_escritas
        if vacias:
            print("Tablas sin contenido escrito: %s" % sorted(vacias))
        a_eliminar |= vacias

    for ti in sorted(a_eliminar, reverse=True):
        if ti < len(doc.tables):
            elimina_tabla(doc, ti)
            print("Tabla %d eliminada" % ti)
        else:
            avisos.append("No existe la tabla %d (eliminar_tablas)" % ti)

    if previsualizar:
        print("\n[previsualización] no se ha guardado ningún fichero.")
    else:
        salida.parent.mkdir(parents=True, exist_ok=True)
        doc.save(salida)
        print("\nGenerado: %s  (%d celdas escritas)" % (salida, escritas))

    for a in avisos:
        print("AVISO: " + a)

    if con_mapa and not previsualizar:
        print("\n--- MAPA DEL DOCUMENTO RESULTANTE ---")
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        from analizar_plantilla import analiza_docx
        analiza_docx(salida, 70)


if __name__ == "__main__":
    main()
