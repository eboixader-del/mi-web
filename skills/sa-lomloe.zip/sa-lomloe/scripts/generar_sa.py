# -*- coding: utf-8 -*-
"""
Genera un documento de Situación de Aprendizaje en .docx cuando el centro NO
tiene plantilla propia (o solo la tiene en PDF/papel y hay que reproducirla).

El documento sale con los ocho apartados estándar:

    1. Identificación
    2. Contextualización y justificación
    3. Concreción curricular
    4. Producto final y reto
    5. Metodología y secuencia de actividades
    6. Evaluación
    7. Medidas de respuesta a la diversidad y DUA
    8. Evaluación de la práctica docente   (se omite si viene vacío)

Si el centro sí tiene su plantilla en .docx, usa `analizar_plantilla.py` y
`rellenar_plantilla.py`: conservan el formato oficial del centro.

Uso:
    python generar_sa.py datos_sa.json [carpeta_salida]

El esquema del JSON está en `references/esquema-datos-sa.md`. Para poner el
logotipo y el nombre del centro en la cabecera, añade al JSON:

    "centro": { "nombre": "CEIP Ejemplo", "logo": "ruta/al/logo.png" }

Requisitos: pip install python-docx
"""
import json
import re
import sys
import unicodedata
from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

# Paleta: cámbiala aquí si quieres acercarte al diseño del centro.
AZUL = RGBColor(0x1F, 0x38, 0x64)
GRIS_TEXTO = RGBColor(0x59, 0x59, 0x59)
CABECERA = "1F3864"      # fondo de los títulos de apartado
ETIQUETA = "D9E2F3"      # fondo de las etiquetas de campo
ACENTO = "C5E0B3"        # fondo de cabeceras de tabla secundarias
SUAVE = "F2F2F2"
BLANCO = RGBColor(0xFF, 0xFF, 0xFF)
ANCHO_UTIL = 18.0        # cm de ancho útil en A4 vertical con márgenes de 1,5 cm


# --------------------------------------------------------------------------
# utilidades de formato
# --------------------------------------------------------------------------
def sombrea(celda, color_hex):
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), color_hex)
    celda._tc.get_or_add_tcPr().append(shd)


def bordes(tabla, color="8FAADC", tam="4"):
    tblPr = tabla._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for lado in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement("w:" + lado)
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), tam)
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), color)
        borders.append(el)
    tblPr.append(borders)


def ancho(celda, cm):
    celda.width = Cm(cm)
    tcPr = celda._tc.get_or_add_tcPr()
    tcW = tcPr.find(qn("w:tcW"))
    if tcW is None:
        tcW = OxmlElement("w:tcW")
        tcPr.append(tcW)
    tcW.set(qn("w:w"), str(int(cm * 567)))
    tcW.set(qn("w:type"), "dxa")


def escribe(celda, texto, negrita=False, centrado=False, tam=9, color=None):
    celda.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    p = celda.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER if centrado else WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.space_before = Pt(2)
    for i, linea in enumerate(str(texto).split("\n")):
        if i:
            p = celda.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if centrado else WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.space_after = Pt(2)
        r = p.add_run(linea)
        r.font.size = Pt(tam)
        r.font.name = "Calibri"
        r.bold = negrita
        if color:
            r.font.color.rgb = color


def celda(tabla, fila, col, texto="", relleno=None, negrita=False, centrado=False,
          tam=9, color=None):
    c = tabla.cell(fila, col)
    escribe(c, texto, negrita=negrita, centrado=centrado, tam=tam, color=color)
    if relleno:
        sombrea(c, relleno)
    return c


def lista(valor, vineta="• "):
    """Acepta str o list y devuelve texto con saltos de línea (viñetas si es lista)."""
    if valor is None:
        return ""
    if isinstance(valor, (list, tuple)):
        salida = []
        for v in valor:
            v = str(v).strip()
            if not v:
                continue
            salida.append(v if v.startswith(("•", "-", "–")) else vineta + v)
        return "\n".join(salida)
    return str(valor)


def texto_plano(valor):
    if isinstance(valor, (list, tuple)):
        return "\n".join(str(v) for v in valor)
    return "" if valor is None else str(valor)


def vacio(valor):
    return not str(texto_plano(valor)).strip()


def diseno_fijo(tabla, anchos):
    tblPr = tabla._tbl.tblPr
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    tblPr.append(layout)
    ind = OxmlElement("w:tblInd")
    ind.set(qn("w:w"), "0")
    ind.set(qn("w:type"), "dxa")
    tblPr.append(ind)
    grid = tabla._tbl.find(qn("w:tblGrid"))
    if grid is not None:
        for col, a in zip(grid.findall(qn("w:gridCol")), anchos):
            col.set(qn("w:w"), str(int(a * 567)))


def no_partir_filas(tabla):
    for fila in tabla.rows:
        trPr = fila._tr.get_or_add_trPr()
        trPr.append(OxmlElement("w:cantSplit"))


def tabla_nueva(doc, filas, cols, anchos=None):
    t = doc.add_table(rows=filas, cols=cols)
    t.autofit = False
    t.style = "Table Grid"
    bordes(t)
    if anchos:
        diseno_fijo(t, anchos)
        for f in t.rows:
            for c, a in zip(f.cells, anchos):
                ancho(c, a)
    no_partir_filas(t)
    return t


def apartado(doc, numero, titulo):
    """Barra de título de apartado, en una tabla de una celda con fondo."""
    t = tabla_nueva(doc, 1, 1, [ANCHO_UTIL])
    celda(t, 0, 0, str(numero) + ". " + titulo.upper(), CABECERA,
          negrita=True, tam=11, color=BLANCO)
    espacio(doc)
    return t


def espacio(doc, pt=4):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(pt)
    p.paragraph_format.space_before = Pt(0)
    for r in p.runs:
        r.font.size = Pt(2)
    return p


def subtitulo(doc, texto):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(texto)
    r.bold = True
    r.font.size = Pt(10)
    r.font.name = "Calibri"
    r.font.color.rgb = AZUL
    return p


def campos(doc, pares, ancho_etiqueta=5.0):
    """Tabla de dos columnas: etiqueta | contenido. Omite los pares vacíos."""
    pares = [(k, v) for k, v in pares if not vacio(v)]
    if not pares:
        return None
    anchos = [ancho_etiqueta, ANCHO_UTIL - ancho_etiqueta]
    t = tabla_nueva(doc, len(pares), 2, anchos)
    for i, (etiqueta, valor) in enumerate(pares):
        celda(t, i, 0, etiqueta, ETIQUETA, negrita=True)
        escribe(t.cell(i, 1), lista(valor))
    espacio(doc)
    return t


def documento(datos):
    centro = datos.get("centro") or {}
    ident = datos.get("identificacion", {})
    doc = Document()
    sec = doc.sections[0]
    sec.orientation = WD_ORIENT.PORTRAIT
    sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(1.5)
    sec.top_margin = Cm(1.2)
    sec.bottom_margin = Cm(1.2)
    sec.header_distance = Cm(0.6)

    cab = sec.header.paragraphs[0]
    cab.alignment = WD_ALIGN_PARAGRAPH.LEFT
    logo = centro.get("logo")
    if logo and Path(logo).exists():
        cab.add_run().add_picture(str(logo), width=Cm(3.0))
        cab.add_run("     ")
    r = cab.add_run("SITUACIÓN DE APRENDIZAJE")
    r.bold = True
    r.font.size = Pt(11)
    r.font.name = "Calibri"
    r.font.color.rgb = AZUL
    sufijo = []
    if centro.get("nombre"):
        sufijo.append(centro["nombre"])
    if ident.get("curso_academico"):
        sufijo.append("Curso " + str(ident["curso_academico"]))
    if sufijo:
        n = cab.add_run("     " + " · ".join(sufijo))
        n.font.size = Pt(9)
        n.font.name = "Calibri"
        n.font.color.rgb = GRIS_TEXTO

    estilo = doc.styles["Normal"]
    estilo.font.name = "Calibri"
    estilo.font.size = Pt(9)

    # Título de la SA
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(8)
    partes = []
    if ident.get("unidad_programacion"):
        partes.append("Unidad de programación " + str(ident["unidad_programacion"]))
    if ident.get("numero_sa"):
        partes.append("SA " + str(ident["numero_sa"]))
    if partes:
        r = p.add_run(" · ".join(partes) + "\n")
        r.font.size = Pt(9)
        r.font.color.rgb = GRIS_TEXTO
    r = p.add_run(ident.get("titulo", "Situación de aprendizaje"))
    r.bold = True
    r.font.size = Pt(16)
    r.font.color.rgb = AZUL
    return doc


# --------------------------------------------------------------------------
# apartados
# --------------------------------------------------------------------------
def ap1_identificacion(doc, datos):
    i = datos.get("identificacion", {})
    apartado(doc, 1, "Identificación")
    campos(doc, [
        ("Etapa", i.get("etapa")),
        ("Curso y grupo", i.get("curso_grupo")),
        ("Área / materia / ámbito / módulo", i.get("area")),
        ("Docentes", i.get("docentes")),
        ("Nº de sesiones", i.get("num_sesiones")),
        ("Temporalización", i.get("temporalizacion")),
        ("Lengua vehicular", i.get("lengua_vehicular")),
        ("Vinculación con otras áreas", i.get("vinculacion_otras_areas")),
    ], ancho_etiqueta=5.5)


def ap2_contexto(doc, datos):
    c = datos.get("contextualizacion", {})
    if not c:
        return
    apartado(doc, 2, "Contextualización y justificación")
    campos(doc, [
        ("La situación", c.get("situacion")),
        ("Reto / pregunta guía", c.get("reto")),
        ("Justificación", c.get("justificacion")),
        ("Conexión con el entorno", c.get("conexion_entorno")),
        ("Transversales", c.get("transversales")),
    ], ancho_etiqueta=5.5)

    ods = c.get("ods") or []
    if ods:
        subtitulo(doc, "Objetivos de Desarrollo Sostenible")
        t = tabla_nueva(doc, len(ods) + 1, 2, [5.5, ANCHO_UTIL - 5.5])
        celda(t, 0, 0, "ODS / META", ACENTO, negrita=True, centrado=True)
        celda(t, 0, 1, "CONCRECIÓN EN ESTA SA", ACENTO, negrita=True, centrado=True)
        for j, item in enumerate(ods, start=1):
            escribe(t.cell(j, 0), item.get("meta", ""), negrita=True)
            escribe(t.cell(j, 1), texto_plano(item.get("concrecion", "")))
        espacio(doc)


def ap3_curriculo(doc, datos):
    cc = datos.get("concrecion_curricular", {})
    comps = cc.get("competencias") or []
    if not comps:
        return
    apartado(doc, 3, "Concreción curricular")

    if cc.get("fuente"):
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(4)
        r = p.add_run("Fuente curricular: " + str(cc["fuente"]))
        r.font.size = Pt(8)
        r.italic = True
        r.font.color.rgb = GRIS_TEXTO
        if cc.get("literal") is False:
            r2 = p.add_run("  ·  Redacción orientativa: contrástese con el decreto autonómico "
                           "antes de entregar el documento.")
            r2.font.size = Pt(8)
            r2.italic = True
            r2.bold = True
            r2.font.color.rgb = GRIS_TEXTO

    for comp in comps:
        cod = comp.get("codigo", "")
        criterios = comp.get("criterios") or []
        anchos = [3.2, 6.4, 4.2, 4.2]

        t = tabla_nueva(doc, 2, 4, anchos)
        c = t.cell(0, 0).merge(t.cell(0, 3))
        escribe(c, ((cod + ". ") if cod else "") + comp.get("competencia", ""),
                negrita=True, tam=9.5)
        sombrea(c, ETIQUETA)
        celda(t, 1, 0, "CRITERIO", ACENTO, negrita=True, centrado=True, tam=8.5)
        celda(t, 1, 1, "TEXTO LITERAL", ACENTO, negrita=True, centrado=True, tam=8.5)
        celda(t, 1, 2, "EVIDENCIA EN ESTA SA", ACENTO, negrita=True, centrado=True, tam=8.5)
        celda(t, 1, 3, "INSTRUMENTO", ACENTO, negrita=True, centrado=True, tam=8.5)

        for cr in criterios:
            fila = t.add_row()
            for cc_, a in zip(fila.cells, anchos):
                ancho(cc_, a)
            escribe(fila.cells[0], cr.get("codigo", ""), centrado=True, negrita=True, tam=8.5)
            escribe(fila.cells[1], cr.get("texto", ""), tam=8.5)
            escribe(fila.cells[2], texto_plano(cr.get("evidencia", "")), tam=8.5)
            escribe(fila.cells[3], texto_plano(cr.get("instrumento", "")), tam=8.5)

        extras = [("Saberes básicos", comp.get("saberes")),
                  ("Descriptores del perfil de salida", comp.get("descriptores")),
                  ("Objetivos de etapa", comp.get("objetivos_etapa"))]
        for etiqueta, valor in extras:
            if vacio(valor):
                continue
            fila = t.add_row()
            for cc_, a in zip(fila.cells, anchos):
                ancho(cc_, a)
            izq = fila.cells[0]
            escribe(izq, etiqueta, negrita=True, tam=8.5)
            sombrea(izq, SUAVE)
            der = fila.cells[1].merge(fila.cells[3])
            escribe(der, lista(valor), tam=8.5)
        no_partir_filas(t)
        espacio(doc)

    if not vacio(cc.get("justificacion_competencial")):
        subtitulo(doc, "Contribución al desarrollo competencial del alumnado")
        p = doc.add_paragraph(texto_plano(cc["justificacion_competencial"]))
        p.paragraph_format.space_after = Pt(6)


def ap4_producto(doc, datos):
    pf = datos.get("producto_final", {})
    if not pf:
        return
    apartado(doc, 4, "Producto final y reto")
    campos(doc, [
        ("Producto final", pf.get("descripcion")),
        ("Audiencia", pf.get("audiencia")),
        ("Formato y condiciones", pf.get("formato_condiciones")),
        ("Difusión", pf.get("difusion")),
    ], ancho_etiqueta=5.5)


def ap5_secuencia(doc, datos):
    met = datos.get("metodologia", {})
    sec = datos.get("secuencia") or []
    if not met and not sec:
        return
    apartado(doc, 5, "Metodología y secuencia de actividades")

    campos(doc, [
        ("Modelos de enseñanza", met.get("modelos")),
        ("Metodologías", met.get("metodologias")),
        ("Técnicas didácticas", met.get("tecnicas")),
        ("Agrupamientos", met.get("agrupamientos")),
        ("Espacios", met.get("espacios")),
        ("Distribución del tiempo", met.get("tiempos")),
        ("Recursos y materiales", met.get("recursos")),
    ], ancho_etiqueta=5.5)

    if not sec:
        return
    subtitulo(doc, "Secuencia de actividades")
    anchos = [1.1, 2.6, 6.3, 2.6, 2.7, 2.7]
    t = tabla_nueva(doc, 1, 6, anchos)
    for j, texto in enumerate(["Nº", "FASE", "QUÉ HACE EL ALUMNADO",
                               "AGRUPAMIENTO / ESCENARIO", "RECURSOS",
                               "EVIDENCIA Y EVALUACIÓN"]):
        celda(t, 0, j, texto, ACENTO, negrita=True, centrado=True, tam=8.5)
    for i, s in enumerate(sec, start=1):
        fila = t.add_row()
        for c_, a in zip(fila.cells, anchos):
            ancho(c_, a)
        n = str(s.get("n", i))
        ses = str(s.get("sesiones", "") or "")
        escribe(fila.cells[0], n + ("\n(" + ses + ")" if ses and ses != "1" else ""),
                centrado=True, negrita=True, tam=8.5)
        escribe(fila.cells[1], s.get("fase", ""), tam=8.5)
        cuerpo = texto_plano(s.get("actividad", ""))
        titulo = s.get("titulo")
        escribe(fila.cells[2], ((titulo + "\n") if titulo else "") + cuerpo, tam=8.5)
        if titulo and fila.cells[2].paragraphs[0].runs:
            fila.cells[2].paragraphs[0].runs[0].bold = True
        agr = " / ".join(x for x in [texto_plano(s.get("agrupamiento", "")),
                                     texto_plano(s.get("escenario", ""))] if x)
        escribe(fila.cells[3], agr, tam=8.5)
        escribe(fila.cells[4], lista(s.get("recursos", "")), tam=8.5)
        ev = [x for x in [texto_plano(s.get("evidencia", "")),
                          texto_plano(s.get("evaluacion", ""))] if x]
        escribe(fila.cells[5], "\n".join(ev), tam=8.5)
    no_partir_filas(t)
    espacio(doc)


def ap6_evaluacion(doc, datos):
    ev = datos.get("evaluacion", {})
    if not ev:
        return
    apartado(doc, 6, "Evaluación")
    campos(doc, [
        ("Evaluación inicial / diagnóstica", ev.get("diagnostica")),
        ("Evaluación formativa", ev.get("formativa")),
        ("Evaluación sumativa", ev.get("sumativa")),
        ("Recuperación y mejora", ev.get("recuperacion")),
    ], ancho_etiqueta=5.5)

    crit = ev.get("criterios_calificacion") or []
    if crit:
        subtitulo(doc, "Criterios de calificación")
        anchos = [5.6, 5.0, 3.4, 4.0]
        t = tabla_nueva(doc, len(crit) + 2, 4, anchos)
        for j, texto in enumerate(["INSTRUMENTO", "CRITERIOS ASOCIADOS", "MOMENTO", "PESO (%)"]):
            celda(t, 0, j, texto, ACENTO, negrita=True, centrado=True, tam=8.5)
        for j, item in enumerate(crit, start=1):
            escribe(t.cell(j, 0), item.get("instrumento", ""), tam=8.5)
            escribe(t.cell(j, 1), texto_plano(item.get("criterios", "")), tam=8.5)
            escribe(t.cell(j, 2), item.get("momento", ""), centrado=True, tam=8.5)
            escribe(t.cell(j, 3), str(item.get("peso", "")), centrado=True, negrita=True, tam=8.5)
        ultima = len(crit) + 1
        c = t.cell(ultima, 0).merge(t.cell(ultima, 2))
        escribe(c, "TOTAL", negrita=True, centrado=True, tam=8.5)
        sombrea(c, SUAVE)
        escribe(t.cell(ultima, 3), str(suma_pesos(crit)), negrita=True, centrado=True, tam=8.5)
        sombrea(t.cell(ultima, 3), SUAVE)
        espacio(doc)

    rub = ev.get("rubrica") or {}
    indicadores = rub.get("indicadores") or []
    if indicadores:
        subtitulo(doc, "Rúbrica del producto final" +
                  ((": " + rub["titulo"]) if rub.get("titulo") else ""))
        niveles = rub.get("escala") or ["1 · En inicio", "2 · En desarrollo",
                                        "3 · Adquirido", "4 · Avanzado"]
        cols = 2 + len(niveles)
        ancho_niv = (ANCHO_UTIL - 4.4 - 1.4) / len(niveles)
        anchos = [4.4] + [ancho_niv] * len(niveles) + [1.4]
        t = tabla_nueva(doc, len(indicadores) + 1, cols, anchos)
        celda(t, 0, 0, "INDICADOR DE LOGRO", ACENTO, negrita=True, centrado=True, tam=8.5)
        for j, niv in enumerate(niveles, start=1):
            celda(t, 0, j, niv, ACENTO, negrita=True, centrado=True, tam=8)
        celda(t, 0, cols - 1, "PESO", ACENTO, negrita=True, centrado=True, tam=8.5)
        for j, ind in enumerate(indicadores, start=1):
            cabeza = ind.get("indicador", "")
            if ind.get("criterio"):
                cabeza = "[" + str(ind["criterio"]) + "] " + cabeza
            escribe(t.cell(j, 0), cabeza, tam=8.5)
            for k, desc in enumerate(ind.get("niveles") or [], start=1):
                if k < cols - 1:
                    escribe(t.cell(j, k), desc, tam=8)
            escribe(t.cell(j, cols - 1), str(ind.get("peso", "")), centrado=True,
                    negrita=True, tam=8.5)
        no_partir_filas(t)
        espacio(doc)


def ap7_diversidad(doc, datos):
    div = datos.get("diversidad", {})
    if not div:
        return
    apartado(doc, 7, "Respuesta a la diversidad y DUA")
    dua = div.get("dua") or {}
    filas = [("Múltiples formas de REPRESENTACIÓN (el qué)", dua.get("representacion")),
             ("Múltiples formas de IMPLICACIÓN (el porqué)", dua.get("implicacion")),
             ("Múltiples formas de ACCIÓN Y EXPRESIÓN (el cómo)", dua.get("accion_expresion"))]
    filas = [f for f in filas if not vacio(f[1])]
    if filas:
        anchos = [5.5, ANCHO_UTIL - 5.5]
        t = tabla_nueva(doc, len(filas) + 1, 2, anchos)
        celda(t, 0, 0, "PRINCIPIO DUA", ACENTO, negrita=True, centrado=True)
        celda(t, 0, 1, "MEDIDAS CONCRETAS EN ESTA SA", ACENTO, negrita=True, centrado=True)
        for j, (nombre, contenido) in enumerate(filas, start=1):
            celda(t, j, 0, nombre, SUAVE, negrita=True)
            escribe(t.cell(j, 1), lista(contenido))
        espacio(doc)

    campos(doc, [
        ("Alumnado NEAE", div.get("neae")),
        ("Refuerzo y apoyo", div.get("refuerzo")),
        ("Profundización y enriquecimiento", div.get("profundizacion")),
        ("Otras medidas", div.get("otras")),
    ], ancho_etiqueta=5.5)


def ap8_practica(doc, datos):
    pd = datos.get("practica_docente") or {}
    if all(vacio(pd.get(k)) for k in ("diseno", "implementacion", "mejora")):
        return
    apartado(doc, 8, "Evaluación de la práctica docente")
    campos(doc, [
        ("Valoración del diseño", pd.get("diseno")),
        ("Valoración de la implementación", pd.get("implementacion")),
        ("Propuestas de mejora", pd.get("mejora")),
    ], ancho_etiqueta=5.5)


def referencias(doc, datos):
    ref = datos.get("referencias") or {}
    if all(vacio(ref.get(k)) for k in ("bibliografia", "web")):
        return
    subtitulo(doc, "Referencias y recursos")
    campos(doc, [
        ("Bibliografía", ref.get("bibliografia")),
        ("Recursos web", ref.get("web")),
    ], ancho_etiqueta=5.5)


# --------------------------------------------------------------------------
# comprobaciones
# --------------------------------------------------------------------------
def numero(valor):
    m = re.search(r"(\d+(?:[.,]\d+)?)", str(valor))
    return float(m.group(1).replace(",", ".")) if m else None


def suma_pesos(items):
    total = 0.0
    for item in items:
        n = numero(item.get("peso", ""))
        if n is not None:
            total += n
    return int(total) if abs(total - round(total)) < 0.01 else round(total, 2)


def comprobaciones(datos):
    avisos = []
    ev = datos.get("evaluacion", {}) or {}

    crit = ev.get("criterios_calificacion") or []
    if crit:
        total = suma_pesos(crit)
        if abs(float(total) - 100) > 0.5:
            avisos.append("Los criterios de calificación suman " + str(total) +
                          " % (deberían sumar 100 %).")

    indicadores = (ev.get("rubrica") or {}).get("indicadores") or []
    pesos_ind = [i for i in indicadores if numero(i.get("peso", "")) is not None]
    if pesos_ind:
        total = suma_pesos(indicadores)
        if abs(float(total) - 100) > 0.5:
            avisos.append("Los pesos de la rúbrica suman " + str(total) +
                          " % (deberían sumar 100 %).")

    sec = datos.get("secuencia") or []
    total_ses = 0
    for s in sec:
        n = numero(s.get("sesiones", 1)) if s.get("sesiones") else 1
        total_ses += int(n or 1)
    declaradas = numero((datos.get("identificacion") or {}).get("num_sesiones", ""))
    if sec:
        avisos.append("Sesiones planificadas en la secuencia: " + str(total_ses) + ".")
        if declaradas is not None and abs(total_ses - declaradas) > 0.5:
            avisos.append("No coincide con las " + str(int(declaradas)) +
                          " sesiones declaradas en la identificación.")

    cc = datos.get("concrecion_curricular", {}) or {}
    comps = cc.get("competencias") or []
    if len(comps) > 4:
        avisos.append("Hay " + str(len(comps)) + " competencias específicas. Con más de 4 es muy "
                      "difícil evaluarlas todas: revisa si sobra alguna.")
    for comp in comps:
        for cr in comp.get("criterios") or []:
            cod = cr.get("codigo", "?")
            if vacio(cr.get("evidencia")):
                avisos.append("El criterio " + str(cod) + " no tiene evidencia asociada.")
            if vacio(cr.get("instrumento")):
                avisos.append("El criterio " + str(cod) + " no tiene instrumento de evaluación.")
    if cc.get("literal") is False:
        avisos.append("El currículo está marcado como redacción orientativa (literal: false): "
                      "avisa al docente de que debe contrastarlo con su decreto.")
    if not cc.get("fuente"):
        avisos.append("No se ha indicado la fuente curricular (concrecion_curricular.fuente).")
    return avisos


# --------------------------------------------------------------------------
def generar(datos, salida):
    doc = documento(datos)
    ap1_identificacion(doc, datos)
    ap2_contexto(doc, datos)
    ap3_curriculo(doc, datos)
    ap4_producto(doc, datos)
    ap5_secuencia(doc, datos)
    ap6_evaluacion(doc, datos)
    ap7_diversidad(doc, datos)
    ap8_practica(doc, datos)
    referencias(doc, datos)
    doc.save(str(salida))
    return salida


def nombre_fichero(datos):
    ident = datos.get("identificacion", {})
    titulo = ident.get("titulo") or "situacion-de-aprendizaje"
    titulo = unicodedata.normalize("NFKD", titulo).encode("ascii", "ignore").decode()
    titulo = re.sub(r"[^A-Za-z0-9]+", "-", titulo).strip("-")[:60]
    num = ident.get("numero_sa")
    return "SA" + (str(num) + "_" if num else "_") + (titulo or "sin-titulo") + ".docx"


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    origen = Path(sys.argv[1])
    destino = Path(sys.argv[2]) if len(sys.argv) > 2 else origen.parent
    destino.mkdir(parents=True, exist_ok=True)
    datos = json.loads(origen.read_text(encoding="utf-8"))

    salida = generar(datos, destino / nombre_fichero(datos))
    print("Generado: " + str(salida))
    avisos = comprobaciones(datos)
    if avisos:
        print("")
        for aviso in avisos:
            print("AVISO: " + aviso)


if __name__ == "__main__":
    main()
