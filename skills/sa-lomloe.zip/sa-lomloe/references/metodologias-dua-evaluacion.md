# Catálogo didáctico: modelos, metodologías, DUA, evaluación y ODS

Repertorio para rellenar con coherencia los apartados de metodología, secuencia y diversidad de la
SA. Elige siempre la opción que encaje con lo que realmente hace el alumnado en esa sesión, no la
que suene mejor en el documento.

Los ejemplos están redactados en clave de Secundaria. Para **Infantil y Primaria**, traduce:
propuestas, rincones, talleres, asambleas, juego simbólico, ambientes, aprendizaje globalizado y
documentación pedagógica. Para **FP**, traduce: unidades de trabajo, encargos y simulaciones del
entorno productivo, prácticas de taller, proyectos intermodulares y evaluación por resultados de
aprendizaje.

## Modelos de enseñanza (columna «MODELO DE ENSEÑANZA»)

| Modelo | Cuándo usarlo |
| --- | --- |
| Enseñanza directiva | Modelado de un procedimiento paso a paso con práctica guiada |
| Organizadores previos | Presentación estructurada de conceptos nuevos anclados en lo que ya se sabe |
| Formación de conceptos | El alumnado clasifica ejemplos y contraejemplos hasta definir el concepto |
| Inductivo básico | De la observación de casos a la generalización |
| Indagación / Investigación experimental | Preguntas investigables, hipótesis, datos y conclusiones |
| Investigación grupal | Reparto de subtemas, indagación por equipos y puesta en común |
| Memorístico | Automatización de vocabulario, símbolos, fórmulas o léxico |
| Sinéctico | Creatividad por analogías y metáforas |
| Simulación / Juego de roles | Reproducción de un escenario profesional o social |
| Enseñanza no directiva | Acompañamiento de procesos de reflexión, debate o metacognición |

## Metodologías (columna «METODOLOGÍA»)

Aprendizaje basado en proyectos (ABP) · Aprendizaje basado en problemas · Aprendizaje basado en
retos · Aprendizaje-servicio (ApS) · Aprendizaje cooperativo (folio giratorio, 1-2-4, lápices al
centro, rompecabezas/jigsaw, parada de tres minutos) · Gamificación y aprendizaje basado en juegos ·
Flipped classroom · Estudio de caso · Debate académico y controversia estructurada · Rutinas y
destrezas de pensamiento · Trabajo por rincones o estaciones de aprendizaje · Aprendizaje basado en
el pensamiento computacional · Design thinking · Aula invertida con práctica deliberada ·
Evaluación formativa y metacognición.

## Organización del aula (agrupamientos)

Individual · Parejas (tutoría entre iguales) · Equipos cooperativos de 3-4 (roles: coordinación,
secretaría, portavocía, control del tiempo y materiales) · Grupos flexibles por nivel de apoyo ·
Grupos de expertos (jigsaw) · Gran grupo · Trabajo en red con otras aulas o centros.

## Escenarios

Aula ordinaria · Laboratorio · Taller · Aula de informática · Biblioteca · Gimnasio o pistas ·
Salón de actos · Patio · Entorno próximo (barrio, empresa, museo, centro de salud, ayuntamiento) ·
Entorno virtual (aula virtual, foro, documento colaborativo) · Espacio de exposición pública.

## Instrumentos de evaluación

| Instrumento | Uso habitual | Momento |
| --- | --- | --- |
| Prueba objetiva / escrita | Saberes básicos conceptuales y procedimentales | Mitad y/o final |
| Rúbrica del producto final | Tarea integradora | Final |
| Rúbrica o lista de cotejo de entregas parciales | Andamiaje del producto | Durante |
| Cuaderno o diario de aprendizaje | Proceso, metacognición | Continuo |
| Escala de observación | Debates, prácticas, trabajo en equipo | Durante |
| Diana de autoevaluación | Autorregulación del alumnado | Cierre |
| Coevaluación entre iguales | Producciones de otros equipos | Aplicación/cierre |
| Portfolio | Evidencias seleccionadas por el propio alumnado | Final |
| Exposición oral / defensa | Comunicación y argumentación | Final |

**Reglas de ponderación:** todo criterio de evaluación seleccionado debe tener al menos un
instrumento; ningún instrumento sin criterio asociado; el conjunto suma 100 %; conviene que el
producto final no baje del 30 % ni supere el 60 %, y reservar un 10-20 % a evaluación formativa
(entregas parciales, coevaluación, autoevaluación).

## DUA (Diseño Universal para el Aprendizaje, CAST 3.0)

**Múltiples formas de REPRESENTACIÓN (el qué)**
Ofrecer la información en varios formatos (texto, audio, vídeo con subtítulos, esquema, maqueta);
glosarios e ilustraciones de vocabulario clave; organizadores gráficos; activación de conocimientos
previos; materiales accesibles (tipografía, contraste, lectura fácil, lengua de signos).

**Múltiples formas de IMPLICACIÓN (el porqué)**
Contexto real y audiencia auténtica; posibilidad de elección (tema, formato, rol, compañeros);
objetivos y rúbricas conocidos desde el inicio; retos ajustados al nivel con apoyo variable;
rutinas de autorregulación y gestión emocional; retroalimentación frecuente orientada a la mejora.

**Múltiples formas de ACCIÓN Y EXPRESIÓN (el cómo)**
Varias vías para demostrar el aprendizaje (escrito, oral, audiovisual, gráfico, manipulativo);
plantillas y andamiajes (guiones, bancos de conectores, ejemplos resueltos); herramientas de apoyo
(conversor voz-texto, calculadora, traductor, corrector); tiempos y extensiones flexibles;
descomposición de la tarea en hitos con listas de comprobación.

## Atención a la diversidad

- **Refuerzo y apoyo**: guiones pautados, modelos resueltos, reducción de la extensión (nunca de los
  criterios), tutoría entre iguales, apoyo del profesorado de PT/AL dentro del aula, materiales de
  lectura fácil, priorización de saberes imprescindibles.
- **Profundización y enriquecimiento (altas capacidades)**: ampliación con datos o fuentes
  adicionales, roles de coordinación o mentoría, productos con mayor exigencia de abstracción o de
  transferencia, conexión con expertos externos, retos abiertos de investigación.
- **Alumnado con desconocimiento de la lengua vehicular**: apoyo visual, vocabulario clave
  anticipado, producciones bilingües, compañero-guía.

## ODS y valores

Vincula siempre **metas concretas**, no el objetivo entero. Metas de uso frecuente en Secundaria:

| ODS | Metas útiles |
| --- | --- |
| 3 Salud y bienestar | 3.3 enfermedades transmisibles · 3.4 salud mental · 3.5 adicciones · 3.6 seguridad vial |
| 4 Educación de calidad | 4.7 educación para el desarrollo sostenible y la ciudadanía mundial |
| 5 Igualdad de género | 5.1 discriminación · 5.2 violencia · 5.5 participación |
| 6 Agua limpia | 6.3 calidad del agua · 6.4 uso eficiente |
| 7 Energía asequible | 7.2 renovables · 7.3 eficiencia energética |
| 8 Trabajo decente | 8.5 empleo pleno · 8.6 jóvenes que no estudian ni trabajan |
| 10 Reducción de desigualdades | 10.2 inclusión social · 10.3 igualdad de oportunidades |
| 11 Ciudades sostenibles | 11.2 movilidad · 11.6 calidad del aire y residuos · 11.7 espacios públicos |
| 12 Producción y consumo | 12.3 desperdicio alimentario · 12.5 reducción de residuos · 12.8 consumo consciente |
| 13 Acción por el clima | 13.1 resiliencia · 13.3 educación y sensibilización climática |
| 14 / 15 Vida submarina y terrestre | 14.1 contaminación marina · 15.5 biodiversidad |
| 16 Paz y justicia | 16.3 estado de derecho · 16.7 participación · 16.10 acceso a la información |

**Pensamiento crítico**: contraste de fuentes, detección de sesgos y desinformación, argumentación
con evidencias, deliberación democrática y valoración ética de las soluciones propuestas.
