# Cómo anclar la SA al currículo correcto

Las competencias específicas, los criterios de evaluación, los saberes básicos y los resultados de
aprendizaje son **texto normativo**: cambian según la etapa y la comunidad autónoma, y el docente
los va a incorporar a un documento oficial de centro. Esta habilidad **no incluye ningún currículo
concreto**, así que la fuente se resuelve al principio del proceso, en la Fase 0.

## Qué está incluido y qué no

| Elemento | Disponible aquí | Ámbito |
| --- | --- | --- |
| Competencias clave y descriptores operativos del Perfil de salida (final de la enseñanza básica) | Sí, `perfil-de-salida.md` | Estatal, idéntico en toda España |
| Descriptores operativos de final de 6.º de Primaria | No | Estatal (RD 157/2022, Anexo I) |
| Descriptores operativos de Bachillerato | No | Estatal (RD 243/2022, Anexo I) |
| Objetivos de etapa | No | Estatal, con matices autonómicos |
| Competencias específicas por área/materia | **No** | Autonómico |
| Criterios de evaluación por curso | **No** | Autonómico |
| Saberes básicos y sus bloques | **No** | Autonómico |
| Resultados de aprendizaje de FP | **No** | Estatal por título + desarrollo autonómico |

## Qué preguntar al docente

En el mensaje único de la Fase 0, junto a la etapa y el área:

> ¿En qué comunidad autónoma trabajas? Y si tienes a mano el decreto de currículo, la programación
> de tu departamento o ciclo, o simplemente las páginas de tu área con las competencias específicas
> y los criterios de evaluación, adjúntalo: así cito el texto literal en vez de una redacción
> aproximada.

## Opciones, de mejor a peor

1. **El docente adjunta el decreto autonómico en PDF.** Extrae el currículo por áreas:

   ```bash
   python scripts/extraer_curriculo.py DECRETO.pdf references/curriculo-<comunidad>
   ```

   El script localiza cada materia por el epígrafe «1. Presentación», guarda un `.md` por materia
   conservando las tablas de criterios (una columna por curso) y escribe un `INDICE.md`. Está
   pensado para la maquetación habitual de los boletines autonómicos; si no detecta materias, avisa
   en lugar de inventar. Después usa Grep/Read sobre esos ficheros para citar literal.

2. **El docente adjunta su programación de departamento, de ciclo o las páginas de su área.**
   Trabaja directamente sobre ese documento: es la fuente que su centro considera válida.

3. **No hay documento.** Entonces:
   - Usa el **real decreto estatal de enseñanzas mínimas** de la etapa como referencia (ver tabla
     de abajo): los currículos autonómicos parten de ahí, aunque cada comunidad los reordena,
     renumera y amplía.
   - **Avísalo explícitamente**, con una frase como: «He redactado las competencias específicas y
     los criterios a partir del currículo estatal; antes de entregar el documento, compruébalos con
     el decreto de tu comunidad, porque la numeración y la redacción pueden cambiar».
   - Nunca presentes esa redacción como cita literal del decreto autonómico.

## Marco normativo estatal por etapa

| Etapa | Norma estatal de referencia | Elementos curriculares |
| --- | --- | --- |
| Infantil | RD 95/2022 | Áreas, competencias específicas, criterios de evaluación, saberes básicos. **No hay perfil de salida** |
| Primaria | RD 157/2022 | Áreas, competencias específicas, criterios por ciclo, saberes básicos, descriptores operativos a final de 6.º |
| ESO | RD 217/2022 | Materias y ámbitos, competencias específicas, criterios por curso, saberes básicos, Perfil de salida |
| Bachillerato | RD 243/2022 | Materias, competencias específicas, criterios, saberes básicos, descriptores propios de la etapa |
| FP | LO 3/2022 y su desarrollo reglamentario, más el RD de cada título | Módulos profesionales, **resultados de aprendizaje**, criterios de evaluación, contenidos, competencias profesionales, personales y sociales |
| Personas adultas | Normativa autonómica de EPA sobre la base de los RD anteriores | Currículo modularizado por ámbitos |

Confirma siempre con el docente la norma vigente en su comunidad: las órdenes autonómicas de
ordenación y evaluación se actualizan con frecuencia y son las que fijan el formato del documento
de SA.

## Adaptación de la terminología

Habla el idioma de la etapa del docente. Usar «materia» en Infantil o «competencia específica» en
FP delata que la SA está copiada de otra etapa.

| Etapa | Se dice | No se dice |
| --- | --- | --- |
| Infantil | Área, propuesta, experiencia, rincón, taller, asamblea; documentación pedagógica | Sesión magistral, examen |
| Primaria | Área, ciclo, sesión, tarea; equipo docente de ciclo | Materia, departamento |
| ESO / Bachillerato | Materia, ámbito, sesión, departamento | Asignatura, temario |
| FP | Módulo profesional, resultado de aprendizaje, unidad de trabajo, encargo, entorno productivo | Competencia específica, saber básico |

## Coherencia interna

Sea cual sea la fuente:

- Los criterios de evaluación son **los del curso o ciclo** que se programa, no los de otro curso
  de la misma área.
- Cada criterio se cita con su numeración original (`1.2`, `3.4`, `RA2 c)`…) y se mantiene el
  código de la competencia específica o del resultado de aprendizaje tal como aparece en la fuente.
- Los saberes básicos se citan indicando su bloque (`Bloque A`, `Bloque 2`, según la fuente).
- Si el currículo indica, junto a cada competencia específica, los descriptores del Perfil de
  salida que desarrolla, **úsalo**: es la vinculación oficial y evita cruces arbitrarios.
- En Infantil no fuerces un perfil de salida que no existe: vincula con los objetivos de etapa y
  con las competencias clave adaptadas que recoja su normativa.
