# Evaluación de la Situación de Aprendizaje

La evaluación se diseña **antes que la secuencia**. Es la parte que más se improvisa y la que más
problemas da después, en las sesiones de evaluación y en las reclamaciones.

## 1. Regla de oro

> Se evalúa por **criterios de evaluación**, no por instrumentos ni por actividades.

De ahí salen tres comprobaciones que hay que hacer siempre:

1. **Todo criterio seleccionado tiene al menos un instrumento** que recoge evidencia de él.
2. **Todo instrumento evalúa criterios identificados**, no «el trabajo en general».
3. **Los pesos suman 100 %.**

## 2. Los tres momentos

### Evaluación inicial o diagnóstica

No es una nota. Es información para decidir. Al empezar la SA:

* Qué se explora: ideas previas sobre el reto, saberes de partida, experiencias del alumnado con el
  contexto, competencias de trabajo en equipo o digitales que la SA va a exigir.
* Con qué: lluvia de ideas registrada, cuestionario breve, rutina de pensamiento («veo–pienso–me
  pregunto», «antes pensaba / ahora pienso»), diana de autopercepción, prueba de nivel corta.
* **Qué se hace con el resultado**: es la pregunta que casi nunca se responde. Escríbelo: qué
  grupos se forman, qué andamiaje se prepara, qué se recorta o se amplía.

### Evaluación formativa

El corazón de la SA. Requisitos mínimos:

* **Al menos un hito intermedio** con entrega y **retroalimentación antes de la nota**. La
  retroalimentación se describe: quién la da, en qué formato, con qué instrumento y cuándo puede
  el alumnado incorporarla.
* **Al menos una autoevaluación o coevaluación** con su instrumento propio (rúbrica simplificada,
  lista de cotejo, diana, protocolo de comentario entre iguales tipo «dos estrellas y un deseo»).
* La **rúbrica del producto final compartida desde el principio**, en la sesión 1 o 2, y a poder
  ser comentada o negociada con el alumnado.

### Evaluación sumativa

Recoge lo que el alumnado ha llegado a demostrar. En una SA suele repartirse entre:

* el **producto final** (rúbrica);
* las **evidencias del proceso** (entregas parciales, cuaderno de equipo, diario de aprendizaje);
* una **prueba individual** cuando el criterio lo exige o cuando el producto es de equipo y hace
  falta evidencia individual;
* la **comunicación o defensa** del producto ante su audiencia.

## 3. Instrumentos

| Instrumento | Qué evalúa bien | Momento |
| --- | --- | --- |
| Rúbrica del producto final | Desempeños complejos e integrados | Final |
| Lista de cotejo | Requisitos que se cumplen o no (formato, elementos exigidos) | Durante y final |
| Escala de observación | Trabajo en equipo, práctica de taller o laboratorio, debate | Durante |
| Diario o cuaderno de aprendizaje | Proceso, dificultades, metacognición | Continuo |
| Portfolio con evidencias seleccionadas | Progreso y capacidad de justificar el propio aprendizaje | Final |
| Prueba objetiva o escrita | Saberes conceptuales y procedimentales concretos | Mitad y/o final |
| Exposición oral, defensa o entrevista | Comunicación, argumentación, dominio real del contenido | Final |
| Coevaluación entre equipos | Análisis crítico de producciones ajenas | Aplicación / cierre |
| Diana o cuestionario de autoevaluación | Autorregulación | Cierre de fase |
| Registro anecdótico y documentación pedagógica | Infantil y primeros ciclos: procesos difíciles de medir | Continuo |

Elige pocos y buenos. Cuatro instrumentos bien colocados evalúan mejor que ocho a medias.

## 4. Construir la rúbrica desde los criterios

Procedimiento:

1. Coge cada criterio de evaluación implicado en el producto final.
2. Tradúcelo a **uno o dos indicadores observables en este producto concreto**. El indicador
   menciona el producto: «el informe cita al menos tres fuentes y contrasta dos de ellas», no
   «utiliza fuentes».
3. Describe **cuatro niveles** en términos de hechos, cantidades o cualidades verificables. Prohíbe
   los adverbios como única diferencia entre niveles:

   | ✘ Mal | ✔ Bien |
   | --- | --- |
   | Cita fuentes adecuadamente | Cita 3 o más fuentes y contrasta al menos dos entre sí |
   | Cita fuentes correctamente | Cita 3 o más fuentes sin contrastarlas |
   | Cita fuentes con ayuda | Cita 1 o 2 fuentes |
   | Apenas cita fuentes | No cita fuentes o las cita sin identificar |

4. Asigna **peso a cada indicador** dentro del producto.
5. Escríbela en un lenguaje que el alumnado entienda: si no la entiende, no puede usarla para
   mejorar y deja de ser formativa.

Escalas habituales de cuatro niveles: *En inicio / En desarrollo / Adquirido / Avanzado*, o
*Insuficiente / Suficiente / Notable / Excelente*, o los descriptores propios del centro.

## 5. Criterios de calificación

Reparto orientativo, ajustable al área y al centro:

| Bloque | Peso orientativo |
| --- | --- |
| Producto final (rúbrica) | 30-50 % |
| Evidencias de proceso y entregas parciales | 20-30 % |
| Prueba o evidencia individual de saberes | 15-30 % |
| Comunicación o defensa | 10-20 % |
| Autoevaluación y coevaluación | 5-10 % |

Cautelas:

* Si el producto es de equipo, **debe existir alguna evidencia individual**, o la calificación no
  es defendible.
* No hagas depender más del 60 % de la nota de una sola entrega final.
* Comprueba la suma antes de generar el documento. Si no da 100, **dilo en la respuesta** en vez de
  dejarlo pasar.

## 6. Recuperación y mejora

Prevé por escrito qué ocurre con quien no alcanza los criterios: qué evidencia puede rehacer, con
qué plazo, con qué apoyo y si la nueva calificación sustituye o promedia. Es lo primero que
pregunta jefatura de estudios y lo que casi nunca aparece en el documento.

## 7. Evaluación de la práctica docente

Es el último apartado de la mayoría de plantillas y **se rellena después de implementar la SA**: qué
funcionó, qué no, qué evidencias lo indican y qué se cambia para el curso siguiente. Al diseñar la
SA se deja vacío. Puedes ofrecerle al docente tres preguntas para cuando la termine:

* ¿Qué actividad produjo más aprendizaje por minuto invertido, y cuál menos?
* ¿Qué medidas DUA usó realmente el alumnado y cuáles quedaron sin usar?
* ¿La rúbrica sirvió al alumnado para mejorar antes de la entrega, o solo al docente para poner nota?
