# Checklist de calidad de una Situación de Aprendizaje

Recórrela **siempre** antes de entregar el documento, y úsala también como guion en el «modo
revisión». Marca cada punto como **cumple / mejorable / no cumple** y, si no cumple, propón la
reescritura concreta.

## A · La situación y el reto

1. La situación es **real o verosímil** y el alumnado puede reconocerla en su entorno.
2. **Prueba del contexto**: si se elimina la situación, las actividades cambian. Si no cambian, no
   es una SA.
3. El reto está formulado como **una sola pregunta** que el alumnado podría repetir de memoria.
4. Hay al menos **una decisión real** en manos del alumnado.
5. El reto es abarcable con las sesiones y los recursos disponibles.

## B · Producto y audiencia

6. Hay un **producto final** concreto, con formato y condiciones definidas.
7. Tiene **audiencia fuera del aula** (o, como mínimo, fuera del grupo) y se dice **cómo llega** a
   ella.
8. Si el producto es de equipo, existe además **evidencia individual** de cada alumno.

## C · Concreción curricular

9. Hay entre **2 y 4 competencias específicas**, no más.
10. Competencias, criterios y saberes están **citados literalmente** de la fuente curricular, con su
    numeración, y la fuente está identificada.
11. Los criterios son **los del curso o ciclo** que se programa.
12. **Cada criterio tiene una evidencia concreta** en la SA. Ninguno queda de adorno.
13. Los descriptores del perfil de salida y los objetivos de etapa son los que el propio currículo
    asocia, no cruces arbitrarios.
14. Si algún texto curricular es redacción propia y no cita literal, **está advertido en la
    respuesta** al docente.

## D · Evaluación

15. Hay **evaluación inicial** y se dice **qué se hace** con su resultado.
16. Hay **al menos un hito intermedio con retroalimentación** antes de la calificación final.
17. Hay **al menos una autoevaluación o coevaluación**, con instrumento propio.
18. **Todo criterio tiene instrumento** y **todo instrumento tiene criterios** asociados.
19. La **rúbrica se deriva de los criterios**, menciona el producto concreto y sus niveles se
    distinguen por **hechos observables**, no por adverbios.
20. La rúbrica se comparte con el alumnado **al principio** de la SA.
21. Los **pesos de calificación suman 100 %** y ninguna evidencia única supera el 60 %.
22. Está previsto **qué se rehace** y cómo si no se alcanzan los criterios.

## E · Secuencia

23. La secuencia recorre las **fases de la SA**: activación, indagación, estructuración, aplicación,
    comunicación y reflexión.
24. Cada sesión describe **qué hace el alumnado**, no qué explica el docente.
25. Cada sesión indica agrupamiento, escenario, recursos y **qué evidencia deja**.
26. El **número de sesiones coincide** con el acordado en la Fase 0.
27. Hay **enseñanza explícita** de los saberes que el reto exige: la SA no consiste en dejar al
    alumnado a su aire.

## F · Diversidad y DUA

28. Las medidas DUA cubren **representación, implicación y acción/expresión**.
29. Cada medida está **anclada a una actividad y a un recurso concretos de esta SA**. Ninguna
    valdría igual para cualquier otra SA.
30. Hay medidas para el **alumnado NEAE concreto del grupo** descrito en la Fase 0.
31. Hay **profundización o enriquecimiento**, no solo refuerzo.

## G · Transversales y coherencia

32. Los **ODS** se vinculan a **metas concretas** («ODS 12 · meta 12.5»), no al objetivo entero.
33. La interdisciplinariedad, si la hay, **nombra el área y qué aporta**, y dice quién la imparte.
34. La terminología corresponde a la **etapa** (no «materia» en Infantil ni «saber básico» en FP).
35. La SA está escrita de modo que **otro docente del equipo podría implementarla** solo con el
    documento.

## H · Documento

36. El documento sigue la **plantilla del centro**, si la hay.
37. No quedan **avisos internos ni texto de ejemplo** de la plantilla.
38. Los bloques repetibles (sesiones, competencias, criterios) están **bien numerados** y no hay
    duplicados ni sobrantes vacíos por descuido.
39. El apartado de **evaluación de la práctica docente** se ha dejado vacío a propósito (salvo que
    el docente ya haya implementado la SA), y así se le ha dicho.
40. Se ha **abierto y revisado el fichero generado**, no solo generado.
