# El proceso de diseño, paso a paso

El diseño de una SA es **inverso**: se empieza por lo que el alumnado tendrá que demostrar y se
termina por cómo se le enseña. Diseñar la secuencia primero es lo que produce SA con actividades
bonitas y evaluación pegada con celo al final.

Orden correcto:

```
situación real → competencias y criterios → evidencias y producto → evaluación → secuencia → DUA
```

---

## Fase 0 · Encuadre

Objetivo: no diseñar a ciegas. Lo que hay que saber antes de proponer nada está en el protocolo de
`SKILL.md`. Tres avisos:

* **La comunidad autónoma no es un dato menor.** Cambia la numeración de los criterios, a veces su
  redacción y casi siempre la plantilla oficial.
* **Pregunta por el grupo, no solo por el curso.** Las medidas DUA y de diversidad se escriben para
  ese grupo concreto o no valen nada.
* **Si el docente no tiene claro el reto, no pasa nada.** Para eso está la Fase 1. Pero necesitas
  saber en qué momento del curso está y qué saberes toca.

## Fase 1 · La situación y el reto

Una buena situación tiene cuatro ingredientes:

1. **Un problema o necesidad auténtica**, no un ejercicio disfrazado. Fuentes fiables de retos: el
   propio centro (residuos, consumo eléctrico, convivencia, patios, ruido), el barrio o la
   localidad (accesibilidad, comercio, memoria oral, medioambiente), el entorno digital del
   alumnado (bulos, privacidad, algoritmos), la actualidad científica o social, y en FP, el
   encargo profesional realista.
2. **Un destinatario real** que va a recibir el producto. Es lo que convierte la tarea en algo que
   merece hacerse bien: familias, otro curso, el AMPA, el ayuntamiento, una asociación, una
   residencia, una empresa colaboradora, la web del centro, un medio local.
3. **Una decisión en manos del alumnado.** Si todo está decidido de antemano, es una ficha larga.
4. **Un producto abarcable** con el tiempo y los recursos disponibles.

Formula el reto como **pregunta guía** en segunda persona del plural y en una sola frase:
«¿Cómo podemos convencer al ayuntamiento de que instale…?», «¿Qué le contamos a las familias
sobre…?», «¿Cómo diseñamos un… que sirva para…?».

Ofrece **4 o 5 opciones variadas**, no cinco variantes de la misma: mezcla investigación,
divulgación, creación, servicio a la comunidad y simulación profesional.

## Fase 2 · Anclaje curricular

Trabaja **desde los criterios de evaluación**, no desde los saberes. Los criterios describen lo que
hay que ser capaz de hacer; los saberes son lo que hace falta saber para poder hacerlo.

Procedimiento:

1. Localiza en la fuente curricular las competencias específicas del área y curso (Grep/Read si
   tienes el fichero; lectura directa si el docente adjuntó su programación).
2. Elige **2-4** que la situación movilice de verdad. Descarta las que solo se rozan.
3. Baja a los **criterios de evaluación de ese curso** asociados a cada competencia. Cópialos
   literales, con su numeración.
4. Para cada criterio, escribe **qué evidencia lo demuestra en esta SA**. Si no se te ocurre
   ninguna, el criterio sobra (o falta una actividad).
5. Selecciona los **saberes básicos** que el reto exige, con su bloque. No copies el bloque entero:
   solo lo que se va a trabajar.
6. Recoge los **descriptores del perfil de salida** que el propio currículo asocia a cada
   competencia específica, y los **objetivos de etapa** a los que contribuye.

Comprobación: cada competencia específica seleccionada tiene al menos un criterio; cada criterio
tiene evidencia; cada saber básico se usa en alguna actividad.

## Fase 3 · Producto y evaluación

Detalle completo en `evaluacion-competencial.md`. El orden importa:

1. **Concreta el producto final** hasta que el alumnado pueda imaginarlo: formato, extensión,
   soporte, condiciones, fecha, audiencia, cómo se difunde.
2. **Deriva la rúbrica de los criterios de evaluación.** Cada indicador de la rúbrica debe poder
   trazarse hasta un criterio. Cuatro niveles, descritos con hechos observables.
3. **Coloca la evaluación formativa**: hitos con retroalimentación antes de la entrega. Como mínimo
   uno a mitad de la SA. Y una autoevaluación o coevaluación con su instrumento.
4. **Reparte los pesos** hasta sumar 100 %.
5. **Prevé la recuperación**: qué se rehace, cuándo y con qué apoyo.

## Fase 4 · Secuencia de actividades

Las seis fases de una SA, con lo que caracteriza a cada una:

| Fase | Qué ocurre | Señales de que está bien |
| --- | --- | --- |
| **Activación y contextualización** | Se presenta la situación, se activan ideas previas, se negocia el reto y se comparten los criterios de evaluación | El alumnado sabe qué va a producir y cómo se le va a valorar desde el primer día |
| **Indagación** | Búsqueda, entrevistas, experimentos, recogida y contraste de datos, salidas o visitas | Entra información de fuera del libro de texto |
| **Estructuración** | Se aprenden y organizan los saberes que el reto exige, con explicación, práctica y andamiaje | Hay enseñanza explícita: una SA no es dejar al alumnado solo |
| **Aplicación** | Se crea el producto por hitos, con retroalimentación | Hay borradores y mejora, no una entrega única |
| **Comunicación** | El producto llega a la audiencia | Alguien de fuera lo recibe, lo usa o responde |
| **Reflexión y transferencia** | Metacognición, autoevaluación, ¿dónde más sirve esto? | Se habla de cómo se ha aprendido, no solo de la nota |

Para cada sesión, define: número y fase; **qué hace el alumnado**; agrupamiento; escenario;
recursos; tiempo; **evidencia o producto parcial**; instrumento de evaluación que se activa.

Reparto orientativo del tiempo: activación 10 %, indagación 20 %, estructuración 30 %,
aplicación 25 %, comunicación 10 %, reflexión 5 %. Ajústalo al área y al reto; en FP y en las áreas
prácticas, aplicación y comunicación pesan más.

## Fase 5 · DUA y diversidad

Escribe cada medida **anclada a una actividad concreta**:

* «Representación: el vídeo de la sesión 3 se entrega también transcrito y con un glosario visual
  de los seis términos técnicos» ✔
* «Se ofrecerán múltiples formas de representación» ✘

Repasa el grupo descrito en la Fase 0 alumno a alumno si el docente ha dado detalles: qué barrera
concreta encuentra cada perfil en esta SA y qué se hace con ella.

## Fase 6 · Volcado

Ver `plantilla-del-centro.md`. Dos avisos:

* No empieces a rellenar la plantilla hasta que el contenido esté cerrado con el docente. Rellenar
  una plantilla dos veces cuesta más que redactar la SA.
* Revisa el documento generado antes de entregarlo. Un bloque de sesión duplicado de más o un
  criterio en la celda equivocada arruinan la confianza en todo lo demás.
