# Esquema del JSON de la Situación de Aprendizaje

Este JSON es la representación estructurada de la SA acordada con el docente. Alimenta
`scripts/generar_sa.py` (documento estándar) y sirve de fuente para construir el mapeo de
`scripts/rellenar_plantilla.py` (plantilla del centro).

**Todos los campos son opcionales**: lo que falta se omite del documento. No rellenes un campo con
una suposición: es preferible dejarlo vacío y decírselo al docente.

Los campos de texto admiten **cadena o lista**. Si es lista, cada elemento se escribe como una
viñeta. Dentro de una cadena, `\n` separa párrafos.

```jsonc
{
  "centro": { "nombre": "CEIP Ejemplo", "logo": "ruta/al/logo.png" },

  "identificacion": {
    "titulo": "Título de la SA",
    "unidad_programacion": "2",          // si el centro numera las unidades de programación
    "numero_sa": "1",
    "curso_academico": "2026/2027",
    "etapa": "Educación Secundaria Obligatoria",
    "curso_grupo": "3.º ESO A",
    "area": "Biología y Geología",       // área, materia, ámbito o módulo profesional
    "docentes": "...",
    "num_sesiones": "8",
    "temporalizacion": "2.º trimestre, del 12 al 30 de enero",
    "lengua_vehicular": "Castellano",
    "vinculacion_otras_areas": "Geografía e Historia (aporta...), Tecnología (aporta...)"
  },

  "contextualizacion": {
    "situacion": "Qué pasa, dónde y por qué importa.",
    "reto": "Pregunta guía en una sola frase.",
    "justificacion": "Por qué merece la pena y qué necesidad del grupo o del entorno atiende.",
    "conexion_entorno": "Entidades, espacios o personas del entorno implicadas.",
    "ods": [ { "meta": "ODS 12 · meta 12.5", "concrecion": "Cómo se concreta en esta SA" } ],
    "transversales": "Coeducación, convivencia, competencia digital, plan lector…"
  },

  "producto_final": {
    "descripcion": "Qué produce el alumnado.",
    "audiencia": "Quién lo recibe fuera del aula.",
    "formato_condiciones": "Formato, extensión, requisitos de entrega y fecha.",
    "difusion": "Cómo llega a su audiencia."
  },

  "concrecion_curricular": {
    "fuente": "Decreto 107/2022 (Comunitat Valenciana)",   // SIEMPRE identificada
    "literal": true,                                       // false = redacción orientativa, avísalo
    "competencias": [
      {
        "codigo": "CE1",
        "competencia": "Texto literal de la competencia específica.",
        "descriptores": "CCL1, STEM2, CD1",
        "objetivos_etapa": "1, 5, 7",
        "criterios": [
          {
            "codigo": "1.2",
            "texto": "Texto literal del criterio de evaluación.",
            "evidencia": "Qué produce o hace el alumnado que lo demuestra en esta SA.",
            "instrumento": "Rúbrica del informe"
          }
        ],
        "saberes": [ "Bloque A. Saber básico literal…", "Bloque B. …" ]
      }
    ],
    "justificacion_competencial": "Párrafo sobre la contribución al desarrollo competencial."
  },

  "metodologia": {
    "modelos": "Indagación, investigación grupal…",
    "metodologias": "ABP, aprendizaje cooperativo…",
    "tecnicas": "Rompecabezas, folio giratorio, rutina veo-pienso-me pregunto…",
    "agrupamientos": "Equipos cooperativos de 4 con roles…",
    "espacios": "Aula, laboratorio, salida al barrio…",
    "tiempos": "Sesiones de 55 min; la 4 y la 5 en bloque de 2 h",
    "recursos": "Materiales, dispositivos, aplicaciones, fuentes…"
  },

  "secuencia": [
    {
      "n": 1,
      "fase": "Activación y contextualización",
      "titulo": "Nos llega el encargo",
      "sesiones": "1",
      "actividad": "Qué hace el alumnado, en detalle.",
      "agrupamiento": "Gran grupo y parejas",
      "escenario": "Aula",
      "recursos": "Carta del ayuntamiento, mural, post-its",
      "evidencia": "Mural de preguntas iniciales",
      "evaluacion": "Evaluación inicial: registro del mural"
    }
  ],

  "evaluacion": {
    "diagnostica": "Qué se explora, con qué y qué se hace con el resultado.",
    "formativa": "Hitos, retroalimentación, auto y coevaluación.",
    "sumativa": "Qué instrumento evalúa qué criterios al final.",
    "criterios_calificacion": [
      { "instrumento": "Rúbrica del producto final", "criterios": "1.2, 2.1",
        "momento": "Final", "peso": "40" }
    ],
    "rubrica": {
      "titulo": "Informe divulgativo",
      "escala": ["1 · En inicio", "2 · En desarrollo", "3 · Adquirido", "4 · Avanzado"],
      "indicadores": [
        { "criterio": "1.2", "indicador": "Cita y contrasta fuentes",
          "niveles": ["No cita fuentes", "Cita 1 o 2", "Cita 3 o más",
                      "Cita 3 o más y contrasta dos entre sí"],
          "peso": "20" }
      ]
    },
    "recuperacion": "Qué se rehace, cuándo, con qué apoyo y cómo se recalifica."
  },

  "diversidad": {
    "dua": {
      "representacion": [ "Medida concreta anclada a una actividad y un recurso" ],
      "implicacion": [ "…" ],
      "accion_expresion": [ "…" ]
    },
    "neae": "Medidas para el alumnado NEAE concreto del grupo.",
    "refuerzo": "Apoyo y andamiaje adicional.",
    "profundizacion": "Enriquecimiento para altas capacidades."
  },

  "practica_docente": { "diseno": "", "implementacion": "", "mejora": "" },

  "referencias": { "bibliografia": "…", "web": "…" }
}
```

## Comprobaciones que hace el script

`generar_sa.py` avisa por consola (no bloquea) si:

* los pesos de `criterios_calificacion` no suman 100;
* los pesos de los indicadores de la rúbrica no suman 100;
* el total de sesiones de `secuencia` no coincide con `identificacion.num_sesiones`;
* hay criterios de evaluación sin `evidencia` o sin `instrumento`;
* `concrecion_curricular.literal` es `false` (recordatorio de avisar al docente);
* hay más de 4 competencias específicas.

**Lee siempre esos avisos y corrige el JSON antes de entregar.**

## Notas

* `practica_docente` se deja vacío al diseñar la SA: el apartado se omite del documento si los tres
  campos están vacíos.
* `secuencia[].sesiones` permite que un bloque ocupe más de una sesión; si se omite, cuenta como 1.
* Los códigos (`CE1`, `1.2`, `RA2 c)`) se copian **tal como aparecen en la fuente**, sin renumerar.
