# Anatomía de una Situación de Aprendizaje

## 1. La definición normativa

Los reales decretos de enseñanzas mínimas definen las situaciones de aprendizaje como
«situaciones y actividades que implican el despliegue por parte del alumnado de actuaciones
asociadas a competencias clave y competencias específicas y que contribuyen a la adquisición y
desarrollo de las mismas» (artículo 2 de los RD 95/2022 de Infantil, 157/2022 de Primaria,
217/2022 de ESO y 243/2022 de Bachillerato).

El Anexo III de esos decretos añade las orientaciones de diseño. Las SA deben:

* estar **bien contextualizadas** y ser **respetuosas con las experiencias del alumnado**;
* estar **compuestas por tareas complejas** cuya resolución conlleve la construcción de nuevos
  aprendizajes;
* favorecer **diferentes tipos de agrupamiento**, del trabajo individual al trabajo en grupo;
* propiciar la **producción y la interacción verbal** e incluir **recursos auténticos** en
  distintos soportes;
* fomentar aspectos relacionados con el **interés común, la sostenibilidad y la convivencia
  democrática**.

Cada comunidad autónoma concreta además qué apartados debe contener el documento de SA en su
normativa de ordenación y evaluación. **La plantilla del centro es la traducción de esa norma**: si
existe, manda sobre cualquier estructura que propongas.

## 2. Los apartados que toda SA contiene

Los nombres cambian de una comunidad a otra, pero el contenido es prácticamente el mismo:

| Apartado | Qué responde |
| --- | --- |
| **1. Identificación** | Título, etapa, curso, área/materia/ámbito/módulo, docentes, nº de sesiones, temporalización, lengua vehicular, vinculación con otras áreas |
| **2. Contextualización y justificación** | Qué situación real se plantea, por qué merece la pena, qué necesidad del grupo o del entorno atiende, con qué se conecta (ODS, planes de centro, entorno) |
| **3. Concreción curricular** | Competencias específicas, criterios de evaluación, saberes básicos, descriptores del perfil de salida y objetivos de etapa **literales** |
| **4. Producto final y reto** | Qué produce el alumnado, para quién, con qué condiciones y cómo se difunde |
| **5. Metodología y secuencia de actividades** | Fases, sesión a sesión: qué hace el alumnado, con quién, dónde, con qué y qué evidencia deja |
| **6. Evaluación** | Diagnóstica, formativa y sumativa; instrumentos por criterio; rúbrica; criterios de calificación; recuperación |
| **7. Medidas de respuesta a la diversidad y DUA** | Representación, implicación, acción y expresión; NEAE; refuerzo; enriquecimiento |
| **8. Evaluación de la práctica docente** | Se rellena **después** de implementar la SA: qué funcionó, qué no y qué se cambia |

El apartado 8 normalmente se deja en blanco al diseñar. No lo inventes: si el docente no ha
impartido aún la SA, déjalo vacío y explícale que es para después.

## 3. Diferencias con la unidad didáctica y con la UDI

| | Unidad didáctica clásica | UDI | Situación de Aprendizaje |
| --- | --- | --- | --- |
| Punto de partida | El tema o bloque de contenidos | La tarea integradora que concreta el currículo | La **situación-problema del entorno** |
| Documento | Objetivos, contenidos, actividades | Concreción curricular + transposición didáctica (dos documentos) | Un documento único con la situación, la concreción y la secuencia |
| Papel del contexto | Motivador, opcional | Marco de la tarea final | **Constitutivo**: sin él la SA no existe |
| Producto | Puede no haberlo | Tarea integradora | Producto **con audiencia** fuera del aula |
| Evaluación | De contenidos | Por criterios, con ponderación | Por criterios, con evidencia en cada actividad y evaluación formativa explícita |

En la práctica, muchos centros que trabajan con UDI y muchos que trabajan con SA hacen cosas muy
parecidas. La diferencia real de la SA está en dos sitios: **el contexto tiene que hacer trabajo
didáctico** y **cada actividad tiene que dejar una evidencia** de la que se pueda evaluar.

## 4. Los ocho errores que más se repiten

1. **El contexto es decorativo.** Si al quitar la historia («sois periodistas de un diario local»)
   las actividades siguen igual, no hay SA. Prueba de fuego: ¿el contexto cambia lo que el alumnado
   decide, o solo cómo se llama la ficha?
2. **Demasiadas competencias específicas.** Cinco, seis, ocho competencias en una SA de diez
   sesiones no se pueden evaluar. Dos a cuatro, bien evaluadas, valen mucho más.
3. **Criterios de evaluación sin evidencia.** Se listan porque «tocan», pero no hay ninguna
   actividad de la que se pueda recoger nada. Si no hay evidencia, fuera.
4. **La rúbrica llega al final.** Se diseña después de la secuencia y no se parece a los criterios.
   La rúbrica se construye en la fase de evaluación, **antes** de la secuencia, y se deriva de los
   criterios.
5. **El producto no sale del aula.** «Una presentación al resto de la clase» es mejor que nada,
   pero la SA gana mucho cuando alguien de fuera lo recibe, lo usa o responde.
6. **DUA de manual.** Copiar los tres principios y sus pautas no es diseñar. La medida DUA se
   nombra con la actividad y el recurso concreto de esta SA.
7. **La secuencia describe al docente.** «Se explica…», «se corrige…». Las sesiones se redactan
   desde lo que hace el alumnado.
8. **Currículo parafraseado.** Reescribir un criterio de evaluación «con mis palabras» invalida el
   documento: es texto normativo y se cita literal.

## 5. Buenas señales

Una SA sólida se reconoce enseguida:

* El alumnado podría explicar el reto a alguien de fuera en una frase.
* Hay al menos una decisión real en manos del alumnado (qué investigar, cómo presentarlo, a quién
  dirigirse).
* Se sabe qué se recoge en cada sesión y para qué sirve.
* La retroalimentación está planificada, no improvisada: hay hitos con devolución antes de la
  entrega final.
* Cualquier docente del departamento podría implementarla leyendo el documento.
