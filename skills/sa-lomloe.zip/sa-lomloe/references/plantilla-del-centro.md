# Trabajar con la plantilla de SA del centro

Esta habilidad no lleva plantillas dentro: usa **la del centro del docente**. Aquí está cómo
pedirla, analizarla y rellenarla sin romper su formato.

## 1. Cuándo y cómo pedirla

Menciónala como opcional en la **Fase 0** («si tu centro tiene plantilla propia, puedes adjuntarla
ahora o más adelante») y pídela **en firme al iniciar la Fase 6**, cuando el contenido ya está
acordado. Pídela así:

> Para volcar la SA en el formato de tu centro necesito la plantilla. Adjúntala a ser posible en
> **.docx** (Word), que es el formato que permite rellenarla conservando el diseño. Si solo la
> tienes en PDF o en papel, mándala igualmente: la reproduzco lo más fielmente que pueda, aunque el
> resultado no será idéntico. Si tu centro no tiene plantilla propia, dímelo y uso un formato
> estándar.

Si el centro tiene además una **plantilla de programación de aula o de unidad de programación** en
la que la SA se inserta, pídela también: a veces la SA es un anexo con numeración («Unidad de
programación 2 · Situación de aprendizaje 1») y hay que rellenar esos campos.

## 2. Analizar la plantilla

```bash
python scripts/analizar_plantilla.py "PLANTILLA SA DEL CENTRO.docx"
```

Imprime la orientación y márgenes, el texto de la cabecera, y para cada tabla el contenido de todas
las celdas con sus coordenadas `[tabla, fila, columna]`, su color de fondo y las combinaciones de
celdas. Lee ese mapa con atención antes de escribir nada:

- Las celdas con texto (`ETAPA:`, `PRODUCTO FINAL`, `SABERES BÁSICOS`…) son **rótulos de la
  plantilla**: no se borran.
- Las celdas `VACÍA` son las casillas a rellenar.
- `= combinada con [t,f,c]` indica que esa posición pertenece a otra celda: escribe en la
  coordenada de origen, no en la combinada.

Con un PDF, el script genera una imagen por página: **ábrelas** para ver el diseño real y decidir
si puedes reproducirlo o si conviene pedir el .docx.

Ojo con un patrón muy común en las plantillas de SA: **una sola tabla larguísima** que recorre todo
el documento, con las etiquetas en negrita al principio de la celda y la respuesta en un párrafo
posterior **dentro de la misma celda**. En ese caso, escribe en modo `anexar`, no `reemplazar`, o
borrarás la etiqueta.

## 3. Preparar la estructura si no cuadra el número de bloques

Las plantillas de SA suelen traer un número fijo de bloques repetibles:

* **Competencias específicas** (a menudo 3 filas de partida).
* **Sesiones o actividades** (bloques de varias filas, típicamente 3 de partida, con un aviso
  interno tipo «duplicar según la duración de la SA» que hay que **eliminar** del documento final).
* **Criterios de calificación** (varias filas sobre una fila TOTAL).

Casi siempre **sobran**, y basta con dejarlos vacíos o eliminarlos. Si **faltan**, se duplican.
Ambas cosas se hacen desde el fichero de mapeo:

```jsonc
"duplicar_tablas": [ {"tabla": 1, "veces": 2},              // dos bloques más iguales al 1
                     {"tablas": [1, 2], "veces": 3} ],      // bloque de tablas contiguas
"duplicar_filas":  [ {"tabla": 1, "fila": 3, "veces": 2} ], // dos filas de criterio más
"eliminar_tablas": [7, 8],
"eliminar_filas":  [ {"tabla": 2, "filas": [5, 6]} ],
"eliminar_tablas_sin_escribir": true                        // limpia los bloques no usados
```

Cuando cada bloque se construye con **dos tablas seguidas**, usa `"tablas": [1, 2]`: se duplican
juntas y en el orden correcto. Con `"tabla": 1` duplicarías solo la mitad del bloque.

Cuidado con los índices: **al duplicar, las tablas posteriores se renumeran**. Con duplicaciones, lo
más seguro es trabajar en dos pasos:

```bash
python scripts/rellenar_plantilla.py mapeo.json --solo-estructura
python scripts/analizar_plantilla.py salida_intermedia.docx    # coordenadas definitivas
```

Y si la plantilla numera las sesiones («Sesión 1», «Sesión 2»…), **renumera** después de duplicar o
eliminar: quedan tres «Sesión 3» seguidas con una facilidad pasmosa.

## 4. Rellenar

```bash
python scripts/rellenar_plantilla.py mapeo.json
```

Escribe sobre una copia de la plantilla respetando tipografía, colores y márgenes del centro. Modos
de escritura:

| Modo | Efecto | Cuándo |
| --- | --- | --- |
| `reemplazar` (defecto) | Vacía la celda y escribe | Casillas vacías |
| `misma_linea` | Añade el texto detrás de lo que ya hay | Rótulos tipo `ETAPA:`, `CURSO:` |
| `anexar` | Añade párrafos debajo | Celdas con etiqueta en negrita que se conserva |

El script avisa si sobrescribe una celda que tenía texto: **revisa siempre esos avisos**, porque
suelen indicar que se ha borrado un rótulo por error.

## 5. Comprobar el resultado

Antes de entregar, abre el documento generado de verdad: vuelca el texto de las tablas con
python-docx, o conviértelo con `soffice --headless --convert-to pdf` y mira las páginas. Comprueba:

- Ningún apartado importante ha quedado vacío teniendo contenido acordado.
- El número de bloques de sesión coincide con el número de sesiones de la SA, y están bien
  numerados.
- Los pesos de los criterios de calificación suman 100.
- No queda ningún aviso interno de la plantilla («duplicar este bloque…», texto de ejemplo en gris).

Después entrega la ruta del fichero e indica **qué casillas se han dejado vacías a propósito** (por
ejemplo, la evaluación de la práctica docente, o firmas y fechas del departamento).

## 6. Si no hay plantilla, o solo hay PDF

```bash
python scripts/generar_sa.py datos_sa.json carpeta_salida
```

Produce un documento de SA en A4 con los ocho apartados estándar (identificación, contextualización,
concreción curricular, producto final, metodología y secuencia, evaluación, diversidad y DUA,
evaluación de la práctica docente). Admite logotipo y nombre del centro:

```jsonc
"centro": { "nombre": "CEIP Ejemplo", "logo": "ruta/al/logo.png" }
```

Si el docente tenía la plantilla solo en PDF, puedes acercarte a su diseño ajustando el generador
(los colores y los títulos están al principio del script), pero **dile con claridad que es una
reproducción**, no su documento oficial, y ofrécele pedir el .docx a jefatura de estudios.

## 7. Reutilizar el mapeo

El fichero de mapeo es específico de **cada plantilla**, no de cada SA: las coordenadas no cambian.
Guárdalo y ofrécelo al docente («guarda este `mapeo-plantilla.json`: la próxima SA se vuelca en
segundos»). Para la siguiente basta con cambiar los textos.
