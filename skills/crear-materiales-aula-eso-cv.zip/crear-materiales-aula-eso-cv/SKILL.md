---
name: crear-materiales-aula-eso-cv
description: Crea materiales del alumnado y guía docente para actividades de ESO ya diseñadas, accesibles según el DUA.
---

# Crear materiales de aula de ESO

## Procedimiento
1. Recupera la situación de aprendizaje, los criterios de evaluación implicados, la evidencia esperada, el destinatario y los recursos disponibles. Si el diseño no está cerrado, aplica primero (o resume) lo mínimo necesario de la skill disenar-situaciones-aprendizaje-eso-cv antes de producir material.
2. Crea los recursos: consignas completas, datos o casos necesarios (marca como ficticios los que lo sean), ejemplos, apoyos, y el tiempo y producto esperado. Aplica el DUA: ofrece más de una forma de acceder a la consigna y de expresar el resultado, sin diluir el criterio de evaluación.
3. Entrega dos versiones separadas: la del alumnado y la guía docente, con soluciones o respuestas admisibles, errores previsibles del alumnado, orientaciones de corrección y cómo retirar apoyos progresivamente para quien no los necesite.
4. Comprueba que el alumnado tiene toda la información necesaria para completar la actividad, y que los apoyos no revelan la respuesta en una prueba que deba medir autonomía. Un título o un enlace a un recurso que no existe no es material terminado.

## Límites
No generes materiales sobre un criterio de evaluación que no se ha confirmado en la programación de la materia. No inventes datos reales (estadísticas, hechos históricos, fuentes) que la actividad use: verifícalos o márcalos como ficticios con fines didácticos.
