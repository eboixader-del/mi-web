---
name: programar-aula-primaria-cv
description: Coordina la programación de aula de un área de Educación Primaria (una situación de aprendizaje o una secuencia completa de curso) a partir de una programación didáctica existente, con diseño accesible según el DUA.
---

# Programar aula de un área de Educación Primaria

Usa esta skill cuando el encargo sea "prográmame el aula de esta área/curso" de principio a fin; para una pieza aislada (solo materiales, solo instrumentos, solo revisión), ve directamente a la skill correspondiente.

## Procedimiento
1. Recupera la programación didáctica vigente del área (competencias específicas, criterios de evaluación, saberes básicos, situaciones de aprendizaje previstas) — si no está disponible, pide al docente el mínimo imprescindible y continúa con lo demás como propuesta pendiente de confirmar.
2. Para diseñar una situación de aprendizaje nueva, aplica la skill disenar-situaciones-aprendizaje-primaria-cv.
3. Según el encargo, aplica crear-materiales-aula-primaria-cv y/o crear-instrumentos-aula-primaria-cv.
4. Integra los productos y aplica auditar-aula-primaria-cv; corrige lo detectado dentro del alcance del encargo.
5. Entrega la situación de aprendizaje, los materiales, los instrumentos y las comprobaciones realizadas, dejando explícitos los pendientes.

## Nota sobre accesibilidad
Todo el diseño de aula sigue el DUA (Diseño Universal para el Aprendizaje): un único itinerario con múltiples formas de acceso, implicación, procesamiento y expresión, en vez de recorridos paralelos distintos por nivel de alumnado. Documenta también, cuando el docente lo indique, las medidas de atención a la diversidad específicas del centro (refuerzo, adaptaciones de acceso, apoyo PT/AL) sin inventar el nombre del plan o programa si no te lo han confirmado.
