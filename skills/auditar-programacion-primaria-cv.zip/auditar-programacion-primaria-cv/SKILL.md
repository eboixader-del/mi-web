---
name: auditar-programacion-primaria-cv
description: Audita una programación didáctica de área de Educación Primaria ya redactada frente al Decreto 106/2022 y los acuerdos de centro, señalando huecos y contradicciones sin inventar una nota oficial.
---

# Auditar una programación de Educación Primaria

Esta skill es de solo lectura salvo que el docente pida explícitamente que corrijas el documento.

## Lista de comprobación
Verifica que la programación contiene, con contenido real y no solo el título del epígrafe:
1. Contextualización y marco normativo (Decreto 106/2022 y normativa vigente).
2. Competencias específicas del área y su contribución al perfil de salida de la etapa.
3. Criterios de evaluación y saberes básicos literales del curso.
4. Secuenciación de situaciones de aprendizaje con su distribución horaria y su relación con competencias específicas/criterios de evaluación.
5. Metodología didáctica.
6. Recursos y materiales.
7. Medidas de atención a la diversidad.
8. Procedimientos e instrumentos de evaluación y criterios de calificación, coherentes con la normativa vigente (ver la skill disenar-evaluacion-primaria-cv).
9. Actividades complementarias, si las hay.
10. Procedimiento de evaluación de la programación y de la práctica docente.

## Procedimiento
1. Fija alcance y versión del documento auditado; identifica qué fuentes faltan (currículo, acuerdos de ciclo, concreción curricular del centro) para verificar cada punto.
2. Para cada apartado, evalúa como cumple / parcial / no cumple / no verificable, citando ubicación exacta y evidencia.
3. Revisa especialmente: que los criterios de evaluación citados sean literales del decreto de currículo, que cada criterio tenga al menos un instrumento asociado, y que la programación no choque con la concreción curricular o el PEC del centro.
4. Entrega los hallazgos en una tabla: apartado, estado, evidencia, diagnóstico, acción propuesta, responsable. No emitas una calificación global oficial de la programación.
5. Si el docente pide corrección, aplícala solo sobre lo detectado.

## Límites
No certifiques conformidad institucional ni sustituyas la aprobación del ciclo o la dirección del centro. No inventes una versión del decreto si no la tienes disponible: pide el documento o marca el punto como no verificable.
