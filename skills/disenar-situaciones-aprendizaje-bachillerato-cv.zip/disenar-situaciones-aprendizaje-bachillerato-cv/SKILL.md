---
name: disenar-situaciones-aprendizaje-bachillerato-cv
description: Diseña una situación de aprendizaje para una materia de 1º o 2º de Bachillerato con anclaje curricular literal (competencias específicas, criterios de evaluación, saberes básicos del Decreto 108/2022), producto final y accesibilidad DUA.
---

# Diseñar una situación de aprendizaje de Bachillerato

El término es normativo en esta etapa: el art. 2.6 del Decreto 108/2022 define las situaciones de aprendizaje como "situaciones y actividades que implican el despliegue por parte del alumnado de actuaciones asociadas a las competencias específicas y a las competencias clave, y que contribuyen a su adquisición y desarrollo", y el art. 23.4 las exige como contenido de la programación de aula. Esa vinculación con las competencias clave forma parte de la definición: no la pierdas al diseñar.

## Procedimiento
1. Fija las competencias específicas, los criterios de evaluación y los saberes básicos del alcance, literales del anexo II vigente para ese curso (para 1º en 2026-2027, en la redacción del Decreto 103/2026). Identifica el reto, problema o contexto que da sentido a la situación.
2. Define el producto o desempeño final y la evidencia que acreditará cada criterio de evaluación trabajado.
3. Diseña la secuencia de sesiones desde esa evidencia: activación, desarrollo, práctica, transferencia, síntesis y evaluación. Relaciona cada actividad con su criterio o criterios y con los recursos y espacios necesarios; distingue claramente qué es práctica y qué es evaluación.
4. Aplica el DUA a lo largo de la secuencia: varía formas de acceso a la información, de implicación, de procesamiento y de expresión del aprendizaje, sin rebajar el nivel de exigencia del criterio de evaluación. Documenta los apoyos y cómo se retiran progresivamente.
5. Ajusta la exigencia al nivel de la etapa: en Bachillerato es razonable pedir autonomía en la búsqueda y contraste de fuentes, argumentación formal y manejo de lenguaje técnico propio de la materia, cosa que no cabría en etapas anteriores.
6. Entrega: cronograma de sesiones, inventario de materiales e instrumentos necesarios (sin darlos por existentes si aún no lo están) y cobertura curricular del alcance, indicando qué queda fuera.

## Límites
No inventes datos de centro, horario o calendario que no se hayan confirmado. Un cronograma de diseño no acredita que los recursos existan: dilo explícitamente si faltan. Si la situación se plantea en 2º y el docente menciona las pruebas de acceso a la universidad, trabaja con lo que él te diga sobre su formato: no afirmes por tu cuenta cómo es la PAU.
