---
name: disenar-secuencias-aula-fp-cv
description: Diseña una secuencia de aula de FP (un resultado de aprendizaje, una unidad didáctica o una situación de aprendizaje) con trazabilidad curricular completa y accesibilidad DUA.
---

# Diseñar una secuencia de aula de FP

## Procedimiento
1. Fija los RA/CE del alcance, los contenidos y prerrequisitos asociados, y la evidencia que probará el desempeño (qué tiene que hacer o producir el alumnado para acreditar cada CE).
2. Diseña la secuencia de sesiones desde esa evidencia: actuaciones, práctica guiada, transferencia, retroalimentación y recuperación. Relaciona cada actividad con su(s) CE y con los recursos necesarios; distingue claramente qué es práctica y qué es evaluación.
3. Aplica el DUA a lo largo de la secuencia: varía formas de acceso a la información, formas de implicación/motivación (relevante en FP: conecta con el entorno productivo real), formas de procesamiento y formas de expresión del aprendizaje, sin bajar el nivel de exigencia del CE. Documenta apoyos, responsable y cómo se retiran progresivamente.
4. Señala barreras de aprendizaje previsibles del grupo (si el docente las ha indicado) y cómo la secuencia las anticipa.
5. Entrega: cronograma de sesiones, inventario de materiales/instrumentos necesarios (sin darlos por hechos si aún no existen) y cobertura de CE del alcance. Indica qué queda fuera del alcance si no se cubre completo.

## Límites
No inventes datos de centro, horario o calendario que no se hayan confirmado. Un cronograma de diseño no acredita que los recursos ya existan: dilo explícitamente si aún faltan.
