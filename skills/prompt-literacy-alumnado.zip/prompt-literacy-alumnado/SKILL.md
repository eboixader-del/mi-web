---
name: prompt-literacy-alumnado
description: "Diseña una secuencia didáctica que enseña por qué la calidad del prompt determina la calidad de la respuesta de la IA — comparando prompts vagos con prompts refinados. Úsala cuando el docente quiera enseñar a su alumnado a usar la IA con más criterio, sin que lo pida con estas palabras exactas."
disable-model-invocation: false
user-invocable: true
effort: medium
skill_id: "ai-literacy/prompt-literacy-alumnado"
skill_name: "Diseñador de Secuencias de Alfabetización en Prompts"
domain: "alfabetizacion-ia"
version: "1.0"
contributor: "Gareth Manning (original en inglés, CC BY-SA 4.0)"
adaptado_por: "traducción y adaptación al castellano, con ejemplo propio ligado a CSI Flors"
fuente_original: "https://github.com/GarethManning/education-agent-skills/blob/main/skills/ai-literacy/prompt-literacy-sequence-designer/SKILL.md"
licencia: "CC BY-SA 4.0 — mantiene la atribución al autor original"
evidence_strength: "baja-moderada — sólida para los principios técnicos de los prompts, frontera todavía en la pedagogía específica de cómo enseñarlos"
evidence_sources:
  - "Brown et al. (2020) — Language Models are Few-Shot Learners (el artículo de GPT-3; primera evidencia de que la formulación del prompt cambia la calidad del resultado)"
  - "Liu et al. (2023) — Pre-Train, Prompt, and Predict: revisión sistemática de métodos de prompting en PLN"
  - "Reynolds & McDonell (2021) — Prompt programming for large language models: los 'metaprompts' que indican a la IA cómo razonar o estructurar su respuesta"
  - "Rosenshine (2012) — Principles of instruction (estructura de modelado → práctica guiada → práctica independiente)"
  - "Willingham (2007) — Critical thinking: why is it so hard to teach? (la especificidad depende de la disciplina)"
input_schema:
  requerido:
    - materia: "La disciplina — afecta a qué cuenta como un prompt específico y bueno en ese contexto"
    - nivel_alumnado: "Curso y hábitos actuales de uso de IA"
    - tipo_de_tarea_ia: "Para qué usa el alumnado la IA — investigación, ayuda de redacción, explicación, resolución de problemas, revisión"
  opcional:
    - foco_alfabetizacion_prompts: "Qué dimensión del prompt priorizar — especificidad del contexto, aportación de restricciones, especificación de formato, persona/rol, o refinamiento iterativo"
    - prompts_habituales_alumnado: "Ejemplos reales de los prompts vagos que suele escribir el alumnado — ayuda a generar comparaciones realistas"
    - tiempo_disponible: "Tiempo disponible para la secuencia"
output_schema:
  - anatomia_del_prompt: "Desglose de los componentes de un prompt eficaz — contexto, tarea, restricciones, formato, persona — con ejemplos específicos de la materia"
  - actividad_comparar_contrastar: "Actividad estructurada: prompt vago frente a prompt refinado, con análisis guiado de qué cambió y por qué mejoró la respuesta"
  - ejercicio_de_precios: "La adaptación del 'Pricing Exercise' de Kharbach (2026): cómo añadir restricciones paso a paso transforma una respuesta genérica en una útil"
  - actividad_de_reescritura: "Actividad del alumnado: coger un prompt débil, diagnosticar qué le falta, reescribirlo, comparar resultados"
  - tarjeta_resumen_de_principios: "Un resumen breve y memorable de los principios de prompting, en lenguaje para el alumnado, usable como tarjeta de referencia"
chains_well_with:
  - mapa-limites-ia
teacher_time: "4 minutos"
tags: [alfabetizacion-ia, prompts, especificidad, ia-generativa, contexto, restricciones]
---

# Diseñador de Secuencias de Alfabetización en Prompts

## Qué hace esta skill

Genera una secuencia didáctica que enseña al alumnado por qué la calidad del prompt determina la
calidad de la respuesta de la IA — y qué movimientos concretos producen respuestas más útiles,
precisas y ajustadas al contexto. La secuencia sigue una estructura de comparar y contrastar: el
alumnado ejecuta un prompt vago y uno refinado sobre la misma pregunta, analiza la diferencia en la
calidad del resultado, y extrae los principios.

La idea central: la IA rellena el contexto que falta con la respuesta estadísticamente más común — así
que un prompt sin contexto sobre audiencia, propósito, materia o restricciones recibe una respuesta
calibrada para el caso medio, no para la situación concreta del alumno. El "Ejercicio de Precios"
(Kharbach, 2026) es la actividad ancla: el alumnado parte de una respuesta de IA sin contexto ("¿cuánto
debería cobrar por un servicio?") y va añadiendo restricciones una a una (tipo de servicio, ubicación,
mercado, nivel de calidad), viendo en tiempo real cómo la especificidad transforma el resultado de
genéricamente inútil a genuinamente útil.

La secuencia enseña cinco dimensiones del prompt: contexto (¿quién soy, qué estoy haciendo?), tarea
(¿qué quiero exactamente?), restricciones (¿qué límites aplican?), formato (¿cómo debe estructurarse la
respuesta?) y persona (¿qué papel debe adoptar la IA?). La alfabetización en prompts es un requisito
previo para un buen uso de la IA, y complementa directamente las destrezas de evaluación crítica de sus
respuestas.

Esta skill encaja bien con `mapa-limites-ia`: una decide en qué partes de una tarea tiene sentido usar
IA; esta enseña a usarla bien, precisamente, en esas partes donde sí está permitida.

## Fundamento de evidencia

Brown et al. (2020), en el artículo de GPT-3, demostraron empíricamente que la forma en que se formula
un prompt afecta de manera notable a la calidad del resultado — los ejemplos "few-shot" dentro del
propio prompt (mostrarle a la IA cómo es una buena respuesta) producen resultados sustancialmente
mejores que los prompts "zero-shot" (sin ejemplos). Esta es la evidencia fundacional de que el diseño
del prompt no es arbitrario. Liu et al. (2023) realizaron una revisión sistemática de métodos de
prompting, documentando cómo distintas estructuras (cadena de pensamiento, juego de rol, seguimiento de
instrucciones, few-shot) afectan a la calidad del resultado según la tarea — su revisión establece que
la ingeniería de prompts es una destreza con principios aprendibles, no una cuestión de azar. Reynolds &
McDonell (2021) ampliaron esto con el concepto de "metaprompts" — prompts que indican explícitamente a
la IA cómo razonar, estructurar su respuesta o adoptar una persona — mostrando que estos elementos
estructurales pueden mejorar sustancialmente el resultado.

Estas tres fuentes aportan la base de evidencia específica de IA. Sin embargo, la base de evidencia
pedagógica sobre cómo *enseñar* alfabetización en prompts al alumnado es todavía muy limitada — es
territorio de frontera en la investigación educativa. Las fuentes restantes sostienen el *diseño
instruccional* de esta secuencia: Rosenshine (2012) aporta la estructura de modelado → práctica guiada →
práctica independiente que se usa aquí; Willingham (2007) aporta el argumento de especificidad por
disciplina (lo que cuenta como buen prompt en Historia es distinto de lo que cuenta en Matemáticas), que
justifica una instrucción de alfabetización en prompts específica por materia.

## Esquema de entrada

El profesorado debe aportar:

- **Materia:** la disciplina. *Ej.: "Biología y Geología" / "Física y Química" / "Matemáticas" /
  "Tecnología"*
- **Nivel del alumnado:** curso y uso actual de IA. *Ej.: "3º ESO, usan Gemini o ChatGPT a diario para
  los deberes pero reciben respuestas genéricas que no encajan con lo que se está trabajando en clase"*
- **Tipo de tarea con IA:** para qué la usa el alumnado. *Ej.: "Investigación: buscar información
  científica para resolver una pista dentro de una misión de CSI Flors" / "Redacción: generar borradores
  o mejorar la redacción de un informe de laboratorio"*

Opcional:

- **Foco de alfabetización en prompts:** qué dimensión priorizar
- **Prompts habituales del alumnado:** ejemplos reales de cómo prompean ahora mismo
- **Tiempo disponible:** duración de la secuencia

## Instrucciones (prompt)

```
Eres un experto en pedagogía de la alfabetización en IA y en diseño instruccional, con conocimiento de
la investigación sobre ingeniería de prompts (Brown et al. 2020; Liu et al. 2023; Reynolds & McDonell
2021) y de principios de diseño instruccional (Rosenshine, 2012; Willingham, 2007). Entiendes que la
alfabetización en prompts es una destreza genuinamente nueva con investigación pedagógica dedicada
todavía limitada — la base de evidencia más sólida es la de los principios técnicos (la estructura del
prompt afecta a la calidad del resultado), no la de métodos de enseñanza específicos. Vas a diseñar una
secuencia de aprendizaje fundamentada en principios de diseño instruccional aplicados a este dominio
nuevo.

PRINCIPIOS CRÍTICOS PARA LA ALFABETIZACIÓN EN PROMPTS:
- **La IA rellena el contexto que falta con la media.** Cuando un alumno escribe "explícame la
  fotosíntesis", la IA genera una explicación calibrada para el lector más probable de esa pregunta
  — probablemente un adulto cualquiera, no un alumno de 3º ESO preparando un examen concreto. Los
  buenos prompts cierran esa brecha entre el caso medio y el caso específico.
- **Las restricciones son productivas, no restrictivas.** La mayoría del alumnado cree que un prompt
  está "terminado" en cuanto ha planteado la tarea. Las restricciones — "en no más de 100 palabras",
  "sin usar fórmulas que no hayamos visto en clase", "para alguien que nunca ha estudiado el tema" —
  transforman la calidad del resultado porque obligan a la IA a resolver un problema más concreto.
- **La alfabetización en prompts depende de la disciplina.** Lo que hace bueno a un prompt para un
  ensayo de Historia es distinto de lo que lo hace bueno para explicar un problema de Física. Los
  principios son los mismos; la aplicación cambia.
- **Comparar y contrastar es el mecanismo de aprendizaje central.** El alumnado aprende alfabetización
  en prompts de forma más eficaz ejecutando dos prompts en paralelo y analizando la diferencia — no
  memorizando reglas. Las reglas se vuelven comprensibles a través del contraste.
- **Mejorar un prompt es iterativo, no de un solo intento.** Quien usa bien la IA refina su prompt a
  partir de la respuesta que recibe. El alumnado necesita entender que un primer prompt es un punto de
  partida, no una petición definitiva.

Tu tarea es diseñar una secuencia de alfabetización en prompts para:

**Materia:** {{materia}}
**Nivel del alumnado:** {{nivel_alumnado}}
**Tipo de tarea con IA:** {{tipo_de_tarea_ia}}

El siguiente contexto opcional puede estar disponible o no. Usa lo que haya; ignora los campos marcados
como "no proporcionado".

**Foco de alfabetización en prompts:** {{foco_alfabetizacion_prompts}} — si no se indica, aborda las
cinco dimensiones (contexto, tarea, restricciones, formato, persona) pero da más peso a las 2-3 más
relevantes para el tipo de tarea indicado.
**Prompts habituales del alumnado:** {{prompts_habituales_alumnado}} — si no se indica, genera ejemplos
realistas de cómo prompea el alumnado de ese nivel para ese tipo de tarea — normalmente breves, solo la
tarea, sin contexto.
**Tiempo disponible:** {{tiempo_disponible}} — si no se indica, diseña para una sesión de 30 minutos o
una tarea para casa.

Devuelve tu resultado en este formato exacto:

## Secuencia de Alfabetización en Prompts: [Materia/Tipo de tarea]

**Para:** [Nivel del alumnado]
**Tipo de tarea con IA:** [Para qué usa el alumnado la IA]
**Foco de la secuencia:** [Qué dimensiones se priorizan y por qué]

### Anatomía del prompt

[Las cinco dimensiones con ejemplos específicos de la materia:]

**1. Contexto:** [Qué es el contexto — quién soy, qué hago, para qué. Ejemplo de la materia: sin
contexto vs. con buen contexto]
**2. Tarea:** [Qué significa la especificidad de la tarea más allá de "explica X". Ejemplo de la
materia]
**3. Restricciones:** [Qué hacen las restricciones — cómo fuerzan un resultado más específico y útil.
Ejemplo de la materia]
**4. Formato:** [Qué consigue especificar el formato. Ejemplo de la materia]
**5. Persona:** [Qué consigue asignar un rol. Ejemplo de la materia]

### Actividad de comparar y contrastar

**Prompt vago:** [Un ejemplo realista de cómo escribe ahora el alumnado los prompts para esta tarea]

**Qué devuelve la IA:** [Descripción de qué respuesta genera este prompt — genérica, poco específica,
caso medio]

**Prompt refinado:** [La misma tarea con todas las dimensiones relevantes añadidas]

**Qué devuelve la IA:** [Descripción de cómo cambia la calidad del resultado — específico, calibrado a
la audiencia, más útil]

**Preguntas de análisis para el alumnado:**
[4-5 preguntas que guíen al alumnado a identificar POR QUÉ el prompt refinado produjo un mejor
resultado — no solo "es mejor", sino qué cambió exactamente]

### El Ejercicio de Precios

[La actividad central: una demostración de cómo añadir restricciones de forma iterativa transforma la
respuesta de la IA.]

**El prompt base:** [Una pregunta sin contexto relevante para la materia que produce una respuesta
genéricamente inútil]

**Paso 1 — Añadir contexto de audiencia:** [El prompt tras añadir quién es el usuario y su propósito]
**Cambio observado:** [Qué cambia en la respuesta]

**Paso 2 — Añadir restricciones:** [El prompt tras añadir restricciones específicas relevantes al
contexto]
**Cambio observado:** [Qué cambia en la respuesta]

**Paso 3 — Añadir especificación de formato:** [El prompt tras añadir requisitos de formato]
**Cambio observado:** [Qué cambia en la respuesta]

**El principio:** [Una frase: qué demuestra este ejercicio sobre el principio de "la IA rellena con la
media"]

### Actividad de reescritura de prompts

**Instrucciones:** [Instrucciones paso a paso para que el alumnado diagnostique y reescriba un prompt
débil]

**Prompt débil para reescribir:** [Un prompt realista del alumnado para esta materia y tarea]

**Marco de diagnóstico:** [Preguntas que el alumnado responde antes de reescribir: ¿qué contexto falta?
¿qué restricciones mejorarían esto? ¿qué formato sería más útil? ¿qué persona ayudaría?]

**Espacio de reescritura guiado:** [Plantilla con huecos para cada dimensión del prompt]

**Compartir y comparar:** [Cómo comparte el alumnado sus reescrituras y compara resultados]

### Tarjeta resumen de principios

[Un resumen breve y memorable para el alumnado — 5 principios con una explicación de una línea y un
ejemplo corto de esta materia]

**Autocomprobación antes de devolver el resultado:** verifica que (a) los ejemplos son específicos de
la materia y el tipo de tarea indicados; (b) la comparación muestra una diferencia concreta y
observable en la calidad del resultado; (c) el Ejercicio de Precios usa un prompt base realista que de
verdad produce una respuesta genéricamente inútil; (d) la actividad de reescritura exige criterio del
alumnado, no solo rellenar huecos; y (e) la tarjeta de principios es genuinamente memorable, no una
lista de reglas abstractas.
```

## Ejemplo de salida

**Escenario:** *Materia: "Biología y Geología (3º ESO), dentro del marco narrativo de CSI Flors."
Nivel del alumnado: "3º ESO, usan Gemini a diario durante las misiones de CSI Flors pero reciben
respuestas genéricas que no encajan con el expediente del caso." Tipo de tarea con IA: "Investigación:
pedir a la IA información científica para resolver una pista dentro de un caso." Prompts habituales del
alumnado: "explícame el ADN" / "cómo se compara una muestra de ADN"*

---

## Secuencia de Alfabetización en Prompts: Biología y Geología — Investigación en CSI Flors (3º ESO)

**Para:** 3º ESO, alumnado que usa IA a diario dentro de las misiones de CSI Flors pero recibe
respuestas genéricas
**Tipo de tarea con IA:** Investigación científica para resolver pistas dentro de un caso
**Foco de la secuencia:** Contexto (encaje con el expediente del caso) y restricciones (longitud y
nivel adecuados a 3º ESO) — son las dos dimensiones que más cambian la utilidad de la respuesta para
este uso

### Anatomía del prompt

**1. Contexto:** Sin contexto, la IA responde para el lector medio de esa pregunta — un adulto
cualquiera, no un alumno de 3º ESO resolviendo un caso concreto. *Sin contexto:* "explícame el ADN".
*Con contexto:* "Soy alumno de 3º ESO y estoy resolviendo el caso [nombre del expediente] de CSI Flors,
en el que hay que identificar a un sospechoso a partir de una muestra biológica."

**2. Tarea:** No basta con nombrar el tema — hay que decir qué necesitas hacer con él. *Tarea vaga:*
"explícame el ADN". *Tarea específica:* "explícame cómo se compara una muestra de ADN con una base de
datos para identificar a una persona."

**3. Restricciones:** Las restricciones convierten una clase magistral en una nota de investigación
usable. *Sin restricciones:* párrafos largos con vocabulario universitario. *Con restricciones:* "en
unas 100 palabras, sin fórmulas ni términos que no hayamos visto en clase, como si fuera una nota para
mi expediente de investigación."

**4. Formato:** Especifica la estructura. "Como una nota de campo de investigador, no como un texto de
libro" o "en 3 frases que pueda pegar directamente en mi expediente" producen resultados distintos y
más útiles.

**5. Persona:** "Actúa como un perito forense explicándole el procedimiento a un ayudante nuevo" produce
un tono distinto al de no indicar ningún papel.

### Actividad de comparar y contrastar

**Prompt vago:** "explícame el ADN"

**Qué devuelve la IA:** Un párrafo largo, de nivel universitario, sobre la estructura del ADN en
general — sin relación con el caso, con vocabulario que no se ha visto en 3º ESO, e inútil para pegar
en el expediente tal cual.

**Prompt refinado:** "Soy alumno de 3º ESO y estoy resolviendo el caso 'La muestra del laboratorio' de
CSI Flors. Necesito una nota de investigación de unas 100 palabras que explique cómo se compara una
muestra de ADN con una base de datos para identificar a un sospechoso, sin fórmulas ni vocabulario que
no hayamos visto en clase de Biología y Geología."

**Qué devuelve la IA:** Una nota breve, en un lenguaje adecuado a 3º ESO, centrada exactamente en el
procedimiento de comparación (no en la estructura química del ADN), con una longitud que encaja
directamente en el expediente del caso.

**Preguntas de análisis para el alumnado:**
- "¿Qué información añadiste en el prompt refinado que faltaba en el vago? Haz una lista."
- "¿Por qué mencionar 'el caso' y 'mi expediente' cambió el tipo de respuesta que diste?"
- "La respuesta refinada tiene el nivel de 3º ESO. ¿Qué habría pasado si no hubieras dicho tu curso?"
- "Si la primera respuesta era demasiado difícil, ¿fue culpa de la IA o del prompt? ¿Qué te dice esto?"
- "¿Cómo reescribirías el prompt refinado para pedir la misma información pero en forma de 3 pasos
  numerados?"

### El Ejercicio de Precios

**El prompt base:** "¿Cómo se identifica a una persona a partir de una muestra biológica?"

**Paso 1 — Añadir contexto de audiencia:** "Soy alumno de 3º ESO resolviendo un caso de investigación
en clase de Biología. ¿Cómo se identifica a una persona a partir de una muestra biológica?"
**Cambio observado:** La IA empieza a centrarse en el procedimiento de comparación de ADN en un
contexto forense escolar, no en técnicas de laboratorio avanzadas.

**Paso 2 — Añadir restricciones:** "...Dame los 3 pasos principales del proceso, cada uno en una frase,
sin vocabulario técnico que no se dé en 3º ESO." **Cambio observado:** La IA produce tres pasos breves y
concretos en vez de un párrafo largo con terminología de laboratorio.

**Paso 3 — Añadir especificación de formato:** "...Preséntalo como una lista numerada que pueda copiar
directamente en mi expediente de investigador." **Cambio observado:** La respuesta pasa a ser una lista
lista para pegar, no un texto que hay que reformatear.

**El principio:** La IA empieza desde el caso medio; cada restricción que añades acerca la respuesta a
tu situación concreta.

### Actividad de reescritura de prompts

**Instrucciones:**
1. Lee el prompt débil de abajo.
2. Diagnostícalo con las cuatro preguntas del marco.
3. Reescríbelo con la plantilla — no lo alargues sin más, haz cada dimensión más concreta.
4. Compara tu reescritura con la de un compañero.

**Prompt débil para reescribir:** "Cómo se compara una muestra de ADN"

**Marco de diagnóstico:**
- ¿Qué contexto falta? (¿Quién eres? ¿Para qué caso o tarea es esto?)
- ¿Qué restricciones mejorarían esto? (¿Longitud? ¿Nivel de vocabulario?)
- ¿Qué formato sería más útil? (¿Lista? ¿Nota de investigador? ¿Pasos numerados?)
- ¿Qué persona ayudaría? (¿Un perito explicando a un ayudante nuevo?)

**Plantilla de reescritura para el alumnado:** "Soy [contexto: quién eres y para qué es esto]. Necesito
[tarea específica: exactamente qué quieres, no solo el tema]. Por favor [restricciones: qué incluir o
excluir, longitud aproximada, nivel de vocabulario]. Preséntalo como [formato: la estructura que
quieres]. [Opcional: hazlo como [persona]]."

**Compartir y comparar:** Por parejas, ambos ejecutan su prompt reescrito y comparan resultados. Debate:
¿qué reescritura produjo una respuesta más útil para el expediente? ¿cuál de las cinco dimensiones marcó
más diferencia? ¿qué añadirías a la reescritura de tu compañero?

### Tarjeta resumen de principios

1. **Da el contexto primero.** Dile a la IA quién eres, qué caso o tarea es, y para qué es la
   respuesta. Sin contexto, la IA responde para nadie en particular.
2. **Sé específico con la tarea.** "Explícame X" casi nunca basta. Di exactamente qué necesitas saber.
3. **Añade restricciones.** Longitud, nivel de vocabulario, qué excluir — las restricciones fuerzan una
   respuesta específica y útil.
4. **Especifica el formato.** Lista, pasos numerados, nota de investigador — decir qué estructura
   necesitas ahorra tiempo de reescritura después.
5. **Refina, no reempieces.** Si la primera respuesta no está bien del todo, responde con: "Está bien,
   pero [problema concreto]. Cambia [elemento concreto]." Iterar es más rápido que volver a empezar.

---

## Limitaciones conocidas

1. **La base de evidencia sobre cómo enseñar alfabetización en prompts al alumnado es todavía muy
   limitada.** La investigación sobre ingeniería de prompts (Brown et al. 2020; Liu et al. 2023;
   Reynolds & McDonell 2021) documenta que la estructura del prompt afecta a la calidad del resultado —
   no estudia enfoques pedagógicos para enseñar esta destreza. Esta secuencia aplica principios de
   diseño instruccional ya establecidos a un dominio de frontera. Trátala como fundamentada pero
   provisional.

2. **La alfabetización en prompts tiene una vida útil corta a medida que mejoran los modelos.** Los
   modelos actuales necesitan contexto y restricciones explícitos porque rellenan la información que
   falta con la media estadística. Los modelos futuros podrían inferir mejor el contexto, dejando
   obsoletas algunas estrategias concretas. El principio de fondo (una comunicación clara y específica
   produce mejores resultados que una petición vaga) es poco probable que deje de ser relevante; los
   movimientos concretos sí pueden cambiar.

3. **Enseñar alfabetización en prompts puede aumentar la dependencia de la IA.** El alumnado que
   aprende a escribir mejores prompts obtendrá respuestas más útiles — lo que puede reducir su
   motivación para desarrollar destrezas independientes. Esta skill debería usarse siempre junto con
   herramientas de evaluación crítica de las respuestas de la IA (como el análisis del apartado de
   "Alineación normativa" de `mapa-limites-ia`), para que la alfabetización en prompts forme parte de un
   marco crítico más amplio, no de una simple optimización de productividad.

4. **Los resultados de un prompt son probabilísticos, no deterministas.** El mismo prompt puede producir
   respuestas distintas en ejecuciones distintas. Las actividades de comparar y contrastar deben tener
   esto en cuenta — puede hacer falta ejecutar los prompts 2-3 veces para ver un patrón consistente, y
   "el prompt refinado siempre es mejor" no es del todo exacto (normalmente lo es, de forma coherente
   con los principios, pero no siempre).
