# -*- coding: utf-8 -*-
"""
Empaqueta un vídeo (i, opcionalment, activitats) en un paquet SCORM 1.2 llest per a
pujar a una plataforma de formació (Moodle, etc.).

Ús:
    python empaquetar_scorm.py video.mp4 paquet_scorm.zip [--titol "Títol"] [--activitats activitats.json]

El paquet conté:
    imsmanifest.xml   (SCORM 1.2)
    index.html        (reproductor + registre de compleció via API SCORM)
    scorm_api.js      (localització de l'API i seguiment mínim)
    <video>           (el fitxer de vídeo)

Quan l'alumne acaba de veure el vídeo (o completa les activitats), es marca
cmi.core.lesson_status = "completed".

Format d'activitats.json (opcional):
    [{"pregunta": "…", "opcions": ["a", "b", "c"], "correcta": 0}, ...]
"""
import json
import sys
import zipfile
from html import escape
from pathlib import Path

MANIFEST = """<?xml version="1.0" encoding="UTF-8"?>
<manifest identifier="VIDEO_FORMATIU" version="1.2"
  xmlns="http://www.imsproject.org/xsd/imscp_rootv1p1p2"
  xmlns:adlcp="http://www.adlnet.org/xsd/adlcp_rootv1p2"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://www.imsproject.org/xsd/imscp_rootv1p1p2 imscp_rootv1p1p2.xsd
                      http://www.adlnet.org/xsd/adlcp_rootv1p2 adlcp_rootv1p2.xsd">
  <metadata>
    <schema>ADL SCORM</schema>
    <schemaversion>1.2</schemaversion>
  </metadata>
  <organizations default="ORG">
    <organization identifier="ORG">
      <title>{titol}</title>
      <item identifier="ITEM1" identifierref="RES1">
        <title>{titol}</title>
      </item>
    </organization>
  </organizations>
  <resources>
    <resource identifier="RES1" type="webcontent" adlcp:scormtype="sco" href="index.html">
      <file href="index.html"/>
      <file href="scorm_api.js"/>
      <file href="{video}"/>
    </resource>
  </resources>
</manifest>
"""

SCORM_JS = """// Localitza l'API SCORM 1.2 en les finestres pare
var API = null;
function trobaAPI(win){
  var n=0;
  while(win.API==null && win.parent!=null && win.parent!=win && n<10){ win=win.parent; n++; }
  return win.API;
}
function initSCORM(){
  API = trobaAPI(window) || (window.opener ? trobaAPI(window.opener) : null);
  if(API){ API.LMSInitialize(""); API.LMSSetValue("cmi.core.lesson_status","incomplete"); API.LMSCommit(""); }
}
function completaSCORM(){
  if(API){ API.LMSSetValue("cmi.core.lesson_status","completed"); API.LMSCommit(""); API.LMSFinish(""); }
}
window.addEventListener("load", initSCORM);
window.addEventListener("unload", function(){ if(API){ API.LMSFinish(""); } });
"""

INDEX = """<!doctype html>
<html lang="{lang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{titol}</title>
<script src="scorm_api.js"></script>
<style>
  body{{font-family:system-ui,Segoe UI,Arial,sans-serif;margin:0;background:#0f1b33;color:#fff;}}
  header{{padding:16px 20px;background:#1F3864;font-size:1.1rem;font-weight:600;}}
  main{{max-width:960px;margin:0 auto;padding:20px;}}
  video{{width:100%;border-radius:10px;background:#000;}}
  .estat{{margin-top:12px;padding:10px 14px;border-radius:8px;background:#22345c;}}
  .fet{{background:#1e7d47;}}
  .activitat{{margin-top:20px;padding:16px;background:#182a4d;border-radius:10px;}}
  button{{background:#2E5090;color:#fff;border:0;padding:10px 16px;border-radius:8px;cursor:pointer;font-size:1rem;}}
  label{{display:block;margin:6px 0;cursor:pointer;}}
</style>
</head>
<body>
<header>{titol}</header>
<main>
  <video id="v" controls preload="metadata" src="{video}"></video>
  <div class="estat" id="estat">Mira el vídeo fins al final per a completar la formació.</div>
  <div id="activitats">{activitats}</div>
</main>
<script>
  var v=document.getElementById("v"), estat=document.getElementById("estat");
  var hiHaActivitats={te_activitats};
  v.addEventListener("ended", function(){{
    if(!hiHaActivitats){{ marcarFet(); }}
    else {{ estat.textContent="Ara respon les activitats per a completar."; }}
  }});
  function marcarFet(){{
    estat.textContent="Formació completada. Pots tancar la finestra.";
    estat.className="estat fet";
    if(typeof completaSCORM==="function") completaSCORM();
  }}
  function corregir(){{
    var ok=true;
    document.querySelectorAll("[data-correcta]").forEach(function(q){{
      var sel=q.querySelector("input:checked");
      if(!sel || sel.value!==q.getAttribute("data-correcta")) ok=false;
    }});
    if(ok) marcarFet();
    else estat.textContent="Revisa les respostes: encara n'hi ha alguna incorrecta.";
  }}
</script>
</body>
</html>
"""


def render_activitats(activitats):
    if not activitats:
        return ""
    parts = []
    for i, a in enumerate(activitats):
        opcions = "".join(
            f'<label><input type="radio" name="q{i}" value="{j}"> {escape(op)}</label>'
            for j, op in enumerate(a.get("opcions", [])))
        parts.append(
            f'<div class="activitat" data-correcta="{a.get("correcta", 0)}">'
            f'<b>{escape(a.get("pregunta", ""))}</b>{opcions}</div>')
    parts.append('<div class="activitat"><button onclick="corregir()">Comprovar respostes</button></div>')
    return "".join(parts)


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    video = Path(sys.argv[1])
    zip_desti = Path(sys.argv[2])
    titol = "Vídeo formatiu"
    if "--titol" in sys.argv:
        titol = sys.argv[sys.argv.index("--titol") + 1]
    activitats = []
    if "--activitats" in sys.argv:
        act_f = Path(sys.argv[sys.argv.index("--activitats") + 1])
        activitats = json.loads(act_f.read_text(encoding="utf-8"))

    if not video.exists():
        print(f"ERROR: no trobe el vídeo {video}")
        sys.exit(2)

    index = INDEX.format(
        lang="va", titol=escape(titol), video=video.name,
        activitats=render_activitats(activitats),
        te_activitats="true" if activitats else "false")
    manifest = MANIFEST.format(titol=escape(titol), video=video.name)

    with zipfile.ZipFile(zip_desti, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("imsmanifest.xml", manifest)
        z.writestr("index.html", index)
        z.writestr("scorm_api.js", SCORM_JS)
        z.write(video, video.name)

    print(f"Paquet SCORM 1.2 generat: {zip_desti}")
    print(f"Títol: {titol} · vídeo: {video.name} · activitats: {len(activitats)}")
    print("Puja el ZIP com a paquet SCORM a la teua plataforma (Moodle: Afig activitat → SCORM).")


if __name__ == "__main__":
    main()
