# -*- coding: utf-8 -*-
"""
Munta el vídeo formatiu a partir del guió JSON: veu, targetes, intro/outro,
subtítols i format d'eixida (píndola, tutorial o reel).

Ús:
    python editar_video.py guio.json carpeta_sortida [opcions]

Opcions:
    --format pindola|tutorial|reel   Relació d'aspecte i durada (per defecte, la del guió)
    --audio  carpeta_audio           Carpeta amb els mp3 i audio_manifest.json (de generar_veu.py)
    --subtitols fitxer.srt           Subtítols a cremar (si no, es generen a partir del guió)
    --sense-veu                      No usa veu; pista silenciosa (per a provar el muntatge)

Dos modes automàtics:
  · Si el guió té "video_base" i el fitxer existix: usa eixe vídeo com a imatge, li posa
    la veu, rètols de secció (lower-third), intro/outro i subtítols.
  · Si no hi ha vídeo base: genera un vídeo de TARGETES a pantalla completa, una per secció,
    amb la durada de la seua veu.

Requisits: ffmpeg i ffprobe. La generació de veu és a banda (scripts/generar_veu.py).
"""
import json
import subprocess
import sys
import tempfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
ASSETS = RAIZ / "assets"

FORMATS = {
    "pindola": (1920, 1080),
    "tutorial": (1920, 1080),
    "reel": (1080, 1920),
}
PARAULES_PER_SEGON = 2.5
BG = "0x1F3864"      # blau corporatiu
BG2 = "0x2E5090"

FONTS_CANDIDATES = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    "C:/Windows/Fonts/arial.ttf",
    "C:/Windows/Fonts/segoeui.ttf",
]
FONTS_BOLD = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf",
    "C:/Windows/Fonts/arialbd.ttf",
]


def primera_font(cands):
    for f in cands:
        if Path(f).exists():
            return f
    return cands[0]


FONT = primera_font(FONTS_CANDIDATES)
FONT_BOLD = primera_font(FONTS_BOLD)


def ff(args):
    """Executa ffmpeg silenciós i llança si falla."""
    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error"] + args
    subprocess.run(cmd, check=True)


def durada(cami):
    out = subprocess.run(
        ["ffprobe", "-v", "quiet", "-show_entries", "format=duration",
         "-of", "csv=p=0", str(cami)], capture_output=True, text=True)
    try:
        return round(float(out.stdout.strip()), 3)
    except ValueError:
        return None


def esc(text):
    """Escapa el text per a un fitxer de drawtext (usem textfile=, mínim escapat)."""
    return (text or "").replace("\r", "")


def targeta_clip(titol, punts, dur, dims, sortida, fons=BG):
    """Genera un clip de targeta a pantalla completa (color + títol + punts)."""
    w, h = dims
    tmp = Path(tempfile.mkdtemp())
    filtres = [f"color=c={fons}:s={w}x{h}:d={dur}:r=30[bg]"]
    cadena = "[bg]"
    mida_titol = int(h * 0.075)
    mida_punt = int(h * 0.042)

    (tmp / "titol.txt").write_text(esc(titol), encoding="utf-8")
    filtres.append(
        f"{cadena}drawtext=fontfile='{FONT_BOLD}':textfile='{tmp/'titol.txt'}':"
        f"fontcolor=white:fontsize={mida_titol}:x=(w-text_w)/2:"
        f"y=h*0.30:line_spacing=12[t]")
    cadena = "[t]"

    for i, p in enumerate(punts or []):
        (tmp / f"p{i}.txt").write_text("•  " + esc(p), encoding="utf-8")
        y = f"h*0.48+{i}*{int(mida_punt*1.7)}"
        seg = f"{cadena}drawtext=fontfile='{FONT}':textfile='{tmp/f'p{i}.txt'}':" \
              f"fontcolor=0xEFEFEF:fontsize={mida_punt}:x=w*0.18:y={y}[p{i}]"
        filtres.append(seg)
        cadena = f"[p{i}]"

    filtre = ";".join(filtres)
    ff(["-f", "lavfi", "-i", f"anullsrc=r=48000:cl=stereo:d={dur}",
        "-filter_complex", filtre, "-map", cadena, "-map", "0:a",
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest",
        str(sortida)])
    return sortida


def concat(clips, sortida):
    llista = sortida.parent / "concat_list.txt"
    llista.write_text("".join(f"file '{c.resolve()}'\n" for c in clips), encoding="utf-8")
    ff(["-f", "concat", "-safe", "0", "-i", str(llista), "-c", "copy", str(sortida)])


def concat_reencode(clips, sortida, dims):
    """Concatena reescalant tot a les mateixes dimensions (per si venen de fonts diferents)."""
    w, h = dims
    entrades = []
    for c in clips:
        entrades += ["-i", str(c)]
    filtres = []
    for i in range(len(clips)):
        filtres.append(
            f"[{i}:v]scale={w}:{h}:force_original_aspect_ratio=decrease,"
            f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1[v{i}]")
    cadena = "".join(f"[v{i}][{i}:a]" for i in range(len(clips)))
    filtre = ";".join(filtres) + ";" + cadena + f"concat=n={len(clips)}:v=1:a=1[v][a]"
    ff(entrades + ["-filter_complex", filtre, "-map", "[v]", "-map", "[a]",
                   "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", str(sortida)])


def concat_audio(fitxers, sortida):
    llista = sortida.parent / "audio_list.txt"
    llista.write_text("".join(f"file '{Path(f).resolve()}'\n" for f in fitxers), encoding="utf-8")
    ff(["-f", "concat", "-safe", "0", "-i", str(llista), "-c", "copy", str(sortida)])


def crema_subtitols(entrada, srt, sortida, dims):
    w, h = dims
    mida = 24 if w > h else 20
    estil = (f"FontName=DejaVu Sans,Fontsize={mida},PrimaryColour=&H00FFFFFF,"
             f"OutlineColour=&H00000000,BorderStyle=1,Outline=2,Shadow=0,"
             f"Alignment=2,MarginV={int(h*0.06)}")
    srt_esc = str(srt).replace("\\", "/").replace(":", "\\:")
    ff(["-i", str(entrada), "-vf", f"subtitles='{srt_esc}':force_style='{estil}'",
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "copy", str(sortida)])


def reemmarca_reel(entrada, sortida):
    """Converteix un vídeo horitzontal en 9:16 amb fons difuminat."""
    w, h = FORMATS["reel"]
    vf = (f"split[a][b];[a]scale={w}:{h}:force_original_aspect_ratio=increase,"
          f"crop={w}:{h},boxblur=20[bg];"
          f"[b]scale={w}:-1:force_original_aspect_ratio=decrease[fg];"
          f"[bg][fg]overlay=(W-w)/2:(H-h)/2")
    ff(["-i", str(entrada), "-vf", vf, "-c:v", "libx264", "-pix_fmt", "yuv420p",
        "-c:a", "copy", str(sortida)])


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    guio = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    sortida = Path(sys.argv[2])
    sortida.mkdir(parents=True, exist_ok=True)

    fmt = guio.get("format", "pindola")
    if "--format" in sys.argv:
        fmt = sys.argv[sys.argv.index("--format") + 1]
    dims = FORMATS.get(fmt, FORMATS["pindola"])
    sense_veu = "--sense-veu" in sys.argv

    carpeta_audio = None
    if "--audio" in sys.argv:
        carpeta_audio = Path(sys.argv[sys.argv.index("--audio") + 1])

    # durada de cada secció (veu real o estimada)
    dur_seccio = {}
    ordre_audio = []
    manifest = {}
    if carpeta_audio and (carpeta_audio / "audio_manifest.json").exists():
        for m in json.loads((carpeta_audio / "audio_manifest.json").read_text(encoding="utf-8")):
            manifest[m["id"]] = m
    for sec in guio.get("seccions", []):
        if sec["id"] in manifest and manifest[sec["id"]].get("durada"):
            dur_seccio[sec["id"]] = manifest[sec["id"]]["durada"]
            ordre_audio.append(carpeta_audio / manifest[sec["id"]]["fitxer"])
        else:
            paraules = len((sec.get("text") or "").split())
            dur_seccio[sec["id"]] = max(2.0, round(paraules / PARAULES_PER_SEGON, 2))

    # ---- mode targetes (sense vídeo base) ----
    base = guio.get("video_base")
    base_cami = (Path(sys.argv[1]).parent / base) if base else None
    usa_targetes = not (base_cami and base_cami.exists())

    clips = []
    if usa_targetes:
        # intro
        intro = guio.get("intro", {})
        clips.append(targeta_clip(intro.get("titol", guio.get("titol", "")),
                                  [intro.get("subtitol", "")] if intro.get("subtitol") else [],
                                  2.5, dims, sortida / "intro.mp4", fons=BG2))
        for i, sec in enumerate(guio.get("seccions", [])):
            t = sec.get("targeta", {})
            clips.append(targeta_clip(t.get("titol", ""), t.get("punts", []),
                                      dur_seccio[sec["id"]], dims,
                                      sortida / f"sec_{i}.mp4"))
        outro = guio.get("outro", {})
        clips.append(targeta_clip("Gràcies!",
                                  [outro.get("credits", ""), outro.get("llicencia", "")],
                                  3.0, dims, sortida / "outro.mp4", fons=BG2))
        video_mut = sortida / "video_mut.mp4"
        concat_reencode(clips, video_mut, dims)

        # àudio: veu concatenada o silenci
        final_sense_subs = sortida / "video_amb_veu.mp4"
        if ordre_audio and not sense_veu:
            veu = sortida / "veu.m4a"
            concat_audio(ordre_audio, veu)
            ff(["-i", str(video_mut), "-i", str(veu), "-map", "0:v", "-map", "1:a",
                "-c:v", "copy", "-c:a", "aac", "-shortest", str(final_sense_subs)])
        else:
            final_sense_subs = video_mut
    else:
        # ---- mode vídeo base ----
        w, h = dims
        escala = (f"scale={w}:{h}:force_original_aspect_ratio=decrease,"
                  f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1")
        video_mut = sortida / "base_fmt.mp4"
        if fmt == "reel":
            reemmarca_reel(base_cami, video_mut)
        else:
            ff(["-i", str(base_cami), "-vf", escala, "-c:v", "libx264",
                "-pix_fmt", "yuv420p", "-c:a", "aac", str(video_mut)])

        final_sense_subs = sortida / "video_amb_veu.mp4"
        if ordre_audio and not sense_veu:
            veu = sortida / "veu.m4a"
            concat_audio(ordre_audio, veu)
            ff(["-i", str(video_mut), "-i", str(veu), "-map", "0:v", "-map", "1:a",
                "-c:v", "copy", "-c:a", "aac", "-shortest", str(final_sense_subs)])
        else:
            final_sense_subs = video_mut

    # ---- subtítols ----
    srt = None
    if "--subtitols" in sys.argv:
        srt = Path(sys.argv[sys.argv.index("--subtitols") + 1])
    else:
        srt = sortida / "subtitols.srt"
        subprocess.run([sys.executable, str(RAIZ / "scripts" / "generar_subtitols.py"),
                        sys.argv[1], str(srt)] +
                       (["--audio", str(carpeta_audio)] if carpeta_audio else []),
                       check=False)

    final = sortida / "video.mp4"
    if srt and Path(srt).exists() and Path(srt).stat().st_size > 0:
        crema_subtitols(final_sense_subs, srt, final, dims)
    else:
        ff(["-i", str(final_sense_subs), "-c", "copy", str(final)])

    d = durada(final)
    print(f"\nVídeo generat: {final}")
    print(f"Format: {fmt} ({dims[0]}x{dims[1]}) · durada: {d} s")
    if usa_targetes:
        print("Mode: targetes a pantalla completa (sense vídeo base).")
    else:
        print(f"Mode: vídeo base ({base_cami.name}).")
    if sense_veu or not ordre_audio:
        print("AVÍS: sense veu. Genera-la amb generar_veu.py i torna a muntar amb --audio.")


if __name__ == "__main__":
    main()
