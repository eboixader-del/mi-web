# -*- coding: utf-8 -*-
"""
Genera la veu (fitxers mp3) de cada secció d'un guió JSON amb l'API d'ElevenLabs.

Ús:
    python generar_veu.py guio.json carpeta_audio [--veu <id_o_nom>] [--model <model>]

Requisits:
    pip install requests
    Variable d'entorn ELEVENLABS_API_KEY amb la clau de l'API.

Genera un fitxer <id_seccio>.mp3 per secció i un manifest audio_manifest.json amb
la durada de cada tall (per a sincronitzar subtítols i targetes al muntatge).

CONSENTIMENT: clonar la veu d'una persona real requerix el seu permís. Usa només
veus pròpies o veus per a les quals tingues autorització.
"""
import json
import os
import subprocess
import sys
from pathlib import Path

API = "https://api.elevenlabs.io/v1"

# Mapatge de noms amfamilies a IDs públics d'ElevenLabs (ajusta'ls al teu compte).
VEUS = {
    "Rachel": "21m00Tcm4TlvDq8ikWAM",
    "Antoni": "ErXwobaYiN019PkySvjV",
    "Bella": "EXAVITQu4vr4xnSDxMaL",
}


def durada_mp3(cami):
    """Durada en segons d'un mp3, via ffprobe."""
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "quiet", "-show_entries", "format=duration",
             "-of", "csv=p=0", str(cami)],
            capture_output=True, text=True, check=True)
        return round(float(out.stdout.strip()), 3)
    except Exception:
        return None


def sintetitza(text, veu_id, model, clau, desti):
    import requests
    url = f"{API}/text-to-speech/{veu_id}"
    cos = {
        "text": text,
        "model_id": model,
        "voice_settings": {"stability": 0.5, "similarity_boost": 0.75},
    }
    cap = {"xi-api-key": clau, "Content-Type": "application/json",
           "Accept": "audio/mpeg"}
    r = requests.post(url, json=cos, headers=cap, timeout=120)
    if r.status_code != 200:
        raise RuntimeError(f"ElevenLabs {r.status_code}: {r.text[:200]}")
    Path(desti).write_bytes(r.content)


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    guio = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    carpeta = Path(sys.argv[2])
    carpeta.mkdir(parents=True, exist_ok=True)

    veu = guio.get("veu", {}).get("veu_id", "Rachel")
    model = guio.get("veu", {}).get("model", "eleven_multilingual_v2")
    if "--veu" in sys.argv:
        veu = sys.argv[sys.argv.index("--veu") + 1]
    if "--model" in sys.argv:
        model = sys.argv[sys.argv.index("--model") + 1]
    veu_id = VEUS.get(veu, veu)  # accepta nom conegut o ID directe

    clau = os.environ.get("ELEVENLABS_API_KEY")
    if not clau:
        print("AVÍS: falta ELEVENLABS_API_KEY. No es pot generar la veu.")
        print("      Defineix la variable d'entorn i torna a executar, o continua")
        print("      amb subtítols i targetes sense veu.")
        sys.exit(3)

    manifest = []
    for sec in guio.get("seccions", []):
        text = (sec.get("text") or "").strip()
        if not text:
            continue
        desti = carpeta / f"{sec['id']}.mp3"
        print(f"Generant veu: {sec['id']} ...", end=" ", flush=True)
        try:
            sintetitza(text, veu_id, model, clau, desti)
            dur = durada_mp3(desti)
            manifest.append({"id": sec["id"], "fitxer": desti.name, "durada": dur})
            print(f"ok ({dur} s)")
        except Exception as e:
            print(f"ERROR: {e}")

    (carpeta / "audio_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    total = sum(m["durada"] or 0 for m in manifest)
    print(f"\nFet: {len(manifest)} talls, {round(total, 1)} s de veu en total.")
    print(f"Manifest: {carpeta / 'audio_manifest.json'}")


if __name__ == "__main__":
    main()
