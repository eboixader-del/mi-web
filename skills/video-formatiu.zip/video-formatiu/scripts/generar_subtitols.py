# -*- coding: utf-8 -*-
"""
Genera un fitxer .srt a partir del guió JSON.

Ús:
    python generar_subtitols.py guio.json subtitols.srt [--audio carpeta_audio]

Si es passa --audio amb un audio_manifest.json (generat per generar_veu.py), usa la
durada real de cada secció. Si no, estima la durada a partir del nombre de paraules
(~2,5 paraules/segon). Cada secció es partix en blocs de màxim 2 línies i ~42
caràcters per línia perquè els subtítols siguen llegibles.
"""
import json
import sys
from pathlib import Path

PARAULES_PER_SEGON = 2.5
MAX_CAR = 42


def parteix_linies(text, max_car=MAX_CAR):
    paraules = text.split()
    linies, actual = [], ""
    for p in paraules:
        if len((actual + " " + p).strip()) <= max_car:
            actual = (actual + " " + p).strip()
        else:
            if actual:
                linies.append(actual)
            actual = p
    if actual:
        linies.append(actual)
    return linies


def blocs_de_seccio(text):
    """Divideix una secció en blocs de subtítol de com a molt 2 línies."""
    linies = parteix_linies(text)
    blocs = []
    for i in range(0, len(linies), 2):
        blocs.append("\n".join(linies[i:i + 2]))
    return blocs or [text]


def marca(segons):
    h = int(segons // 3600)
    m = int((segons % 3600) // 60)
    s = int(segons % 60)
    ms = int(round((segons - int(segons)) * 1000))
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    guio = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    desti = Path(sys.argv[2])

    durades = {}
    if "--audio" in sys.argv:
        carpeta = Path(sys.argv[sys.argv.index("--audio") + 1])
        man = carpeta / "audio_manifest.json"
        if man.exists():
            for m in json.loads(man.read_text(encoding="utf-8")):
                durades[m["id"]] = m.get("durada")

    linies_srt = []
    n = 0
    t = 0.0
    for sec in guio.get("seccions", []):
        text = (sec.get("text") or "").strip()
        if not text:
            continue
        dur = durades.get(sec["id"]) or len(text.split()) / PARAULES_PER_SEGON
        blocs = blocs_de_seccio(text)
        # repartix la durada de la secció entre els seus blocs, proporcional als caràcters
        pesos = [max(1, len(b.replace("\n", " "))) for b in blocs]
        total_pes = sum(pesos)
        inici = t
        for b, pes in zip(blocs, pesos):
            n += 1
            db = dur * pes / total_pes
            linies_srt.append(str(n))
            linies_srt.append(f"{marca(inici)} --> {marca(inici + db)}")
            linies_srt.append(b)
            linies_srt.append("")
            inici += db
        t += dur

    desti.write_text("\n".join(linies_srt), encoding="utf-8")
    print(f"Subtítols generats: {desti} ({n} blocs, {round(t, 1)} s).")
    if not durades:
        print("AVÍS: durada estimada per paraules (sense àudio real). "
              "Passa --audio per a sincronitzar amb la veu generada.")


if __name__ == "__main__":
    main()
