# Copia (o actualitza) l'habilitat a la carpeta d'habilitats personals.
# Ús:  powershell -ExecutionPolicy Bypass -File scripts\instalar.ps1

$origen  = Split-Path -Parent $PSScriptRoot
$destino = Join-Path $env:USERPROFILE ".claude\skills\video-formatiu"

New-Item -ItemType Directory -Force (Split-Path -Parent $destino) | Out-Null
if (Test-Path $destino) { Remove-Item $destino -Recurse -Force }
Copy-Item -Recurse -Force $origen $destino

Write-Host "Habilitat instal·lada en: $destino"
Write-Host "Recorda: cal ffmpeg al PATH i la variable ELEVENLABS_API_KEY per a la veu."
Write-Host "Reinicia l'aplicació perquè detecte l'habilitat."
