# Guió i estil dels vídeos formatius

## To i llengua
- Per defecte, **valencià** (AVL, variant septentrional). Castellà només si es demana.
- To proper però rigorós: parles a una persona, no a una audiència abstracta.
- Frases curtes, una idea per frase. Evita subordinades llargues i incisos.
- Verbs en acció ("obri", "escriu", "fixa't en…"), no en abstracte.

## Durada per format
| Format | Durada objectiu | Ritme de locució |
| --- | --- | --- |
| Píndola | 1–3 min (≈150–450 paraules) | ~150 paraules/min |
| Tutorial | 3–8 min, amb capítols | ~140 paraules/min, pauses entre passos |
| Reel | 20–60 s (≈50–150 paraules) | Ràpid, ganxo als 3 primers segons |

## Estructura recomanada
1. **Ganxo** (0–5 s): una pregunta o promesa concreta. "Vols posar veu a un vídeo sense gravar-te? Mira açò."
2. **Context** (breu): què vas a mostrar i per què val la pena.
3. **Desenvolupament**: passos numerats (tutorial) o idees clau (píndola).
4. **Tancament**: resum d'una frase + crida a l'acció ("prova-ho", "ho tens als recursos").

## Targetes de text
- Una idea per targeta. Títol de 3–6 paraules; punts de màxim una línia.
- Apareixen quan la veu les nomena, no abans.
- Usos típics: títol de secció, definició clau, cita, passos resumits, dades.

## Subtítols
- Màxim 2 línies i ~42 caràcters per línia.
- Sincronitzats amb la veu; cada bloc, entre 1 i 5 segons.
- Al reel, subtítols grans i cremats (sempre visibles, perquè es veu sense so).

## Errors a evitar
- Paràgrafs sencers en una targeta.
- Locució monòtona sense pauses entre idees.
- Música que tape la veu.
- Reels en horitzontal o sense subtítols.
