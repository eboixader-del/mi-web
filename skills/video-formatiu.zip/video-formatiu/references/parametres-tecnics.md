# Paràmetres tècnics per format

## Resolucions i relació d'aspecte
| Format | Resolució | Aspecte | FPS |
| --- | --- | --- | --- |
| Píndola / Tutorial | 1920×1080 | 16:9 | 30 |
| Reel | 1080×1920 | 9:16 | 30 |

## Vídeo
- Còdec: H.264 (`libx264`), perfil `high`, `-pix_fmt yuv420p` (compatibilitat màxima).
- Bitrate orientatiu: 8 Mbps a 1080p; CRF 20 si es prefereix qualitat constant.
- Àudio: AAC, 192 kbps, 48 kHz, estèreo.

## Targetes
- Fons: color corporatiu o imatge de `assets/`. Text centrat.
- Títol: 64–80 px (1080p). Cos: 40–48 px. Marge de seguretat: 8% per cada costat.
- Durada per defecte d'una targeta a pantalla completa: 3–4 s.

## Subtítols
- Tipografia llegible (DejaVu Sans / Liberation Sans). Contorn negre per a contrast.
- 1080p: cos ~28 px. Reel 9:16: cos ~40–48 px, situats al terç inferior.
- Format `.srt`; es poden cremar (`burn-in`) o deixar com a pista separada.

## Intro / Outro
- Intro: 2–3 s amb logo + títol del vídeo.
- Outro: 3–4 s amb crèdits, llicència i crida a l'acció.

## Recomanacions de captura (per a l'usuari)
- Gravar la pantalla a 1080p, 30 fps, cursor visible.
- Si el vídeo original és vertical de mòbil, ja va bé per a reel; si és horitzontal, per a reel es
  reemmarca amb fons difuminat (l'script ho fa amb `--format reel`).
