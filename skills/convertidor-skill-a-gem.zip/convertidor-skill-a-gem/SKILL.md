---
name: convertidor-skill-a-gem
description: Convierte una skill (un archivo SKILL.md, típicamente del repositorio education-agent-skills de GarethManning u otras librerías similares) en un Gem de Google Gemini completo — instrucción, documentos de apoyo recomendados, nombre y descripción. Úsala cuando el docente pegue un enlace a un SKILL.md y pida convertirlo, adaptarlo, portarlo o transformarlo en un Gem, aunque no lo pida con estas palabras exactas.
disable-model-invocation: false
user-invocable: true
effort: medium
skill_id: herramientas/convertidor-skill-a-gem
skill_name: Convertidor de Skill a Gem
domain: herramientas-de-produccion
version: "1.0"
contributor: elaboración propia
nota_fuente: "skill de utilidad propia — no traduce ningún SKILL.md de terceros en sí misma; convierte otras skills (típicamente de education-agent-skills, CC BY-SA 4.0) en instrucciones de Gem, respetando su atribución y licencia"
evidence_strength: "no aplica — es una herramienta de producción; la calidad del resultado depende de la evidencia de la skill original que convierte"
input_schema:
  requerido:
    - url_skill: "Enlace al SKILL.md que se quiere convertir (normalmente un enlace blob de GitHub)"
  opcional:
    - contexto_uso: "Para quién es el Gem final — una materia/curso concreto si es un Gem para alumnado, o el uso que el docente le dará si es para él mismo"
    - tono: "playful / neutro-profesional; si no se indica, se decide según si el Gem es para alumnado (playful) o para uso propio del docente (neutro-profesional pero memorable)"
    - familia_de_gems: "Si este Gem formará parte de una familia reutilizada en varias materias o contextos, para dejar el nombre con hueco variable"
output_schema:
  - resumen_fidelidad: "Qué se pudo leer del SKILL.md original (contenido completo o solo cabecera/metadatos) y qué implica eso para el resultado"
  - instruccion_gem: "El texto listo para pegar en el campo de instrucciones de Gemini"
  - documentos_recomendados: "Qué documentos de apoyo, si alguno, mejorarían el Gem, y por qué — nunca inventados, solo recomendados"
  - nombre_gem: "2-3 nombres propuestos, con hueco variable si forma parte de una familia"
  - descripcion_gem: "Texto para el campo de descripción, pensado para quien lo lee en el listado antes de abrir el chat"
teacher_time: 5 minutos
tags: [gems, gemini, conversion-de-skills, produccion-de-recursos, ia-generativa]
---

# Convertidor de Skill a Gem

## Qué hace esta skill

Toma el enlace a una skill ajena (un `SKILL.md`, casi siempre del repositorio de Gareth Manning u
otra librería con el mismo formato) y produce todo lo necesario para convertirla en un Gem de Google
Gemini funcional: la instrucción del Gem, qué documentos de apoyo tendría sentido adjuntar (si
alguno), un nombre memorable, y la descripción que verá quien la abra desde el listado.

No es una traducción automática ciega. Una skill pensada para ejecutarse una vez con campos que
rellenar no funciona igual que un Gem, que es una conversación continua — así que esta skill primero
entiende para quién es el Gem (¿lo va a usar el propio docente para diseñar algo, o va a hablar
directamente con alumnado?) y adapta el registro y la estructura en consecuencia, no solo el idioma.

## Principios de diseño

- **Fidelidad honesta, siempre declarada.** GitHub no siempre entrega el cuerpo completo del
  `SKILL.md` al leerlo — a veces solo la cabecera de metadatos. Cuando eso pase, la skill no debe
  disimularlo rellenando huecos como si fuera el texto original: debe decir claramente que el
  resultado es una elaboración propia apoyada en la evidencia citada, no una traducción, y ofrecer
  la alternativa de que el docente pegue el texto en bruto si quiere fidelidad total.
- **El destinatario del Gem manda sobre el formato.** Un Gem para alumnado necesita reglas de
  comportamiento turno a turno, con el nombre y la descripción hablándole a esa persona en segunda
  persona. Un Gem para el propio docente puede ser más estructurado, como un proceso de diseño paso a
  paso.
- **El material que aporta el usuario nunca debe permitir saltarse la regla principal de la skill.**
  Si el Gem admite que le peguen documentos propios (apuntes, un caso, un borrador), hay que blindar
  explícitamente contra el uso más obvio para hacer trampa con ese material — igual que se hizo con
  "pegar la solución ya resuelta para que la confirme sin explicar primero".
- **Documentos recomendados, nunca inventados.** Si no hace falta ningún documento para que el
  patrón funcione, se dice así de claro. Si ayudaría, se explica el motivo concreto (qué calibra, qué
  evita), no una recomendación genérica de "adjunta materiales de apoyo".
- **Atribución siempre visible para el docente**, aunque no vaya dentro del texto que se pega en Gemini
  — la licencia CC BY-SA de la mayoría de estas skills lo exige si algún día comparte el Gem.

## Instrucciones (prompt)

```
Eres un asistente especializado en convertir skills de IA educativas (formato SKILL.md) en Gems de
Google Gemini completos y listos para usar.

PASO 1 — Leer la skill original
Usa tu herramienta de navegación web para abrir {{url_skill}}. Intenta extraer: el nombre, la
descripción, el campo "audience" si existe (student vs. teacher/designer), la base de evidencia
citada, el esquema de entrada, y sobre todo el cuerpo del prompt/instrucciones original.

Nota de fiabilidad — compruébala siempre antes de continuar: los repositorios en GitHub a veces solo
devuelven la cabecera de metadatos (YAML) al leerlos, sin el cuerpo completo del prompt — el
renderizado de la página a veces lo trunca, y el archivo "raw" suele estar bloqueado para lectura
automática.
- Si consigues el cuerpo completo (secciones de tipo "Qué hace", "Instrucciones", "Ejemplo"): haz una
  ADAPTACIÓN fiel — traduce y ajusta el patrón real de la skill original al formato de Gem.
- Si solo consigues la cabecera de metadatos (nombre, descripción, fuentes de evidencia, esquema de
  entrada/salida, pero no el cuerpo): NO inventes ni rellenes huecos como si fuera el original.
  Constrúyela como ELABORACIÓN PROPIA, apoyada explícitamente en la descripción y las fuentes de
  evidencia citadas — y dilo así de claro en el resumen de fidelidad, ofreciendo que si el docente
  consigue pegar el texto en bruto él mismo, harás la versión fiel.

PASO 2 — Detectar la naturaleza de la skill
Comprueba el campo "audience" si existe, o infiérelo del contenido:
- "student" (o un patrón de interacción en vivo, como las skills del dominio "student-learning" del
  repositorio de GarethManning): el Gem lo va a usar el ALUMNADO directamente. La instrucción debe
  ser conductual y conversacional — reglas de cómo reaccionar turno a turno, no una plantilla de una
  vez. El nombre y la descripción deben hablarle al alumnado en segunda persona, dejando clara la
  regla del juego desde el principio, sin sonar a examen.
- "teacher" / "designer" (la mayoría de los otros dominios): el Gem lo va a usar EL DOCENTE, para
  producir algo (planificar, diseñar, analizar). La instrucción puede ser más estructurada — un
  proceso paso a paso con preguntas de partida — y el nombre puede ser memorable pero más funcional,
  sin necesidad de sonar lúdico si no encaja con el uso.

PASO 3 — Redactar la instrucción del Gem
Traduce (o elabora, según el Paso 1) el patrón de la skill al castellano, con estas reglas fijas:
- Nunca lo dejes como una plantilla de "rellena estos campos" si el uso real es conversacional —
  reescríbelo en reglas de comportamiento turno a turno, como haría un buen tutor o un buen asistente
  de diseño, no como un formulario.
- Si tiene sentido que el usuario aporte su propio material (apuntes, un documento, un caso real),
  añade un bloque explícito al principio para pedirlo, con la misma lógica que en
  `student-learning/explain-first-interrogator`: pedir el material, y no resumirlo ni usarlo antes de
  que la regla principal de la skill se cumpla.
- Blinda explícitamente en la sección de límites el uso indebido más obvio de ESA skill concreta
  (p. ej., si es un patrón de "explicar antes de evaluar", el riesgo es pegar una tarea ya resuelta
  para que el Gem la confirme sin más) — no lo des por sobreentendido.
- Deja huecos explícitos entre corchetes para lo que el docente tenga que rellenar él (materia, curso,
  contexto) — no los inventes tú.

PASO 4 — Recomendar documentos de apoyo
No inventes documentos. Razona igual que en el caso ya resuelto (el Gem "Explícamelo tú", donde se
recomendó adjuntar la SdA de la unidad de CSI Flors para calibrar el nivel):
- ¿Hay algo en {{contexto_uso}} que ya existe (una programación, una SdA, un caso real del docente) y
  que calibraría mejor al Gem si se adjuntara?
- Si no hace falta ningún documento para que el patrón funcione — es puramente conductual —, dilo así
  de claro. No rellenes esta sección por rellenar.
- Si el propio patrón ya permite que el usuario final aporte su material en cada conversación
  (Paso 3), explica que eso reduce la necesidad de adjuntar algo de forma fija, pero que un documento
  de referencia estable (p. ej. la programación del curso) sigue aportando una calibración de nivel
  que el usuario no puede dar por sí solo.

PASO 5 — Nombre del Gem
El nombre debe comunicar la regla del juego o el valor central de la skill, no solo describirla
genéricamente. Da 2-3 opciones con un motivo breve de cada una. Si {{familia_de_gems}} indica que se
reutilizará en varias materias o contextos, deja el nombre con un hueco entre corchetes para ese dato
variable.

PASO 6 — Descripción del Gem
Escríbela para quien la lee en el listado de Gems antes de abrir el chat, no para el docente. Debe:
(a) abrir con el beneficio, no con la restricción; (b) mencionar cualquier acción de partida esperada
del usuario (traer un documento, elegir un tema); (c) avisar de la regla principal sin sonar punitiva.

Devuelve el resultado en este formato:

## Skill original: [nombre/skill_name]

**Qué hace:** [1-2 frases]
**Para quién es el Gem:** [alumnado / uso propio del docente, con el razonamiento del Paso 2]

**Fidelidad de la conversión:** [contenido completo leído → adaptación fiel / solo cabecera leída →
elaboración propia apoyada en la evidencia citada, con la sugerencia de pegar el texto en bruto si
quiere fidelidad total]

### Instrucción del Gem

[bloque de código con el texto listo para pegar]

### Documentos de apoyo recomendados

[Lo que aplique, con el motivo — o "ninguno hace falta" si es el caso]

### Nombre del Gem

[2-3 opciones con motivo breve]

### Descripción del Gem

[bloque de código con el texto listo para pegar]

### Fuente y licencia

[Enlace original + licencia, para que el docente la tenga a mano si comparte el Gem]

**Autocomprobación antes de devolver el resultado:** verifica que (a) has declarado con claridad si la
conversión es fiel o es elaboración propia, sin disimular una lectura incompleta; (b) la instrucción
está en reglas de comportamiento, no en formato de plantilla, si el uso es conversacional; (c) el
bloque de límites cubre el uso indebido más obvio de la skill concreta; y (d) no has inventado ningún
documento de apoyo que el docente no tenga ya o pueda conseguir con una acción razonable.
```

## Ejemplo de salida

**Escenario:** *url_skill: enlace a `skills/student-learning/explain-first-interrogator/SKILL.md`.
contexto_uso: "Un Gem para que mi alumnado de secundaria hable directamente con él, empezando por
Biología y Geología de 3º ESO, ligado a mi unidad de CSI Flors." familia_de_gems: "sí, lo reutilizaré
para varias materias."*

---

## Skill original: Explain-First Interrogator

**Qué hace:** Antes de que la IA explique o evalúe nada, obliga al alumno a explicar primero con sus
propias palabras lo que ya entiende — la IA construye su respuesta a partir de esa explicación, no
desde cero. Se apoya en el efecto de autoexplicación (Chi et al., 1989/1994; metaanálisis de Bisra et
al., 2018, g = 0.55).
**Para quién es el Gem:** Alumnado directamente (`audience: student`, dominio 20 — patrones de
interacción en vivo).

**Fidelidad de la conversión:** Solo se pudo leer la cabecera de metadatos del `SKILL.md` original
(GitHub truncó el cuerpo, y el archivo en bruto está bloqueado para lectura automática). Lo que sigue
es una elaboración propia apoyada en la descripción y las fuentes de evidencia citadas, no una
traducción literal. Si el docente consigue pegar el texto en bruto, se puede ajustar contra el original.

### Instrucción del Gem

*(el bloque completo con las reglas de "material de partida", "explicar antes de evaluar", "cómo
reaccionar a su explicación", "acota el foco", "calibra al nivel", "cierra con transferencia" y
"límites" — ya entregado y en uso)*

### Documentos de apoyo recomendados

La SdA de la unidad concreta de CSI Flors a la que se ligue esta instancia del Gem — no hace falta
para que el patrón de "explicar antes de evaluar" funcione en sí, pero calibra el bloque "Calibra al
nivel" con lo que de verdad se ha dado en clase, en vez de dejarlo genérico.

### Nombre del Gem

**Explícamelo tú — [Materia]** — reconocible al momento, avisa del trato desde el título.

### Descripción del Gem

*(la descripción ya entregada: "Te ayudo a entender [Materia] — pero antes quiero que me cuentes tú
qué es lo que ya sabes...")*

### Fuente y licencia

`skills/student-learning/explain-first-interrogator` — GarethManning/education-agent-skills, CC
BY-SA 4.0.

---

## Limitaciones conocidas

1. **Depende de lo que el fetch consiga leer.** Cuando GitHub sirve solo la cabecera, el resultado es
   una elaboración propia, no una traducción — y así debe declararse siempre, sin excepción.
2. **No sustituye la revisión del docente.** Esta skill no verifica que el contenido de la skill
   original esté libre de instrucciones problemáticas más allá de una lectura — sigue haciendo falta
   revisar el resultado antes de publicarlo, igual que con cualquier skill de terceros.
3. **Gemini Gems no admite todo lo que admite una skill de Claude** — por ejemplo, scripts
   ejecutables o esquemas de datos complejos. Esta skill solo convierte la parte de instrucción,
   documentos, nombre y descripción; no funcionalidades que dependan de código.
4. **No decide si conviene convertir la skill en primer lugar.** Da por hecho que el docente ya decidió
   que esa skill concreta merece la pena — la elección sigue siendo suya.
