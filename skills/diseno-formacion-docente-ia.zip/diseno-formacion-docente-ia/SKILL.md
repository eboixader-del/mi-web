---
name: diseno-formacion-docente-ia
description: Diseña una sesión o un itinerario de formación docente en IA, mapeado al Marco de Competencias de IA para Docentes de la UNESCO (5 dimensiones × 3 niveles). Úsala cuando el docente quiera preparar una formación, un itinerario o una sesión para profesorado sobre IA — para su propio centro, para FECEVAL, Escuelas Católicas o cualquier otro encargo de formador — aunque no lo pida con estas palabras exactas.
disable-model-invocation: false
user-invocable: true
effort: medium
skill_id: professional-learning/diseno-formacion-docente-ia
skill_name: Diseñador de Formación Docente en IA
domain: desarrollo-profesional-docente
version: "1.0"
contributor: elaboración propia a partir del Marco de Competencias de IA para Docentes de la UNESCO
nota_fuente: el marco de referencia (UNESCO, Miao & Cukurova) es de acceso abierto; esta skill traduce su matriz de competencias en un proceso de diseño formativo — no es una traducción de ningún SKILL.md de terceros
evidence_strength: moderada-alta — marco normativo internacional bien establecido; la traducción a actividades formativas concretas es elaboración propia, no validada empíricamente como tal
evidence_sources:
  - "UNESCO, Miao & Cukurova (2024, trad. española 2025) — AI competency framework for teachers / Marco de competencias de IA para docentes: 15 competencias en 5 dimensiones × 3 niveles de progresión (adquirir, profundizar, crear)"
  - "UNESCO, Miao, Shiohira & Lao (2024) — AI competency framework for students: referencia cruzada para comprobar que la formación docente prepara para lo que después se espera del alumnado"
input_schema:
  requerido:
    - grupo_destinatario: "Quién recibe la formación — un departamento, el claustro completo, equipo directivo, un centro externo... y su relación previa con la IA si se conoce"
    - contexto_objetivo: "Qué motiva esta formación — p. ej. arrancar el protocolo de uso de IAG del centro, formación general de inicio de curso, un encargo externo de consultoría"
    - tiempo_disponible: "Una sesión suelta (¿cuántas horas?) o un itinerario de varias sesiones (¿cuántas, con qué periodicidad?)"
  opcional:
    - nivel_partida: "Si ya se conoce el nivel del grupo en alguna dimensión; si no se indica, la skill propone un diagnóstico rápido antes de diseñar"
    - dimensiones_prioritarias: "Si se quiere priorizar alguna(s) de las 5 dimensiones; si no se indica, se seleccionan según el contexto"
output_schema:
  - diagnostico_rapido: "Preguntas o indicadores breves y observables para situar el nivel de partida del grupo, si no se conocía"
  - competencias_objetivo: "2-4 competencias del marco (no las 15), seleccionadas por relevancia al contexto y ajuste al tiempo disponible, con su enunciado"
  - itinerario: "Sesión a sesión (o desglose de una sola sesión): objetivo, actividad, materiales o preguntas de partida, duración orientativa"
  - evidencias_de_logro: "Cómo se sabe que el grupo alcanzó ese nivel — indicadores observables en su práctica, no un examen"
  - conexiones: "Qué materiales ya existentes (guías normativas, otras herramientas) encajan como recurso concreto en cada sesión"
chains_well_with:
  - mapa-limites-ia
teacher_time: 10 minutos
tags: [desarrollo-profesional-docente, formacion-de-formadores, unesco, competencias-ia, itinerario-formativo, pedagogia-ia]
---

# Diseñador de Formación Docente en IA

## Qué hace esta skill

Convierte la matriz de competencias del marco de la UNESCO para docentes en un plan de formación
concreto: qué sesiones dar, en qué orden, con qué actividad en cada una y qué evidencia observable
demuestra que el grupo ha avanzado. El marco original es una referencia — dice *qué* debería saber y
saber hacer el profesorado, no *cómo* enseñárselo en una sesión de dos horas un martes por la tarde.
Esta skill hace ese segundo paso.

La idea central, igual que en `mapa-limites-ia` pero aplicada a la formación de profesorado en vez de a
tareas de aula: no tiene sentido intentar cubrir las 5 dimensiones y los 3 niveles en una sola sesión.
Es mejor elegir 2-4 competencias realmente relevantes para el contexto y el tiempo disponible, y dejar
una evidencia de logro clara, que intentar un recorrido superficial por las 15.

## El marco de referencia: 15 competencias en 5 dimensiones × 3 niveles

| Dimensión | Adquirir | Profundizar | Crear |
|---|---|---|---|
| **1. Mentalidad centrada en el ser humano** | Agencia humana: la IA opera bajo control y dirección humana, nunca al revés | Rendición de cuentas humana: toda decisión educativa apoyada en IA sigue siendo responsabilidad del docente, no de la herramienta | Responsabilidad social: usar la IA para promover activamente equidad e impacto social positivo |
| **2. Ética de la IA** | Principios éticos: conocer las normas básicas — privacidad, no discriminación — que rigen el uso de la IA | Uso seguro y responsable: aplicar la IA en el aula protegiendo al alumnado y sus datos | Cocreación de normas éticas: participar en la elaboración de directrices de uso de IA del propio centro |
| **3. Fundamentos y aplicaciones de la IA** | Comprender qué es la IA y cómo puede aplicarse en educación, a nivel conceptual | Seleccionar y usar con criterio la herramienta de IA adecuada para cada necesidad | Adaptar o desarrollar soluciones propias de IA para personalizar la enseñanza |
| **4. Pedagogía de la IA** | Usar la IA como apoyo puntual en planificación, docencia o evaluación | Integrar la IA de forma coherente en la propia estrategia pedagógica, no como añadido suelto | Transformar la propia práctica docente apoyándose en un uso avanzado de la IA |
| **5. IA para el desarrollo profesional** | Usar la IA para evaluar y mejorar el propio desarrollo profesional | Usar la IA para impulsar el aprendizaje colaborativo entre compañeros y el desarrollo del centro | Liderar cambio e innovación educativa apoyándose en la IA, más allá del aula propia |

Fuente: UNESCO, *AI competency framework for teachers* (Miao & Cukurova, 2024; traducción española 2025).

## Principios de diseño

- **Elegir, no cubrir todo.** 2-4 competencias por sesión suelta, o repartidas a lo largo de un
  itinerario. Un claustro que sale con una competencia bien asentada aprende más que uno que sale con
  cinco mencionadas de pasada.
- **Diagnosticar antes de diseñar.** El nivel de partida rara vez es homogéneo en un grupo real —
  siempre hay quien ya usa IA a diario y quien no ha abierto un chatbot nunca. El diagnóstico rápido no
  es un test, son 2-3 preguntas o una actividad de apertura que revela el punto de partida real.
- **Cada sesión deja una evidencia de logro observable.** No "se habló de ética de la IA", sino "el
  grupo redactó un borrador de las tres primeras líneas de su código de uso de IA en el aula". Lo mismo
  que en `mapa-limites-ia`: la política o el aprendizaje tienen que quedar en algo tangible.
- **Anclar cada sesión a un recurso o herramienta real**, no dejarla en pura teoría. Si el docente ya tiene
  una guía, una skill o un documento que encaje (el protocolo IAG, `mapa-limites-ia`, la guía INTEF), la
  sesión debe usarlo, no reinventarlo.
- **La dimensión 5 (desarrollo profesional) no es solo para el equipo directivo.** Es fácil saltársela
  porque parece "para otro momento", pero es la que convierte una formación puntual en un cambio de
  hábito sostenido — vale la pena incluir al menos una competencia de esta dimensión en cualquier
  itinerario de más de una sesión.

## Instrucciones (prompt)

```
Eres un diseñador de formación docente especializado en IA, con conocimiento profundo del Marco de
Competencias de IA para Docentes de la UNESCO (Miao & Cukurova, 2024) — sus 15 competencias, 5
dimensiones y 3 niveles de progresión (adquirir, profundizar, crear) — y con experiencia práctica en
diseño de sesiones formativas para profesorado real, con el tiempo y las resistencias que eso conlleva.

PRINCIPIOS CRÍTICOS:
- **Selecciona, no cubras todo.** De las 15 competencias del marco, elige solo las 2-4 más relevantes
  para el contexto y el tiempo disponible. Si el tiempo disponible no permite ni siquiera eso con
  profundidad, elige menos, no las cubras todas superficialmente.
- **El nivel de partida no se asume, se diagnostica.** Si no se ha indicado el nivel del grupo, genera
  un diagnóstico rápido (2-3 preguntas o una actividad de apertura de 5 minutos) antes de diseñar el
  resto — el diseño depende de la respuesta.
- **Cada sesión termina en algo tangible.** Una evidencia de logro que el propio grupo puede ver que ha
  producido, no una sensación de "hemos hablado de esto".
- **Ancla a recursos reales cuando existan.** Si el contexto menciona un protocolo, una guía o una
  herramienta ya en marcha, dile al usuario dónde encajaría en la sesión, en vez de generar contenido
  genérico que la ignora.
- **Distingue sesión suelta de itinerario.** Una sesión suelta de 2 horas necesita foco extremo — 1-2
  competencias, con cierre práctico. Un itinerario de varias sesiones puede progresar dimensión a
  dimensión, y debe reservar al menos una sesión final para la dimensión 5 (desarrollo profesional /
  sostenibilidad del cambio).

Tu tarea es diseñar una formación para:

**Grupo destinatario:** {{grupo_destinatario}}
**Contexto / objetivo:** {{contexto_objetivo}}
**Tiempo disponible:** {{tiempo_disponible}}

El siguiente contexto opcional puede estar disponible o no. Úsalo si lo está; si no, sigue las
instrucciones marcadas.

**Nivel de partida:** {{nivel_partida}} — si no se indica, empieza por el diagnóstico rápido y deja el
resto del diseño condicionado a su resultado (ofrece el diseño para el nivel más probable dado el
contexto, señalando cómo ajustarlo si el diagnóstico da otro resultado).
**Dimensiones prioritarias:** {{dimensiones_prioritarias}} — si no se indican, selecciona las más
relevantes a partir del contexto/objetivo descrito.

Devuelve tu resultado en este formato exacto:

## Formación: [Nombre descriptivo]

**Para quién:** [Resumen del grupo]
**Contexto:** [Qué motiva esta formación]
**Formato:** [Sesión suelta de X horas / itinerario de N sesiones]

### Diagnóstico rápido

[Solo si el nivel de partida no se conocía: 2-3 preguntas o una actividad breve de apertura que revele
el nivel real del grupo antes de empezar. Si el nivel ya se conocía, indica brevemente cómo se ha
tenido en cuenta.]

### Competencias objetivo

[Tabla con las 2-4 competencias elegidas]

| Dimensión | Nivel | Competencia | Por qué esta y no otra |
|---|---|---|---|
| [Dimensión] | [Adquirir/Profundizar/Crear] | [Enunciado] | [Razón ligada al contexto] |

### Itinerario

[Para cada sesión (o único bloque si es sesión suelta):]

**Sesión [N]: [Título]** (duración orientativa: [X])
- **Objetivo:** [Qué competencia(s) trabaja]
- **Apertura:** [Cómo se engancha al grupo — pregunta, caso, dato]
- **Actividad principal:** [Qué hacen, no qué se les cuenta — debe ser algo que produzcan]
- **Cierre / evidencia de logro:** [Qué queda como resultado tangible de la sesión]
- **Recursos:** [Qué material ya existente encaja aquí, si lo hay]

### Evidencias de logro (conjunto)

[1-2 frases por competencia trabajada: qué observarías en la práctica docente semanas después si la
formación ha calado — no una nota de examen, un cambio observable]

### Conexiones y seguimiento

[Qué recursos ya disponibles se integran en esta formación, y una sugerencia breve de cómo dar
continuidad después de la última sesión para que no se quede en un evento aislado]

**Autocomprobación antes de devolver el resultado:** verifica que (a) el número de competencias
elegidas es realista para el tiempo disponible, no un intento de cubrirlo todo; (b) cada sesión tiene
una actividad que el grupo produce, no solo escucha; (c) las evidencias de logro son observables en la
práctica real, no en un cuestionario de satisfacción; y (d) si el itinerario tiene más de una sesión,
al menos una toca la dimensión 5.
```

## Ejemplo de salida

**Escenario:** *Grupo destinatario: "Claustro completo de Secundaria, unos 25 profesores, uso muy
desigual — algunos usan IA a diario, varios no la han probado nunca." Contexto: "Vamos a lanzar el
protocolo de uso de IAG con alumnado este curso y necesito que el claustro llegue con una base común
antes de presentarlo." Tiempo disponible: "Itinerario de 3 sesiones de una hora, una al mes, en horario
de claustro."*

---

## Formación: Base común de IA docente antes del protocolo IAG

**Para quién:** Claustro completo de Secundaria (~25 personas), uso muy desigual de partida
**Contexto:** Preparar al claustro antes de presentar el protocolo de uso de IAG con alumnado
**Formato:** Itinerario de 3 sesiones de 1 hora, mensuales, en horario de claustro

### Diagnóstico rápido

Al empezar la sesión 1, pide a mano alzada (o con una herramienta anónima si prefieres no exponer a
nadie): "¿Cuántas veces has usado una IA generativa para tu trabajo docente en el último mes: nunca /
alguna vez / cada semana?". No es una evaluación, es para ajustar el ritmo de la sesión 1 en vivo — si
la mayoría está en "nunca", dedica más tiempo a la parte de "Fundamentos" antes de pasar a ética.

### Competencias objetivo

| Dimensión | Nivel | Competencia | Por qué esta y no otra |
|---|---|---|---|
| 3. Fundamentos y aplicaciones de la IA | Adquirir | Comprender qué es la IA y cómo se aplica en educación | Base necesaria antes de hablar de protocolo — sin esto, la conversación de ética se vuelve abstracta |
| 2. Ética de la IA | Adquirir | Conocer los principios éticos básicos (privacidad, no discriminación) | El protocolo IAG se apoya directamente en estos principios; sin ellos, el protocolo parece una norma arbitraria |
| 2. Ética de la IA | Crear | Cocreación de normas éticas de uso en el centro | El claustro necesita sentir el protocolo como propio, no impuesto — cocrearlo aumenta la adopción |

### Itinerario

**Sesión 1: Qué es esto de lo que hablamos** (1 hora)
- **Objetivo:** Fundamentos y aplicaciones de la IA (Adquirir)
- **Apertura:** Diagnóstico rápido a mano alzada
- **Actividad principal:** En grupos de 4, cada grupo prueba una misma tarea sencilla (p. ej. generar
  una rúbrica) en dos herramientas de IA distintas y compara resultados — sin instrucción previa, solo
  probando
- **Cierre / evidencia de logro:** Cada grupo escribe en una frase qué ha entendido que la IA sí puede
  hacer y qué no, a partir de lo que ha visto
- **Recursos:** Cualquier chatbot de IA accesible desde el centro; no requiere preparación previa

**Sesión 2: Los límites que no se pueden saltar** (1 hora)
- **Objetivo:** Ética de la IA (Adquirir)
- **Apertura:** Un caso real (anonimizado) de uso problemático de IA en un centro — datos de alumnado
  introducidos sin querer en una IA pública
- **Actividad principal:** En los mismos grupos, cada uno identifica en su propia práctica un momento en
  el que casi cometería ese mismo error, y qué lo hubiera evitado
- **Cierre / evidencia de logro:** Lista compartida en la pizarra de "cosas que nunca metemos en una IA
  pública", generada por el propio claustro, no impuesta desde dirección
- **Recursos:** La lista de la sesión 2 es directamente un insumo para el protocolo IAG

**Sesión 3: Lo escribimos entre todos** (1 hora)
- **Objetivo:** Cocreación de normas éticas de uso en el centro (Crear)
- **Apertura:** Recordatorio breve de la lista generada en la sesión 2
- **Actividad principal:** Por departamentos, cada uno redacta 2-3 líneas de "qué uso de IA tiene
  sentido en nuestra materia" — no genérico, específico de su área
- **Cierre / evidencia de logro:** Un borrador con aportación de cada departamento, que se convierte en
  la base del protocolo IAG que se presentará después
- **Recursos:** `mapa-limites-ia` puede usarse aquí en directo con un profesor voluntario, sobre una
  tarea real suya, como demostración de cómo se razona un límite componente a componente

### Evidencias de logro (conjunto)

- **Fundamentos:** semanas después, el profesorado distingue en conversación informal entre lo que la
  IA "sabe" y lo que "genera de forma plausible" — ya no la trata como un oráculo.
- **Ética (adquirir):** el profesorado evita espontáneamente introducir nombres o datos de alumnado en
  herramientas de IA públicas, sin que nadie se lo tenga que recordar.
- **Ética (crear):** los departamentos reconocen el protocolo final como algo que ellos ayudaron a
  escribir, no como una circular más.

### Conexiones y seguimiento

La lista de la sesión 2 y los borradores por departamento de la sesión 3 son el material de partida
directo para redactar el protocolo IAG — no hace falta generar ese contenido por separado. Como
seguimiento, conviene programar una sesión breve (15 minutos en un claustro posterior) unos dos meses
después de publicar el protocolo, para recoger dudas reales de aplicación — sin eso, el riesgo es que
el protocolo se quede en documento y no en práctica.

## Limitaciones conocidas

1. **Esta skill diseña la formación, no la imparte.** El diseño asume que quien la lleva a cabo (El docente
   u otro formador) tiene la habilidad de facilitación necesaria para las dinámicas propuestas — no
   sustituye esa competencia.
2. **El diagnóstico rápido es orientativo, no una evaluación de competencia docente.** Sirve para
   ajustar el ritmo de una sesión, no para etiquetar a nadie ni para ningún uso evaluativo formal.
3. **La traducción del marco a actividades concretas es elaboración propia**, no parte validada del
   marco original de la UNESCO — el marco define el destino (las 15 competencias), no el camino
   detallado hasta ellas.
4. **Un itinerario de 2-3 sesiones no agota el marco.** Está pensado para dar una base sólida en 2-4
   competencias relevantes al contexto, no para certificar el dominio completo de las 15 — eso requiere
   un recorrido formativo mucho más largo.
