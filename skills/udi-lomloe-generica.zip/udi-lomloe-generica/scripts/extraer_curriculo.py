# -*- coding: utf-8 -*-
"""
Extrae el currículo (versión en castellano) de un decreto autonómico LOMLOE
publicado en PDF y lo guarda como ficheros Markdown, uno por materia.

Uso:
    python extraer_curriculo.py <decreto.pdf> <carpeta_destino> [--idioma castellano]

Pensado para el DECRETO 107/2022 (ESO, Comunitat Valenciana), cuyo Anexo III
contiene el currículo de todas las materias primero en valenciano y después en
castellano. Sirve también para añadir el currículo de Bachillerato
(DECRETO 108/2022) u otros decretos con la misma maquetación: el script localiza
los títulos de materia buscando el epígrafe "1. Presentación" y toma como título
la línea en mayúsculas inmediatamente anterior.

Las tablas del decreto (criterios de evaluación por curso, saberes básicos) se
conservan como tablas Markdown para no mezclar las columnas de cada curso.

Requisitos: pip install pymupdf
"""
import re
import sys
import unicodedata
from pathlib import Path

import pymupdf

RUIDO = re.compile(r"^(Num\.\s*\d+\s*/\s*[\d.]+|\d{4,6})\s*$")
MARCADOR_ES = re.compile(r"^1\.\s*Presentaci[oó]n", re.I)
MARCADOR_VA = re.compile(r"^1\.\s*Presentaci[oó]$", re.I)


def slug(texto):
    t = unicodedata.normalize("NFKD", texto).encode("ascii", "ignore").decode()
    t = re.sub(r"[^A-Za-z0-9]+", "-", t).strip("-").lower()
    return t


def limpia(texto):
    lineas = []
    for l in texto.split("\n"):
        l = l.rstrip()
        if RUIDO.match(l.strip()):
            continue
        lineas.append(l)
    texto = "\n".join(lineas)
    texto = re.sub(r"\n{3,}", "\n\n", texto)
    return texto.strip()


def tabla_markdown(tabla):
    """Convierte una tabla detectada por PyMuPDF en una tabla Markdown."""
    filas = []
    for fila in tabla.extract():
        celdas = [re.sub(r"\s+", " ", (c or "")).strip().replace("|", "/") for c in fila]
        if any(celdas):
            filas.append(celdas)
    if not filas:
        return ""
    ancho = max(len(f) for f in filas)
    filas = [f + [""] * (ancho - len(f)) for f in filas]
    cabecera, cuerpo = filas[0], filas[1:]
    out = ["| " + " | ".join(cabecera) + " |",
           "|" + "|".join([" --- "] * ancho) + "|"]
    out += ["| " + " | ".join(f) + " |" for f in cuerpo]
    return "\n".join(out)


def contenido_pagina(pagina):
    """Texto de la página conservando las tablas en su posición original."""
    try:
        tablas = list(pagina.find_tables().tables)
    except Exception:
        tablas = []
    cajas = [pymupdf.Rect(t.bbox) for t in tablas]
    piezas = []
    for b in pagina.get_text("blocks"):
        x0, y0, x1, y1, texto = b[0], b[1], b[2], b[3], b[4]
        centro = pymupdf.Point((x0 + x1) / 2, (y0 + y1) / 2)
        if any(c.contains(centro) for c in cajas):
            continue
        piezas.append((y0, limpia(texto)))
    for t, caja in zip(tablas, cajas):
        md = tabla_markdown(t)
        if md:
            piezas.append((caja.y0, md))
    piezas.sort(key=lambda x: x[0])
    return "\n\n".join(p for _, p in piezas if p).strip()


def localiza_materias(paginas, marcador):
    """Devuelve [(titulo, pagina_inicio_0based), ...] en orden de aparición."""
    encontradas = []
    for i, t in enumerate(paginas):
        lineas = [l.strip() for l in t.split("\n")]
        for j, l in enumerate(lineas):
            es_marcador = bool(marcador.match(l))
            # A veces la numeración y el epígrafe caen en líneas distintas
            if not es_marcador and l in ("1.", "1") and j + 1 < len(lineas):
                es_marcador = bool(marcador.match("1. " + lineas[j + 1].strip()))
            if not es_marcador:
                continue
            k = j - 1
            while k >= 0 and (not lineas[k] or lineas[k].isdigit() or RUIDO.match(lineas[k])):
                k -= 1
            if k < 0:
                continue
            titulo = lineas[k]
            if titulo.upper() == titulo and 3 <= len(titulo) <= 70:
                encontradas.append((titulo.strip(), i))
    limpio = []
    for titulo, pag in encontradas:
        if limpio and limpio[-1][0] == titulo:
            continue
        limpio.append((titulo, pag))
    return limpio


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    pdf = Path(sys.argv[1])
    destino = Path(sys.argv[2])
    idioma = "castellano"
    if "--idioma" in sys.argv:
        idioma = sys.argv[sys.argv.index("--idioma") + 1]
    marcador = MARCADOR_VA if idioma.startswith("val") else MARCADOR_ES

    destino.mkdir(parents=True, exist_ok=True)
    doc = pymupdf.open(pdf)
    paginas = [doc[i].get_text() for i in range(doc.page_count)]

    materias = localiza_materias(paginas, marcador)
    if not materias:
        print("No se han localizado materias. Revisa el PDF o el idioma.")
        sys.exit(2)

    fin_documento = len(paginas)
    ultima = materias[-1][1]
    for i in range(ultima + 1, len(paginas)):
        if re.search(r"(Annex|Anexo)\s+[IVX]+", paginas[i]):
            fin_documento = i
            break

    indice = []
    for n, (titulo, ini) in enumerate(materias):
        fin = materias[n + 1][1] if n + 1 < len(materias) else fin_documento
        cuerpo = "\n\n".join(contenido_pagina(doc[p]) for p in range(ini, fin))
        nombre = slug(titulo) + ".md"
        (destino / nombre).write_text(
            "# " + titulo + "\n\n"
            "> Fuente: " + pdf.name + ", páginas " + str(ini + 1) + "-" + str(fin) +
            " (versión en " + idioma + ").\n\n" + cuerpo + "\n",
            encoding="utf-8",
        )
        indice.append((titulo, nombre, fin - ini))
        print(titulo.ljust(55) + " -> " + nombre + " (" + str(fin - ini) + " pág.)")

    lineas = ["# Índice de materias con currículo disponible", ""]
    lineas += ["- **" + t + "** — `" + f + "` (" + str(p) + " páginas del decreto)"
               for t, f, p in indice]
    (destino / "INDICE.md").write_text("\n".join(lineas) + "\n", encoding="utf-8")
    print("\n" + str(len(indice)) + " materias escritas en " + str(destino))


if __name__ == "__main__":
    main()
