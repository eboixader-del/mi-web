# Copia (o actualiza) la habilidad en la carpeta de habilidades personales de Claude Code.
# Uso:  powershell -ExecutionPolicy Bypass -File scripts\instalar.ps1

$origen  = Split-Path -Parent $PSScriptRoot
$destino = Join-Path $env:USERPROFILE ".claude\skills\udi-lomloe-generica"

New-Item -ItemType Directory -Force (Split-Path -Parent $destino) | Out-Null
if (Test-Path $destino) { Remove-Item $destino -Recurse -Force }
Copy-Item -Recurse -Force $origen $destino

Write-Host "Habilidad instalada en: $destino"
Write-Host "Reinicia Claude Code para que la detecte."
