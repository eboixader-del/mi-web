# Cómo obtener el currículo correcto

Las competencias específicas, los criterios de evaluación y los saberes básicos **cambian según la
comunidad autónoma** y no pueden inventarse: son texto normativo que el docente va a incorporar a un
documento oficial. Esta habilidad no incluye ningún currículo autonómico concreto, así que hay que
resolver la fuente al principio del proceso.

## Qué está incluido y qué no

| Elemento | Disponible aquí | Ámbito |
| --- | --- | --- |
| Competencias clave y descriptores operativos del Perfil de salida | Sí, `perfil-de-salida.md` | Estatal (RD 217/2022), idéntico en toda España |
| Objetivos generales de etapa de ESO | Sí, `objetivos-etapa.md` | Estatal, con notas sobre notación y lengua propia |
| Competencias específicas por materia | **No** | Autonómico |
| Criterios de evaluación por curso | **No** | Autonómico |
| Saberes básicos y sus bloques | **No** | Autonómico |
| Currículo de Bachillerato | **No** | Autonómico (RD 243/2022) |

## Qué preguntar al docente (Fase 1)

Junto a la etapa y la materia, pregunta:

> ¿En qué comunidad autónoma trabajas? Y si tienes a mano el decreto de currículo (o la programación
> del departamento con las competencias específicas y los criterios de evaluación de la materia),
> adjúntalo: así cito el texto literal en vez de una redacción aproximada.

## Opciones, de mejor a peor

1. **El docente adjunta el decreto en PDF.** Extrae el currículo por materias:

   ```bash
   python scripts/extraer_curriculo.py DECRETO.pdf references/curriculo-<comunidad>
   ```

   El script localiza cada materia por el epígrafe «1. Presentación», guarda un `.md` por materia
   conservando las tablas de criterios (una columna por curso) y escribe un `INDICE.md`. Está
   probado con decretos con la maquetación habitual del boletín autonómico; si no detecta materias,
   avisa en lugar de inventar.

2. **El docente adjunta solo su programación de departamento o las páginas de su materia.** Trabaja
   directamente sobre ese documento: es la fuente que su centro considera válida.

3. **No hay documento.** Entonces:
   - Usa el **Real Decreto 217/2022** (ESO) o **243/2022** (Bachillerato) como referencia: los
     saberes básicos y criterios autonómicos parten de ellos, aunque cada comunidad los reordena,
     numera y amplía.
   - **Avisa explícitamente** al docente, con una frase como: «He redactado las competencias
     específicas y los criterios a partir del currículo estatal; antes de entregar el documento,
     compruébalos con el decreto de tu comunidad, porque la numeración y la redacción pueden
     cambiar».
   - Nunca presentes esa redacción como cita literal del decreto autonómico.

## Coherencia interna

Sea cual sea la fuente:

- Los criterios de evaluación deben ser **los del curso** que se programa, no los de otro curso de la
  misma materia.
- Cada criterio se cita con su numeración original (`1.2`, `3.4`…) y se mantiene el código de la
  competencia específica (`CE1`, `CE3`…) tal como aparece en la fuente.
- Los saberes básicos se citan indicando su bloque (`Bloque A`, `Bloque 2`, según la fuente).
- Si el currículo indica, junto a cada competencia específica, los descriptores del Perfil de salida
  que desarrolla, **úsalo**: es la vinculación oficial y evita cruces arbitrarios.
