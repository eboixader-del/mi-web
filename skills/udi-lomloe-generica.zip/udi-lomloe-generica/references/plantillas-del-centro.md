# Trabajar con la plantilla del centro

Esta habilidad no lleva plantillas dentro: usa **la del centro del docente**. Este documento explica
cómo pedirla, analizarla y rellenarla sin romper su formato.

## 1. Cuándo y cómo pedirla

Menciónala como opcional en la **Fase 1** («si tu centro tiene plantillas propias, puedes
adjuntarlas ahora o más adelante») y pídela **en firme al iniciar la Fase 4**, cuando ya está
acordado todo el contenido. Pídela así:

> Para volcar la UDI en el formato de tu centro necesito la plantilla. Adjúntala, a ser posible en
> **.docx** (Word), que es el formato que permite rellenarla conservando el diseño. Si solo la
> tienes en PDF o en papel, mándala igualmente: la reproduzco lo más fielmente que pueda, aunque el
> resultado no será idéntico. Si tu centro no tiene plantilla propia, dímelo y uso un formato
> estándar de concreción curricular y transposición didáctica.

Si el centro usa **dos documentos separados** (concreción curricular y transposición didáctica),
pídelos los dos. Si usa uno solo con todo, se trabaja igual.

## 2. Analizar la plantilla

```bash
python scripts/analizar_plantilla.py "PLANTILLA DEL CENTRO.docx"
```

Imprime la orientación y márgenes, el texto de la cabecera, y para cada tabla el contenido de todas
las celdas con sus coordenadas `[tabla, fila, columna]`, su color de fondo y las combinaciones de
celdas. Lee ese mapa con atención antes de escribir nada:

- Las celdas con texto (`ETAPA:`, `CRITERIOS DE EVALUACIÓN`, `MATERIALES`…) son **rótulos de la
  plantilla**: no se borran.
- Las celdas `VACÍA` son las casillas a rellenar.
- `= combinada con [t,f,c]` indica que esa posición pertenece a otra celda: escribe en la
  coordenada de origen, no en la combinada.

Con un PDF, el script genera una imagen por página: **ábrelas** para ver el diseño real y decidir si
puedes reproducirlo o si conviene pedir el .docx.

## 3. Preparar la estructura si no cuadra el número de bloques

Las plantillas suelen traer un número fijo de bloques (p. ej. 8 competencias específicas o 20
actividades). Casi siempre **sobran**, y basta con dejarlos vacíos o eliminarlos. Si **faltan**, se
duplican. Ambas cosas se hacen desde el mismo fichero de mapeo:

```jsonc
"duplicar_tablas": [ {"tabla": 1, "veces": 2},              // dos bloques más iguales al 1
                     {"tablas": [1, 2], "veces": 3} ],      // bloque de tablas contiguas
"duplicar_filas":  [ {"tabla": 1, "fila": 3, "veces": 2} ], // dos filas de criterio más
"eliminar_tablas": [7, 8],
"eliminar_filas":  [ {"tabla": 2, "filas": [5, 6]} ],
"eliminar_tablas_sin_escribir": true                        // limpia los bloques no usados
```

Muchas plantillas construyen **cada bloque con dos tablas seguidas** (por ejemplo, la de la
actividad y la de sesiones/escenarios/materiales). En ese caso usa `"tablas": [1, 2]`: se duplican
juntas y en el orden correcto. Con `"tabla": 1` duplicarías solo la mitad del bloque.

`"eliminar_tablas_sin_escribir": true` borra al final **todas las tablas en las que el mapeo no haya
escrito nada**: es la forma cómoda de quitar los bloques sobrantes sin llevar la cuenta de índices.
Ojo: si una tabla debe conservarse tal cual (una fila de firma, por ejemplo), escríbele algo o no
uses esta opción.

Cuidado con los índices: **al duplicar, las tablas posteriores se renumeran**. Cuando haya
duplicaciones, lo más seguro es trabajar en dos pasos:

```bash
python scripts/rellenar_plantilla.py mapeo.json --solo-estructura
python scripts/analizar_plantilla.py salida_intermedia.docx    # coordenadas definitivas
```

## 4. Rellenar

```bash
python scripts/rellenar_plantilla.py mapeo.json
```

Escribe en el documento original (sobre una copia; la plantilla no se toca) respetando tipografía,
colores y márgenes del centro. Modos de escritura:

| Modo | Efecto | Cuándo |
| --- | --- | --- |
| `reemplazar` (defecto) | Vacía la celda y escribe | Casillas vacías |
| `misma_linea` | Añade el texto detrás de lo que ya hay | Rótulos tipo `ETAPA:`, `CURSO:` |
| `anexar` | Añade párrafos debajo | Casillas con un encabezado que se conserva |

El script avisa si sobrescribe una celda que tenía texto: **revisa siempre esos avisos**, porque
suelen indicar que se ha borrado un rótulo de la plantilla por error.

## 5. Comprobar el resultado

Repasa la salida del script (celdas escritas y avisos) y vuelve a analizar el documento generado si
hay dudas. Después entrega al docente la ruta del fichero e indícale qué casillas han quedado
vacías a propósito (por ejemplo, las que debe firmar o fechar el departamento).

## 6. Si no hay plantilla, o solo hay PDF

```bash
python scripts/generar_udi_generico.py datos_udi.json carpeta_salida
```

Produce dos documentos en A4 apaisado con una maquetación estándar (cabecera, tabla de concreción
por competencia específica y secuencia de actividades). Admite el logotipo y el nombre del centro:

```jsonc
"centro": { "nombre": "IES Ejemplo", "logo": "ruta/al/logo.png" }
```

Si el docente tenía la plantilla en PDF, puedes acercarte a su diseño ajustando este generador
(colores y títulos están al principio del script), pero **dile con claridad que el resultado es una
reproducción**, no su documento oficial, y ofrécele pedir el .docx a su jefatura de estudios.

## 7. Reutilizar el mapeo

El fichero de mapeo es específico de cada plantilla, no de cada UDI: las coordenadas no cambian.
Guárdalo y ofrécelo al docente («guarda este `mapeo-plantilla.json`: la próxima UDI se vuelca en
segundos»). Para la siguiente unidad basta con cambiar los textos.
