# Objetivos Generales de Etapa (OGE) — ESO

> Fuente: artículo 7 del Real Decreto 217/2022, en la redacción del DECRETO 107/2022 del Consell
> (Comunitat Valenciana), del que se extrajo este texto.

En la casilla **OGE** de la plantilla de concreción curricular se anotan los objetivos de etapa a
los que contribuye cada competencia específica trabajada en la UDI. Selecciona solo los que la
unidad desarrolla de verdad (habitualmente 2-4 por competencia).

> **Diferencias entre comunidades.** Los catorce objetivos son los mismos en todo el Estado, pero:
> - El Real Decreto 217/2022 los enumera con **letras (a-n)** y muchos decretos autonómicos y
>   plantillas de centro mantienen esa notación; otros los numeran del 1 al 14, como aquí. Pregunta
>   al docente qué notación usa su plantilla (`OGE a` / `OGE 1`) y respétala.
> - El objetivo 8 (h) aparece adaptado en las comunidades con lengua cooficial: la redacción de
>   abajo menciona el valenciano como lengua propia. En el resto, el enunciado se refiere solo a la
>   lengua castellana y, en su caso, a la lengua cooficial correspondiente.
>
> Si el docente necesita literalidad para un documento oficial, pídele el decreto de currículo de su
> comunidad y cita desde ahí.

*La educación secundaria obligatoria contribuirá a desarrollar en el alumnado las capacidades que le permitan:*

**OGE 1.** Asumir responsablemente sus deberes, conocer y ejercer sus derechos en el respeto a los otros, practicar la tolerancia, la cooperación y la solidaridad entre las personas y grupos, ejercitarse en el diálogo afianzando los derechos humanos como valores comunes de una sociedad plural y prepararse para el ejercicio de la ciudadanía democrática.

**OGE 2.** Desarrollar y consolidar hábitos de disciplina, estudio y trabajo individual y en equipo como condición necesaria para una realización eficaz de las tareas del aprendizaje y como medio de desarrollo personal.

**OGE 3.** Valorar y respetar las diferencias de géneros y la igualdad de derechos y oportunidades entre ellos. Rechazar los estereotipos que suponen discriminación entre hombres y mujeres.

**OGE 4.** Fortalecer sus capacidades afectivas en todos los ámbitos de la personalidad y en sus relaciones con los otros, así como rechazar la violencia, los prejuicios de cualquier tipo, los comportamientos sexistas y resolver pacíficamente los conflictos.

**OGE 5.** Desarrollar destrezas básicas en la utilización de las fuentes de información para, con sentido crítico, adquirir nuevos conocimientos. Desarrollar las competencias tecnológicas básicas y avanzar en una reflexión ética sobre su funcionamiento y utilización.

**OGE 6.** Concebir el conocimiento científico como un saber integrado, que se estructura en diferentes disciplinas, así como conocer y aplicar los métodos para identificar los problemas en los diversos campos del conocimiento y de la experiencia.

**OGE 7.** Desarrollar el espíritu emprendedor y la confianza en sí mismo, la participación, el sentido crítico, la iniciativa personal y la capacidad para aprender a aprender, planificar, tomar decisiones y asumir responsabilidades.

**OGE 8.** Comprender y expresar con corrección, oralmente y por escrito, en las lenguas oficiales, el valenciano como lengua propia y el castellano como lengua cooficial, textos y mensajes complejos, e iniciarse en el conocimiento, la lectura y el estudio de la literatura.

**OGE 9.** Comprender y expresarse en una o más lenguas extranjeras de manera apropiada.

**OGE 10.** Conocer, valorar y respetar los aspectos básicos de la cultura y la historia propias y de los demás, incluyendo las lenguas familiares, así como el patrimonio artístico y cultural, como muestra del multilingüismo y de la multiculturalidad del mundo, que también se tiene que valorar y respetar.

**OGE 11.** Conocer y aceptar el funcionamiento del propio cuerpo y el de los demás, respetar las diferencias, afianzar los hábitos de atención y salud corporales e incorporar la educación física y la práctica del deporte para favorecer el desarrollo personal y social. Conocer y valorar la dimensión humana de la sexualidad en toda su diversidad.

**OGE 12.** Valorar críticamente los hábitos sociales relacionados con la salud, el consumo, el cuidado, la empatía y el respeto hacia los seres vivos, especialmente los animales, y el medio ambiente, y contribuir así a su conservación y mejora.

**OGE 13.** Apreciar la creación artística y comprender el lenguaje de las diferentes manifestaciones artísticas, utilizando varios medios de expresión y representación.

**OGE 14.** Tomar conciencia de las problemáticas que tiene planteadas la humanidad y que se concretan en los Objetivos de Desarrollo Sostenible.

## Nota para Bachillerato

Los objetivos de etapa de Bachillerato son los del artículo 7 del Real Decreto 243/2022 (letras
a-n), recogidos en el decreto de currículo de cada comunidad. No están en esta base de conocimiento:
para una UDI de Bachillerato, pide al docente el artículo de su decreto autonómico o confirma con él
la numeración y redacción que usa su plantilla antes de rellenar la casilla OGE.
