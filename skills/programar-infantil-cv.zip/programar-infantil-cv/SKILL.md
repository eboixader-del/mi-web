---
name: programar-infantil-cv
description: Coordina la elaboración de una programación didáctica de ciclo/nivel del segundo ciclo de Educación Infantil en la Comunitat Valenciana, desde el currículo hasta la evaluación y la secuenciación de situaciones de aprendizaje, conforme al Decreto 100/2022.
---

# Programar en el segundo ciclo de Educación Infantil (Comunitat Valenciana)

## Marco normativo de referencia
- Real Decreto 95/2022, de 1 de febrero (ordenación y enseñanzas mínimas de Educación Infantil, marco estatal).
- Decreto 100/2022, de 29 de julio, del Consell, por el que se establece la ordenación y el currículo de Educación Infantil en la Comunitat Valenciana.
- Instrucciones de inicio de curso vigentes cada año. No se ha localizado, a fecha de esta skill, una orden autonómica de "procedimientos" específica para Infantil: si el centro cita una, pide su referencia exacta antes de aplicarla.
- Proyecto Educativo de Centro (PEC) y concreción curricular: la programación debe ajustarse a lo fijado por el centro (Comisión de Coordinación Pedagógica / equipo de ciclo), sin duplicarlo.

Este marco está verificado a fecha de esta skill (curso 2025-2026). Verifica siempre la instrucción de inicio de curso vigente antes de aplicar un plazo o procedimiento concreto.

## Currículo de referencia
La etapa se organiza en tres áreas de desarrollo y aprendizaje, no en materias aisladas, con un enfoque globalizado: **Crecimiento en Armonía**, **Descubrimiento y Exploración del Entorno**, y **Comunicación y Representación de la Realidad**. El currículo se trabaja preferentemente a través de situaciones de aprendizaje que integran varias áreas a la vez, no de unidades por área separadas.

## Entradas
Pide al docente: nivel (3, 4 o 5 años), currículo oficial de las tres áreas (criterios de evaluación no acreditativos, orientadores del progreso), concreción curricular o programación anterior del centro si existe, perfil de grupo, y acuerdos de ciclo sobre metodología y evaluación. Empieza con lo disponible; marca como pendiente lo que falte.

## Procedimiento
1. **Currículo.** Localiza los criterios de evaluación (orientadores, no acreditativos) de las tres áreas para el nivel, y su relación entre sí — en Infantil casi cualquier situación de aprendizaje toca las tres áreas a la vez.
2. **Evaluación.** Aplica la skill disenar-evaluacion-infantil-cv para fijar cómo se observa y documenta el progreso, y cómo se informa a las familias.
3. **Situaciones de aprendizaje.** Organiza el curso en situaciones de aprendizaje globalizadas (proyectos, rincones, talleres, rutinas) secuenciadas a lo largo del curso, relacionando cada una con las tres áreas que trabaja.
4. **Redacción.** Integra los apartados habituales de una programación de ciclo/nivel de Infantil: contextualización y marco normativo; contribución de las áreas al desarrollo integral; criterios de evaluación por área y nivel; secuenciación de situaciones de aprendizaje; metodología (organización de espacios, tiempos, rutinas, agrupamientos); recursos y materiales; medidas de atención a la diversidad y detección temprana; procedimientos de observación y evaluación, y de comunicación a las familias; actividades complementarias; procedimiento de evaluación de la propia programación y de la práctica docente.
5. **Revisión.** Aplica la skill auditar-programacion-infantil-cv sobre el borrador. Corrige lo detectado y deja explícitos los pendientes que dependan de acuerdos de ciclo o del centro.
6. Entrega la programación diferenciando lo confirmado, lo propuesto y lo pendiente.

## Límites
No inventes acuerdos de ciclo ni normativa. No conviertas los criterios de evaluación de Infantil en una calificación acreditativa: en esta etapa no existe calificación numérica ni aprobado/suspenso. Cuando falte un dato de centro, declara pendiente.
