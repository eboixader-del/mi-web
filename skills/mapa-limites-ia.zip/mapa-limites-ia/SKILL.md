---
name: mapa-limites-ia
description: Analiza una tarea o actividad, componente a componente, para determinar en cuáles ayuda la IA generativa y en cuáles estropea el aprendizaje. Úsala cuando el docente quiera rediseñar una tarea para la era de la IA, definir una política de uso de IA defendible para una actividad concreta, o avanzar en el protocolo de uso de IAG con alumnado, aunque no lo pida con estas palabras exactas.
disable-model-invocation: false
user-invocable: true
effort: medium
skill_id: ai-literacy/mapa-limites-ia
skill_name: Mapa de Límites de Uso de IA
domain: alfabetizacion-ia
version: "1.0"
contributor: Gareth Manning (original en inglés, CC BY-SA 4.0)
adaptado_por: traducción y adaptación al castellano
fuente_original: https://github.com/GarethManning/education-agent-skills/blob/main/skills/ai-literacy/ai-learning-boundary-mapper/SKILL.md
licencia: CC BY-SA 4.0 — mantiene la atribución al autor original
evidence_strength: moderada
evidence_sources:
  - "Wiggins & McTighe (2005) — Understanding by Design (diseño inverso y alineación de la evaluación)"
  - "Bjork et al. (2013) — Self-regulated learning: beliefs, techniques, and illusions"
  - "Kazemitabaar et al. (2023) — Studying the effect of AI code generators on supporting novice learners"
  - "Kirschner, Sweller & Clark (2006) — Why minimal guidance during instruction does not work"
  - "Wineburg & McGrew (2019) — Lateral reading and the nature of expertise"
  - "UNESCO, Miao & Holmes (2023) — Guidance for Generative AI in Education and Research (marco normativo internacional)"
  - "INTEF (2024) — Guía sobre el uso de la inteligencia artificial en el ámbito educativo, Ministerio de Educación, FP y Deportes (marco normativo España)"
  - "UNESCO, Miao, Shiohira & Lao (2024) — AI competency framework for students (taxonomía de competencias del alumnado)"
  - "UNESCO, Miao & Cukurova (2024, trad. española 2025) — Marco de competencias de IA para docentes (taxonomía de competencias docentes)"
input_schema:
  requerido:
    - descripcion_tarea: "La actividad tal como está planteada — qué deben hacer, producir o demostrar los alumnos"
    - objetivos_aprendizaje: "Qué destrezas, conocimientos o disposiciones desarrolla la tarea"
  opcional:
    - politica_ia_actual: "Qué uso de la IA está actualmente permitido, restringido o sin definir"
    - nivel_alumnado: "Curso / edad"
    - area: "La materia o disciplina"
    - contexto_evaluacion: "Formativa, sumativa, preparación de examen, portfolio..."
    - comparar_herramientas: "Si se incluye también una comparación buscador vs. chatbot de IA para las partes de búsqueda de información"
output_schema:
  - analisis_por_objetivo: "Para cada objetivo de aprendizaje, si la IA lo apoya o lo socava, con el razonamiento"
  - mapa_de_componentes: "Análisis componente a componente de la tarea: IA-beneficiosa, IA-neutra, IA-perjudicial, con modificaciones sugeridas"
  - recomendaciones_politica_ia: "Recomendaciones concretas de uso de IA para esta tarea — no un permitir/prohibir general, sino guía por componente"
  - comparacion_herramientas: "Cuándo usar buscador vs. IA para las partes de búsqueda de información"
  - sugerencias_rediseno: "Modificaciones concretas de la tarea que preservan el reto en los componentes críticos para el aprendizaje, permitiendo IA donde de verdad ayuda"
chains_well_with:
  - metacognitive-monitoring-ai-contexts
  - backwards-design-unit-planner
  - assessment-validity-checker
teacher_time: 5 minutos
tags: [alfabetizacion-ia, diseno-de-tareas, politica-ia, diseno-inverso, seleccion-de-herramientas, objetivos-de-aprendizaje, limites-ia, unesco, intef]
---

# Mapa de Límites de Uso de IA

## Qué hace esta skill

Genera un análisis componente a componente de una tarea concreta, señalando qué elementos se benefician de la ayuda de la IA, cuáles son neutros y cuáles se ven perjudicados por su intervención — todo ello a partir de los objetivos de aprendizaje que persigue la tarea.

Es la herramienta de diseño, pensada para el profesorado, para rediseñar actividades en la era de la IA: toma una tarea ya existente y produce un mapa de límites que permite fijar políticas de uso de IA específicas y defendibles, en lugar de posiciones genéricas de "IA permitida" o "IA prohibida".

La idea central: dentro de una misma tarea, distintos componentes sirven a distintos objetivos de aprendizaje — y la ayuda de la IA que resulta útil para uno puede socavar otro. Un ensayo que exige tanto investigación (la IA puede ayudar a resumir el contexto) como argumentación original (la ayuda de la IA aquí evita el trabajo cognitivo de construir un argumento) se beneficia de una política a nivel de componente, no de una política uniforme.

La salida incluye: un análisis por objetivo (para cada objetivo de aprendizaje, si la ayuda de la IA lo apoya o lo socava), un mapa de componentes, recomendaciones de política de IA defendibles, una comparación opcional buscador-vs-IA para las tareas de búsqueda de información, y sugerencias de rediseño que preservan el reto en los componentes críticos para el aprendizaje mientras permiten IA donde realmente ayuda.

Esta skill es el complemento, en el lado del diseño docente, de `metacognitive-monitoring-ai-contexts`: el mapa de límites previene que aparezca el riesgo metacognitivo; la otra skill lo aborda cuando ya ha aparecido.

## Fundamento de evidencia

Wiggins & McTighe (2005) establecieron el principio del diseño inverso (*backward design*): el diseño de la evaluación debe partir de los objetivos de aprendizaje (fase 1) y retroceder a través de las evidencias de aprendizaje (fase 2) hasta llegar a las actividades de aprendizaje (fase 3). Este principio se aplica directamente a la fijación de límites de IA: la pregunta no es "¿debería usarse IA en esta tarea?" sino "¿a qué objetivos de aprendizaje sirve esta tarea, y la ayuda de la IA apoya o evita el trabajo cognitivo que esos objetivos requieren?"

Bjork et al. (2013) documentaron las "ilusiones de competencia" — situaciones en las que el alumnado siente que ha aprendido más de lo que realmente ha aprendido. La ayuda de la IA produce esta ilusión de fluidez: las tareas completadas con ayuda de IA parecen completas y correctas, pero se ha evitado el trabajo cognitivo que genera aprendizaje duradero. El mapa de límites está pensado para identificar qué componentes de la tarea son más vulnerables a este efecto.

Kazemitabaar et al. (2023) aportaron evidencia empírica directa: el alumnado que programaba con ayuda de IA completaba las tareas más rápido y con menos errores, pero mostraba una comprensión más débil en tareas posteriores sin esa ayuda. Este efecto se usa aquí como modelo para identificar los componentes "IA-perjudiciales": cualquier tarea en la que el proceso cognitivo (no solo el producto) sea el objetivo de aprendizaje.

Kirschner, Sweller & Clark (2006) establecieron que la instrucción con guía mínima produce un aprendizaje más débil que la instrucción explícita en el caso de los novatos, porque el alumnado novel necesita el reto cognitivo de la propia tarea para construir las estructuras de conocimiento necesarias para llegar a ser experto. Esto respalda identificar los componentes en los que eliminar el reto cognitivo (mediante IA) también elimina el aprendizaje.

Wineburg & McGrew (2019) aportan un respaldo indirecto a la dimensión de comparación de herramientas: distintas herramientas de información tienen propiedades epistémicas distintas (citas verificables frente a inferencia sintetizada), y el alumnado se beneficia de una orientación explícita sobre qué herramienta usar para cada necesidad de información.

## Marco normativo de referencia (España e internacional)

La ciencia del aprendizaje de más arriba responde a **dónde** está la línea cognitiva (qué componente
construye conocimiento y cuál no). Pero una política de aula defendible también tiene que encajar con
el marco normativo y ético ya establecido — algo especialmente relevante para un protocolo de centro,
que tendrá que sostenerse ante dirección, inspección o familias. Esta skill incorpora dos referencias:

- **UNESCO (2023), *Guidance for Generative AI in Education and Research*** (Miao & Holmes): primera
  guía global de la UNESCO sobre IA generativa en educación. Parte de un enfoque humanista y centrado
  en la persona, y pide a los sistemas educativos regular con medidas como: proteger la agencia humana
  y las interacciones interpersonales significativas, proteger la privacidad de los datos del alumnado,
  fijar una edad mínima para el uso autónomo de estas herramientas sin supervisión, desarrollar la
  competencia en IA del alumnado y del profesorado, y validar localmente cualquier herramienta antes de
  su adopción en el aula. El principio de que la IA debe *aumentar*, no sustituir, el papel del docente
  conecta directamente con la lógica de "componente por componente" de esta skill: no se trata de
  prohibir o permitir en bloque, sino de decidir dónde la IA amplía la capacidad del alumnado y dónde la
  sustituye.
- **INTEF (2024), *Guía sobre el uso de la inteligencia artificial en el ámbito educativo*** (Ministerio
  de Educación, Formación Profesional y Deportes): la referencia oficial española, dirigida a tres
  perfiles — alumnado, docentes y centro educativo/administración —, con un decálogo de buen uso (sesgo
  algorítmico, *deepfakes*, dependencia tecnológica) y un anexo de buenas prácticas. Aporta el lenguaje y
  la estructura que reconocerá cualquier equipo directivo o inspección en España, y es coherente con el
  enfoque de la UNESCO en el que se apoya.
- **UNESCO (2024), *Marco de competencias de IA para estudiantes*** (Miao, Shiohira & Lao): define qué
  debe saber y saber hacer el alumnado en materia de IA, en 4 dimensiones (mentalidad centrada en el ser
  humano, ética de la IA, fundamentos y aplicaciones de la IA, diseño de sistemas de IA) y 3 niveles
  (comprender, aplicar, crear). El "análisis por objetivo" y el "mapa de componentes" de esta skill
  operacionalizan, para una tarea concreta, la pregunta que este marco deja abierta a nivel general: qué
  competencia se está desarrollando y si la IA la apoya o la sustituye.
- **UNESCO (2024, trad. española 2025), *Marco de competencias de IA para docentes*** (Miao & Cukurova):
  el equivalente para profesorado — 15 competencias en 5 dimensiones (mentalidad centrada en el ser
  humano, ética de la IA, fundamentos y aplicaciones de la IA, pedagogía de la IA, IA para el aprendizaje
  profesional) y 3 niveles (adquirir, profundizar, crear). Diseñar mapas de límites como los que produce
  esta skill es, en los términos de este marco, un ejercicio de la competencia de "pedagogía de la IA" en
  el nivel profundizar/crear.

**Aviso de terminología:** estos dos marcos de la UNESCO usan una taxonomía distinta de la del informe
AILit (OCDE/Comisión Europea, 2026) que también manejamos en esta conversación — dominios y niveles con
nombres distintos, aunque relacionados. Esta skill no depende de ninguna de las dos taxonomías en
concreto (usa su propio lenguaje de IA-beneficiosa/neutra/perjudicial), pero si vas a citar varios marcos
en el mismo documento (por ejemplo, el protocolo IAG), conviene no mezclar sus términos como si fueran
intercambiables.

Esta skill no sustituye la lectura de ambos documentos, pero asegura que cada política de aula que
genera es coherente con sus principios: protección de datos del alumnado (no introducir datos
personales o trabajos identificables de menores en herramientas de IA sin las garantías adecuadas),
transparencia (explicitar qué uso de IA se permite y por qué, no solo restringirlo sin explicación), y
equidad (considerar el impacto de la política en el alumnado con menos acceso a apoyo fuera del aula).

## Esquema de entrada

El profesorado debe aportar:

- **Descripción de la tarea:** Qué hacen los alumnos. *Ej.: "4º ESO, Historia: ensayo argumentativo de 600 palabras sobre si el Tratado de Versalles fue la causa principal de la II Guerra Mundial, usando al menos tres historiadores citados" / "3º ESO, Física y Química: informe de laboratorio de la práctica de velocidad de reacción — método, resultados, análisis, conclusión" / "2º Bachillerato, Lengua: comentario comparativo de dos textos trabajados en clase"*
- **Objetivos de aprendizaje:** Qué desarrolla la tarea. *Ej.: "El alumnado aprende a construir un argumento histórico basado en evidencias, evaluar interpretaciones historiográficas contrapuestas y usar la evidencia documental de forma apropiada" / "El alumnado aprende a redactar un análisis científico a partir de datos recogidos por ellos mismos, extrayendo conclusiones válidas"*

Opcional (si está disponible):

- **Política de IA actual:** qué está permitido ahora mismo
- **Nivel del alumnado:** curso
- **Área:** la materia
- **Contexto de evaluación:** formativa, sumativa, preparación de examen
- **Comparación de herramientas:** si se incluye orientación buscador vs. IA

## Instrucciones (prompt)

```
Eres un experto en diseño curricular y de evaluación, con conocimiento profundo del diseño inverso de
Wiggins & McTighe (2005), la investigación de Bjork et al. (2013) sobre ilusiones de competencia, los
hallazgos empíricos de Kazemitabaar et al. (2023) sobre ayuda de IA y aprendizaje, los hallazgos de
Kirschner et al. (2006) sobre instrucción con guía mínima, y el trabajo de Wineburg & McGrew (2019)
sobre evaluación de herramientas de información. Entiendes que la pregunta para fijar límites de IA no
es "¿es útil la IA?" sino "¿la ayuda de la IA apoya o evita el trabajo cognitivo concreto que exige esta
tarea?".

PRINCIPIOS CRÍTICOS:
- **El objetivo de aprendizaje es el límite.** Si el objetivo es "el alumnado construirá un argumento",
  entonces un argumento generado por IA evita ese aprendizaje, sea cual sea la calidad del resultado
  final. Si el objetivo es "el alumnado revisará su argumento para mejorar la claridad", la ayuda de la
  IA no evita el aprendizaje — apoya una fase posterior al trabajo cognitivo central.
- **Las políticas de IA generales no están justificadas por este análisis.** La respuesta casi nunca es
  "nada de IA en ningún sitio" ni "IA en todas partes". Dentro de cualquier tarea, algunos componentes
  son IA-beneficiosos, otros IA-neutros, otros IA-perjudiciales. Una política defendible es específica
  por componente.
- **Los componentes de proceso son más vulnerables que los de producto.** La IA perjudica más el
  aprendizaje cuando el PROCESO de hacer la tarea es el objetivo de aprendizaje. Investigar, redactar
  un borrador, analizar datos, plantear un problema — son objetivos de proceso. Formatear, corregir
  ortografía, dar formato a las citas — son objetivos de producto, donde la ayuda de la IA suele ser
  neutra.
- **La novedad y la transferencia son los indicadores clave.** La IA es más perjudicial cuando el
  alumnado está construyendo estructuras de conocimiento nuevas o practicando la transferencia del
  aprendizaje a una situación nueva. Es menos perjudicial en tareas rutinarias o administrativas. El
  mapa de límites debe identificar qué componentes construyen conocimiento y cuáles no.
- **La comparación de herramientas importa.** Para las tareas de búsqueda de información, los
  buscadores (citas verificables, información actualizada) y los chatbots de IA (inferencia
  sintetizada, sin atribución clara, con fecha de corte del entrenamiento) tienen propiedades
  epistémicas fundamentalmente distintas. Al alumnado se le debe orientar explícitamente hacia la
  herramienta adecuada para cada necesidad de información.
- **La política también debe encajar con el marco normativo (UNESCO 2023, INTEF 2024).** Además de la
  justificación cognitiva, toda política de componente debe respetar: (a) protección de datos — no
  recomendar introducir datos personales o trabajos identificables de menores en herramientas de IA sin
  garantías; (b) transparencia — la política debe explicar el porqué, no solo el permitir/restringir,
  en lenguaje que el alumnado entienda; (c) equidad — señalar si una restricción puede perjudicar más al
  alumnado con menos apoyo fuera del aula; (d) agencia humana — el rol del profesorado no se sustituye,
  se apoya.

Tu tarea es generar un mapa de límites de uso de IA para:

**Descripción de la tarea:** {{descripcion_tarea}}
**Objetivos de aprendizaje:** {{objetivos_aprendizaje}}

El siguiente contexto opcional puede estar disponible o no. Usa lo que haya; ignora los campos marcados
como "no proporcionado".

**Política de IA actual:** {{politica_ia_actual}} — si no se indica, asume que no hay política formal.
**Nivel del alumnado:** {{nivel_alumnado}} — si no se indica, diseña para un contexto general de
secundaria.
**Área:** {{area}} — si no se indica, infiérela a partir de la tarea.
**Contexto de evaluación:** {{contexto_evaluacion}} — si no se indica, trátalo como una tarea de
evaluación formativa.
**Comparación de herramientas:** {{comparar_herramientas}} — si no se indica, inclúyela si la tarea
tiene un componente de investigación o búsqueda de información.

Devuelve tu resultado en este formato exacto:

## Mapa de Límites de Uso de IA: [Nombre de la tarea]

**Tarea:** [Descripción breve]
**Objetivos de aprendizaje clave:** [Lista]
**Contexto de evaluación:** [Cómo se evalúa]

### Análisis por objetivo

[Para cada objetivo de aprendizaje, un párrafo analizando si la ayuda de la IA lo apoya, es neutra o lo
socava — con razonamiento explícito desde el principio del diseño inverso]

| Objetivo de aprendizaje | Impacto de la IA | Razonamiento |
|---|---|---|
| [Objetivo] | Apoya / Neutro / Socava | [Por qué] |

### Mapa de componentes

[Divide la tarea en 4-8 componentes. Para cada uno:]

**Componente [N]: [Nombre]**
- **Qué hace el alumnado:** [Descripción]
- **Sirve al objetivo:** [A qué objetivo de aprendizaje]
- **Límite de IA:** IA-BENEFICIOSA / IA-NEUTRA / IA-PERJUDICIAL
- **Razonamiento:** [Por qué este límite — qué trabajo cognitivo evita o apoya la IA]
- **Política específica:** [Qué uso de IA está permitido o restringido exactamente en este componente]

### Recomendaciones de política de IA

[A partir del análisis por componentes, una política de uso de IA específica y defendible para esta
tarea. No un permitir/prohibir general — orientación por componente en lenguaje claro para el alumnado]

**Enunciado de política recomendado:**
> [El texto exacto que un profesor podría usar en el enunciado de la tarea]

**Justificación de cada restricción:** [Justificación breve, comprensible para el alumnado, de cada
componente restringido — "La IA está restringida aquí porque este componente desarrolla [destreza
concreta] que exige que hagas tú el trabajo cognitivo"]

**Alineación normativa:** [Una nota breve confirmando que la política respeta: protección de datos del
alumnado, transparencia hacia el alumnado y las familias, equidad de acceso, y el papel del docente como
apoyo no sustituido — con referencia a UNESCO (2023) e INTEF (2024) cuando proceda]

### Comparación de herramientas

[Si la tarea tiene componentes de búsqueda de información — o si se ha pedido la comparación:]

**Para [componente de información]: usa [buscador / IA / biblioteca] porque:**
[Orientación sobre qué herramienta usar para cada necesidad de información, con el razonamiento sobre
las propiedades epistémicas de cada una]

| Tarea | Mejor herramienta | Por qué |
|---|---|---|
| [Tarea] | [Herramienta] | [Razón epistémica] |

### Sugerencias de rediseño

[3-5 modificaciones concretas de la tarea que refuerzan el límite entre los componentes asistidos por
IA y los críticos para el aprendizaje, sin cambiar fundamentalmente la tarea]

**Sugerencia [N]: [Nombre]**
- **Diseño actual:** [Qué pide la tarea ahora]
- **Modificación:** [Qué cambiar]
- **Por qué ayuda:** [Cómo esta modificación hace que el componente crítico para el aprendizaje sea más
  resistente a la IA, o que la ayuda de la IA sea más claramente beneficiosa]

**Autocomprobación antes de devolver el resultado:** verifica que (a) el análisis por objetivo es
específico para estos objetivos de aprendizaje, no genérico; (b) cada límite de componente está
justificado con un razonamiento claro desde el principio del diseño inverso; (c) la política es
específica por componente, no general; (d) el enunciado de política está en lenguaje claro y accesible
para el alumnado; y (e) las sugerencias de rediseño son modificaciones prácticas, no reescrituras
completas.
```

## Ejemplo de salida

**Escenario:** *Descripción de la tarea: "4º ESO, Historia: ensayo argumentativo de 600 palabras — ¿fue
el Tratado de Versalles la causa principal de la II Guerra Mundial? Debe usar al menos tres historiadores
citados con su argumento. Entrega la semana que viene." / Objetivos de aprendizaje: "El alumnado
construirá un argumento histórico basado en evidencias; evaluará interpretaciones historiográficas
contrapuestas; seleccionará y usará evidencia documental de forma apropiada; escribirá en el registro
analítico propio del argumento histórico" / Contexto de evaluación: "Sumativa — 30% de la nota de la
unidad"*

---

## Mapa de Límites de Uso de IA: Ensayo argumentativo sobre el Tratado de Versalles

**Tarea:** ensayo argumentativo de 600 palabras sobre si el Tratado de Versalles fue la causa principal
de la II Guerra Mundial
**Objetivos de aprendizaje clave:** construir un argumento histórico; evaluar interpretaciones
historiográficas; usar evidencia documental; escribir en registro analítico
**Contexto de evaluación:** sumativa — 30% de la nota de la unidad

### Análisis por objetivo

| Objetivo de aprendizaje | Impacto de la IA | Razonamiento |
|---|---|---|
| Construir un argumento histórico basado en evidencias | Socava | Si la IA construye el argumento, el alumnado practica leer/editar prosa generada por IA, no argumentación histórica. Se evita el trabajo cognitivo de elegir una postura y construir el respaldo basado en evidencias. Es el objetivo principal — la restricción de IA aquí es la más crítica. |
| Evaluar interpretaciones historiográficas contrapuestas | Socava | Comparar y evaluar a distintos historiadores exige entender ambas posturas, comparar la calidad de sus evidencias y emitir un juicio razonado. Que la IA haga esa comparación evita el trabajo cognitivo de evaluación. |
| Seleccionar y usar evidencia documental | Socava | Que el alumnado elija qué evidencia usar y la sitúe en el argumento es lo que construye conocimiento. Que la IA la seleccione evita esto. Ahora bien: que la IA confirme que existe la obra de un historiador concreto (ayuda bibliográfica) es neutro — el objetivo es el uso de la evidencia, no su localización. |
| Escribir en el registro analítico del argumento histórico | Socava parcialmente | Escribir en un registro nuevo requiere práctica. Sin embargo, usar la IA para mejorar un borrador ya escrito por el alumno (edición de desarrollo) es distinto de usarla para producir el borrador. Lo primero apoya, lo segundo socava. |

### Mapa de componentes

**Componente 1: Investigación — identificar historiadores relevantes y sus argumentos**
- **Qué hace el alumnado:** Investigar quién ha escrito sobre Versalles como causa de la IIGM y cuáles son sus argumentos
- **Sirve al objetivo:** Evaluar interpretaciones historiográficas
- **Límite de IA:** IA-NEUTRA con matices
- **Razonamiento:** Averiguar que un historiador defendió X es una tarea de localización; entender y evaluar ese argumento es la tarea de aprendizaje. La IA puede ayudar con "qué historiadores son relevantes" — pero el alumnado debe leer y entender los argumentos por sí mismo.
- **Política específica:** Puedes usar IA para identificar historiadores relevantes y obtener un resumen breve de sus posturas. Después debes leer al menos una fuente primaria o secundaria de cada historiador que cites.

**Componente 2: Planificar el argumento**
- **Qué hace el alumnado:** Decidir una postura y planificar el caso basado en evidencias
- **Sirve al objetivo:** Construir un argumento histórico
- **Límite de IA:** IA-PERJUDICIAL
- **Razonamiento:** Construir el argumento es el objetivo de aprendizaje central. Que la IA planifique evita el trabajo cognitivo crucial de decidir qué argumentar y cómo respaldarlo.
- **Política específica:** No se permite IA para planificar el argumento. El plan debe estar escrito a mano o elaborado sin ayuda de IA.

**Componente 3: Redactar el ensayo**
- **Qué hace el alumnado:** Escribir el argumento en el registro analítico de la escritura histórica
- **Sirve al objetivo:** Argumento histórico y registro
- **Límite de IA:** IA-PERJUDICIAL
- **Razonamiento:** Aquí ocurre el aprendizaje principal. Escribir es pensar — producir el argumento es producir la comprensión. Que la IA redacte evita esto por completo.
- **Política específica:** Tu borrador debe estar escrito por ti. Compararemos tu borrador con cualquier salida de IA que encontremos en la red.

**Componente 4: Revisar y corregir**
- **Qué hace el alumnado:** Mejorar el borrador — claridad, estructura, solidez del argumento
- **Sirve al objetivo:** Escritura en registro analítico (fase de desarrollo)
- **Límite de IA:** IA-NEUTRA a IA-BENEFICIOSA con condiciones
- **Razonamiento:** Una vez que el alumno tiene un borrador genuino, usar la IA para identificar debilidades en la estructura del argumento o sugerir frases más claras es retroalimentación de desarrollo, no generación del argumento. El pensamiento original sigue siendo del alumno.
- **Política específica:** Una vez tengas un borrador completo escrito por ti, puedes preguntar a la IA: "¿qué debilidades ves en la estructura de mi argumento?" o "¿esta frase es clara?". No le pidas que reescriba fragmentos — pídele que identifique problemas para que tú los corrijas.

**Componente 5: Formato de las citas**
- **Qué hace el alumnado:** Dar formato correcto a las citas
- **Sirve al objetivo:** Ninguno de los objetivos declarados
- **Límite de IA:** IA-BENEFICIOSA
- **Razonamiento:** Dar formato a las citas es una tarea administrativa que no sirve a los objetivos de aprendizaje declarados. La ayuda de la IA aquí ahorra tiempo sin afectar al aprendizaje.
- **Política específica:** Se permite y se anima el uso de herramientas de IA para el formato de citas.

### Recomendaciones de política de IA

**Enunciado de política recomendado:**
> Para este ensayo: puedes usar IA (1) para identificar historiadores relevantes y obtener resúmenes
> breves de sus posturas — pero debes leer al menos una fuente de cada historiador que cites; (2) para
> recibir retroalimentación sobre un borrador que ya has escrito — pregúntale "¿qué falla en mi
> argumento?", no "escríbeme una versión mejor"; (3) para el formato de las citas. NO puedes usar IA
> para planificar tu argumento, producir tu borrador o reescribir fragmentos de tu ensayo. Tu plan debe
> estar escrito a mano. Tu borrador debe estar escrito por ti.

**Justificación de cada restricción:**
- "Sin IA en la planificación: decidir qué argumentar y cómo respaldarlo es la destreza que este ensayo está diseñado para desarrollar. Si lo decide la IA, no la practicas."
- "Sin IA en la redacción: escribir el argumento es cómo construyes el pensamiento histórico que trabaja esta unidad. Si lo escribe la IA, te pierdes el aprendizaje."

**Alineación normativa:** la política no pide al alumnado introducir datos personales en la IA (solo
resúmenes de posturas historiográficas ya públicas), explica el porqué de cada restricción en lugar de
imponerla sin justificación, y mantiene al docente como referencia última en la evaluación del
argumento — coherente con el enfoque centrado en la persona de UNESCO (2023) y con el decálogo de buen
uso de INTEF (2024).

### Comparación de herramientas

| Tarea | Mejor herramienta | Por qué |
|---|---|---|
| Averiguar qué historiadores han escrito sobre Versalles | Buscador (Google Scholar, base de datos de biblioteca) | El buscador da fuentes reales y citables; la IA puede dar historiadores reales pero inventarse artículos concretos |
| Obtener un resumen breve del argumento de un historiador | Chatbot de IA (con verificación) | La IA es útil para resúmenes rápidos, pero hay que verificar el resumen contra una fuente real antes de usarlo |
| Encontrar la fecha de publicación o el título completo de una fuente | Base de datos de biblioteca o web de la editorial | La IA puede dar datos bibliográficos plausibles pero incorrectos; verificar siempre |
| Comprobar si la estructura del argumento es clara | Chatbot de IA | La retroalimentación estructural sobre un borrador ya terminado es un buen uso de la IA |

### Sugerencias de rediseño

**Sugerencia 1: Añadir la entrega de un plan escrito a mano**
- **Diseño actual:** El alumnado entrega el ensayo directamente; no hay fase intermedia
- **Modificación:** Exigir la entrega de un plan del ensayo escrito a mano (argumento + esquema de evidencias) un día antes de la fecha de entrega
- **Por qué ayuda:** Hace detectable la planificación con IA y cambia los incentivos — quien no ha planificado por sí mismo tiene que producir un plan desde cero de todos modos

**Sugerencia 2: Incluir un campo de "justificación del historiador elegido"**
- **Diseño actual:** El alumnado cita historiadores sin explicar por qué los ha elegido
- **Modificación:** Añadir el requisito de, por cada historiador citado, una frase explicando por qué se ha elegido su argumento y qué aporta al caso
- **Por qué ayuda:** Esta frase no puede generarse con IA sin delatar esa intervención — exige que el alumnado articule su propio razonamiento evaluativo

**Sugerencia 3: Sustituir la fase de investigación abierta por un conjunto de fuentes dado**
- **Diseño actual:** El alumnado investiga de forma independiente
- **Modificación:** Proporcionar 4-5 extractos de historiadores con los que trabajar — no pueden usar historiadores fuera de ese conjunto
- **Por qué ayuda:** Elimina por completo la fase de investigación (reduciendo ahí el riesgo de IA) y concentra todo el tiempo de aprendizaje en la argumentación y la evaluación con un conjunto de fuentes definido

---

## Limitaciones conocidas

1. **Esta skill analiza el diseño de la tarea, no el comportamiento del alumnado.** Una política de IA
   defendible no impide el uso de IA — deja clara la razón de aprendizaje detrás de los límites, cambia
   la estructura de incentivos, y da al profesorado una base fundamentada para la detección y la
   retroalimentación. El alumnado decidido a usar IA en todo el proceso puede seguir haciéndolo.

2. **La detección de IA no es fiable.** Las herramientas que dicen detectar texto generado por IA
   tienen tasas altas de falsos positivos y falsos negativos. Las recomendaciones de límites no deberían
   depender de una detección fiable — deben diseñarse para que el uso de IA sea, o bien genuinamente
   inofensivo, o bien visible desde el punto de vista educativo.

3. **Fijar límites tiene implicaciones de equidad.** El alumnado que no puede permitirse clases
   particulares puede recurrir a la IA como andamiaje cognitivo de forma parecida a como lo haría con
   clases particulares costosas — una restricción uniforme de la IA puede perjudicar
   desproporcionadamente a este alumnado. El profesorado debería considerar si los componentes
   IA-neutros podrían ser más permisivos para el alumnado con necesidades de apoyo identificadas.

4. **Las aplicaciones de este marco específicas para IA tienen una validación empírica directa
   limitada.** El principio del diseño inverso (Wiggins & McTighe, 2005) y la base de evidencia sobre
   carga cognitiva e ilusiones de competencia están sólidamente respaldados para el diseño del
   aprendizaje en general. Su aplicación específica a la fijación de límites de IA es razonada pero
   novedosa — todavía no hay evidencia empírica sustancial sobre qué tipos de límites de IA preservan
   mejor el aprendizaje mientras permiten un uso útil de la IA.
