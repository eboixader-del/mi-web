---
name: programar-bachillerato-cv
description: Coordina la elaboración de la programación de una materia de 1º o 2º de Bachillerato en la Comunitat Valenciana (propuesta pedagógica de departamento y programación de aula), desde el currículo hasta la evaluación y la secuenciación de situaciones de aprendizaje, conforme al Decreto 108/2022 y su modificación por el Decreto 103/2026.
---

# Programar una materia de Bachillerato en la Comunitat Valenciana

## Marco normativo de referencia (verificado a septiembre de 2026, curso 2026-2027)
- **Real Decreto 243/2022, de 5 de abril**, de ordenación y enseñanzas mínimas del Bachillerato (BOE-A-2022-5521): marco estatal.
- **Decreto 108/2022, de 5 de agosto, del Consell**, por el que se establecen la ordenación y el currículo de Bachillerato (DOGV núm. 9404, de 12.08.2022; con corrección de errores en DOGV de 07.11.2022).
- **Decreto 103/2026, de 26 de junio, del Consell** (DOGV núm. 10396, de 02.07.2026), que modifica el Decreto 108/2022. Se aplica a **1º desde el curso 2026-2027** y a **2º desde 2027-2028**.
- **Orden 19/2023, de 29 de junio**, de la Conselleria de Educación, Cultura y Deporte (DOGV de 04.07.2023), que regula los procedimientos derivados del Decreto 107/2022 (ESO) y del Decreto 108/2022 (Bachillerato), así como la organización del Bachillerato nocturno y a distancia. Vigente, afectada por el Decreto 66/2024, de 21 de junio.
- **Resolución de 15 de julio de 2026** (DOGV de 17.07.2026, signatura 2026/24443): instrucciones de organización y funcionamiento para ESO y Bachillerato en el curso 2026-2027.
- Proyecto Educativo de Centro y concreción curricular: la programación se ajusta a ellos sin duplicarlos.

Dos avisos de precisión, importantes:
- El **Decreto 66/2024, de 21 de junio**, modifica el Decreto 107/2022 (ESO) y la Orden 19/2023; **no modifica el Decreto 108/2022**. Afecta a Bachillerato solo de forma indirecta, a través de la Orden.
- Existe un **Decreto 103/2026 de Cataluña, de 7 de julio** (DOGC de 09.07.2026), que modifica el Decreto 171/2022 catalán. No lo confundas con el valenciano, que es **de 26 de junio** y se publicó en el DOGV el 02.07.2026.

## Qué cambió el Decreto 103/2026 (y qué no)
Modifica los artículos 9, 16, 19, 21.6, 22, 23.4, 26.5, 46 y 47.3 y las disposiciones adicionales 1ª y 3ª, y reescribe los anexos II, III, IV, V, VI y XII. En concreto: sustituye la optativa "Programación, Redes y Sistemas Informáticos I y II" por **"Informática I y II"**, crea la optativa **"Unión Europea"**, adapta la enseñanza de lenguas a la Ley 1/2024, y establece que las calificaciones de las enseñanzas de religión **no computan en la nota media a efectos de acceso a la universidad ni para la obtención de becas**.

Ojo: **sí toca los horarios**, porque los anexos IV, V y XII son los de distribución horaria (de la etapa, del bachillerato por bloques en tres cursos y del régimen de adultos, nocturno y a distancia). No repitas la idea de que "solo cambia currículo y optativas".

**No modifica** los artículos de evaluación y promoción (39 a 45), permanencia (49), titulación (50 y 51) ni matrícula de honor (53), ni las modalidades y vías del artículo 10. Para esos aspectos rige el Decreto 108/2022. No atribuyas al Decreto 103/2026 cambios que no hizo.

## Terminología: qué documento estás elaborando
La normativa valenciana de Bachillerato **no usa "programación didáctica" como documento de departamento**. Usa dos figuras distintas, y conviene no mezclarlas. Ambas tienen contenido mínimo normativo:

**Propuesta pedagógica de departamento** (art. 22 del Decreto 108/2022, en la redacción dada por el Decreto 103/2026), que se integra en la concreción curricular del centro, la cual aprueba y evalúa el claustro; las instrucciones de inicio de curso la sitúan en el Plan de actuación para la mejora de la PGA. El art. 22.5 exige que concrete:
- los elementos del currículo establecidos para cada materia en los **anexos II y III**, para planificar la acción educativa;
- los **instrumentos de recogida de información** sobre el nivel de logro del alumnado;
- los **criterios de calificación cualitativa y cuantitativa**;
- las **medidas de respuesta educativa para la inclusión**.

**Programación de aula** (art. 23.4, en la redacción dada por el Decreto 103/2026), que debe incluir: **situaciones de aprendizaje, criterios de evaluación, espacios, distribución temporal, recursos, medidas de inclusión e instrumentos de evaluación**.

Si el docente dice "programación didáctica" (uso coloquial extendido), pregúntale cuál de los dos documentos necesita, o cuál es la plantilla de su centro, antes de estructurar nada.

Lo que la normativa valenciana **no** fija es la **estructura de apartados y epígrafes** de estos documentos: eso lo decide cada centro. Así que exige el contenido del art. 22.5 y del art. 23.4, pero no impongas un índice concreto como si fuera obligatorio ni lo atribuyas a la Orden 19/2023 o a las instrucciones de inicio de curso. Si el centro tiene plantilla propia, úsala; si no, ofrece una estructura de trabajo diciendo que es práctica habitual, no exigencia normativa.

## Entradas
Pide al docente: curso (1º o 2º), materia y modalidad, currículo oficial de la materia (competencias específicas, criterios de evaluación y saberes básicos del anexo II en su redacción vigente), plantilla o concreción curricular del centro, programación anterior si la hay, perfil de grupo y acuerdos de departamento sobre evaluación. Empieza con lo disponible y marca como pendiente lo que falte.

## Procedimiento
1. **Currículo.** Localiza competencias específicas, criterios de evaluación y saberes básicos literales de la materia. Para 1º en 2026-2027 usa el anexo II **en la redacción del Decreto 103/2026**; para 2º, la redacción anterior hasta 2027-2028. Comprueba también si la materia es de las que cambiaron de denominación (Informática I y II) o son nuevas (Unión Europea).
2. **Evaluación.** Aplica la skill disenar-evaluacion-bachillerato-cv para calificación, promoción, recuperación y titulación.
3. **Situaciones de aprendizaje.** Secuencia el curso en situaciones de aprendizaje, relacionando cada una con las competencias específicas y los criterios de evaluación que trabaja, y reparte la carga horaria de la materia.
4. **Redacción.** Vuelca el trabajo en la plantilla del centro. Si vas a redactar la programación de aula, cubre los siete elementos del art. 23.4. Si es la propuesta pedagógica de departamento, cubre los cuatro bloques del art. 22.5 y acuerda con el docente la estructura de apartados, que la norma no fija.
5. **Revisión.** Aplica la skill auditar-programacion-bachillerato-cv antes de entregar y deja explícitos los pendientes que dependan del departamento o del centro.
6. Entrega diferenciando lo confirmado, lo propuesto y lo pendiente; no presentes una propuesta tuya como acuerdo ya tomado.

## Límites
No cites artículos concretos de la Orden 19/2023: su articulado no está verificado en esta skill. No entrecomilles articulado del Decreto 108/2022 salvo que lo tengas delante. No inventes acuerdos de departamento, calendario de evaluaciones ni normativa; cuando falte un dato de centro, decláralo pendiente.
