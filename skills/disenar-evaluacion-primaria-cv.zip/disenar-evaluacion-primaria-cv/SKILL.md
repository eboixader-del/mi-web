---
name: disenar-evaluacion-primaria-cv
description: Diseña el sistema de evaluación de un área de Educación Primaria en la Comunitat Valenciana (instrumentos por criterio de evaluación, calificación e informes competenciales) conforme a la normativa de evaluación y promoción vigente.
---

# Diseñar la evaluación de un área de Educación Primaria

## Normativa de referencia
- Real Decreto 984/2021 (marco estatal de evaluación, promoción) y Resolución de 20 de abril de 2022 que lo concreta en la Comunitat Valenciana.
- Decreto 106/2022 (currículo de Primaria en la Comunitat Valenciana).
- Instrucciones de inicio de curso vigentes cada año.

Puntos fijados por la normativa que debes respetar, no reinterpretar (verifícalos contra la instrucción del curso vigente antes de aplicarlos):
- La evaluación es continua y global; toma como referente principal los criterios de evaluación de cada área.
- El equipo docente realiza la evaluación final de manera colegiada en una única sesión al terminar el curso.
- Se emiten informes de aprendizaje/competenciales al finalizar 2º, 4º y 6º curso (documentos 1, 2 y 3 de la etapa).
- La decisión de promoción o repetición de curso solo se adopta al finalizar 2º, 4º y 6º; no se repite en 1º, 3º ni 5º.
- No existe un número fijo de áreas no superadas que impida promocionar: la decisión la adopta el equipo docente de forma colegiada, considerando el grado de adquisición de las competencias.
- Máximo una repetición en toda la etapa de Primaria (y máximo dos repeticiones combinando Primaria y ESO).

## Lo que decide el centro/ciclo, no la normativa
La normativa no fija instrumentos concretos ni la ponderación entre criterios de evaluación de una misma competencia específica: eso lo decide el equipo de ciclo/centro y debe quedar reflejado en la programación. No lo inventes; pide el acuerdo o propónlo explícitamente como pendiente de validar.

## Procedimiento
1. Recupera los criterios de evaluación literales del curso y área, agrupados por competencia específica.
2. Define, para cada criterio de evaluación, qué instrumento(s) lo evalúan; especifica cómo se combinan las competencias específicas en la valoración final del área.
3. Describe cómo se refuerzan los aprendizajes no adquiridos durante el curso (no existe convocatoria de recuperación como en ESO; es refuerzo continuo).
4. Redacta cómo se comunican al alumnado y a las familias los resultados de cada evaluación, y cómo se integran con los informes de 2º/4º/6º cuando corresponda.
5. Añade el apartado de evaluación de la propia programación y de la práctica docente.
6. Comprueba coherencia: todos los criterios de evaluación del curso quedan cubiertos por al menos un instrumento; las medidas de refuerzo están vinculadas a criterios concretos, no a valoraciones genéricas.

## Límites
No inventes una regla de promoción más estricta o más laxa que la vigente (por ejemplo, un número máximo de áreas no superadas). No inventes acuerdos de ponderación de ciclo si no existen: márcalos como propuesta.
